#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
石器时代脚本网络稳定性优化工具 - 示例脚本
展示如何在实际脚本中使用优化工具
"""

import time
import random
from datetime import datetime
from 石器时代脚本网络稳定性优化工具 import NetworkStabilityOptimizer, ASSAScriptOptimizer

def example_ng25_quest_script():
    """NG25跑环脚本示例"""
    print("=" * 60)
    print("NG25跑环脚本 - 网络稳定性优化示例")
    print("=" * 60)
    
    # 1. 创建优化器
    optimizer = NetworkStabilityOptimizer(script_name="NG25自动跑环脚本")
    optimizer.script_state.total_steps = 15
    
    # 2. 配置优化器（针对NG25网络特点）
    optimizer.config.update({
        "max_retries": 5,           # NG25网络波动大，增加重试次数
        "retry_delay_base_ms": 2000, # 基础等待时间加长
        "retry_delay_max_ms": 15000, # 最大等待时间
        "poor_network_threshold_ms": 150,  # NG25网络阈值调整
        "enable_position_verification": True  # NG25需要位置验证
    })
    
    # 3. 创建ASSA优化器
    assa_optimizer = ASSAScriptOptimizer(optimizer)
    
    # 4. 启动网络监控
    print("🚀 启动网络监控...")
    optimizer.start_monitoring()
    
    # 5. 模拟跑环任务
    print("\n🎮 开始执行跑环任务...")
    
    # 任务1: 渔村接任务
    print("\n📝 任务1: 渔村接任务")
    tasks = [
        ("走到村长家", lambda: assa_optimizer._optimize_walk_command(89, 51, "渔村")),
        ("与村长对话", lambda: assa_optimizer._optimize_talk_command("村长", 0)),
        ("接受跑环任务", lambda: assa_optimizer._optimize_click_command(300, 200, "left")),
        ("确认任务", lambda: assa_optimizer._optimize_input_command("接受"))
    ]
    
    for task_name, task_func in tasks:
        print(f"  → {task_name}")
        success = task_func()
        if not success:
            print(f"  ⚠️ {task_name}失败，尝试恢复...")
            # 尝试恢复机制
            time.sleep(2)
            task_func()  # 重试一次
    
    # 任务2: 收集材料
    print("\n📝 任务2: 收集材料")
    materials = [
        ("木料", 120, 80),
        ("石料", 150, 90),
        ("铁矿", 180, 120)
    ]
    
    for material_name, x, y in materials:
        print(f"  → 收集{material_name}")
        
        # 走到材料点
        assa_optimizer._optimize_walk_command(x, y, "渔村外围")
        
        # 采集材料（模拟网络波动）
        def collect_material():
            # 模拟采集过程中的网络波动
            if random.random() < 0.3:  # 30%概率模拟网络问题
                raise ConnectionError("采集时网络波动")
            print(f"    ✓ 成功采集{material_name}")
            return True
        
        success = optimizer.execute_with_retry(
            operation=collect_material,
            operation_name=f"采集{material_name}",
            max_retries=3
        )
        
        if success:
            print(f"    ✅ {material_name}收集完成")
        else:
            print(f"    ⚠️ {material_name}收集失败，跳过")
    
    # 任务3: 交付任务
    print("\n📝 任务3: 交付任务")
    delivery_tasks = [
        ("返回渔村", lambda: assa_optimizer._optimize_walk_command(89, 51, "渔村")),
        ("与村长对话", lambda: assa_optimizer._optimize_talk_command("村长", 1)),
        ("交付材料", lambda: assa_optimizer._optimize_click_command(350, 250, "left")),
        ("确认交付", lambda: assa_optimizer._optimize_input_command("交付完成")),
        ("领取奖励", lambda: assa_optimizer._optimize_click_command(400, 300, "left"))
    ]
    
    for task_name, task_func in delivery_tasks:
        print(f"  → {task_name}")
        task_func()
    
    # 6. 停止监控并生成报告
    print("\n📊 任务执行完成，生成报告...")
    optimizer.stop_monitoring()
    
    report = optimizer.get_performance_report()
    
    # 显示关键指标
    print(f"\n📈 执行统计:")
    print(f"  完成步骤: {report['script_info']['current_step']}/{report['script_info']['total_steps']}")
    print(f"  成功率: {report['script_info'].get('success_rate', 0):.1f}%")
    print(f"  错误次数: {report['script_info']['error_count']}")
    print(f"  重试次数: {report['performance_stats']['total_retries']}")
    
    print(f"\n🌐 网络质量:")
    status_emoji = {
        "excellent": "✅",
        "good": "👍",
        "fair": "⚠️",
        "poor": "🔶",
        "bad": "🔴"
    }
    emoji = status_emoji.get(report['network_status'], "❓")
    print(f"  状态: {emoji} {report['network_status']}")
    print(f"  平均延迟: {report['performance_stats']['avg_latency_ms']:.1f}ms")
    
    print(f"\n💡 优化建议:")
    for i, rec in enumerate(report['recommendations'][:3], 1):
        print(f"  {i}. {rec}")
    
    # 7. 保存执行状态
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    state_file = f"NG25跑环脚本状态_{timestamp}.json"
    optimizer.save_state(state_file)
    print(f"\n💾 脚本状态已保存: {state_file}")
    
    print("\n✅ NG25跑环脚本示例执行完成!")
    return optimizer

def example_network_stress_test():
    """网络压力测试示例"""
    print("\n" + "=" * 60)
    print("网络压力测试 - 模拟极端网络条件")
    print("=" * 60)
    
    optimizer = NetworkStabilityOptimizer(script_name="网络压力测试")
    
    # 模拟各种网络条件
    network_conditions = [
        ("优秀网络", 30, 0.5),
        ("良好网络", 80, 2),
        ("一般网络", 150, 4),
        ("差网络", 300, 8),
        ("很差网络", 800, 15),
        ("断开连接", 2000, 50)
    ]
    
    print("\n🌐 测试不同网络条件下的优化效果:")
    
    results = []
    for condition_name, latency, packet_loss in network_conditions:
        print(f"\n测试: {condition_name}")
        print(f"  模拟延迟: {latency}ms, 丢包率: {packet_loss}%")
        
        # 模拟网络条件
        metrics = type('Metrics', (), {
            'latency_ms': latency,
            'packet_loss_percent': packet_loss,
            'jitter_ms': latency * 0.2,
            'bandwidth_kbps': 1000
        })()
        
        optimizer.update_network_status(metrics)
        
        # 测试操作成功率
        def test_operation():
            # 模拟操作失败概率
            fail_probability = packet_loss / 100 * 2  # 丢包率影响失败概率
            if random.random() < fail_probability:
                raise ConnectionError(f"模拟网络问题: {condition_name}")
            return True
        
        success_count = 0
        for i in range(5):  # 测试5次
            success = optimizer.execute_with_retry(
                operation=test_operation,
                operation_name=f"测试操作{i+1}",
                max_retries=2
            )
            if success:
                success_count += 1
        
        success_rate = (success_count / 5) * 100
        results.append((condition_name, success_rate))
        
        print(f"  成功率: {success_rate:.1f}%")
    
    # 显示测试结果
    print("\n📊 压力测试结果汇总:")
    print("=" * 40)
    for condition_name, success_rate in results:
        rating = "✅" if success_rate >= 80 else "⚠️" if success_rate >= 50 else "❌"
        print(f"  {rating} {condition_name}: {success_rate:.1f}%")
    
    print("\n📈 结论:")
    print("  1. 优秀到一般网络: 优化器能保持高成功率")
    print("  2. 差网络: 需要多次重试，但能完成大部分操作")
    print("  3. 很差网络: 成功率显著下降，建议暂停脚本")
    print("  4. 断开连接: 自动等待恢复机制生效")
    
    return results

def example_custom_optimization_rules():
    """自定义优化规则示例"""
    print("\n" + "=" * 60)
    print("自定义优化规则 - 针对特定场景")
    print("=" * 60)
    
    optimizer = NetworkStabilityOptimizer(script_name="自定义规则测试")
    
    # 示例1: NG25特定时间优化规则
    print("\n📝 示例1: NG25高峰时段优化")
    
    def ng25_peak_hour_condition(metrics, state):
        # NG25高峰时段（晚上8-10点）网络压力大
        current_hour = datetime.now().hour
        return 20 <= current_hour <= 22 and metrics.latency_ms > 100
    
    def ng25_peak_hour_action():
        print("  ⏰ NG25高峰时段，增加等待时间")
        time.sleep(3)  # 额外等待3秒
        return "WAIT"
    
    # 示例2: 特定地图优化规则
    print("\n📝 示例2: 渔村地图优化")
    
    def fishing_village_condition(metrics, state):
        # 渔村地图玩家密集，需要特殊处理
        return state.script_name == "渔村任务" and metrics.packet_loss_percent > 3
    
    def fishing_village_action():
        print("  🎣 渔村地图玩家密集，使用备用路径")
        return "FALLBACK"
    
    # 示例3: 连续成功奖励规则
    print("\n📝 示例3: 连续成功奖励机制")
    
    def consecutive_success_condition(metrics, state):
        # 连续10次成功，减少等待时间作为奖励
        return state.current_step >= 10 and state.error_count == 0
    
    def consecutive_success_action():
        print("  🎉 连续成功，减少等待时间")
        return "OPTIMIZE"
    
    print("\n✅ 自定义规则示例完成")
    print("💡 提示: 可以根据实际游戏场景创建更多定制规则")
    
    return [
        ("NG25高峰时段", ng25_peak_hour_condition, ng25_peak_hour_action),
        ("渔村地图", fishing_village_condition, fishing_village_action),
        ("连续成功", consecutive_success_condition, consecutive_success_action)
    ]

def example_integration_with_existing_tools():
    """与现有工具集成示例"""
    print("\n" + "=" * 60)
    print("工具集成示例 - 构建完整开发工作流")
    print("=" * 60)
    
    print("\n🛠️ 完整石器时代脚本开发工作流:")
    
    workflow = [
        ("1. 📝 脚本编写", "使用ASSA脚本编辑器"),
        ("2. 🔧 网络优化", "使用本工具进行稳定性优化"),
        ("3. 🐛 脚本调试", "使用石器时代脚本调试器"),
        ("4. 🧪 自动化测试", "使用自动化测试框架"),
        ("5. 📊 性能分析", "使用性能分析工具"),
        ("6. 🔄 持续优化", "基于数据分析持续改进")
    ]
    
    for step_name, tool_name in workflow:
        print(f"  {step_name}: {tool_name}")
    
    print("\n🔗 集成示例代码:")
    
    integration_code = '''
# 集成网络优化器到脚本执行框架
class EnhancedScriptExecutor:
    def __init__(self, script_name):
        self.optimizer = NetworkStabilityOptimizer(script_name)
        self.debugger = ScriptDebugger()  # 假设的调试器
        self.tester = ScriptTester()      # 假设的测试器
        
    def execute_with_full_optimization(self, script_lines):
        # 1. 启动网络监控
        self.optimizer.start_monitoring()
        
        # 2. 执行脚本（带优化）
        for i, line in enumerate(script_lines):
            success = self.optimizer.execute_with_retry(
                operation=lambda: self._execute_assa_command(line),
                operation_name=f"步骤{i+1}"
            )
            
            if not success:
                # 3. 触发调试模式
                self.debugger.analyze_failure(line, self.optimizer.get_performance_report())
                
        # 4. 生成完整报告
        report = self.optimizer.get_performance_report()
        self.tester.record_execution(report)
        
        return report
    '''
    
    print(integration_code)
    
    print("\n🎯 集成优势:")
    print("  ✅ 统一的错误处理和恢复机制")
    print("  ✅ 完整的性能监控和报告")
    print("  ✅ 自动化测试和验证")
    print("  ✅ 持续优化和改进循环")
    
    print("\n✅ 工具集成示例完成")

def main():
    """主演示函数"""
    print("石器时代脚本网络稳定性优化工具 - 完整示例套件")
    print("=" * 60)
    print("展示工具的各种使用场景和高级功能")
    print("=" * 60)
    
    examples = [
        ("NG25跑环脚本示例", example_ng25_quest_script),
        ("网络压力测试", example_network_stress_test),
        ("自定义优化规则", example_custom_optimization_rules),
        ("工具集成示例", example_integration_with_existing_tools)
    ]
    
    while True:
        print("\n📋 示例菜单:")
        for i, (name, _) in enumerate(examples, 1):
            print(f"  {i}. {name}")
        print("  5. 🚪 运行所有示例")
        print("  6. 🏁 退出")
        
        choice = input("\n请选择示例 (1-6): ").strip()
        
        if choice == "1":
            example_ng25_quest_script()
        elif choice == "2":
            example_network_stress_test()
        elif choice == "3":
            example_custom_optimization_rules()
        elif choice == "4":
            example_integration_with_existing_tools()
        elif choice == "5":
            print("\n🚀 开始运行所有示例...")
            for name, func in examples:
                print(f"\n{'='*60}")
                print(f"运行: {name}")
                print(f"{'='*60}")
                try:
                    func()
                    print(f"✅ {name} 完成")
                except Exception as e:
                    print(f"❌ {name} 出错: {str(e)}")
            print("\n🎉 所有示例运行完成!")
        elif choice == "6":
            print("\n👋 感谢使用示例套件!")
            break
        else:
            print("⚠️ 无效选择，请重新输入")
        
        input("\n按Enter键继续...")

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n👋 示例程序被用户中断")
    except Exception as e:
        print(f"\n❌ 示例程序运行出错: {str(e)}")
        import traceback
        traceback.print_exc()