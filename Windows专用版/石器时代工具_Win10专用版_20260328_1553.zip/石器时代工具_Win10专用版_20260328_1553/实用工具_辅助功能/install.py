#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
石器时代验证码识别工具 - 安装脚本
支持一键安装、依赖检查和环境配置
"""

import os
import sys
import subprocess
import platform
import shutil
import json
import time
from pathlib import Path
from typing import Dict, List, Tuple, Optional

class StoneCaptchaInstaller:
    """石器时代验证码识别工具安装器"""
    
    def __init__(self):
        self.project_root = Path(__file__).parent
        self.requirements_file = self.project_root / "requirements.txt"
        self.config_dir = Path.home() / "StoneCaptcha"
        
        # 系统信息
        self.system = platform.system().lower()
        self.is_windows = self.system == 'windows'
        self.is_linux = self.system == 'linux'
        self.is_macos = self.system == 'darwin'
        
        # 安装状态
        self.install_log = []
        self.errors = []
        
        # 颜色输出
        self.colors = {
            'reset': '\033[0m',
            'green': '\033[92m',
            'yellow': '\033[93m',
            'red': '\033[91m',
            'blue': '\033[94m',
            'cyan': '\033[96m'
        }
    
    def print_header(self, text: str):
        """打印标题"""
        print(f"\n{self.colors['cyan']}{'='*60}{self.colors['reset']}")
        print(f"{self.colors['cyan']}{text.center(60)}{self.colors['reset']}")
        print(f"{self.colors['cyan']}{'='*60}{self.colors['reset']}")
    
    def print_success(self, text: str):
        """打印成功信息"""
        print(f"{self.colors['green']}✅ {text}{self.colors['reset']}")
        self.install_log.append(f"✅ {text}")
    
    def print_warning(self, text: str):
        """打印警告信息"""
        print(f"{self.colors['yellow']}⚠️  {text}{self.colors['reset']}")
        self.install_log.append(f"⚠️  {text}")
    
    def print_error(self, text: str):
        """打印错误信息"""
        print(f"{self.colors['red']}❌ {text}{self.colors['reset']}")
        self.install_log.append(f"❌ {text}")
        self.errors.append(text)
    
    def print_info(self, text: str):
        """打印信息"""
        print(f"{self.colors['blue']}ℹ️  {text}{self.colors['reset']}")
        self.install_log.append(f"ℹ️  {text}")
    
    def check_python_version(self) -> bool:
        """检查Python版本"""
        self.print_header("检查Python版本")
        
        version = sys.version_info
        required = (3, 8)
        
        if version.major < required[0] or (version.major == required[0] and version.minor < required[1]):
            self.print_error(f"Python版本过低: {version.major}.{version.minor}.{version.micro}")
            self.print_error(f"需要Python {required[0]}.{required[1]} 或更高版本")
            return False
        
        self.print_success(f"Python版本满足要求: {version.major}.{version.minor}.{version.micro}")
        return True
    
    def check_system_dependencies(self) -> bool:
        """检查系统依赖"""
        self.print_header("检查系统依赖")
        
        missing_deps = []
        
        # 检查Tesseract（可选）
        try:
            if self.is_windows:
                # Windows需要检查Tesseract安装
                tesseract_paths = [
                    r"C:\Program Files\Tesseract-OCR\tesseract.exe",
                    r"C:\Program Files (x86)\Tesseract-OCR\tesseract.exe"
                ]
                tesseract_found = any(os.path.exists(path) for path in tesseract_paths)
            else:
                # Linux/macOS使用which命令
                result = subprocess.run(['which', 'tesseract'], 
                                      capture_output=True, text=True)
                tesseract_found = result.returncode == 0
            
            if tesseract_found:
                self.print_success("Tesseract OCR已安装")
            else:
                self.print_warning("Tesseract OCR未安装（可选）")
                missing_deps.append("Tesseract OCR")
                
        except Exception as e:
            self.print_warning(f"检查Tesseract时出错: {e}")
        
        # 检查OpenCV系统依赖（Linux）
        if self.is_linux:
            try:
                # 检查常见的OpenCV依赖
                libs_to_check = ['libgl1-mesa-glx', 'libsm6', 'libxext6', 'libxrender-dev']
                for lib in libs_to_check:
                    result = subprocess.run(['dpkg', '-l', lib], 
                                          capture_output=True, text=True)
                    if result.returncode != 0:
                        missing_deps.append(lib)
                
                if missing_deps:
                    self.print_warning(f"缺少系统库: {', '.join(missing_deps)}")
                else:
                    self.print_success("系统依赖检查通过")
                    
            except Exception as e:
                self.print_warning(f"检查系统依赖时出错: {e}")
        
        return len(missing_deps) == 0
    
    def install_python_dependencies(self) -> bool:
        """安装Python依赖"""
        self.print_header("安装Python依赖")
        
        if not self.requirements_file.exists():
            self.print_error(f"requirements.txt文件不存在: {self.requirements_file}")
            return False
        
        try:
            # 读取requirements.txt
            with open(self.requirements_file, 'r', encoding='utf-8') as f:
                requirements = [line.strip() for line in f if line.strip() and not line.startswith('#')]
            
            self.print_info(f"找到 {len(requirements)} 个依赖包")
            
            # 安装依赖
            for i, requirement in enumerate(requirements, 1):
                self.print_info(f"安装依赖 ({i}/{len(requirements)}): {requirement}")
                
                try:
                    # 使用pip安装
                    cmd = [sys.executable, "-m", "pip", "install", requirement]
                    result = subprocess.run(cmd, capture_output=True, text=True)
                    
                    if result.returncode == 0:
                        self.print_success(f"安装成功: {requirement}")
                    else:
                        self.print_error(f"安装失败: {requirement}")
                        self.print_error(f"错误信息: {result.stderr}")
                        return False
                        
                except Exception as e:
                    self.print_error(f"安装 {requirement} 时出错: {e}")
                    return False
            
            self.print_success("所有Python依赖安装完成")
            return True
            
        except Exception as e:
            self.print_error(f"安装依赖时出错: {e}")
            return False
    
    def create_config_directory(self) -> bool:
        """创建配置目录"""
        self.print_header("创建配置目录")
        
        try:
            # 创建主配置目录
            self.config_dir.mkdir(parents=True, exist_ok=True)
            
            # 创建子目录
            subdirs = [
                'configs',
                'logs',
                'captchas',
                'templates',
                'backups',
                'test_captchas',
                'benchmark'
            ]
            
            for subdir in subdirs:
                subdir_path = self.config_dir / subdir
                subdir_path.mkdir(exist_ok=True)
                self.print_success(f"创建目录: {subdir_path}")
            
            # 创建默认配置文件
            default_config = {
                'version': '1.0.0',
                'description': '石器时代验证码识别工具配置',
                'game': {
                    'window_title': '石器时代',
                    'check_interval': 5,
                    'captcha_timeout': 30
                },
                'ocr': {
                    'primary_engine': 'tesseract',
                    'fallback_engines': ['easyocr', 'paddleocr'],
                    'confidence_threshold': 0.7
                },
                'system': {
                    'log_level': 'INFO',
                    'max_log_files': 10,
                    'auto_backup': True
                }
            }
            
            config_file = self.config_dir / 'configs' / 'default_config.json'
            with open(config_file, 'w', encoding='utf-8') as f:
                json.dump(default_config, f, indent=2, ensure_ascii=False)
            
            self.print_success(f"创建默认配置文件: {config_file}")
            
            # 创建示例脚本
            example_script = self.config_dir / 'example_usage.py'
            example_content = '''#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
石器时代验证码识别工具 - 使用示例
"""

import sys
from pathlib import Path

# 添加项目路径
project_root = Path(__file__).parent.parent / "石器时代验证码识别工具"
sys.path.insert(0, str(project_root))

from src.core.ocr_multi_engine import OCRMultiEngine
from src.core.game_integration_enhanced import GameIntegrationEnhanced

def main():
    """主函数"""
    print("石器时代验证码识别工具 - 使用示例")
    print("=" * 50)
    
    # 初始化OCR引擎
    print("初始化OCR引擎...")
    ocr = OCRMultiEngine()
    print(f"可用引擎: {ocr.available_engines}")
    
    # 初始化游戏集成
    print("初始化游戏集成...")
    game = GameIntegrationEnhanced()
    
    # 获取性能统计
    ocr_stats = ocr.get_performance_stats()
    game_stats = game.get_performance_stats()
    
    print(f"OCR统计: {ocr_stats['total_recognitions']} 次识别")
    print(f"游戏窗口检测: {len(game_stats['stats']['windows_found'])} 次成功")
    
    print("示例运行完成！")

if __name__ == "__main__":
    main()
'''
            
            with open(example_script, 'w', encoding='utf-8') as f:
                f.write(example_content)
            
            self.print_success(f"创建使用示例: {example_script}")
            
            return True
            
        except Exception as e:
            self.print_error(f"创建配置目录时出错: {e}")
            return False
    
    def create_desktop_shortcut(self) -> bool:
        """创建桌面快捷方式（仅Windows）"""
        if not self.is_windows:
            return True  # 非Windows系统跳过
        
        self.print_header("创建桌面快捷方式")
        
        try:
            import winshell
            
            desktop = winshell.desktop()
            shortcut_path = os.path.join(desktop, "石器时代验证码识别工具.lnk")
            
            target = sys.executable
            wDir = str(self.project_root)
            icon = str(self.project_root / "assets" / "icon.ico")
            
            # 创建快捷方式
            shell = winshell.CreateShortcut(
                Path=shortcut_path,
                Target=target,
                Arguments=str(self.project_root / "src" / "main.py"),
                StartIn=wDir,
                Icon=(icon, 0),
                Description="石器时代验证码识别工具"
            )
            
            self.print_success(f"创建桌面快捷方式: {shortcut_path}")
            return True
            
        except ImportError:
            self.print_warning("winshell未安装，跳过创建快捷方式")
            return True
        except Exception as e:
            self.print_warning(f"创建快捷方式时出错: {e}")
            return True
    
    def create_start_menu_entry(self) -> bool:
        """创建开始菜单项（仅Windows）"""
        if not self.is_windows:
            return True  # 非Windows系统跳过
        
        self.print_header("创建开始菜单项")
        
        try:
            import winshell
            
            start_menu = winshell.start_menu()
            program_dir = os.path.join(start_menu, "程序", "石器时代验证码识别工具")
            os.makedirs(program_dir, exist_ok=True)
            
            shortcut_path = os.path.join(program_dir, "石器时代验证码识别工具.lnk")
            
            target = sys.executable
            wDir = str(self.project_root)
            icon = str(self.project_root / "assets" / "icon.ico")
            
            # 创建快捷方式
            shell = winshell.CreateShortcut(
                Path=shortcut_path,
                Target=target,
                Arguments=str(self.project_root / "src" / "main.py"),
                StartIn=wDir,
                Icon=(icon, 0),
                Description="石器时代验证码识别工具"
            )
            
            self.print_success(f"创建开始菜单项: {shortcut_path}")
            return True
            
        except ImportError:
            self.print_warning("winshell未安装，跳过创建开始菜单项")
            return True
        except Exception as e:
            self.print_warning(f"创建开始菜单项时出错: {e}")
            return True
    
    def create_uninstall_script(self) -> bool:
        """创建卸载脚本"""
        self.print_header("创建卸载脚本")
        
        try:
            uninstall_script = self.project_root / "uninstall.py"
            
            uninstall_content = '''#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
石器时代验证码识别工具 - 卸载脚本
"""

import os
import sys
import shutil
import subprocess
from pathlib import Path

def main():
    """主函数"""
    print("石器时代验证码识别工具 - 卸载")
    print("=" * 50)
    
    # 确认卸载
    confirm = input("确定要卸载石器时代验证码识别工具吗？(y/N): ").strip().lower()
    if confirm != 'y':
        print("卸载已取消")
        return
    
    # 删除配置目录
    config_dir = Path.home() / "StoneCaptcha"
    if config_dir.exists():
        try:
            shutil.rmtree(config_dir)
            print(f"✅ 已删除配置目录: {config_dir}")
        except Exception as e:
            print(f"❌ 删除配置目录失败: {e}")
    
    # 删除桌面快捷方式（Windows）
    if sys.platform == 'win32':
        try:
            import winshell
            desktop = winshell.desktop()
            shortcut = os.path.join(desktop, "石器时代验证码识别工具.lnk")
            if os.path.exists(shortcut):
                os.remove(shortcut)
                print(f"✅ 已删除桌面快捷方式")
            
            # 删除开始菜单项
            start_menu = winshell.start_menu()
            program_dir = os.path.join(start_menu, "程序", "石器时代验证码识别工具")
            if os.path.exists(program_dir):
                shutil.rmtree(program_dir)
                print(f"✅ 已删除开始菜单项")
        except ImportError:
            print("⚠️  winshell未安装，跳过快捷方式删除")
        except Exception as e:
            print(f"⚠️  删除快捷方式时出错: {e}")
    
    print("=" * 50)
    print("卸载完成！")
    print("注意：Python依赖包需要手动卸载")
    print("可以使用: pip uninstall -r requirements.txt")

if __name__ == "__main__":
    main()
'''
            
            with open(uninstall_script, 'w', encoding='utf-8') as f:
                f.write(uninstall_content)
            
            # 设置执行权限（Linux/macOS）
            if not self.is_windows:
                os.chmod(uninstall_script, 0o755)
            
            self.print_success(f"创建卸载脚本: {uninstall_script}")
            return True
            
        except Exception as e:
            self.print_error(f"创建卸载脚本时出错: {e}")
            return False
    
    def run_post_install_tests(self) -> bool:
        """运行安装后测试"""
        self.print_header("运行安装后测试")
        
        try:
            # 导入测试模块
            test_script = self.project_root / "tests" / "test_suite.py"
            
            if not test_script.exists():
                self.print_warning("测试脚本不存在，跳过测试")
                return True
            
            # 运行基本测试
            cmd = [sys.executable, str(test_script), "--test", "config"]
            result = subprocess.run(cmd, capture_output=True, text=True)
            
            if result.returncode == 0:
                self.print_success("安装后测试通过")
                return True
            else:
                self.print_warning("安装后测试失败，但安装继续")
                self.print_warning(f"测试输出: {result.stderr}")
                return True  # 测试失败不影响安装
            
        except Exception as e:
            self.print_warning(f"运行安装后测试时出错: {e}")
            return True  # 测试失败不影响安装
    
    def generate_install_report(self) -> bool:
        """生成安装报告"""
        self.print_header("生成安装报告")
        
        try:
            report_file = self.config_dir / "install_report.json"
            
            report_data = {
                'timestamp': time.time(),
                'system': platform.platform(),
                'python_version': f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}",
                'install_path': str(self.project_root),
                'config_path': str(self.config_dir),
                'log': self.install_log,
                'errors': self.errors,
                'success': len(self.errors) == 0
            }
            
            with open(report_file, 'w', encoding='utf-8') as f:
                json.dump(report_data, f, indent=2, ensure_ascii=False)
            
            self.print_success(f"安装报告已保存: {report_file}")
            return True
            
        except Exception as e:
            self.print_error(f"生成安装报告时出错: {e}")
            return False
    
    def install(self) -> bool:
        """执行完整安装流程"""
        self.print_header("石器时代验证码识别工具 - 安装程序")
        
        print(f"项目路径: {self.project_root}")
        print(f"系统类型: {platform.platform()}")
        print(f"Python版本: {sys.version}")
        
        # 安装步骤
        steps = [
            ("检查Python版本", self.check_python_version),
            ("检查系统依赖", self.check_system_dependencies),
            ("安装Python依赖", self.install_python_dependencies),
            ("创建配置目录", self.create_config_directory),
            ("创建桌面快捷方式", self.create_desktop_shortcut),
            ("创建开始菜单项", self.create_start_menu_entry),
            ("创建卸载脚本", self.create_uninstall_script),
            ("运行安装后测试", self.run_post_install_tests),
            ("生成安装报告", self.generate_install_report)
        ]
        
        # 执行所有步骤
        all_success = True
        
        for step_name, step_func in steps:
            self.print_header(f"步骤: {step_name}")
            
            try:
                success = step_func()
                if not success:
                    all_success = False
                    self.print_error(f"步骤失败: {step_name}")
                    
                    # 询问是否继续
                    if step_name not in ["检查Python版本", "安装Python依赖"]:
                        continue_install = input("是否继续安装？(y/N): ").strip().lower()
                        if continue_install != 'y':
                            self.print_error("安装被用户取消")
                            return False
            except KeyboardInterrupt:
                self.print_error("安装被用户中断")
                return False
            except Exception as e:
                self.print_error(f"步骤执行异常: {step_name} - {e}")
                all_success = False
        
        # 显示安装结果
        self.print_header("安装完成")
        
        if all_success:
            print(f"{self.colors['green']}🎉 安装成功！{self.colors['reset']}")
            print(f"\n📁 配置目录: {self.config_dir}")
            print(f"🐍 Python脚本: {self.project_root / 'src' / 'main.py'}")
            print(f"🖥️  使用示例: {self.config_dir / 'example_usage.py'}")
            
            if self.is_windows:
                print(f"📋 桌面快捷方式: 石器时代验证码识别工具.lnk")
                print(f"📋 开始菜单: 程序 → 石器时代验证码识别工具")
            
            print(f"\n🚀 启动方式:")
            print(f"   1. 直接运行: python {self.project_root / 'src' / 'main.py'}")
            print(f"   2. 使用示例: python {self.config_dir / 'example_usage.py'}")
            print(f"   3. 运行测试: python {self.project_root / 'tests' / 'test_suite.py'}")
            
            print(f"\n📚 文档:")
            print(f"   • 配置文件: {self.config_dir / 'configs' / 'default_config.json'}")
            print(f"   • 日志文件: {self.config_dir / 'logs'}")
            print(f"   • 卸载脚本: {self.project_root / 'uninstall.py'}")
        else:
            print(f"{self.colors['red']}⚠️  安装完成，但有错误{self.colors['reset']}")
            print(f"\n❌ 错误列表:")
            for error in self.errors:
                print(f"   • {error}")
            
            print(f"\n💡 建议:")
            print(f"   1. 检查错误信息")
            print(f"   2. 手动安装缺失的依赖")
            print(f"   3. 运行测试验证功能: python {self.project_root / 'tests' / 'test_suite.py'}")
        
        return all_success

def main():
    """主函数"""
    installer = StoneCaptchaInstaller()
    
    # 显示欢迎信息
    print(f"{installer.colors['cyan']}")
    print("╔══════════════════════════════════════════════════════════╗")
    print("║        石器时代验证码识别工具 - 安装程序                ║")
    print("║        Stone Age Captcha Recognition Tool               ║")
    print("╚══════════════════════════════════════════════════════════╝")
    print(f"{installer.colors['reset']}")
    
    print("版本: 1.0.0")
    print("作者: OpenClaw AI Assistant")
    print("描述: 自动识别石器时代游戏中的验证码")
    print("")
    
    # 确认安装
    confirm = input("是否开始安装？(Y/n): ").strip().lower()
    if confirm == 'n':
        print("安装已取消")
        return 1
    
    # 执行安装
    try:
        success = installer.install()
        return 0 if success else 1
    except KeyboardInterrupt:
        print("\n安装被用户中断")
        return 130
    except Exception as e:
        print(f"安装过程中发生错误: {e}")
        import traceback
        traceback.print_exc()
        return 1

if __name__ == "__main__":
    sys.exit(main())