#!/usr/bin/env python3
"""
基础功能测试脚本

测试游戏客户端集成工具的基础功能，包括:
1. 配置系统
2. 日志系统
3. 异常系统
"""

import sys
import os

# 添加src目录到Python路径
current_dir = os.path.dirname(os.path.abspath(__file__))
src_dir = os.path.join(current_dir, '..', 'src')
sys.path.insert(0, src_dir)

def test_core_modules():
    """测试核心模块"""
    print("=" * 60)
    print("🧪 核心模块测试")
    print("=" * 60)
    
    try:
        # 测试配置系统
        from core.config import Config, get_config
        
        print("\n1. 测试配置系统...")
        config = get_config()
        print(f"   ✅ 配置系统初始化成功")
        print(f"      游戏窗口标题: {config.game.window_title}")
        print(f"      游戏进程名称: {config.game.process_name}")
        print(f"      窗口搜索超时: {config.game.window_search_timeout}秒")
        print(f"      进程检查间隔: {config.monitor.process_monitor_interval}秒")
        
        # 验证配置
        if config.validate():
            print("   ✅ 配置验证通过")
        else:
            print("   ⚠️  配置验证失败")
        
        # 测试日志系统
        from core.logger import get_logger
        
        print("\n2. 测试日志系统...")
        logger = get_logger()
        logger.info("日志系统测试 - 信息级别")
        logger.debug("日志系统测试 - 调试级别")
        logger.warning("日志系统测试 - 警告级别")
        print("   ✅ 日志系统测试完成")
        
        # 测试异常系统
        from core.exceptions import (
            StoneAgeClientError, WindowNotFoundError, ProcessNotFoundError,
            handle_exception, safe_execute
        )
        
        print("\n3. 测试异常系统...")
        
        # 测试自定义异常
        try:
            raise WindowNotFoundError("测试窗口", "测试详情")
        except WindowNotFoundError as e:
            print(f"   ✅ 自定义异常正确抛出: {e}")
        
        # 测试异常处理函数
        def risky_function():
            raise ValueError("测试异常")
        
        result = safe_execute(risky_function, default="默认值", context="测试安全执行")
        print(f"   ✅ 安全执行函数: 返回 {result}")
        
        print("\n🎉 核心模块测试全部通过！")
        return True
        
    except Exception as e:
        print(f"\n❌ 核心模块测试失败: {e}")
        import traceback
        traceback.print_exc()
        return False

def test_monitor_modules():
    """测试监控模块"""
    print("\n" + "=" * 60)
    print("🖥️  监控模块测试")
    print("=" * 60)
    
    try:
        # 测试窗口管理器
        from monitor.window_manager import WindowManager, WindowState
        
        print("\n1. 测试窗口管理器...")
        wm = WindowManager()
        print(f"   ✅ 窗口管理器初始化成功")
        
        # 测试窗口状态枚举
        print(f"   支持的窗口状态: {[state.value for state in WindowState]}")
        
        # 测试进程监控器
        from monitor.process_monitor import ProcessMonitor, ProcessState
        
        print("\n2. 测试进程监控器...")
        pm = ProcessMonitor()
        print(f"   ✅ 进程监控器初始化成功")
        
        # 测试进程状态枚举
        print(f"   支持的进程状态: {[state.value for state in ProcessState]}")
        
        print("\n⚠️  注意: 窗口和进程的实际功能测试需要在Windows环境中进行")
        print("   当前只测试了模块初始化和枚举定义")
        
        print("\n🎉 监控模块基础测试通过！")
        return True
        
    except Exception as e:
        print(f"\n❌ 监控模块测试失败: {e}")
        import traceback
        traceback.print_exc()
        return False

def test_integration():
    """测试模块集成"""
    print("\n" + "=" * 60)
    print("🔗 模块集成测试")
    print("=" * 60)
    
    try:
        # 测试从主包导入
        import src as stoneage_client_tools
        
        print("\n1. 测试主包导入...")
        print(f"   ✅ 主包导入成功")
        print(f"      版本: {stoneage_client_tools.__version__}")
        print(f"      描述: {stoneage_client_tools.__description__}")
        
        # 测试简化导入
        from src import Config, Logger, WindowManager, ProcessMonitor
        
        print("\n2. 测试简化导入...")
        config = Config()
        logger = Logger()
        wm = WindowManager()
        pm = ProcessMonitor()
        
        print(f"   ✅ 所有主要类导入成功")
        print(f"      Config: {type(config).__name__}")
        print(f"      Logger: {type(logger).__name__}")
        print(f"      WindowManager: {type(wm).__name__}")
        print(f"      ProcessMonitor: {type(pm).__name__}")
        
        print("\n🎉 模块集成测试通过！")
        return True
        
    except Exception as e:
        print(f"\n❌ 模块集成测试失败: {e}")
        import traceback
        traceback.print_exc()
        return False

def generate_test_report():
    """生成测试报告"""
    print("\n" + "=" * 60)
    print("📊 测试报告")
    print("=" * 60)
    
    report = {
        "测试时间": "2026-03-26 21:30",
        "测试环境": "Linux (开发环境)",
        "目标环境": "Windows + 石器时代客户端",
        "测试结果": {}
    }
    
    # 运行测试
    core_result = test_core_modules()
    monitor_result = test_monitor_modules()
    integration_result = test_integration()
    
    report["测试结果"]["核心模块"] = "通过" if core_result else "失败"
    report["测试结果"]["监控模块"] = "通过" if monitor_result else "失败"
    report["测试结果"]["模块集成"] = "通过" if integration_result else "失败"
    
    # 总结
    all_passed = core_result and monitor_result and integration_result
    report["总体结果"] = "全部通过" if all_passed else "部分失败"
    
    print("\n📋 测试总结:")
    for category, result in report["测试结果"].items():
        status = "✅" if result == "通过" else "❌"
        print(f"   {status} {category}: {result}")
    
    print(f"\n🏁 总体结果: {report['总体结果']}")
    
    if all_passed:
        print("\n🎉 恭喜！所有基础测试通过！")
        print("   现在可以将工具复制到Windows环境进行实际游戏测试。")
    else:
        print("\n⚠️  部分测试失败，请检查错误信息。")
    
    return report

def main():
    """主函数"""
    print("🦖 石器时代游戏客户端集成工具 - 基础测试")
    print("=" * 60)
    print("测试环境: Linux (开发环境)")
    print("目标环境: Windows 10/11 + 石器时代客户端")
    print("=" * 60)
    
    try:
        report = generate_test_report()
        
        print("\n" + "=" * 60)
        print("📝 下一步行动")
        print("=" * 60)
        print("1. 将以下文件复制到Windows测试环境:")
        print("   - src/ 目录下的所有Python文件")
        print("   - requirements.txt (依赖库列表)")
        print("   - examples/ 目录下的测试脚本")
        print("   - 测试指南.md (详细测试说明)")
        print("\n2. 在Windows上安装依赖:")
        print("   pip install -r requirements.txt")
        print("\n3. 运行实际游戏测试:")
        print("   python examples/window_test.py")
        print("   python examples/process_test.py")
        
        return 0 if report["总体结果"] == "全部通过" else 1
        
    except KeyboardInterrupt:
        print("\n\n⏹️  测试被用户中断")
        return 1
    except Exception as e:
        print(f"\n❌ 测试过程发生未预期错误: {e}")
        import traceback
        traceback.print_exc()
        return 1

if __name__ == "__main__":
    sys.exit(main())