#!/usr/bin/env python3
"""
石器时代脚本测试运行器
专门用于运行和监控石器时代脚本测试
"""

import os
import sys
import json
import time
import logging
import argparse
import subprocess
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass, field, asdict
from enum import Enum

# 添加当前目录到Python路径
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

try:
    from 石器时代专用测试模块 import (
        StoneAgeTestAssertion,
        StoneAgeScriptParser,
        StoneAgeScript,
        ASSACommandType
    )
except ImportError:
    print("警告: 无法导入石器时代专用测试模块，使用简化版本")
    # 定义简化版本
    class StoneAgeTestAssertion:
        @staticmethod
        def assert_no_errors(script_content: str):
            return True, []

logger = logging.getLogger(__name__)

class TestStatus(Enum):
    """测试状态枚举"""
    PENDING = "pending"
    RUNNING = "running"
    PASSED = "passed"
    FAILED = "failed"
    SKIPPED = "skipped"
    ERROR = "error"
    TIMEOUT = "timeout"

@dataclass
class TestResult:
    """测试结果数据结构"""
    test_id: str
    test_name: str
    status: TestStatus
    start_time: datetime
    end_time: Optional[datetime] = None
    duration_seconds: float = 0.0
    assertions_passed: int = 0
    assertions_failed: int = 0
    assertions_total: int = 0
    error_message: Optional[str] = None
    details: Dict[str, Any] = field(default_factory=dict)
    logs: List[str] = field(default_factory=list)

@dataclass
class TestSuiteResult:
    """测试套件结果数据结构"""
    suite_name: str
    start_time: datetime
    end_time: Optional[datetime] = None
    duration_seconds: float = 0.0
    total_tests: int = 0
    passed_tests: int = 0
    failed_tests: int = 0
    skipped_tests: int = 0
    error_tests: int = 0
    test_results: List[TestResult] = field(default_factory=list)
    summary: Dict[str, Any] = field(default_factory=dict)

class StoneAgeTestRunner:
    """石器时代脚本测试运行器"""
    
    def __init__(self, config_path: str = None):
        self.config_path = config_path
        self.config = self._load_config(config_path) if config_path else {}
        self.test_suite_result = None
        self.script_parser = StoneAgeScriptParser()
        
    def _load_config(self, config_path: str) -> Dict[str, Any]:
        """加载测试配置"""
        try:
            with open(config_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            logger.error(f"加载配置失败: {e}")
            return {}
    
    def run_test_suite(self, config_path: str = None) -> TestSuiteResult:
        """运行测试套件"""
        if config_path:
            self.config_path = config_path
            self.config = self._load_config(config_path)
        
        if not self.config:
            raise ValueError("未提供有效的测试配置")
        
        suite_config = self.config.get("test_suite", {})
        test_cases = self.config.get("test_cases", [])
        
        # 初始化测试套件结果
        self.test_suite_result = TestSuiteResult(
            suite_name=suite_config.get("name", "未命名测试套件"),
            start_time=datetime.now(),
            total_tests=len(test_cases)
        )
        
        logger.info(f"开始运行测试套件: {self.test_suite_result.suite_name}")
        logger.info(f"测试用例数量: {len(test_cases)}")
        
        # 运行每个测试用例
        for test_case in test_cases:
            self._run_test_case(test_case)
        
        # 完成测试套件
        self.test_suite_result.end_time = datetime.now()
        self.test_suite_result.duration_seconds = (
            self.test_suite_result.end_time - self.test_suite_result.start_time
        ).total_seconds()
        
        # 生成摘要
        self._generate_summary()
        
        logger.info(f"测试套件完成: {self.test_suite_result.suite_name}")
        logger.info(f"总耗时: {self.test_suite_result.duration_seconds:.2f}秒")
        logger.info(f"通过: {self.test_suite_result.passed_tests}, 失败: {self.test_suite_result.failed_tests}")
        
        return self.test_suite_result
    
    def _run_test_case(self, test_case: Dict[str, Any]) -> TestResult:
        """运行单个测试用例"""
        test_id = test_case.get("id", "unknown")
        test_name = test_case.get("name", "未命名测试")
        
        logger.info(f"开始测试: {test_name} ({test_id})")
        
        # 初始化测试结果
        test_result = TestResult(
            test_id=test_id,
            test_name=test_name,
            status=TestStatus.RUNNING,
            start_time=datetime.now()
        )
        
        try:
            # 获取脚本路径
            script_path = test_case.get("script_path")
            if not script_path:
                raise ValueError("测试用例未指定脚本路径")
            
            # 解析脚本
            script = self.script_parser.parse_script(script_path)
            test_result.details["script_info"] = {
                "name": script.script_name,
                "total_lines": script.total_lines,
                "command_count": len(script.commands),
                "function_count": len(script.functions),
                "variable_count": len(script.variables)
            }
            
            # 运行断言
            assertions = test_case.get("assertions", [])
            test_result.assertions_total = len(assertions)
            
            for assertion in assertions:
                passed = self._run_assertion(assertion, script, test_result)
                if passed:
                    test_result.assertions_passed += 1
                else:
                    test_result.assertions_failed += 1
            
            # 确定测试状态
            if test_result.assertions_failed == 0:
                test_result.status = TestStatus.PASSED
                self.test_suite_result.passed_tests += 1
            else:
                test_result.status = TestStatus.FAILED
                self.test_suite_result.failed_tests += 1
                
        except Exception as e:
            test_result.status = TestStatus.ERROR
            test_result.error_message = str(e)
            self.test_suite_result.error_tests += 1
            logger.error(f"测试 {test_name} 出错: {e}")
        
        finally:
            # 完成测试
            test_result.end_time = datetime.now()
            test_result.duration_seconds = (
                test_result.end_time - test_result.start_time
            ).total_seconds()
            
            # 添加到套件结果
            self.test_suite_result.test_results.append(test_result)
            
            # 记录日志
            status_emoji = {
                TestStatus.PASSED: "✅",
                TestStatus.FAILED: "❌",
                TestStatus.ERROR: "⚠️",
                TestStatus.SKIPPED: "⏭️"
            }.get(test_result.status, "❓")
            
            logger.info(f"{status_emoji} 测试完成: {test_name} - {test_result.status.value}")
            if test_result.assertions_total > 0:
                logger.info(f"   断言: {test_result.assertions_passed}/{test_result.assertions_total} 通过")
        
        return test_result
    
    def _run_assertion(self, assertion: Dict[str, Any], script: StoneAgeScript, 
                      test_result: TestResult) -> bool:
        """运行单个断言"""
        assertion_type = assertion.get("type", "")
        message = assertion.get("message", "未指定断言消息")
        
        try:
            if assertion_type == "no_errors":
                # 检查脚本无错误
                is_valid, errors = StoneAgeTestAssertion.assert_no_errors(
                    script.file_path.read_text(encoding='utf-8', errors='ignore')
                )
                if not is_valid:
                    test_result.logs.append(f"断言失败[{assertion_type}]: {message}")
                    test_result.logs.extend([f"  - {error}" for error in errors])
                return is_valid
                
            elif assertion_type == "script_structure":
                # 检查脚本结构
                is_valid, structure_info = StoneAgeTestAssertion.assert_script_structure(
                    script.file_path.read_text(encoding='utf-8', errors='ignore')
                )
                test_result.details["structure_info"] = structure_info
                
                # 检查额外条件
                min_comments = assertion.get("min_comments", 0)
                require_main_loop = assertion.get("require_main_loop", False)
                require_error_handling = assertion.get("require_error_handling", False)
                min_functions = assertion.get("min_functions", 0)
                
                conditions_met = True
                if min_comments > 0 and not structure_info.get("has_comments", False):
                    conditions_met = False
                    test_result.logs.append(f"结构断言: 注释比例不足 {min_comments}")
                
                if require_main_loop and not structure_info.get("has_main_loop", False):
                    conditions_met = False
                    test_result.logs.append("结构断言: 缺少主循环")
                
                if require_error_handling and not structure_info.get("has_error_handling", False):
                    conditions_met = False
                    test_result.logs.append("结构断言: 缺少错误处理")
                
                if min_functions > 0 and structure_info.get("function_count", 0) < min_functions:
                    conditions_met = False
                    test_result.logs.append(f"结构断言: 函数数量不足 {min_functions}")
                
                if not conditions_met:
                    test_result.logs.append(f"断言失败[{assertion_type}]: {message}")
                
                return is_valid and conditions_met
                
            elif assertion_type == "function_exists":
                # 检查函数是否存在
                function_name = assertion.get("function_name", "")
                exists = function_name in script.functions
                
                if not exists:
                    test_result.logs.append(f"断言失败[{assertion_type}]: 函数 {function_name} 不存在")
                    test_result.logs.append(f"可用函数: {', '.join(script.functions.keys())}")
                
                return exists
                
            elif assertion_type == "variable_exists":
                # 检查变量是否存在
                variable_name = assertion.get("variable_name", "")
                exists = variable_name in script.variables
                
                if not exists:
                    test_result.logs.append(f"断言失败[{assertion_type}]: 变量 {variable_name} 不存在")
                    test_result.logs.append(f"可用变量: {', '.join(script.variables.keys())}")
                
                return exists
                
            elif assertion_type == "coordinates_valid":
                # 检查坐标有效性
                coordinates = assertion.get("coordinates", [])
                is_valid, errors = StoneAgeTestAssertion.assert_coordinates_valid(coordinates)
                
                if not is_valid:
                    test_result.logs.append(f"断言失败[{assertion_type}]: {message}")
                    test_result.logs.extend([f"  - {error}" for error in errors])
                
                return is_valid
                
            elif assertion_type == "has_move_commands":
                # 检查是否有移动命令
                min_move_commands = assertion.get("min_move_commands", 1)
                move_commands = [
                    cmd for cmd in script.commands 
                    if cmd.command_type == ASSACommandType.MOVE
                ]
                has_enough = len(move_commands) >= min_move_commands
                
                if not has_enough:
                    test_result.logs.append(
                        f"断言失败[{assertion_type}]: 移动命令不足 "
                        f"({len(move_commands)}/{min_move_commands})"
                    )
                
                return has_enough
                
            elif assertion_type == "has_error_handling":
                # 检查是否有错误处理
                require_try_catch = assertion.get("require_try_catch", False)
                
                # 检查错误处理命令
                error_commands = [
                    cmd for cmd in script.commands 
                    if cmd.command_type == ASSACommandType.ERROR
                ]
                
                has_error_handling = len(error_commands) > 0
                
                if require_try_catch:
                    # 还需要检查try/catch结构
                    script_content = script.file_path.read_text(encoding='utf-8', errors='ignore')
                    has_try_catch = "try" in script_content.lower() and "catch" in script_content.lower()
                    has_error_handling = has_error_handling and has_try_catch
                
                if not has_error_handling:
                    test_result.logs.append(f"断言失败[{assertion_type}]: {message}")
                
                return has_error_handling
                
            elif assertion_type == "has_conditional_logic":
                # 检查是否有条件逻辑
                min_conditions = assertion.get("min_conditions", 1)
                condition_commands = [
                    cmd for cmd in script.commands 
                    if cmd.command_type == ASSACommandType.CONDITION
                ]
                has_enough = len(condition_commands) >= min_conditions
                
                if not has_enough:
                    test_result.logs.append(
                        f"断言失败[{assertion_type}]: 条件命令不足 "
                        f"({len(condition_commands)}/{min_conditions})"
                    )
                
                return has_enough
                
            elif assertion_type == "has_user_messages":
                # 检查是否有用户消息
                min_messages = assertion.get("min_messages", 1)
                ui_commands = [
                    cmd for cmd in script.commands 
                    if cmd.command_type == ASSACommandType.UI
                ]
                has_enough = len(ui_commands) >= min_messages
                
                if not has_enough:
                    test_result.logs.append(
                        f"断言失败[{assertion_type}]: 用户消息不足 "
                        f"({len(ui_commands)}/{min_messages})"
                    )
                
                return has_enough
                
            else:
                # 未知断言类型
                test_result.logs.append(f"警告: 未知断言类型: {assertion_type}")
                return True  # 默认通过，避免影响其他断言
                
        except Exception as e:
            test_result.logs.append(f"断言执行错误[{assertion_type}]: {e}")
            return False
    
    def _generate_summary(self):
        """生成测试摘要"""
        if not self.test_suite_result:
            return
        
        summary = {
            "suite_name": self.test_suite_result.suite_name,
            "start_time": self.test_suite_result.start_time.isoformat(),
            "end_time": self.test_suite_result.end_time.isoformat() if self.test_suite_result.end_time else None,
            "duration_seconds": self.test_suite_result.duration_seconds,
            "total_tests": self.test_suite_result.total_tests,
            "passed_tests": self.test_suite_result.passed_tests,
            "failed_tests": self.test_suite_result.failed_tests,
            "skipped_tests": self.test_suite_result.skipped_tests,
            "error_tests": self.test_suite_result.error_tests,
            "pass_rate": (
                self.test_suite_result.passed_tests / self.test_suite_result.total_tests * 100
                if self.test_suite_result.total_tests > 0 else 0
            ),
            "test_results_summary": []
        }
        
        # 每个测试结果的摘要
        for result in self.test_suite_result.test_results:
            summary["test_results_summary"].append({
                "test_id": result.test_id,
                "test_name": result.test_name,
                "status": result.status.value,
                "duration_seconds": result.duration_seconds,
                "assertions_passed": result.assertions_passed,
                "assertions_failed": result.assertions_failed,
                "assertions_total": result.assertions_total
            })
        
        self.test_suite_result.summary = summary
    
    def save_results(self, output_dir: str = "test_results") -> str:
        """保存测试结果"""
        if not self.test_suite_result:
            raise ValueError("没有测试结果可保存")
        
        output_path = Path(output_dir)
        output_path.mkdir(exist_ok=True)
        
        # 生成文件名
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"stoneage_test_results_{timestamp}"
        
        # 保存JSON格式
        json_path = output_path / f"{filename}.json"
        with open(json_path, 'w', encoding='utf-8') as f:
            json.dump(asdict(self.test_suite_result), f, ensure_ascii=False, indent=2, default=str)
        
        # 保存Markdown报告
        md_path = output_path / f"{filename}.md"
        self._generate_markdown_report(md_path)
        
        logger.info(f"测试结果已保存:")
        logger.info(f"  JSON: {json_path}")
        logger.info(f"  Markdown: {md_path}")
        
        return str(json_path)
    
    def _generate_markdown_report(self, output_path: Path):
        """生成Markdown格式报告"""
        if not self.test_suite_result:
            return
        
        with open(output_path, 'w', encoding='utf-8') as f:
            # 标题
            f.write(f"# 🧪 石器时代脚本测试报告\n\n")
            f.write(f"**测试套件**: {self.test_suite_result.suite_name}\n")
            f.write(f"**开始时间**: {self.test_suite_result.start_time.strftime('%Y-%m-%d %H:%M:%S')}\n")
            if self.test_suite_result.end_time:
                f.write(f"**结束时间**: {self.test_suite_result.end_time.strftime('%Y-%m-%d %H:%M:%S')}\n")
                f.write(f"**总耗时**: {self.test_suite_result.duration_seconds:.2f} 秒\n")
            f.write(f"**测试用例总数**: {self.test_suite_result.total_tests}\n\n")
            
            # 摘要统计
            f.write("## 📊 测试摘要\n\n")
            f.write("| 状态 | 数量 | 比例 |\n")
            f.write("|------|------|------|\n")
            
            status_counts = {
                "通过": self.test_suite_result.passed_tests,
                "失败": self.test_suite_result.failed_tests,
                "错误": self.test_suite_result.error_tests,
                "跳过": self.test_suite_result.skipped_tests
            }
            
            for status, count in status_counts.items():
                percentage = (count / self.test_suite_result.total_tests * 100) if self.test_suite_result.total_tests > 0 else 0
                f.write(f"| {status} | {count} | {percentage:.1f}% |\n")
            
            f.write("\n")
            
            # 总体通过率
            pass_rate = (self.test_suite_result.passed_tests / self.test_suite_result.total_tests * 100) if self.test_suite_result.total_tests > 0 else 0
            if pass_rate >= 80:
                f.write(f"✅ **总体通过率**: {pass_rate:.1f}% (优秀)\n\n")
            elif pass_rate >= 60:
                f.write(f"⚠️ **总体通过率**: {pass_rate:.1f}% (一般)\n\n")
            else:
                f.write(f"❌ **总体通过率**: {pass_rate:.1f}% (需要改进)\n\n")
            
            # 详细测试结果
            f.write("## 📋 详细测试结果\n\n")
            for result in self.test_suite_result.test_results:
                # 状态图标
                status_icon = {
                    TestStatus.PASSED: "✅",
                    TestStatus.FAILED: "❌",
                    TestStatus.ERROR: "⚠️",
                    TestStatus.SKIPPED: "⏭️",
                    TestStatus.RUNNING: "🔄",
                    TestStatus.PENDING: "⏳"
                }.get(result.status, "❓")
                
                f.write(f"### {status_icon} {result.test_name}\n")
                f.write(f"**ID**: {result.test_id}\n")
                f.write(f"**状态**: {result.status.value}\n")
                f.write(f"**耗时**: {result.duration_seconds:.2f}秒\n")
                f.write(f"**断言**: {result.assertions_passed}/{result.assertions_total} 通过\n")
                
                if result.error_message:
                    f.write(f"**错误**: {result.error_message}\n")
                
                # 详细信息
                if result.details:
                    f.write("\n**详细信息**:\n")
                    for key, value in result.details.items():
                        if isinstance(value, dict):
                            f.write(f"- **{key}**:\n")
                            for sub_key, sub_value in value.items():
                                f.write(f"  - {sub_key}: {sub_value}\n")
                        else:
                            f.write(f"- **{key}**: {value}\n")
                
                # 日志
                if result.logs:
                    f.write("\n**日志**:\n")
                    for log in result.logs:
                        f.write(f"- {log}\n")
                
                f.write("\n---\n\n")
            
            # 建议和改进
            f.write("## 💡 建议和改进\n\n")
            
            if self.test_suite_result.failed_tests > 0:
                f.write("### 需要关注的测试\n")
                failed_tests = [r for r in self.test_suite_result.test_results if r.status == TestStatus.FAILED]
                for test in failed_tests:
                    f.write(f"- **{test.test_name}**: {test.assertions_failed}个断言失败\n")
                f.write("\n")
            
            # 脚本质量评估
            f.write("### 脚本质量评估\n")
            
            # 收集所有脚本信息
            script_infos = []
            for result in self.test_suite_result.test_results:
                if "script_info" in result.details:
                    script_infos.append(result.details["script_info"])
            
            if script_infos:
                # 使用第一个脚本信息
                info = script_infos[0]
                f.write(f"- **脚本名称**: {info.get('name', '未知')}\n")
                f.write(f"- **总行数**: {info.get('total_lines', 0)}\n")
                f.write(f"- **命令数量**: {info.get('command_count', 0)}\n")
                f.write(f"- **函数数量**: {info.get('function_count', 0)}\n")
                f.write(f"- **变量数量**: {info.get('variable_count', 0)}\n")
                
                # 质量评分
                quality_score = 0
                if info.get('function_count', 0) >= 3:
                    quality_score += 25
                if info.get('command_count', 0) >= 20:
                    quality_score += 25
                if info.get('total_lines', 0) >= 50:
                    quality_score += 25
                if info.get('variable_count', 0) >= 3:
                    quality_score += 25
                
                f.write(f"- **质量评分**: {quality_score}/100\n")
                
                if quality_score >= 80:
                    f.write("  - ✅ 脚本质量优秀\n")
                elif quality_score >= 60:
                    f.write("  - ⚠️ 脚本质量一般，有改进空间\n")
                else:
                    f.write("  - ❌ 脚本质量需要大幅改进\n")
            
            f.write("\n")
            
            # 下一步行动
            f.write("### 下一步行动建议\n")
            if self.test_suite_result.passed_tests == self.test_suite_result.total_tests:
                f.write("1. ✅ 所有测试通过，可以部署脚本\n")
                f.write("2. 🔄 考虑添加更多边界条件测试\n")
                f.write("3. 📈 进行性能测试和优化\n")
            else:
                f.write("1. 🔧 修复失败的测试用例\n")
                f.write("2. 🧪 添加缺失的测试覆盖\n")
                f.write("3. 📊 分析失败原因并改进脚本\n")
            
            f.write("\n---\n\n")
            f.write("*报告生成时间: " + datetime.now().strftime('%Y-%m-%d %H:%M:%S') + "*\n")
            f.write("*生成工具: 石器时代脚本自动化测试框架*\n")

def main():
    """主函数"""
    parser = argparse.ArgumentParser(description="石器时代脚本测试运行器")
    parser.add_argument("config", help="测试配置文件路径")
    parser.add_argument("--output", "-o", default="test_results", help="结果输出目录")
    parser.add_argument("--verbose", "-v", action="store_true", help="详细输出模式")
    parser.add_argument("--quick", "-q", action="store_true", help="快速模式，只运行高优先级测试")
    
    args = parser.parse_args()
    
    # 设置日志
    level = logging.DEBUG if args.verbose else logging.INFO
    logging.basicConfig(
        level=level,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.StreamHandler(),
            logging.FileHandler('stoneage_test_runner.log', encoding='utf-8')
        ]
    )
    
    print("🚀 石器时代脚本测试运行器")
    print("=" * 50)
    
    try:
        # 创建测试运行器
        runner = StoneAgeTestRunner()
        
        # 运行测试套件
        print(f"📁 加载配置: {args.config}")
        result = runner.run_test_suite(args.config)
        
        # 保存结果
        print(f"💾 保存结果到: {args.output}")
        output_path = runner.save_results(args.output)
        
        # 显示摘要
        print("\n📊 测试摘要:")
        print(f"  测试套件: {result.suite_name}")
        print(f"  总测试数: {result.total_tests}")
        print(f"  通过: {result.passed_tests}")
        print(f"  失败: {result.failed_tests}")
        print(f"  错误: {result.error_tests}")
        print(f"  总耗时: {result.duration_seconds:.2f}秒")
        
        pass_rate = (result.passed_tests / result.total_tests * 100) if result.total_tests > 0 else 0
        print(f"  通过率: {pass_rate:.1f}%")
        
        if pass_rate == 100:
            print("\n🎉 所有测试通过！脚本质量优秀！")
        elif pass_rate >= 80:
            print("\n👍 测试通过率良好，脚本质量不错")
        elif pass_rate >= 60:
            print("\n⚠️  测试通过率一般，需要改进")
        else:
            print("\n❌ 测试通过率较低，需要重点关注")
        
        print(f"\n📄 详细报告已生成:")
        print(f"  - JSON报告: {output_path}")
        print(f"  - Markdown报告: {output_path.replace('.json', '.md')}")
        
    except Exception as e:
        print(f"❌ 测试运行失败: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)

if __name__ == "__main__":
    main()