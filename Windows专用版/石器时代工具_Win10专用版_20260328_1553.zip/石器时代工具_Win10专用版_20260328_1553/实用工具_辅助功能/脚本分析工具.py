#!/usr/bin/env python3
"""
脚本分析工具 - 用于正确分析脚本版本
避免再犯同样的错误
"""

import os
import re

class ScriptAnalyzer:
    def __init__(self):
        # 官方名称特征
        self.official_features = {
            'npcs': ['卡坦', '红暴', '守护兽', '玛蕾菲雅', '雷尔', '塔蜜提雅'],
            'pets': ['咖啡雷', '红暴龙', '人龙', '雷龙', '凯比'],
            'tasks': ['1.82任务', '六转任务', '成人仪式', '红暴任务'],
        }
        
        # NG25特征（根据经验）
        self.ng25_features = {
            'indicators': ['NG25', '私服', 'sf', '自定义', '修改版'],
            'file_patterns': ['NG25', '私服', 'sf_', 'custom'],
        }
        
        # 常见编码问题特征
        self.encoding_issues = ['�', '򣸰', '򣬽', '޸']
    
    def analyze_file(self, file_path):
        """分析单个文件"""
        filename = os.path.basename(file_path)
        print(f"🔍 分析: {filename}")
        
        try:
            # 尝试读取文件
            with open(file_path, 'rb') as f:
                raw_content = f.read()
            
            # 尝试不同编码
            content = None
            for encoding in ['gbk', 'utf-8', 'gb2312']:
                try:
                    content = raw_content.decode(encoding, errors='ignore')
                    break
                except:
                    continue
            
            if not content:
                print("  ❌ 无法读取文件内容")
                return None
            
            analysis = {
                'filename': filename,
                'size': len(raw_content),
                'lines': content.count('\n') + 1,
                'encoding_issues': 0,
                'official_features': [],
                'ng25_indicators': [],
                'version_hints': [],
                'recommendation': '未知'
            }
            
            # 检查编码问题
            for issue in self.encoding_issues:
                if issue in content:
                    analysis['encoding_issues'] += content.count(issue)
            
            # 检查官方特征
            for category, features in self.official_features.items():
                for feature in features:
                    if feature in content:
                        analysis['official_features'].append(feature)
            
            # 检查NG25指示器
            for indicator in self.ng25_features['indicators']:
                if indicator in content:
                    analysis['ng25_indicators'].append(indicator)
            
            # 检查文件命名模式
            for pattern in self.ng25_features['file_patterns']:
                if pattern in filename:
                    analysis['ng25_indicators'].append(f"文件名包含: {pattern}")
            
            # 分析版本提示
            # 查找注释中的版本信息
            version_patterns = [
                r'版本[:：]\s*([^\n]+)',
                r'Version[:：]\s*([^\n]+)',
                r'v(\d+\.\d+)',
                r'NG25',
                r'私服',
            ]
            
            for pattern in version_patterns:
                matches = re.findall(pattern, content, re.IGNORECASE)
                if matches:
                    analysis['version_hints'].extend(matches)
            
            # 生成建议
            if analysis['ng25_indicators']:
                analysis['recommendation'] = 'NG25版本 - 不要修改名称'
            elif analysis['official_features']:
                analysis['recommendation'] = '官方版本 - 可能需要适配NG25'
            else:
                analysis['recommendation'] = '无法确定 - 需要进一步分析'
            
            # 打印简要结果
            print(f"  大小: {analysis['size']} bytes, 行数: {analysis['lines']}")
            if analysis['encoding_issues']:
                print(f"  ⚠️ 编码问题: {analysis['encoding_issues']} 处")
            if analysis['official_features']:
                print(f"  🎯 官方特征: {', '.join(analysis['official_features'][:3])}")
            if analysis['ng25_indicators']:
                print(f"  🔄 NG25指示: {', '.join(analysis['ng25_indicators'][:3])}")
            print(f"  💡 建议: {analysis['recommendation']}")
            
            return analysis
            
        except Exception as e:
            print(f"  ❌ 分析失败: {e}")
            return None
    
    def analyze_directory(self, directory):
        """分析整个目录"""
        print(f"📁 分析目录: {directory}")
        print("=" * 60)
        
        # 查找所有.asc文件
        asc_files = []
        for root, dirs, files in os.walk(directory):
            for file in files:
                if file.endswith('.asc'):
                    asc_files.append(os.path.join(root, file))
        
        print(f"找到 {len(asc_files)} 个脚本文件")
        
        # 分析关键文件
        key_files = [
            f for f in asc_files if any(
                pattern in os.path.basename(f) 
                for pattern in ['开始', '组队', '总成', '卡坦', '红暴']
            )
        ]
        
        print(f"重点分析 {len(key_files)} 个关键文件")
        print("-" * 40)
        
        analyses = []
        for file_path in key_files[:10]:  # 只分析前10个关键文件
            analysis = self.analyze_file(file_path)
            if analysis:
                analyses.append(analysis)
        
        # 生成总结报告
        self.generate_summary(analyses, directory)
        
        return analyses
    
    def generate_summary(self, analyses, directory):
        """生成分析总结"""
        print(f"\n📊 分析总结")
        print("=" * 60)
        
        total_files = len(analyses)
        ng25_count = sum(1 for a in analyses if a['ng25_indicators'])
        official_count = sum(1 for a in analyses if a['official_features'] and not a['ng25_indicators'])
        unknown_count = total_files - ng25_count - official_count
        
        print(f"分析文件数: {total_files}")
        print(f"NG25版本: {ng25_count} 个")
        print(f"官方版本: {official_count} 个")
        print(f"无法确定: {unknown_count} 个")
        
        # 主要发现
        print(f"\n🔍 主要发现:")
        if ng25_count > 0:
            print("✅ 发现NG25版本脚本 - 不要进行名称替换")
        if official_count > 0:
            print("⚠️ 发现官方版本脚本 - 可能需要适配NG25")
        if unknown_count > 0:
            print("❓ 部分脚本版本无法确定 - 需要进一步分析")
        
        # 建议
        print(f"\n🎯 建议行动:")
        if ng25_count > official_count:
            print("1. 这很可能是NG25版本脚本集")
            print("2. 不要进行任何名称替换")
            print("3. 只进行性能优化和显示优化")
        elif official_count > ng25_count:
            print("1. 这很可能是官方版本脚本集")
            print("2. 可能需要按照替换名单修改名称")
            print("3. 需要适配NG25私服")
        else:
            print("1. 版本混合，需要仔细分析")
            print("2. 建议与用户确认具体需求")
            print("3. 分文件处理，不要一刀切")
        
        # 保存报告
        report_path = os.path.join(directory, "脚本分析报告.txt")
        with open(report_path, 'w', encoding='utf-8') as f:
            f.write("脚本版本分析报告\n")
            f.write("=" * 60 + "\n")
            f.write(f"分析时间: 2026-03-19\n")
            f.write(f"分析目录: {directory}\n")
            f.write(f"分析文件: {total_files} 个关键脚本\n")
            f.write(f"NG25版本: {ng25_count} 个\n")
            f.write(f"官方版本: {official_count} 个\n")
            f.write(f"无法确定: {unknown_count} 个\n")
            f.write("\n详细分析:\n")
            for analysis in analyses:
                f.write(f"\n文件: {analysis['filename']}\n")
                f.write(f"建议: {analysis['recommendation']}\n")
                if analysis['official_features']:
                    f.write(f"官方特征: {', '.join(analysis['official_features'][:5])}\n")
                if analysis['ng25_indicators']:
                    f.write(f"NG25指示: {', '.join(analysis['ng25_indicators'][:5])}\n")
                f.write("-" * 40 + "\n")
        
        print(f"\n📝 详细报告已保存: {report_path}")

def main():
    print("🔧 脚本分析工具 - 避免版本判断错误")
    print("=" * 60)
    print("目的: 正确分析脚本版本，避免错误优化")
    print("=" * 60)
    
    analyzer = ScriptAnalyzer()
    
    # 分析原始脚本目录
    target_dir = "/root/.openclaw/workspace/极品人脚本分析/0-6转极品人"
    
    if os.path.exists(target_dir):
        print(f"\n开始分析原始脚本...")
        analyses = analyzer.analyze_directory(target_dir)
        
        print(f"\n🎯 从这次错误中学到的:")
        print("1. 收到脚本后必须先分析版本")
        print("2. 不要假设所有脚本都需要名称替换")
        print("3. NG25脚本保持原样，只优化性能")
        print("4. 官方脚本才需要按照替换名单修改")
    else:
        print(f"❌ 目录不存在: {target_dir}")

if __name__ == "__main__":
    main()
