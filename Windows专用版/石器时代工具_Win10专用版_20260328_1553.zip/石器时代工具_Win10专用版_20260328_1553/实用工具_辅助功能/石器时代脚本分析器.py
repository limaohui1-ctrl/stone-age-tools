#!/usr/bin/env python3
"""
石器时代脚本分析器
分析1,077个ASSA脚本文件，提取元数据并创建数据库
"""

import os
import re
import json
import time
from datetime import datetime
from pathlib import Path

# 配置
SCRIPTS_DIR = "/root/.openclaw/workspace/石器时代客户端处理/解压内容/sqng25/scripts"
OUTPUT_DIR = "/root/.openclaw/workspace/石器时代脚本数据库"
DB_FILE = os.path.join(OUTPUT_DIR, "脚本数据库.json")
REPORT_FILE = os.path.join(OUTPUT_DIR, "分析报告.md")

# 创建输出目录
os.makedirs(OUTPUT_DIR, exist_ok=True)

def analyze_script(file_path):
    """分析单个脚本文件"""
    try:
        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read()
        
        # 基础信息
        file_name = os.path.basename(file_path)
        file_size = os.path.getsize(file_path)
        lines = content.split('\n')
        line_count = len(lines)
        
        # 提取脚本信息
        script_info = {
            "file_name": file_name,
            "file_path": str(file_path),
            "file_size": file_size,
            "line_count": line_count,
            "analysis_time": datetime.now().isoformat()
        }
        
        # 提取标题（通常在第一行或注释中）
        title_match = re.search(r'^//\s*(.+?)\s*$', content, re.MULTILINE)
        if title_match:
            script_info["title"] = title_match.group(1).strip()
        else:
            # 尝试从文件名提取
            script_info["title"] = file_name.replace('.asc', '').replace('_', ' ')
        
        # 提取作者信息
        author_match = re.search(r'作者[：:]\s*(.+?)\s*$', content, re.MULTILINE)
        if author_match:
            script_info["author"] = author_match.group(1).strip()
        
        # 提取版本信息
        version_match = re.search(r'版本[：:]\s*(.+?)\s*$', content, re.MULTILINE)
        if version_match:
            script_info["version"] = version_match.group(1).strip()
        
        # 提取NPC信息
        npc_patterns = [
            r'(\+NPC[^,\s]+)',  # +NPC名称
            r'dlg\s+([^,\s]+)',  # dlg 指令
            r'waitdlg\s+([^,\s]+)',  # waitdlg 指令
        ]
        
        npcs = set()
        for pattern in npc_patterns:
            matches = re.findall(pattern, content)
            npcs.update(matches)
        
        if npcs:
            script_info["npcs"] = list(npcs)
        
        # 提取坐标信息
        coord_patterns = [
            r'walkpos\s*\(\s*(\d+)\s*,\s*(\d+)\s*\)',  # walkpos(x,y)
            r'waitpos\s*\(\s*(\d+)\s*,\s*(\d+)\s*\)',  # waitpos(x,y)
            r'(\d+)\s*,\s*(\d+)',  # x,y 格式
        ]
        
        coordinates = []
        for pattern in coord_patterns:
            matches = re.findall(pattern, content)
            for match in matches:
                if len(match) == 2:
                    try:
                        x, y = int(match[0]), int(match[1])
                        if 0 <= x <= 1000 and 0 <= y <= 1000:  # 合理的坐标范围
                            coordinates.append(f"{x},{y}")
                    except:
                        pass
        
        if coordinates:
            script_info["coordinates"] = list(set(coordinates))[:20]  # 最多保存20个坐标
        
        # 提取宠物/物品信息
        item_patterns = [
            r'pet\s+([^,\s]+)',  # pet 指令
            r'item\s+([^,\s]+)',  # item 指令
            r'useitem\s+([^,\s]+)',  # useitem 指令
        ]
        
        items = set()
        for pattern in item_patterns:
            matches = re.findall(pattern, content)
            items.update(matches)
        
        if items:
            script_info["items"] = list(items)
        
        # 提取地图信息
        map_patterns = [
            r'map\s+([^,\s]+)',  # map 指令
            r'w\s+([^,\s]+)',  # w 指令（walk）
        ]
        
        maps = set()
        for pattern in map_patterns:
            matches = re.findall(pattern, content)
            maps.update(matches)
        
        if maps:
            script_info["maps"] = list(maps)
        
        # 分析脚本功能
        function_keywords = {
            "自动挂机": ["挂机", "自动", "循环"],
            "转生任务": ["转生", "1转", "2转", "3转", "4转", "5转", "6转"],
            "赚钱脚本": ["赚钱", "石币", "贩卖", "卖钱"],
            "宠物相关": ["抓宠", "练宠", "宠物", "MM"],
            "任务脚本": ["任务", "解任", "活动"],
            "交通脚本": ["传送", "移动", "交通"],
            "料理合成": ["料理", "合成", "精炼"],
            "副本活动": ["副本", "活动", "挑战"],
        }
        
        functions = []
        for func_name, keywords in function_keywords.items():
            for keyword in keywords:
                if keyword in content or keyword in file_name:
                    functions.append(func_name)
                    break
        
        if functions:
            script_info["functions"] = list(set(functions))
        
        # 提取错误处理信息
        error_patterns = [
            r'label\s+([^,\s]+error[^,\s]*)',  # 错误标签
            r'goto\s+([^,\s]+error[^,\s]*)',  # 跳转到错误处理
        ]
        
        error_handlers = set()
        for pattern in error_patterns:
            matches = re.findall(pattern, content, re.IGNORECASE)
            error_handlers.update(matches)
        
        if error_handlers:
            script_info["error_handlers"] = list(error_handlers)
        
        # 计算复杂度指标
        complexity = {
            "has_loops": "loop" in content.lower(),
            "has_conditions": "if" in content.lower(),
            "has_gotos": "goto" in content.lower(),
            "has_labels": "label" in content.lower(),
            "has_comments": "//" in content,
        }
        
        script_info["complexity"] = complexity
        
        return script_info
        
    except Exception as e:
        print(f"❌ 分析失败 {file_path}: {e}")
        return None

def main():
    print("🦕 石器时代脚本分析器")
    print("=" * 60)
    print(f"脚本目录: {SCRIPTS_DIR}")
    print(f"输出目录: {OUTPUT_DIR}")
    print("=" * 60)
    
    # 查找所有.asc文件
    print("🔍 查找脚本文件...")
    script_files = []
    for root, dirs, files in os.walk(SCRIPTS_DIR):
        for file in files:
            if file.lower().endswith('.asc'):
                script_files.append(os.path.join(root, file))
    
    total_scripts = len(script_files)
    print(f"✅ 找到 {total_scripts} 个脚本文件")
    
    if total_scripts == 0:
        print("❌ 未找到脚本文件")
        return
    
    # 分析脚本
    print("🔍 开始分析脚本...")
    script_database = []
    successful = 0
    failed = 0
    
    start_time = time.time()
    
    for i, script_file in enumerate(script_files, 1):
        print(f"  [{i}/{total_scripts}] 分析: {os.path.basename(script_file)}", end="\r")
        
        script_info = analyze_script(script_file)
        if script_info:
            script_database.append(script_info)
            successful += 1
        else:
            failed += 1
        
        # 每100个文件保存一次进度
        if i % 100 == 0:
            print(f"\n  💾 保存进度 ({i}/{total_scripts})...")
            with open(DB_FILE + ".temp", 'w', encoding='utf-8') as f:
                json.dump(script_database, f, ensure_ascii=False, indent=2)
    
    elapsed_time = time.time() - start_time
    
    # 保存最终数据库
    print(f"\n💾 保存最终数据库...")
    with open(DB_FILE, 'w', encoding='utf-8') as f:
        json.dump(script_database, f, ensure_ascii=False, indent=2)
    
    # 生成报告
    print("📊 生成分析报告...")
    generate_report(script_database, total_scripts, successful, failed, elapsed_time)
    
    print("=" * 60)
    print(f"✅ 分析完成!")
    print(f"   成功分析: {successful} 个脚本")
    print(f"   分析失败: {failed} 个脚本")
    print(f"   总耗时: {elapsed_time:.2f} 秒")
    print(f"   数据库文件: {DB_FILE}")
    print(f"   报告文件: {REPORT_FILE}")
    print("=" * 60)

def generate_report(database, total, successful, failed, elapsed_time):
    """生成分析报告"""
    
    # 统计信息
    total_npcs = sum(len(script.get("npcs", [])) for script in database)
    total_coords = sum(len(script.get("coordinates", [])) for script in database)
    total_items = sum(len(script.get("items", [])) for script in database)
    
    # 功能分类统计
    function_stats = {}
    for script in database:
        for func in script.get("functions", []):
            function_stats[func] = function_stats.get(func, 0) + 1
    
    # 生成报告
    with open(REPORT_FILE, 'w', encoding='utf-8') as f:
        f.write("# 🦕 石器时代脚本分析报告\n\n")
        f.write(f"**生成时间**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        f.write(f"**分析脚本**: {total} 个\n")
        f.write(f"**成功分析**: {successful} 个\n")
        f.write(f"**分析失败**: {failed} 个\n")
        f.write(f"**分析耗时**: {elapsed_time:.2f} 秒\n\n")
        
        f.write("## 📊 统计摘要\n\n")
        f.write(f"- **脚本总数**: {total} 个\n")
        f.write(f"- **NPC数量**: {total_npcs} 个\n")
        f.write(f"- **坐标数量**: {total_coords} 个\n")
        f.write(f"- **物品数量**: {total_items} 个\n")
        f.write(f"- **数据库大小**: {os.path.getsize(DB_FILE) // 1024} KB\n\n")
        
        f.write("## 🎯 功能分类统计\n\n")
        for func, count in sorted(function_stats.items(), key=lambda x: x[1], reverse=True):
            percentage = (count / successful) * 100
            f.write(f"- **{func}**: {count} 个脚本 ({percentage:.1f}%)\n")
        
        f.write("\n## 📁 脚本目录结构\n\n")
        
        # 按目录统计
        dir_stats = {}
        for script in database:
            rel_path = os.path.relpath(script["file_path"], SCRIPTS_DIR)
            dir_name = os.path.dirname(rel_path)
            if not dir_name:
                dir_name = "根目录"
            dir_stats[dir_name] = dir_stats.get(dir_name, 0) + 1
        
        for dir_name, count in sorted(dir_stats.items()):
            f.write(f"- **{dir_name}**: {count} 个脚本\n")
        
        f.write("\n## 🔍 样本脚本\n\n")
        
        # 显示前10个脚本的摘要
        for i, script in enumerate(database[:10], 1):
            f.write(f"### {i}. {script.get('title', script['file_name'])}\n")
            f.write(f"- **文件**: {script['file_name']}\n")
            f.write(f"- **大小**: {script['file_size']} 字节\n")
            f.write(f"- **行数**: {script['line_count']} 行\n")
            
            if "author" in script:
                f.write(f"- **作者**: {script['author']}\n")
            
            if "version" in script:
                f.write(f"- **版本**: {script['version']}\n")
            
            if "functions" in script:
                f.write(f"- **功能**: {', '.join(script['functions'])}\n")
            
            if "npcs" in script:
                f.write(f"- **NPC**: {', '.join(script['npcs'][:5])}")
                if len(script["npcs"]) > 5:
                    f.write(f" 等 {len(script['npcs'])} 个")
                f.write("\n")
            
            f.write("\n")
        
        f.write("## 🚀 下一步建议\n\n")
        f.write("1. **创建脚本查询工具** - 基于数据库快速查找脚本\n")
        f.write("2. **分析NG25适配** - 检查脚本兼容性\n")
        f.write("3. **优化脚本性能** - 基于复杂度分析优化建议\n")
        f.write("4. **提取游戏数据** - 从脚本中提取NPC、坐标等游戏数据\n")
        f.write("5. **创建知识库** - 建立完整的石器时代开发知识库\n\n")
        
        f.write("---\n")
        f.write("*本报告由石器时代脚本分析器自动生成*\n")

if __name__ == "__main__":
    main()