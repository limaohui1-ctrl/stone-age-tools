#!/usr/bin/env python3
"""
石器时代脚本测试框架演示
展示如何使用测试框架测试石器时代脚本
"""

import os
import sys
import json
import time
from pathlib import Path

# 添加当前目录到Python路径
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

print("🎮 石器时代脚本测试框架演示")
print("=" * 60)

def demo_1_parse_script():
    """演示1: 解析石器时代脚本"""
    print("\n1️⃣ 演示: 解析石器时代脚本")
    print("-" * 40)
    
    try:
        from 石器时代专用测试模块 import StoneAgeScriptParser
        
        script_path = "示例石器时代脚本.asc"
        if not os.path.exists(script_path):
            print(f"❌ 脚本文件不存在: {script_path}")
            return
        
        print(f"📄 解析脚本: {script_path}")
        script = StoneAgeScriptParser.parse_script(script_path)
        
        print(f"✅ 脚本名称: {script.script_name}")
        print(f"✅ 总行数: {script.total_lines}")
        print(f"✅ 命令数量: {len(script.commands)}")
        print(f"✅ 函数数量: {len(script.functions)}")
        print(f"✅ 变量数量: {len(script.variables)}")
        
        # 显示前5个命令
        print("\n📝 前5个命令:")
        for i, cmd in enumerate(script.commands[:5], 1):
            print(f"  {i}. 第{cmd.line_number}行: {cmd.command} ({cmd.command_type.value})")
            if cmd.parameters:
                print(f"     参数: {cmd.parameters}")
        
        # 显示函数
        print("\n🔧 函数列表:")
        for func_name in list(script.functions.keys())[:5]:
            print(f"  - {func_name}")
        
        # 显示变量
        print("\n📊 变量列表:")
        for var_name, var_value in list(script.variables.items())[:5]:
            print(f"  - {var_name} = {var_value}")
        
        print("\n✅ 脚本解析完成!")
        
    except Exception as e:
        print(f"❌ 解析失败: {e}")

def demo_2_generate_test_cases():
    """演示2: 生成测试用例"""
    print("\n2️⃣ 演示: 生成测试用例")
    print("-" * 40)
    
    try:
        from 石器时代专用测试模块 import StoneAgeTestGenerator
        
        script_path = "示例石器时代脚本.asc"
        if not os.path.exists(script_path):
            print(f"❌ 脚本文件不存在: {script_path}")
            return
        
        print(f"🧪 为脚本生成测试用例: {script_path}")
        
        # 生成测试用例
        test_cases = StoneAgeTestGenerator.generate_test_cases(
            script_path, 
            output_dir="generated_tests"
        )
        
        print(f"✅ 生成了 {len(test_cases)} 个测试用例")
        
        # 显示测试用例
        print("\n📋 生成的测试用例:")
        for i, test_case in enumerate(test_cases, 1):
            print(f"\n  {i}. {test_case['name']}")
            print(f"     描述: {test_case['description']}")
            print(f"     超时: {test_case['timeout']}秒")
            print(f"     断言: {len(test_case['assertions'])}个")
            
            # 显示前2个断言
            for j, assertion in enumerate(test_case['assertions'][:2], 1):
                print(f"     {j}. {assertion['type']}: {assertion['message']}")
        
        # 检查生成的文件
        test_file = Path("generated_tests") / "示例石器时代脚本_tests.json"
        if test_file.exists():
            print(f"\n💾 测试用例已保存到: {test_file}")
            with open(test_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
                print(f"📄 文件大小: {os.path.getsize(test_file)} 字节")
                print(f"📊 包含 {len(data)} 个测试用例")
        
        print("\n✅ 测试用例生成完成!")
        
    except Exception as e:
        print(f"❌ 生成失败: {e}")

def demo_3_run_tests():
    """演示3: 运行测试"""
    print("\n3️⃣ 演示: 运行测试套件")
    print("-" * 40)
    
    try:
        from 石器时代测试运行器 import StoneAgeTestRunner
        
        config_path = "石器时代脚本测试配置.json"
        if not os.path.exists(config_path):
            print(f"❌ 配置文件不存在: {config_path}")
            return
        
        print(f"🚀 运行测试套件: {config_path}")
        
        # 创建测试运行器
        runner = StoneAgeTestRunner()
        
        # 运行测试
        print("⏳ 正在运行测试...")
        start_time = time.time()
        
        result = runner.run_test_suite(config_path)
        
        end_time = time.time()
        duration = end_time - start_time
        
        print(f"✅ 测试完成! 耗时: {duration:.2f}秒")
        
        # 显示结果摘要
        print("\n📊 测试结果摘要:")
        print(f"  测试套件: {result.suite_name}")
        print(f"  总测试数: {result.total_tests}")
        print(f"  通过: {result.passed_tests}")
        print(f"  失败: {result.failed_tests}")
        print(f"  错误: {result.error_tests}")
        
        pass_rate = (result.passed_tests / result.total_tests * 100) if result.total_tests > 0 else 0
        print(f"  通过率: {pass_rate:.1f}%")
        
        # 保存结果
        print("\n💾 保存测试结果...")
        output_path = runner.save_results("demo_test_results")
        print(f"✅ 结果已保存到: {output_path}")
        
        # 显示详细结果
        print("\n📋 详细测试结果:")
        for test_result in result.test_results:
            status_icon = "✅" if test_result.status.value == "passed" else "❌"
            print(f"  {status_icon} {test_result.test_name}")
            print(f"    状态: {test_result.status.value}")
            print(f"    耗时: {test_result.duration_seconds:.2f}秒")
            print(f"    断言: {test_result.assertions_passed}/{test_result.assertions_total} 通过")
            
            if test_result.error_message:
                print(f"    错误: {test_result.error_message}")
        
        print("\n✅ 测试运行完成!")
        
    except Exception as e:
        print(f"❌ 测试运行失败: {e}")
        import traceback
        traceback.print_exc()

def demo_4_quick_test():
    """演示4: 快速测试"""
    print("\n4️⃣ 演示: 快速测试单个脚本")
    print("-" * 40)
    
    try:
        from 石器时代专用测试模块 import StoneAgeTestAssertion
        
        script_path = "示例石器时代脚本.asc"
        if not os.path.exists(script_path):
            print(f"❌ 脚本文件不存在: {script_path}")
            return
        
        print(f"⚡ 快速测试脚本: {script_path}")
        
        # 读取脚本内容
        with open(script_path, 'r', encoding='utf-8', errors='ignore') as f:
            script_content = f.read()
        
        print("🧪 运行断言测试...")
        
        # 测试1: 检查语法错误
        print("\n1. 检查语法错误:")
        has_errors, errors = StoneAgeTestAssertion.assert_no_errors(script_content)
        if has_errors:
            print("   ✅ 无语法错误")
        else:
            print("   ❌ 发现语法错误:")
            for error in errors[:3]:  # 只显示前3个错误
                print(f"     - {error}")
            if len(errors) > 3:
                print(f"     ... 还有 {len(errors) - 3} 个错误")
        
        # 测试2: 检查脚本结构
        print("\n2. 检查脚本结构:")
        is_valid, structure_info = StoneAgeTestAssertion.assert_script_structure(script_content)
        if is_valid:
            print("   ✅ 脚本结构合理")
        else:
            print("   ⚠️  脚本结构需要改进")
        
        print("   📊 结构信息:")
        for key, value in structure_info.items():
            print(f"     - {key}: {value}")
        
        # 测试3: 检查坐标
        print("\n3. 检查坐标有效性:")
        coordinates = [(100, 200), (150, 250), (200, 300)]
        is_valid, errors = StoneAgeTestAssertion.assert_coordinates_valid(coordinates)
        if is_valid:
            print("   ✅ 所有坐标有效")
        else:
            print("   ❌ 坐标错误:")
            for error in errors:
                print(f"     - {error}")
        
        print("\n✅ 快速测试完成!")
        
    except Exception as e:
        print(f"❌ 快速测试失败: {e}")

def demo_5_create_custom_test():
    """演示5: 创建自定义测试"""
    print("\n5️⃣ 演示: 创建自定义测试配置")
    print("-" * 40)
    
    try:
        # 创建自定义测试配置
        custom_config = {
            "test_suite": {
                "name": "自定义石器时代脚本测试",
                "description": "专门为特定脚本创建的自定义测试",
                "version": "1.0.0"
            },
            "test_cases": [
                {
                    "id": "custom_001",
                    "name": "自定义功能测试",
                    "description": "测试脚本的特定功能",
                    "script_path": "示例石器时代脚本.asc",
                    "timeout": 120,
                    "assertions": [
                        {
                            "type": "function_exists",
                            "function_name": "mainLoop",
                            "message": "脚本应包含主循环函数"
                        },
                        {
                            "type": "variable_exists",
                            "variable_name": "targetLevel",
                            "message": "脚本应定义目标等级变量"
                        },
                        {
                            "type": "has_move_commands",
                            "min_move_commands": 2,
                            "message": "脚本应包含移动命令"
                        }
                    ]
                }
            ]
        }
        
        # 保存配置
        config_path = "custom_test_config.json"
        with open(config_path, 'w', encoding='utf-8') as f:
            json.dump(custom_config, f, ensure_ascii=False, indent=2)
        
        print(f"📝 创建自定义测试配置: {config_path}")
        print("📋 配置内容:")
        print(json.dumps(custom_config, ensure_ascii=False, indent=2))
        
        # 运行自定义测试
        print("\n🚀 运行自定义测试...")
        from 石器时代测试运行器 import StoneAgeTestRunner
        
        runner = StoneAgeTestRunner()
        result = runner.run_test_suite(config_path)
        
        print(f"✅ 自定义测试完成!")
        print(f"  通过: {result.passed_tests}/{result.total_tests}")
        
        print("\n✅ 自定义测试创建完成!")
        
    except Exception as e:
        print(f"❌ 创建失败: {e}")

def main():
    """主演示函数"""
    print("\n" + "=" * 60)
    print("🎯 石器时代脚本测试框架完整演示")
    print("=" * 60)
    
    # 检查必要文件
    required_files = ["示例石器时代脚本.asc", "石器时代脚本测试配置.json"]
    missing_files = [f for f in required_files if not os.path.exists(f)]
    
    if missing_files:
        print("⚠️  缺少必要文件:")
        for file in missing_files:
            print(f"  - {file}")
        print("\n请确保所有演示文件都存在。")
        return
    
    # 运行演示
    demos = [
        demo_1_parse_script,
        demo_2_generate_test_cases,
        demo_3_run_tests,
        demo_4_quick_test,
        demo_5_create_custom_test
    ]
    
    for i, demo in enumerate(demos, 1):
        demo()
        if i < len(demos):
            input(f"\n⏎ 按Enter键继续下一个演示...")
            print("\n" + "=" * 60)
    
    print("\n" + "=" * 60)
    print("🎉 所有演示完成!")
    print("=" * 60)
    
    # 总结
    print("\n📚 学习总结:")
    print("1. ✅ 学会了如何解析石器时代脚本")
    print("2. ✅ 学会了如何生成测试用例")
    print("3. ✅ 学会了如何运行测试套件")
    print("4. ✅ 学会了如何进行快速测试")
    print("5. ✅ 学会了如何创建自定义测试")
    
    print("\n🚀 下一步:")
    print("1. 🔧 使用框架测试您自己的石器时代脚本")
    print("2. 📈 根据测试结果优化脚本")
    print("3. 🔄 集成到您的开发工作流中")
    print("4. 🤝 分享您的测试经验和改进建议")
    
    print("\n💡 提示:")
    print("- 查看 'test_results/' 目录获取详细测试报告")
    print("- 修改 '石器时代脚本测试配置.json' 自定义测试")
    print("- 运行 'python 石器时代测试运行器.py --help' 查看所有选项")
    
    print("\n🎮 祝您石器时代脚本开发顺利!")

if __name__ == "__main__":
    main()