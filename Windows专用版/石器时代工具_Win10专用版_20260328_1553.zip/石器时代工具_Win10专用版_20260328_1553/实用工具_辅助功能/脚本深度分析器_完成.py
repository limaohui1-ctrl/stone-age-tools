#!/usr/bin/env python3
"""
脚本深度分析器 - 完成版本
深度分析原作者的所有逻辑和经验
"""

import os
import re
from datetime import datetime
from pathlib import Path

class ScriptDeepAnalyzer:
    def __init__(self):
        self.base_dir = Path("/root/.openclaw/workspace/石器时代知识库")
        
    def deep_analyze_script(self, script_path):
        """深度分析脚本"""
        script_name = Path(script_path).name
        print(f"🔍 深度分析: {script_name}")
        print("=" * 60)
        
        with open(script_path, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read()
        
        # 执行深度分析
        analysis = self.perform_deep_analysis(content, script_name)
        
        # 生成分析报告
        report = self.generate_analysis_report(analysis, script_name)
        
        # 保存报告
        report_dir = self.base_dir / "分析报告"
        report_dir.mkdir(parents=True, exist_ok=True)
        report_path = report_dir / f"{script_name}_深度分析报告.md"
        
        with open(report_path, 'w', encoding='utf-8') as f:
            f.write(report)
        
        print(f"📄 深度分析报告已生成: {report_path}")
        return analysis, report_path
    
    def perform_deep_analysis(self, content, script_name):
        """执行深度分析"""
        lines = content.split('\n')
        
        analysis = {
            'script_name': script_name,
            'analysis_time': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'total_lines': len(lines),
            'logic_categories': {},
            'time_parameters': [],
            'error_handling': [],
            'special_functions': [],
            'author_experience': [],
            'configuration_items': [],
            'key_decisions': [],
            'learning_points': []
        }
        
        # 分析逻辑分类
        analysis['logic_categories'] = self.analyze_logic_categories(content)
        
        # 分析时间参数
        analysis['time_parameters'] = self.analyze_time_parameters(content)
        
        # 分析错误处理
        analysis['error_handling'] = self.analyze_error_handling(content)
        
        # 分析特殊功能
        analysis['special_functions'] = self.analyze_special_functions(content)
        
        # 分析作者经验
        analysis['author_experience'] = self.analyze_author_experience(content)
        
        # 分析配置项
        analysis['configuration_items'] = self.analyze_configuration_items(content)
        
        # 分析关键决策
        analysis['key_decisions'] = self.analyze_key_decisions(content)
        
        # 提取学习要点
        analysis['learning_points'] = self.extract_learning_points(content, analysis)
        
        return analysis
    
    def analyze_logic_categories(self, content):
        """分析逻辑分类"""
        categories = {
            'initialization': {'count': 0, 'examples': []},
            'configuration': {'count': 0, 'examples': []},
            'team_management': {'count': 0, 'examples': []},
            'combat_logic': {'count': 0, 'examples': []},
            'movement_logic': {'count': 0, 'examples': []},
            'item_management': {'count': 0, 'examples': []},
            'error_recovery': {'count': 0, 'examples': []},
            'user_interaction': {'count': 0, 'examples': []},
            'timing_control': {'count': 0, 'examples': []},
            'special_mechanics': {'count': 0, 'examples': []}
        }
        
        lines = content.split('\n')
        
        for i, line in enumerate(lines, 1):
            line = line.strip()
            if not line or line.startswith("'"):
                continue
            
            # 初始化逻辑
            if any(keyword in line for keyword in ['dim ', 'let ', 'set ', 'call ']):
                if '初始化' in line or '开始' in line:
                    categories['initialization']['count'] += 1
                    if len(categories['initialization']['examples']) < 3:
                        categories['initialization']['examples'].append(f"行{i}: {line[:50]}")
            
            # 配置逻辑
            if 'let @d' in line or 'let @���' in line or '修改' in line or '改为' in line:
                categories['configuration']['count'] += 1
                if len(categories['configuration']['examples']) < 3:
                    categories['configuration']['examples'].append(f"行{i}: {line[:50]}")
            
            # 队伍管理
            if any(keyword in line for keyword in ['join', '队伍', '队友', 'check 队伍']):
                categories['team_management']['count'] += 1
                if len(categories['team_management']['examples']) < 3:
                    categories['team_management']['examples'].append(f"行{i}: {line[:50]}")
            
            # 战斗逻辑
            if any(keyword in line for keyword in ['attack', 'skill', '战斗', '血量', '宠物']):
                categories['combat_logic']['count'] += 1
                if len(categories['combat_logic']['examples']) < 3:
                    categories['combat_logic']['examples'].append(f"行{i}: {line[:50]}")
            
            # 移动逻辑
            if any(keyword in line for keyword in ['walkpos', 'waitpos', '移动', '坐标']):
                categories['movement_logic']['count'] += 1
                if len(categories['movement_logic']['examples']) < 3:
                    categories['movement_logic']['examples'].append(f"行{i}: {line[:50]}")
            
            # 物品管理
            if any(keyword in line for keyword in ['useitem', 'ifitem', '物品', '丢弃', '检查']):
                categories['item_management']['count'] += 1
                if len(categories['item_management']['examples']) < 3:
                    categories['item_management']['examples'].append(f"行{i}: {line[:50]}")
            
            # 错误恢复
            if any(keyword in line for keyword in ['goto', '错误', '恢复', '重试', '超时']):
                categories['error_recovery']['count'] += 1
                if len(categories['error_recovery']['examples']) < 3:
                    categories['error_recovery']['examples'].append(f"行{i}: {line[:50]}")
            
            # 用户交互
            if any(keyword in line for keyword in ['input', 'msg', '提示', '选择', '用户']):
                categories['user_interaction']['count'] += 1
                if len(categories['user_interaction']['examples']) < 3:
                    categories['user_interaction']['examples'].append(f"行{i}: {line[:50]}")
            
            # 时间控制
            if any(keyword in line for keyword in ['delay', 'wait', '时间', '计时', '@time']):
                categories['timing_control']['count'] += 1
                if len(categories['timing_control']['examples']) < 3:
                    categories['timing_control']['examples'].append(f"行{i}: {line[:50]}")
            
            # 特殊机制
            if any(keyword in line for keyword in ['声望', '海底', '特殊', '机制', '专属']):
                categories['special_mechanics']['count'] += 1
                if len(categories['special_mechanics']['examples']) < 3:
                    categories['special_mechanics']['examples'].append(f"行{i}: {line[:50]}")
        
        return categories
    
    def analyze_time_parameters(self, content):
        """分析时间参数"""
        time_params = []
        
        # 查找所有时间相关设置
        time_patterns = [
            r'delay\s+(\d+)',
            r'wait\s+(\d+)',
            r'let @time',
            r'set.*ʱ',
            r'@\[tick\]'
        ]
        
        for pattern in time_patterns:
            matches = re.finditer(pattern, content, re.IGNORECASE)
            for match in matches:
                if pattern == r'delay\s+(\d+)':
                    time = match.group(1)
                    time_params.append({
                        'type': 'delay',
                        'value': f"{time}ms",
                        'context': match.group(0)[:50],
                        'analysis': self.analyze_delay_time(int(time))
                    })
                elif pattern == r'let @time':
                    time_params.append({
                        'type': 'timer_variable',
                        'value': '计时器变量',
                        'context': match.group(0)[:50],
                        'analysis': '用于时间控制和检测'
                    })
        
        return time_params
    
    def analyze_delay_time(self, ms):
        """分析延迟时间"""
        if ms < 100:
            return "快速响应，用于即时操作"
        elif ms < 1000:
            return f"短等待 ({ms}ms)，用于网络响应"
        elif ms < 5000:
            return f"中等等待 ({ms/1000:.1f}秒)，用于对话框或状态检查"
        else:
            return f"长等待 ({ms/1000:.1f}秒)，用于地图切换或复杂操作"
    
    def analyze_error_handling(self, content):
        """分析错误处理"""
        error_handling = []
        
        # 查找错误处理逻辑
        lines = content.split('\n')
        
        for i, line in enumerate(lines, 1):
            line = line.strip()
            
            # 检查错误跳转
            if 'goto' in line and ('错误' in line or '失败' in line or '超时' in line):
                error_handling.append({
                    'line': i,
                    'type': '错误跳转',
                    'code': line[:50],
                    'analysis': '检测到错误时跳转到处理流程'
                })
            
            # 检查重试逻辑
            if any(keyword in line for keyword in ['重试', 'retry', '再次', '重新']):
                error_handling.append({
                    'line': i,
                    'type': '重试机制',
                    'code': line[:50],
                    'analysis': '失败后自动重试'
                })
            
            # 检查超时检测
            if any(keyword in line for keyword in ['超时', 'timeout', '> 60', '> 30']):
                error_handling.append({
                    'line': i,
                    'type': '超时检测',
                    'code': line[:50],
                    'analysis': '检测操作是否超时'
                })
        
        return error_handling
    
    def analyze_special_functions(self, content):
        """分析特殊功能"""
        special_funcs = []
        
        # 查找函数定义
        func_pattern = r'function\s+(\S+)'
        matches = re.finditer(func_pattern, content, re.IGNORECASE)
        
        for match in matches:
            func_name = match.group(1)
            
            # 分析函数用途
            analysis = self.analyze_function_purpose(func_name, content)
            
            special_funcs.append({
                'name': func_name,
                'analysis': analysis
            })
        
        return special_funcs
    
    def analyze_function_purpose(self, func_name, content):
        """分析函数用途"""
        if '初始化' in func_name or '开始' in func_name:
            return "初始化函数，设置初始状态"
        elif '检查' in func_name or '检测' in func_name:
            return "检查函数，验证状态或条件"
        elif '移动' in func_name or '行走' in func_name:
            return "移动函数，控制角色移动"
        elif '战斗' in func_name or '攻击' in func_name:
            return "战斗函数，处理战斗逻辑"
        elif '物品' in func_name or '道具' in func_name:
            return "物品函数，管理物品使用"
        elif '错误' in func_name or '恢复' in func_name:
            return "错误处理函数，处理异常情况"
        elif '时间' in func_name or '计时' in func_name:
            return "时间函数，控制时间相关逻辑"
        else:
            return "通用功能函数"
    
    def analyze_author_experience(self, content):
        """分析作者经验"""
        experiences = []
        
        # 查找注释中的经验说明
        lines = content.split('\n')
        
        for i, line in enumerate(lines, 1):
            line = line.strip()
            
            # 注释中的经验说明
            if line.startswith("'"):
                comment = line[1:].strip()
                
                # 识别经验类注释
                if any(keyword in comment for keyword in ['经验', '建议', '推荐', '注意', '重要', '提示']):
                    experiences.append({
                        'line': i,
                        'type': '经验注释',
                        'content': comment[:100],
                        'analysis': '作者的游戏经验或建议'
                    })
                
                # 识别配置说明
                if any(keyword in comment for keyword in ['修改', '改为', '设置', '配置', '调整']):
                    experiences.append({
                        'line': i,
                        'type': '配置说明',
                        'content': comment[:100],
                        'analysis': '配置项的说明和建议'
                    })
        
        return experiences
    
    def analyze_configuration_items(self, content):
        """分析配置项"""
        config_items = []
        
        # 查找配置项
        lines = content.split('\n')
        
        for i, line in enumerate(lines, 1):
            line = line.strip()
            
            # 变量设置
            if line.startswith('let @'):
                parts = line.split(',')
                if len(parts) >= 3:
                    var_name = parts[0].replace('let ', '').strip()
                    var_value = parts[2].strip()
                    
                    config_items.append({
                        'line': i,
                        'variable': var_name,
                        'value': var_value,
                        'description': self.get_variable_description(var_name, line)
                    })
            
            # set指令
            elif line.startswith('set '):
                parts = line.split(',')
                if len(parts) >= 2:
                    setting = parts[0].replace('set ', '').strip()
                    value = parts[1].strip()
                    
                    config_items.append({
                        'line': i,
                        'setting': setting,
                        'value': value,
                        'description': self.get_setting_description(setting, line)
                    })
        
        return config_items
    
    def get_variable_description(self, var_name, line):
        """获取变量描述"""
        if 'd1' in var_name or 'd2' in var_name or 'd3' in var_name or 'd4' in var_name:
            return "队友名称配置，需要修改为自己的队友名"
        elif 'X' in var_name or 'Y' in var_name:
            return "坐标配置，控制移动位置"
        elif 'time' in var_name:
            return "时间相关变量，用于计时和控制"
        elif 'name' in var_name:
            return "名称相关变量，用于角色或物品名"
        else:
            return "通用变量"
    
    def get_setting_description(self, setting, line):
        """获取设置描述"""
        if '血量' in setting:
            return "血量相关设置，控制自动补血"
        elif '战斗' in setting:
            return "战斗相关设置，控制战斗行为"
        elif '自动' in setting:
            return "自动化设置，控制自动功能"
        elif '宠物' in setting:
            return "宠物相关设置，控制宠物行为"
        else:
            return "游戏设置"
    
    def analyze_key_decisions(self, content):
        """分析关键决策"""
        decisions = []
        
        # 查找关键决策点
        lines = content.split('\n')
        
        for i, line in enumerate(lines, 1):
            line = line.strip()
            
            # 条件判断
            if line.startswith('if '):
                decisions.append({
                    'line': i,
                    'type': '条件判断',
                    'decision': line[:80],
                    'analysis': '根据条件执行不同分支'
                })
            
            # 用户选择
            elif 'input' in line:
                decisions.append({
                    'line': i,
                    'type': '用户选择',
                    'decision': line[:80],
                    'analysis': '等待用户输入选择'
                })
            
            # 跳转决策
            elif line.startswith('goto ') and not line.startswith('goto +') and not line.startswith('goto -'):
                decisions.append({
                    'line': i,
                    'type': '流程跳转',
                    'decision': line[:80],
                    'analysis': '跳转到指定标签继续执行'
                })
        
        return decisions
    
    def extract_learning_points(self, content, analysis):
        """提取学习要点"""
        learning_points = []
        
        # 从分析结果中提取学习要点
        learning_points.append({
            'category': '脚本结构',
            'point': f"脚本包含 {analysis['total_lines']} 行代码，结构完整",
            'value': '了解完整脚本的代码量级'
        })
        
        # 逻辑分类学习
        total_categories = sum(cat['count'] for cat in analysis['logic_categories'].values())
        learning_points.append({
            'category': '逻辑分布',
            'point': f"脚本逻辑分布在 {len(analysis['logic_categories'])} 个分类中，共 {total_categories} 个逻辑点",
            'value': '了解脚本的功能分布'
        })
        
        # 时间参数学习
        if analysis['time_parameters']:
            learning_points.append({
                'category': '时间控制',
                'point': f"脚本包含 {len(analysis['time_parameters'])} 个时间参数控制点",
                'value': '了解脚本的时间控制策略'
            })
        
        # 错误处理学习
        if analysis['error_handling']:
            learning_points.append({
                'category': '错误处理',
                'point': f"脚本包含