#!/usr/bin/env python3
"""
石器时代脚本测试框架
自动化测试和验证脚本功能
"""

import os
import re
import time
import json
from datetime import datetime
from pathlib import Path

class ScriptTestFramework:
    def __init__(self):
        self.base_dir = Path("/root/.openclaw/workspace/石器时代知识库")
        self.test_dir = self.base_dir / "开发工具链" / "测试"
        self.results_dir = self.test_dir / "结果"
        
        # 创建目录
        self.test_dir.mkdir(parents=True, exist_ok=True)
        self.results_dir.mkdir(parents=True, exist_ok=True)
        
        # 测试配置
        self.config = {
            'network_test': {
                'enabled': True,
                'timeout_tests': True,
                'retry_tests': True,
                'stuck_detection': True
            },
            'ng25_test': {
                'enabled': True,
                'name_validation': True,
                'compatibility': True
            },
            'performance_test': {
                'enabled': True,
                'execution_time': True,
                'memory_usage': False,
                'stability': True
            },
            'functional_test': {
                'enabled': True,
                'basic_functions': True,
                'error_handling': True,
                'completion': True
            }
        }
    
    def test_script(self, script_path, test_types=None):
        """测试脚本"""
        script_name = Path(script_path).name
        
        print(f"🧪 开始测试脚本: {script_name}")
        print("=" * 60)
        
        # 读取脚本内容
        with open(script_path, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read()
        
        # 执行测试
        results = {
            'script': script_name,
            'test_time': datetime.now().isoformat(),
            'tests': {}
        }
        
        # 基本语法测试
        if not test_types or 'syntax' in test_types:
            results['tests']['syntax'] = self.test_syntax(content)
        
        # 网络优化测试
        if not test_types or 'network' in test_types:
            if self.config['network_test']['enabled']:
                results['tests']['network'] = self.test_network_optimization(content)
        
        # NG25适配测试
        if not test_types or 'ng25' in test_types:
            if self.config['ng25_test']['enabled']:
                results['tests']['ng25'] = self.test_ng25_adaptation(content)
        
        # 性能测试
        if not test_types or 'performance' in test_types:
            if self.config['performance_test']['enabled']:
                results['tests']['performance'] = self.test_performance(content)
        
        # 功能测试
        if not test_types or 'functional' in test_types:
            if self.config['functional_test']['enabled']:
                results['tests']['functional'] = self.test_functional(content)
        
        # 生成测试报告
        report = self.generate_test_report(results)
        
        # 保存结果
        result_file = self.results_dir / f"{script_name}_测试结果_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        with open(result_file, 'w', encoding='utf-8') as f:
            json.dump(results, f, ensure_ascii=False, indent=2)
        
        print(f"📊 测试结果已保存: {result_file}")
        
        return results, report
    
    def test_syntax(self, content):
        """测试脚本语法"""
        print("🔍 执行语法测试...")
        
        results = {
            'passed': 0,
            'failed': 0,
            'warnings': 0,
            'issues': []
        }
        
        lines = content.split('\n')
        
        for i, line in enumerate(lines, 1):
            line = line.strip()
            if not line or line.startswith('//'):
                continue
            
            # 检查常见语法问题
            issues = []
            
            # 检查标签定义
            if line.startswith('label ') and ':' not in line:
                issues.append("标签定义缺少冒号")
            
            # 检查函数定义
            if line.startswith('function ') and ':' not in line:
                issues.append("函数定义缺少冒号")
            
            # 检查set指令
            if line.startswith('set ') and '=' not in line:
                issues.append("set指令缺少等号")
            
            # 检查wait指令格式
            if 'wait ' in line and not re.search(r'wait\s+\d+', line):
                issues.append("wait指令参数格式不正确")
            
            # 检查if指令格式
            if line.startswith('if ') and ',' not in line:
                issues.append("if指令缺少逗号分隔符")
            
            if issues:
                results['failed'] += 1
                results['issues'].append({
                    'line': i,
                    'content': line[:50] + ('...' if len(line) > 50 else ''),
                    'issues': issues
                })
            else:
                results['passed'] += 1
        
        print(f"  通过: {results['passed']}, 失败: {results['failed']}, 警告: {results['warnings']}")
        return results
    
    def test_network_optimization(self, content):
        """测试网络优化"""
        print("🌐 执行网络优化测试...")
        
        results = {
            'timeout_mechanism': {'passed': False, 'details': ''},
            'retry_mechanism': {'passed': False, 'details': ''},
            'stuck_detection': {'passed': False, 'details': ''},
            'error_handling': {'passed': False, 'details': ''},
            'score': 0,
            'total': 4
        }
        
        # 检查超时机制
        timeout_patterns = [
            r'waitdlg\s+[^,]+,\s*\d+',
            r'waitpos\s+[^,]+,[^,]+,\s*\d+',
            r'waitmap\s+[^,]+,\s*\d+'
        ]
        
        has_timeout = False
        for pattern in timeout_patterns:
            if re.search(pattern, content, re.IGNORECASE):
                has_timeout = True
                break
        
        if has_timeout:
            results['timeout_mechanism']['passed'] = True
            results['timeout_mechanism']['details'] = '检测到超时机制'
            results['score'] += 1
        else:
            results['timeout_mechanism']['details'] = '缺少超时机制'
        
        # 检查重试机制
        retry_patterns = [
            r'retry',
            r'goto.*retry',
            r'inc.*retry'
        ]
        
        has_retry = False
        for pattern in retry_patterns:
            if re.search(pattern, content, re.IGNORECASE):
                has_retry = True
                break
        
        if has_retry:
            results['retry_mechanism']['passed'] = True
            results['retry_mechanism']['details'] = '检测到重试机制'
            results['score'] += 1
        else:
            results['retry_mechanism']['details'] = '缺少重试机制'
        
        # 检查防卡检测
        stuck_patterns = [
            r'check_stuck',
            r'stuck',
            r'卡住',
            r'防卡'
        ]
        
        has_stuck_detection = False
        for pattern in stuck_patterns:
            if re.search(pattern, content, re.IGNORECASE):
                has_stuck_detection = True
                break
        
        if has_stuck_detection:
            results['stuck_detection']['passed'] = True
            results['stuck_detection']['details'] = '检测到防卡机制'
            results['score'] += 1
        else:
            results['stuck_detection']['details'] = '缺少防卡机制'
        
        # 检查错误处理
        error_patterns = [
            r'error',
            r'错误',
            r'label.*error',
            r'goto.*error'
        ]
        
        has_error_handling = False
        for pattern in error_patterns:
            if re.search(pattern, content, re.IGNORECASE):
                has_error_handling = True
                break
        
        if has_error_handling:
            results['error_handling']['passed'] = True
            results['error_handling']['details'] = '检测到错误处理'
            results['score'] += 1
        else:
            results['error_handling']['details'] = '缺少错误处理'
        
        print(f"  网络优化得分: {results['score']}/{results['total']}")
        return results
    
    def test_ng25_adaptation(self, content):
        """测试NG25适配"""
        print("🎮 执行NG25适配测试...")
        
        results = {
            'name_checkpoints': {'passed': False, 'details': ''},
            'safe_functions': {'passed': False, 'details': ''},
            'compatibility': {'passed': False, 'details': ''},
            'score': 0,
            'total': 3
        }
        
        # 检查名称检查点
        checkpoint_patterns = [
            r'check_map_names',
            r'check_npc_names',
            r'check_pet_names',
            r'check_item_names'
        ]
        
        has_checkpoints = False
        checkpoints_found = []
        for pattern in checkpoint_patterns:
            if re.search(pattern, content):
                has_checkpoints = True
                checkpoints_found.append(pattern)
        
        if has_checkpoints:
            results['name_checkpoints']['passed'] = True
            results['name_checkpoints']['details'] = f'检测到名称检查点: {", ".join(checkpoints_found)}'
            results['score'] += 1
        else:
            results['name_checkpoints']['details'] = '缺少名称检查点'
        
        # 检查安全函数
        safe_function_patterns = [
            r'waitdlg_safe',
            r'waitpos_safe',
            r'walk_safe'
        ]
        
        has_safe_functions = False
        safe_functions_found = []
        for pattern in safe_function_patterns:
            if re.search(pattern, content):
                has_safe_functions = True
                safe_functions_found.append(pattern)
        
        if has_safe_functions:
            results['safe_functions']['passed'] = True
            results['safe_functions']['details'] = f'检测到安全函数: {", ".join(safe_functions_found)}'
            results['score'] += 1
        else:
            results['safe_functions']['details'] = '缺少安全函数'
        
        # 检查兼容性注释
        compatibility_patterns = [
            r'NG25',
            r'适配',
            r'兼容',
            r'私服'
        ]
        
        has_compatibility = False
        for pattern in compatibility_patterns:
            if re.search(pattern, content):
                has_compatibility = True
                break
        
        if has_compatibility:
            results['compatibility']['passed'] = True
            results['compatibility']['details'] = '检测到兼容性考虑'
            results['score'] += 1
        else:
            results['compatibility']['details'] = '缺少兼容性考虑'
        
        print(f"  NG25适配得分: {results['score']}/{results['total']}")
        return results
    
    def test_performance(self, content):
        """测试性能"""
        print("⚡ 执行性能测试...")
        
        results = {
            'execution_efficiency': {'passed': False, 'details': ''},
            'resource_usage': {'passed': False, 'details': ''},
            'stability': {'passed': False, 'details': ''},
            'score': 0,
            'total': 3
        }
        
        # 分析脚本结构
        lines = content.split('\n')
        
        # 检查执行效率（等待时间）
        total_wait_time = 0
        wait_pattern = r'wait\s+(\d+)'
        
        for line in lines:
            match = re.search(wait_pattern, line)
            if match:
                try:
                    wait_time = int(match.group(1))
                    total_wait_time += wait_time
                except:
                    pass
        
        if total_wait_time < 30000:  # 总等待时间小于30秒
            results['execution_efficiency']['passed'] = True
            results['execution_efficiency']['details'] = f'总等待时间合理: {total_wait_time}ms'
            results['score'] += 1
        else:
            results['execution_efficiency']['details'] = f'总等待时间较长: {total_wait_time}ms'
        
        # 检查资源使用（循环和嵌套）
        loop_count = content.count('loop') + content.count('goto')
        if loop_count < 20:
            results['resource_usage']['passed'] = True
            results['resource_usage']['details'] = f'循环结构合理: {loop_count}个'
            results['score'] += 1
        else:
            results['resource_usage']['details'] = f'循环结构较多: {loop_count}个'
        
        # 检查稳定性（错误处理）
        error_handling_count = content.count('error') + content.count('错误')
        if error_handling_count > 0:
            results['stability']['passed'] = True
            results['stability']['details'] = f'错误处理机制: {error_handling_count}处'
            results['score'] += 1
        else:
            results['stability']['details'] = '缺少错误处理机制'
        
        print(f"  性能测试得分: {results['score']}/{results['total']}")
        return results
    
    def test_functional(self, content):
        """测试功能完整性"""
        print("🔧 执行功能测试...")
        
        results = {
            'basic_functions': {'passed': False, 'details': ''},
            'error_handling': {'passed': False, 'details': ''},
            'completion': {'passed': False, 'details': ''},
            'score': 0,
            'total': 3
        }
        
        # 检查基本功能
        has_start = 'label start' in content
        has_main_logic = 'main_logic' in content or '主逻辑' in content
        has_finish = 'label finish' in content or 'stop' in content
        
        if has_start and has_main_logic and has_finish:
            results['basic_functions']['passed'] = True
            results['basic_functions']['details'] = '基本功能完整'
            results['score'] += 1
        else:
            missing = []
            if not has_start:
                missing.append('start标签')
            if not has_main_logic:
                missing.append('主逻辑')
            if not has_finish:
                missing.append('结束处理')
            results['basic_functions']['details'] = f'缺少: {", ".join(missing)}'
        
        # 检查错误处理
        has_error_label = 'label error' in content or 'label.*error' in content.lower()
        has_logging = 'log' in content
        
        if has_error_label and has_logging:
            results['error_handling']['passed'] = True
            results['error_handling']['details'] = '错误处理和日志完整'
            results['score'] += 1
        else:
            missing = []
            if not has_error_label:
                missing.append('错误处理标签')
            if not has_logging:
                missing.append('日志记录')
            results['error_handling']['details'] = f'缺少: {", ".join(missing)}'
        
        # 检查完成度
        has_comments = content.count('//') > 5
        has_functions = 'function' in content
        has_config = 'set ' in content
        
        if has_comments and has_functions and has_config:
            results['completion']['passed'] = True
            results['completion']['details'] = '脚本完成度高'
            results['score'] += 1
        else:
            missing = []
            if not has_comments:
                missing.append('注释')
            if not has_functions:
                missing.append('函数')
            if not has_config:
                missing.append('配置')
            results['completion']['details'] = f'缺少: {", ".join(missing)}'
        
        print(f"  功能测试得分: {results['score']}/{results['total']}")
        return results
    
    def generate_test_report(self, results):
        """生成测试报告"""
        script_name = results['script']
        test_time = results['test_time']
        
        report = f"# 🧪 脚本测试报告: {script_name}\n\n"
        report += f"**测试时间**: {test_time}\n\n"
        
        # 总体评分
        total_score = 0
        total_max = 0
        
        for test_name, test_results in results['tests'].items():
            if 'score' in test_results and 'total' in test_results:
                total_score += test_results['score']
                total_max += test_results['total']
        
        overall_score = (total_score / total_max * 100) if total_max > 0 else 0
        
        report += "## 📊 总体评分\n\n"
        report += f"**综合得分**: {overall_score:.1f}% ({total_score}/{total_max})\n\n"
        
        # 各测试详情
        for test_name, test_results in results['tests'].items():
            test_title = {
                'syntax': '语法测试',
                'network': '网络优化测试',
                'ng25': 'NG25适配测试',
                'performance': '性能测试',
                'functional': '功能测试'
            }.get(test_name, test_name)
            
            report += f"## 🔍 {test_title}\n\n"
            
            if 'score' in test_results:
                score