#!/usr/bin/env python3
"""
NG25名称验证工具
帮助验证脚本中的地图、NPC、宠物名称是否适配NG25私服
"""

import os
import re
from datetime import datetime

class NG25NameValidator:
    def __init__(self):
        # NG25私服已知名称（需要你根据实际情况补充）
        self.ng25_known_names = {
            # 地图名称（确认在NG25中可用的）
            'maps': [
                '渔村', '福村', '萨村', '加加村', '卡鲁他那村', '达那村',
                '沙姆岛', '奇咯咯', '多多村', '小小村', '霍比特村', '南卡村',
                '塔姆村', '柯奥村', '特尔坷村', '米兰达', '伊甸园',
                '地城', '水城', '火城', '风城', '冰城'
            ],
            
            # NPC名称（确认在NG25中可用的）
            'npcs': [
                '商人', '银行职员', '宠物店', '医院', '村长', '传送员',
                '任务管理员', '魔王', '女神', '守卫', '导师', '精灵'
            ],
            
            # 宠物名称（确认在NG25中可用的）
            'pets': [
                '人龙', '雷龙', '老虎', '暴龙', '机暴', '金虎', '红虎',
                '绿虎', '蓝虎', '黄虎', '红人龙', '蓝人龙', '绿人龙',
                '黄人龙', '灰人龙', '红雷', '蓝雷', '绿雷', '黄雷', '灰雷'
            ],
            
            # 物品名称（确认在NG25中可用的）
            'items': [
                '羽毛', '石币', '药水', '武器', '防具', '饰品', '任务物品',
                '证明', '证书', '材料', '宝石', '矿石', '木材', '皮革'
            ]
        }
        
        # 需要特别注意的名称（可能在NG25中有不同名称）
        self.special_attention = {
            # 地图名称差异
            'maps_diff': {
                # '原名称': 'NG25名称',
                # 例如: '渔村': '渔人村',
                # 根据实际情况补充
            },
            
            # NPC名称差异
            'npcs_diff': {
                # '原名称': 'NG25名称',
            },
            
            # 宠物名称差异
            'pets_diff': {
                # '原名称': 'NG25名称',
            },
            
            # 物品名称差异
            'items_diff': {
                # '原名称': 'NG25名称',
            }
        }
    
    def extract_names_from_script(self, script_path):
        """从脚本中提取所有名称"""
        with open(script_path, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read()
        
        names = {
            'maps': set(),
            'npcs': set(),
            'pets': set(),
            'items': set(),
            'unknown': set()
        }
        
        lines = content.split('\n')
        
        for line in lines:
            line = line.strip()
            if not line or line.startswith('//'):
                continue
            
            # 提取可能的名称（中文、英文、数字组合）
            # 匹配中文字符
            chinese_pattern = re.compile(r'[\u4e00-\u9fff]+')
            chinese_matches = chinese_pattern.findall(line)
            
            for match in chinese_matches:
                if len(match) >= 2:  # 至少2个字符才认为是名称
                    # 分类名称
                    if any(map_word in match for map_word in ['村', '城', '岛', '洞', '窟']):
                        names['maps'].add(match)
                    elif any(npc_word in match for npc_word in ['商', '员', '店', '院', '长', '员', '神', '王', '卫']):
                        names['npcs'].add(match)
                    elif any(pet_word in match for pet_word in ['龙', '虎', '暴', '兽', '宠', '物']):
                        names['pets'].add(match)
                    elif any(item_word in match for item_word in ['羽', '币', '药', '器', '具', '饰', '证', '石', '材']):
                        names['items'].add(match)
                    else:
                        names['unknown'].add(match)
        
        # 转换为列表并排序
        for key in names:
            names[key] = sorted(list(names[key]))
        
        return names
    
    def validate_names(self, extracted_names):
        """验证名称是否适配NG25"""
        validation = {
            'confirmed': [],      # 确认在NG25中可用的
            'needs_check': [],    # 需要检查的
            'likely_diff': [],    # 可能不同的
            'unknown': []         # 未知的
        }
        
        # 检查地图名称
        for map_name in extracted_names.get('maps', []):
            if map_name in self.ng25_known_names['maps']:
                validation['confirmed'].append(('地图', map_name, '✅ 确认可用'))
            elif map_name in self.special_attention['maps_diff']:
                ng25_name = self.special_attention['maps_diff'][map_name]
                validation['likely_diff'].append(('地图', map_name, f'⚠️ 可能不同: {map_name} → {ng25_name}'))
            else:
                validation['needs_check'].append(('地图', map_name, '❓ 需要确认'))
        
        # 检查NPC名称
        for npc_name in extracted_names.get('npcs', []):
            if npc_name in self.ng25_known_names['npcs']:
                validation['confirmed'].append(('NPC', npc_name, '✅ 确认可用'))
            elif npc_name in self.special_attention['npcs_diff']:
                ng25_name = self.special_attention['npcs_diff'][npc_name]
                validation['likely_diff'].append(('NPC', npc_name, f'⚠️ 可能不同: {npc_name} → {ng25_name}'))
            else:
                validation['needs_check'].append(('NPC', npc_name, '❓ 需要确认'))
        
        # 检查宠物名称
        for pet_name in extracted_names.get('pets', []):
            if pet_name in self.ng25_known_names['pets']:
                validation['confirmed'].append(('宠物', pet_name, '✅ 确认可用'))
            elif pet_name in self.special_attention['pets_diff']:
                ng25_name = self.special_attention['pets_diff'][pet_name]
                validation['likely_diff'].append(('宠物', pet_name, f'⚠️ 可能不同: {pet_name} → {ng25_name}'))
            else:
                validation['needs_check'].append(('宠物', pet_name, '❓ 需要确认'))
        
        # 检查物品名称
        for item_name in extracted_names.get('items', []):
            if item_name in self.ng25_known_names['items']:
                validation['confirmed'].append(('物品', item_name, '✅ 确认可用'))
            elif item_name in self.special_attention['items_diff']:
                ng25_name = self.special_attention['items_diff'][item_name]
                validation['likely_diff'].append(('物品', item_name, f'⚠️ 可能不同: {item_name} → {ng25_name}'))
            else:
                validation['needs_check'].append(('物品', item_name, '❓ 需要确认'))
        
        # 未知名称
        for unknown_name in extracted_names.get('unknown', []):
            validation['unknown'].append(('未知', unknown_name, '🔍 需要分类'))
        
        return validation
    
    def generate_validation_report(self, script_path, extracted_names, validation):
        """生成验证报告"""
        script_name = os.path.basename(script_path)
        
        report = f"# 🔍 NG25名称验证报告: {script_name}\n\n"
        report += f"**验证时间**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n"
        
        # 统计信息
        total_names = sum(len(names) for names in extracted_names.values())
        confirmed = len(validation['confirmed'])
        needs_check = len(validation['needs_check'])
        likely_diff = len(validation['likely_diff'])
        unknown = len(validation['unknown'])
        
        report += "## 📊 验证统计\n\n"
        report += f"- **提取名称总数**: {total_names} 个\n"
        report += f"- **确认可用**: {confirmed} 个 ({confirmed/total_names*100:.1f}%)\n"
        report += f"- **需要确认**: {needs_check} 个 ({needs_check/total_names*100:.1f}%)\n"
        report += f"- **可能不同**: {likely_diff} 个 ({likely_diff/total_names*100:.1f}%)\n"
        report += f"- **未知分类**: {unknown} 个 ({unknown/total_names*100:.1f}%)\n\n"
        
        # 详细验证结果
        if validation['confirmed']:
            report += "## ✅ 确认可用的名称\n\n"
            for category, name, status in validation['confirmed']:
                report += f"- **{category}**: `{name}` - {status}\n"
            report += "\n"
        
        if validation['needs_check']:
            report += "## ❓ 需要确认的名称\n\n"
            report += "以下名称需要你在NG25私服中确认是否可用:\n\n"
            for category, name, status in validation['needs_check']:
                report += f"- **{category}**: `{name}`\n"
            report += "\n"
        
        if validation['likely_diff']:
            report += "## ⚠️ 可能不同的名称\n\n"
            report += "以下名称在NG25中可能使用不同名称:\n\n"
            for category, name, status in validation['likely_diff']:
                report += f"- {status}\n"
            report += "\n"
        
        if validation['unknown']:
            report += "## 🔍 未知分类的名称\n\n"
            report += "以下名称需要进一步分类:\n\n"
            for category, name, status in validation['unknown']:
                report += f"- `{name}`\n"
            report += "\n"
        
        # 提取的名称列表
        report += "## 📋 提取的名称列表\n\n"
        
        for category, name_list in extracted_names.items():
            if name_list:
                report += f"### {category.upper()}\n\n"
                for name in name_list:
                    report += f"- `{name}`\n"
                report += "\n"
        
        # NG25适配建议
        report += "## 🎯 NG25适配建议\n\n"
        
        report += "### 1. 验证步骤\n"
        report += "1. 在NG25私服中逐一测试需要确认的名称\n"
        report += "2. 记录实际可用的名称\n"
        report += "3. 更新名称映射表\n\n"
        
        report += "### 2. 测试方法\n"
        report += "- **地图名称**: 尝试传送到该地图\n"
        report += "- **NPC名称**: 尝试与该NPC对话\n"
        report += "- **宠物名称**: 尝试捕捉或查看该宠物\n"
        report += "- **物品名称**: 尝试购买或使用该物品\n\n"
        
        report += "### 3. 更新映射表\n"
        report += "将确认的结果更新到 `special_attention` 字典中:\n"
        report += "```python\n"
        report += "# 地图名称差异\n"
        report += "'maps_diff': {\n"
        report += "    '原名称': 'NG25名称',\n"
        report += "},\n"
        report += "```\n\n"
        
        report += "---\n"
        report += "*本报告由NG25名称验证工具自动生成*\n"
        
        return report
    
    def validate_script(self, script_path):
        """验证单个脚本"""
        print(f"🔍 验证脚本: {os.path.basename(script_path)}")
        
        # 提取名称
        extracted_names = self.extract_names_from_script(script_path)
        
        # 验证名称
        validation = self.validate_names(extracted_names)
        
        # 生成报告
        report = self.generate_validation_report(script_path, extracted_names, validation)
        
        return {
            'script': os.path.basename(script_path),
            'extracted_names': extracted_names,
            'validation': validation,
            'report': report
        }

def main():
    print("🔍 NG25名称验证工具")
    print("=" * 60)
    
    validator = NG25NameValidator()
    
    # 选择要验证的脚本
    scripts_dir = "/root/.openclaw/workspace/石器时代客户端处理/解压内容/sqng25/scripts/12.【副本活动】"
    
    # 查找所有副本脚本
    script_files = []
    for root, dirs, files in os.walk(scripts_dir):
        for file in files:
            if file.lower().endswith('.asc'):
                script_files.append(os.path.join(root, file))
    
    print(f"找到副本脚本: {len(script_files)} 个")
    print()
    
    for i, script_file in enumerate(script_files, 1):
        script_name = os.path.basename(script_file)
        print(f"{i}. {script_name}")
    
    print()
    print("请选择要验证的脚本 (输入序号，多个用逗号分隔，或输入'all'验证所有):")
    choice = input("> ").strip()
    
    results = []
    
    if choice.lower() == 'all':
        # 验证所有脚本
        for script_file in script_files:
            result = validator.validate_script(script_file)
            results.append(result)
    else:
        # 验证选择的脚本
        try:
            indices = [int(idx.strip()) for idx in choice.split(',')]
            for idx in indices:
                if 1 <= idx <= len(script_files):
                    script_file = script_files[idx-1]
                    result = validator.validate_script(script_file)
                    results.append(result)
                else:
                    print(f"❌ 无效序号: {idx}")
        except:
            print("❌ 无效输入")
            return
    
    if not results:
        print("❌ 没有验证任何脚本")
        return
    
    # 保存报告
    output_dir = "/root/.openclaw/workspace/NG25名称验证报告"
    os.makedirs(output_dir, exist_ok=True)
    
    for result in results:
        script_name = result['script']
        report_path = os.path.join(output_dir, f"{script_name}_验证报告.md")
        
        with open(report_path, 'w', encoding='utf-8') as f:
            f.write(result['report'])
        
        print(f"📄 报告已保存: {report_path}")
    
    # 生成总结报告
    summary = generate_summary_report(results)
    summary_path = os.path.join(output_dir, "验证总结报告.md")
    
    with open(summary_path, 'w', encoding='utf-8') as f:
        f.write(summary)
    
    print(f"\n📊 总结报告已保存: {summary_path}")
    print("🎉 名称验证完成!")

def generate_summary_report(results):
    """生成总结报告"""
    report = "# 📊 NG25名称验证总结报告\n\n"
    report += f"**生成时间**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n"
    report += f"**验证脚本**: {len(results)} 个\n\n"
    
    # 总体统计
    total_names = 0
    total_confirmed = 0
    total_needs_check = 0
    total_likely_diff = 0
    total_unknown = 0
    
    for result in results:
        validation = result['validation']
        total_confirmed += len(validation['confirmed'])
        total_needs_check += len(validation['needs_check'])
        total_likely_diff += len(validation['likely_diff'])
        total_unknown += len(validation['unknown'])
    
    total_names = total_confirmed + total_needs_check + total_likely_diff + total_unknown
    
    report += "## 📈 总体统计\n\n"
    report += f"- **验证脚本总数**: {len(results)} 个\n"
    report += f"- **提取名称总数**: {total_names} 个\n"
    report += f"- **确认可用**: {total_confirmed} 个 ({total_confirmed/total_names*100:.1f}%)\n"
    report += f"- **需要确认**: {total_needs_check} 个 ({total_needs_check/total_names*100:.1f}%)\n"
    report += f"- **可能不同**: {total_likely_diff} 个 ({total_likely_diff/total_names*100:.1f}%)\n"
    report += f"- **未知分类**: {total_unknown} 个 ({total_unknown/total_names*100:.1f}%)\n\n"
    
    # 各脚本详情
    report += "## 📋 各脚本验证结果\n\n"
    
    for result in results:
        script_name = result['script']
        validation = result['validation']
        
        confirmed = len(validation['confirmed'])
        needs_check = len(validation['needs_check'])
        likely_diff = len(validation['likely_diff'])
        unknown = len(validation['unknown'])
        total = confirmed + needs_check + likely_diff + unknown
        
        if total > 0:
            confirmed_percent = confirmed/total*100
            status = "✅ 良好" if confirmed_percent > 70 else "⚠️ 需注意" if