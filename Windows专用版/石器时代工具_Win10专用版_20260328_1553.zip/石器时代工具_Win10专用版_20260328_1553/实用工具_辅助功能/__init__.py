"""
石器时代游戏客户端集成工具包

提供完整的石器时代游戏客户端监控、数据读取和自动化控制功能。
"""

__version__ = "1.0.0"
__author__ = "石器时代脚本开发工具链"
__description__ = "石器时代游戏客户端集成工具套件"

# 导出主要模块
from .core.exceptions import *
from .core.config import Config
from .core.logger import Logger

from .monitor.client_monitor import ClientMonitor
from .monitor.window_manager import WindowManager
from .monitor.process_monitor import ProcessMonitor

from .reader.memory_reader import MemoryReader
from .reader.pixel_reader import PixelReader
from .reader.coordinate_reader import CoordinateReader

from .automation.input_simulator import InputSimulator
from .automation.hotkey_manager import HotkeyManager
from .automation.state_machine import StateMachine

from .integration.assa_integration import ASSAIntegration
from .integration.toolchain_integration import ToolchainIntegration

# 简化导入
__all__ = [
    # 核心模块
    "Config",
    "Logger",
    
    # 监控模块
    "ClientMonitor",
    "WindowManager",
    "ProcessMonitor",
    
    # 数据读取模块
    "MemoryReader",
    "PixelReader",
    "CoordinateReader",
    
    # 自动化模块
    "InputSimulator",
    "HotkeyManager",
    "StateMachine",
    
    # 集成模块
    "ASSAIntegration",
    "ToolchainIntegration",
]