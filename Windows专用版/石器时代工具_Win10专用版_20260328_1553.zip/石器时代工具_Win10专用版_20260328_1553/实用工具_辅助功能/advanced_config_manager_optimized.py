#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
高级配置管理器 - 优化版
添加了缓存、加密、模板等高级功能
"""

import os
import json
import logging
import shutil
import hashlib
import base64
import pickle
import time
from pathlib import Path
from typing import Dict, Any, Optional, List, Tuple, Set
from datetime import datetime
from dataclasses import dataclass, asdict
from enum import Enum
import threading
from concurrent.futures import ThreadPoolExecutor

# 配置加密支持
try:
    from cryptography.fernet import Fernet
    from cryptography.hazmat.primitives import hashes
    from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
    ENCRYPTION_AVAILABLE = True
except ImportError:
    ENCRYPTION_AVAILABLE = False
    Fernet = None

class ConfigError(Exception):
    """配置错误异常"""
    pass

class ConfigValidationError(ConfigError):
    """配置验证错误"""
    pass

class ConfigEncryptionError(ConfigError):
    """配置加密错误"""
    pass

class ConfigTemplateType(Enum):
    """配置模板类型"""
    DEFAULT = "default"
    GAMING = "gaming"
    PERFORMANCE = "performance"
    SECURITY = "security"
    CUSTOM = "custom"

@dataclass
class ConfigTemplate:
    """配置模板"""
    name: str
    type: ConfigTemplateType
    description: str
    config: Dict[str, Any]
    created_at: str
    tags: List[str]

class AdvancedConfigManagerOptimized:
    """高级配置管理器 - 优化版"""
    
    # 配置版本
    CONFIG_VERSION = "2.0.0"
    
    # 缓存配置
    CACHE_TTL = 300  # 5分钟缓存时间
    MAX_CACHE_SIZE = 100  # 最大缓存条目数
    
    def __init__(self, config_dir: Optional[str] = None, enable_cache: bool = True, 
                 enable_encryption: bool = False, encryption_key: Optional[str] = None):
        """
        初始化优化版配置管理器
        
        Args:
            config_dir: 配置目录路径
            enable_cache: 是否启用缓存
            enable_encryption: 是否启用加密
            encryption_key: 加密密钥（如果启用加密）
        """
        self.logger = logging.getLogger(__name__)
        
        # 设置配置目录
        if config_dir:
            self.config_dir = Path(config_dir)
        else:
            self.config_dir = Path(__file__).parent.parent.parent / "configs"
        
        # 确保配置目录存在
        self.config_dir.mkdir(parents=True, exist_ok=True)
        
        # 配置文件路径
        self.config_file = self.config_dir / "config.json"
        self.backup_dir = self.config_dir / "backups"
        self.backup_dir.mkdir(exist_ok=True)
        
        # 模板目录
        self.template_dir = self.config_dir / "templates"
        self.template_dir.mkdir(exist_ok=True)
        
        # 缓存设置
        self.enable_cache = enable_cache
        self.cache = {}
        self.cache_timestamps = {}
        self.cache_lock = threading.Lock()
        
        # 加密设置
        self.enable_encryption = enable_encryption and ENCRYPTION_AVAILABLE
        self.encryption_key = encryption_key
        self.cipher = None
        
        if self.enable_encryption:
            self._setup_encryption()
        
        # 线程池用于异步操作
        self.thread_pool = ThreadPoolExecutor(max_workers=4)
        
        # 当前配置
        self.config = None
        self.config_hash = None
        
        # 配置历史
        self.history_file = self.config_dir / "config_history.json"
        self.history = self._load_history()
        
        # 统计信息
        self.stats = {
            "load_count": 0,
            "save_count": 0,
            "cache_hits": 0,
            "cache_misses": 0,
            "encryption_count": 0,
            "decryption_count": 0,
            "errors": 0
        }
        
        self.logger.info(f"优化版配置管理器初始化完成: {self.config_dir}")
        self.logger.info(f"缓存启用: {enable_cache}, 加密启用: {self.enable_encryption}")
    
    def _setup_encryption(self):
        """设置加密"""
        try:
            if not self.encryption_key:
                # 生成或加载加密密钥
                key_file = self.config_dir / ".encryption_key"
                if key_file.exists():
                    with open(key_file, 'rb') as f:
                        self.encryption_key = f.read()
                else:
                    self.encryption_key = Fernet.generate_key()
                    with open(key_file, 'wb') as f:
                        f.write(self.encryption_key)
                    key_file.chmod(0o600)  # 设置文件权限为仅所有者可读写
            elif isinstance(self.encryption_key, str):
                # 如果是字符串，转换为字节
                self.encryption_key = self.encryption_key.encode()
            
            self.cipher = Fernet(self.encryption_key)
            self.logger.info("加密设置完成")
            
        except Exception as e:
            self.logger.error(f"加密设置失败: {e}")
            self.enable_encryption = False
            self.cipher = None
    
    def _encrypt_data(self, data: bytes) -> bytes:
        """加密数据"""
        if not self.enable_encryption or not self.cipher:
            return data
        
        try:
            encrypted = self.cipher.encrypt(data)
            self.stats["encryption_count"] += 1
            return encrypted
        except Exception as e:
            self.logger.error(f"数据加密失败: {e}")
            raise ConfigEncryptionError(f"数据加密失败: {e}")
    
    def _decrypt_data(self, data: bytes) -> bytes:
        """解密数据"""
        if not self.enable_encryption or not self.cipher:
            return data
        
        try:
            decrypted = self.cipher.decrypt(data)
            self.stats["decryption_count"] += 1
            return decrypted
        except Exception as e:
            self.logger.error(f"数据解密失败: {e}")
            raise ConfigEncryptionError(f"数据解密失败: {e}")
    
    def _get_from_cache(self, key: str) -> Optional[Any]:
        """从缓存获取数据"""
        if not self.enable_cache:
            return None
        
        with self.cache_lock:
            if key in self.cache:
                # 检查缓存是否过期
                if time.time() - self.cache_timestamps[key] < self.CACHE_TTL:
                    self.stats["cache_hits"] += 1
                    return self.cache[key]
                else:
                    # 缓存过期，移除
                    del self.cache[key]
                    del self.cache_timestamps[key]
            
            self.stats["cache_misses"] += 1
            return None
    
    def _set_to_cache(self, key: str, value: Any):
        """设置数据到缓存"""
        if not self.enable_cache:
            return
        
        with self.cache_lock:
            # 检查缓存大小，如果超过限制则移除最旧的条目
            if len(self.cache) >= self.MAX_CACHE_SIZE:
                oldest_key = min(self.cache_timestamps.keys(), 
                               key=lambda k: self.cache_timestamps[k])
                del self.cache[oldest_key]
                del self.cache_timestamps[oldest_key]
            
            self.cache[key] = value
            self.cache_timestamps[key] = time.time()
    
    def _clear_cache(self):
        """清空缓存"""
        with self.cache_lock:
            self.cache.clear()
            self.cache_timestamps.clear()
    
    def load_config(self, force_reload: bool = False) -> Dict[str, Any]:
        """
        加载配置文件（带缓存）
        
        Args:
            force_reload: 是否强制重新加载（忽略缓存）
            
        Returns:
            配置字典
        """
        cache_key = f"config_{self.config_file}"
        
        # 尝试从缓存获取
        if not force_reload:
            cached_config = self._get_from_cache(cache_key)
            if cached_config is not None:
                self.config = cached_config
                self.config_hash = self._calculate_config_hash(cached_config)
                self.logger.debug("从缓存加载配置")
                return self.config
        
        try:
            if self.config_file.exists():
                # 读取配置文件
                with open(self.config_file, 'rb') as f:
                    file_data = f.read()
                
                # 解密数据（如果启用了加密）
                if self.enable_encryption:
                    try:
                        file_data = self._decrypt_data(file_data)
                    except ConfigEncryptionError:
                        # 如果解密失败，尝试作为未加密文件读取
                        self.logger.warning("配置解密失败，尝试作为未加密文件读取")
                
                # 解析JSON
                self.config = json.loads(file_data.decode('utf-8'))
                
                # 计算配置哈希
                self.config_hash = self._calculate_config_hash(self.config)
                
                # 验证配置
                validation_result = self.validate_config_detailed(self.config)
                if not validation_result["valid"]:
                    self.logger.warning(f"配置文件验证失败: {validation_result['errors']}")
                    self.config = self._fix_config(self.config)
                
                # 检查配置版本
                if self.config.get('version') != self.CONFIG_VERSION:
                    self.logger.info(f"配置版本不匹配: {self.config.get('version')} -> {self.CONFIG_VERSION}")
                    self.config = self._migrate_config(self.config)
                
                # 保存到缓存
                self._set_to_cache(cache_key, self.config)
                
                self.stats["load_count"] += 1
                self.logger.info(f"配置文件加载成功: {self.config_file}")
                
            else:
                # 创建默认配置
                self.logger.info("配置文件不存在，创建默认配置")
                self.config = self.create_default_config()
                self.save_config()
            
            return self.config
            
        except Exception as e:
            self.stats["errors"] += 1
            self.logger.error(f"加载配置文件失败: {e}")
            # 尝试创建默认配置
            self.config = self.create_default_config()
            return self.config
    
    def save_config(self, backup: bool = True, async_backup: bool = True) -> bool:
        """
        保存配置文件（支持异步备份）
        
        Args:
            backup: 是否创建备份
            async_backup: 是否异步创建备份
            
        Returns:
            是否保存成功
        """
        try:
            if self.config is None:
                self.logger.error("没有配置数据可保存")
                return False
            
            # 更新版本和修改时间
            self.config['version'] = self.CONFIG_VERSION
            self.config['last_modified'] = datetime.now().isoformat()
            
            # 详细验证配置
            validation_result = self.validate_config_detailed(self.config)
            if not validation_result["valid"]:
                error_msg = ", ".join(validation_result["errors"])
                self.logger.error(f"配置验证失败: {error_msg}")
                return False
            
            # 准备数据
            config_json = json.dumps(self.config, indent=2, ensure_ascii=False)
            config_data = config_json.encode('utf-8')
            
            # 加密数据（如果启用了加密）
            if self.enable_encryption:
                config_data = self._encrypt_data(config_data)
            
            # 创建备份（可选异步）
            if backup:
                if async_backup:
                    # 异步创建备份
                    self.thread_pool.submit(self._create_backup_async)
                else:
                    # 同步创建备份
                    self._create_backup()
            
            # 保存配置文件
            with open(self.config_file, 'wb') as f:
                f.write(config_data)
            
            # 计算新哈希
            new_hash = self._calculate_config_hash(self.config)
            
            # 记录配置历史
            if new_hash != self.config_hash:
                self._record_config_change(self.config_hash, new_hash)
                self.config_hash = new_hash
            
            # 更新缓存
            cache_key = f"config_{self.config_file}"
            self._set_to_cache(cache_key, self.config)
            
            self.stats["save_count"] += 1
            self.logger.info(f"配置文件保存成功: {self.config_file}")
            return True
            
        except Exception as e:
            self.stats["errors"] += 1
            self.logger.error(f"保存配置文件失败: {e}")
            return False
    
    def _create_backup_async(self):
        """异步创建备份"""
        try:
            self._create_backup()
        except Exception as e:
            self.logger.error(f"异步备份创建失败: {e}")
    
    def validate_config_detailed(self, config: Dict[str, Any]) -> Dict[str, Any]:
        """
        详细验证配置，返回验证结果和错误信息
        
        Args:
            config: 配置字典
            
        Returns:
            验证结果字典
        """
        errors = []
        warnings = []
        
        try:
            # 检查必需字段
            required_fields = ["version", "game", "ocr", "system"]
            for field in required_fields:
                if field not in config:
                    errors.append(f"缺少必需字段: {field}")
            
            # 检查游戏配置
            if "game" in config:
                game_fields = ["window_title", "check_interval"]
                for field in game_fields:
                    if field not in config["game"]:
                        errors.append(f"游戏配置缺少字段: {field}")
                
                # 检查数值范围
                if "check_interval" in config["game"]:
                    interval = config["game"]["check_interval"]
                    if not isinstance(interval, (int, float)) or interval < 1 or interval > 300:
                        errors.append(f"检查间隔无效: {interval}，应在1-300之间")
            
            # 检查OCR配置
            if "ocr" in config:
                if "primary_engine" not in config["ocr"]:
                    errors.append("OCR配置缺少primary_engine字段")
                elif config["ocr"]["primary_engine"] not in ["tesseract", "easyocr", "paddleocr"]:
                    errors.append(f"无效的OCR引擎: {config['ocr']['primary_engine']}")
                
                # 检查置信度阈值
                if "confidence_threshold" in config["ocr"]:
                    threshold = config["ocr"]["confidence_threshold"]
                    if not isinstance(threshold, (int, float)) or threshold < 0 or threshold > 1:
                        errors.append(f"置信度阈值无效: {threshold}，应在0-1之间")
            
            # 检查用户配置
            if "users" in config:
                if not isinstance(config["users"], list):
                    errors.append("users字段应为列表")
                else:
                    user_ids = set()
                    for i, user in enumerate(config["users"]):
                        if not isinstance(user, dict):
                            errors.append(f"用户 {i} 不是字典")
                            continue
                        
                        # 检查用户ID
                        if "id" not in user:
                            errors.append(f"用户 {i} 缺少id字段")
                        else:
                            user_id = user["id"]
                            if user_id in user_ids:
                                errors.append(f"重复的用户ID: {user_id}")
                            user_ids.add(user_id)
            
            # 检查系统配置
            if "system" in config:
                if "log_level" not in config["system"]:
                    errors.append("系统配置缺少log_level字段")
                elif config["system"]["log_level"] not in ["DEBUG", "INFO", "WARNING", "ERROR"]:
                    errors.append(f"无效的日志级别: {config['system']['log_level']}")
            
            # 检查高级配置（如果有）
            if "advanced" in config and "debug_mode" in config["advanced"]:
                debug_mode = config["advanced"]["debug_mode"]
                if not isinstance(debug_mode, bool):
                    warnings.append("debug_mode应为布尔值")
            
            valid = len(errors) == 0
            
            return {
                "valid": valid,
                "errors": errors,
                "warnings": warnings,
                "error_count": len(errors),
                "warning_count": len(warnings)
            }
            
        except Exception as e:
            return {
                "valid": False,
                "errors": [f"验证过程中发生异常: {str(e)}"],
                "warnings": [],
                "error_count": 1,
                "warning_count": 0
            }
    
    def create_config_from_template(self, template_type: ConfigTemplateType, 
                                   custom_config: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        从模板创建配置
        
        Args:
            template_type: 模板类型
            custom_config: 自定义配置覆盖
            
        Returns:
            配置字典
        """
        # 基础配置
        base_config = self.create_default_config()
        
        # 根据模板类型调整配置
        if template_type == ConfigTemplateType.GAMING:
            # 游戏优化配置
            base_config["system"]["performance"]["max_threads"] = 8
            base_config["game"]["check_interval"] = 2  # 更频繁的检查
            base_config["ocr"]["confidence_threshold"] = 0.6  # 降低阈值提高识别率
            base_config["description"] = "游戏优化配置模板"
            
        elif template_type == ConfigTemplateType.PERFORMANCE:
            # 性能优化配置
            base_config["system"]["performance"]["max_threads"] = 4
            base_config["system"]["performance"]["cache_size"] = 500
            base_config["ocr"]["preprocessing"]["enabled"] = True
            base_config["description"] = "性能优化配置模板"
            
        elif template_type == ConfigTemplateType.SECURITY:
            # 安全配置
            base_config["system"]["auto_update"] = True
            base_config["advanced"]["debug_mode"] = False
            base_config["advanced"]["developer_mode"] = False
            base_config["description"] = "安全配置模板"
        
        elif template_type == ConfigTemplateType.CUSTOM and custom_config:
            # 自定义配置
            base_config.update(custom_config)
            base_config["description"] = "自定义配置模板"
        
        # 应用自定义配置覆盖
        if custom_config:
            self._deep_update(base_config, custom_config)
        
        return base_config
    
    def _deep_update(self, base: Dict[str, Any], update: Dict[str, Any]):
        """深度更新字典"""
        for key, value in update.items():
            if key in base and isinstance(base[key], dict) and isinstance(value, dict):
                self._deep_update(base[key], value)
            else:
                base[key] = value
    
    def save_template(self, name: str, template_type: ConfigTemplateType, 
                     description: str, tags: List[str]) -> bool:
        """
        保存配置模板
        
        Args:
            name: 模板名称
            template_type: 模板类型
            description: 模板描述
            tags: 标签列表
            
        Returns:
            是否保存成功
        """
        try:
            if self.config is None:
                self.logger.error("没有配置数据可保存为模板")
                return False
            
            # 创建模板对象
            template = ConfigTemplate(
                name=name,
                type=template_type,
                description=description,
                config=self.config.copy(),
                created_at=datetime.now().isoformat(),
                tags=tags
            )
            
            # 保存模板文件
            template_file = self.template_dir / f"{name}_{template_type.value}.json"
            with open(template_file, 'w', encoding='utf-8') as f:
                json.dump(asdict(template), f, indent=2, ensure_ascii=False)
            
            self.logger.info(f"配置模板保存成功: {template_file}")
            return True
            
        except Exception as e:
            self.logger.error(f"保存配置模板失败: {e}")
            return False
    
    def load_template(self, name: str) -> Optional[Dict[str, Any]]:
        """
        加载配置模板
        
        Args:
            name: 模板名称
            
        Returns:
            配置字典，如果不存在则返回None
        """
        try:
            # 查找模板文件
            template_files = list(self.template_dir.glob(f"{name}_*.json"))
            if not template_files:
                self.logger.error(f"模板不存在: {name}")
                return None
            
            # 加载第一个匹配的模板
            with open(template_files[0], 'r', encoding='utf-8') as f:
                template_data = json.load(f)
            
            return template_data.get("config")
            
        except Exception as e:
            self.logger.error(f"加载配置模板失败: {e}")
            return None
    
    def list_templates(self) -> List[Dict[str, Any]]:
        """
        列出所有配置模板
        
        Returns:
            模板列表
        """
        templates = []
        try:
            for template_file in self.template_dir.glob("*.json"):
                with open(template_file, 'r', encoding='utf-8') as f:
                    template_data = json.load(f)
                    templates.append(template_data)
            
            return templates
            
        except Exception as e:
            self.logger.error(f"列出模板失败: {e}")
            return []
    
    def batch_operation(self, operation: str, user_ids: List[int], 
                       **kwargs) -> Dict[str, Any]:
        """
        批量操作
        
        Args:
            operation: 操作类型 ("enable", "disable", "update", "delete")
            user_ids: 用户ID列表
            **kwargs: 操作参数
            
        Returns:
            操作结果
        """
        results = {
            "success": [],
            "failed": [],
            "total": len(user_ids),
            "success_count": 0,
            "failed_count": 0
        }
        
        try:
            if self.config is None:
                self.load_config()
            
            for user_id in user_ids:
                try:
                    if operation == "enable":
                        success = self._enable_user(user_id)
                    elif operation == "disable":
                        success = self._disable_user(user_id)
                    elif operation == "update":
                        success = self._update_user(user_id, **kwargs)
                    elif operation == "delete":
                        success = self.remove_user(user_id)
                    else:
                        raise ValueError(f"不支持的操作: {operation}")
                    
                    if success:
                        results["success"].append(user_id)
                        results["success_count"] += 1
                    else:
                        results["failed"].append({"id": user_id, "reason": "操作失败"})
                        results["failed_count"] += 1
                        
                except Exception as e:
                    results["failed"].append({"id": user_id, "reason": str(e)})
                    results["failed_count"] += 1
            
            # 如果有成功操作，保存配置
            if results["success_count"] > 0:
                self.save_config()
            
            return results
            
        except Exception as e:
            self.logger.error(f"批量操作失败: {e}")
            return results
    
    def _enable_user(self, user_id: int) -> bool:
        """启用用户"""
        user = self.get_user_by_id(user_id)
        if user:
            user["enabled"] = True
            return True
        return False
    
    def _disable_user(self, user_id: int) -> bool:
        """禁用用户"""
        user = self.get_user_by_id(user_id)
        if user:
            user["enabled"] = False
            return True
        return False
    
    def _update_user(self, user_id: int, **kwargs) -> bool:
        """更新用户信息"""
        user = self.get_user_by_id(user_id)
        if user:
            for key, value in kwargs.items():
                if key in user:
                    user[key] = value
            return True
        return False
    
    def get_config_health_check(self) -> Dict[str, Any]:
        """
        获取配置健康检查报告
        
        Returns:
            健康检查报告
        """
        try:
            if self.config is None:
                self.load_config()
            
            report = {
                "timestamp": datetime.now().isoformat(),
                "config_version": self.config.get("version", "未知"),
                "health_score": 100,
                "issues": [],
                "warnings": [],
                "recommendations": []
            }
            
            # 检查配置完整性
            validation = self.validate_config_detailed(self.config)
            if not validation["valid"]:
                report["health_score"] -= len(validation["errors"]) * 10
                report["issues"].extend(validation["errors"])
            
            report["warnings"].extend(validation["warnings"])
            
            # 检查用户配置
            users = self.config.get("users", [])
            if not users:
                report["issues"].append("没有配置用户")
                report["health_score"] -= 20
            
            # 检查启用用户
            enabled_users = [u for u in users if u.get("enabled", False)]
            if not enabled_users:
                report["issues"].append("没有启用用户")
                report["health_score"] -= 15
            
            # 检查游戏配置
            game_config = self.config.get("game", {})
            if not game_config.get("window_title"):
                report["warnings"].append("游戏窗口标题未设置")
                report["health_score"] -= 5
            
            # 检查OCR配置
            ocr_config = self.config.get("ocr", {})
            if not ocr_config.get("primary_engine"):
                report["issues"].append("OCR主引擎未设置")
                report["health_score"] -= 20
            
            # 生成建议
            if report["health_score"] < 80:
                report["recommendations"].append("建议运行配置修复功能")
            
            if len(enabled_users) == 0:
                report["recommendations"].append("建议启用至少一个用户")
            
            # 确保健康分数在0-100之间
            report["health_score"] = max(0, min(100, report["health_score"]))
            
            # 健康状态
            if report["health_score"] >= 90:
                report["health_status"] = "优秀"
            elif report["health_score"] >= 70:
                report["health_status"] = "良好"
            elif report["health_score"] >= 50:
                report["health_status"] = "一般"
            else:
                report["health_status"] = "需要修复"
            
            return report
            
        except Exception as e:
            self.logger.error(f"获取配置健康检查报告失败: {e}")
            return {
                "timestamp": datetime.now().isoformat(),
                "error": str(e),
                "health_score": 0,
                "health_status": "检查失败"
            }
    
    def auto_fix_config(self) -> Dict[str, Any]:
        """
        自动修复配置问题
        
        Returns:
            修复报告
        """
        report = {
            "timestamp": datetime.now().isoformat(),
            "fixed_issues": [],
            "remaining_issues": [],
            "backup_created": False
        }
        
        try:
            if self.config is None:
                self.load_config()
            
            # 创建备份
            if self._create_backup():
                report["backup_created"] = True
            
            # 修复配置
            fixed_config = self._fix_config(self.config)
            
            # 检查修复了哪些问题
            old_validation = self.validate_config_detailed(self.config)
            new_validation = self.validate_config_detailed(fixed_config)
            
            # 记录修复的问题
            for error in old_validation["errors"]:
                if error not in new_validation["errors"]:
                    report["fixed_issues"].append(error)
            
            # 记录剩余问题
            report["remaining_issues"].extend(new_validation["errors"])
            
            # 如果配置有变化，保存修复后的配置
            if report["fixed_issues"]:
                self.config = fixed_config
                self.save_config()
                report["config_saved"] = True
            else:
                report["config_saved"] = False
            
            return report
            
        except Exception as e:
            self.logger.error(f"自动修复配置失败: {e}")
            report["error"] = str(e)
            return report
    
    def get_performance_stats(self) -> Dict[str, Any]:
        """
        获取性能统计
        
        Returns:
            性能统计信息
        """
        return {
            "timestamp": datetime.now().isoformat(),
            "stats": self.stats.copy(),
            "cache_info": {
                "enabled": self.enable_cache,
                "size": len(self.cache),
                "max_size": self.MAX_CACHE_SIZE,
                "hit_rate": self.stats["cache_hits"] / max(1, self.stats["cache_hits"] + self.stats["cache_misses"]),
                "ttl": self.CACHE_TTL
            },
            "encryption_info": {
                "enabled": self.enable_encryption,
                "available": ENCRYPTION_AVAILABLE,
                "encryption_count": self.stats["encryption_count"],
                "decryption_count": self.stats["decryption_count"]
            },
            "operation_counts": {
                "load": self.stats["load_count"],
                "save": self.stats["save_count"],
                "errors": self.stats["errors"]
            }
        }
    
    def export_config_with_metadata(self, export_path: str, 
                                   include_history: bool = False,
                                   include_templates: bool = False) -> bool:
        """
        导出配置（包含元数据）
        
        Args:
            export_path: 导出文件路径
            include_history: 是否包含历史记录
            include_templates: 是否包含模板
            
        Returns:
            是否导出成功
        """
        try:
            if self.config is None:
                self.logger.error("没有配置数据可导出")
                return False
            
            export_data = {
                "metadata": {
                    "export_time": datetime.now().isoformat(),
                    "config_version": self.CONFIG_VERSION,
                    "tool_version": "2.0.0",
                    "includes": []
                },
                "config": self.config
            }
            
            # 包含历史记录
            if include_history:
                export_data["history"] = self.history
                export_data["metadata"]["includes"].append("history")
            
            # 包含模板
            if include_templates:
                export_data["templates"] = self.list_templates()
                export_data["metadata"]["includes"].append("templates")
            
            # 包含统计信息
            export_data["statistics"] = self.get_performance_stats()
            export_data["metadata"]["includes"].append("statistics")
            
            # 包含健康检查
            export_data["health_check"] = self.get_config_health_check()
            export_data["metadata"]["includes"].append("health_check")
            
            export_file = Path(export_path)
            export_file.parent.mkdir(parents=True, exist_ok=True)
            
            with open(export_file, 'w', encoding='utf-8') as f:
                json.dump(export_data, f, indent=2, ensure_ascii=False)
            
            self.logger.info(f"配置导出成功（包含元数据）: {export_file}")
            return True
            
        except Exception as e:
            self.logger.error(f"配置导出失败: {e}")
            return False
    
    # 继承基础版本的方法（需要适配）
    def create_default_config(self) -> Dict[str, Any]:
        """创建默认配置"""
        # 直接创建默认配置，避免导入问题
        default_config = {
            "version": self.CONFIG_VERSION,
            "description": "石器时代验证码识别工具 - 优化版默认配置",
            
            "game": {
                "window_title": "石器时代",
                "window_class": "",
                "exe_path": "",
                "captcha_area": {
                    "x": 100,
                    "y": 200,
                    "width": 200,
                    "height": 80,
                    "auto_detect": True
                },
                "input_area": {
                    "x": 150,
                    "y": 300,
                    "width": 100,
                    "height": 30
                },
                "check_interval": 5,
                "auto_input": True,
                "retry_count": 3
            },
            
            "ocr": {
                "primary_engine": "tesseract",
                "fallback_engines": ["easyocr", "paddleocr"],
                "language": "eng",
                "character_whitelist": "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789",
                "confidence_threshold": 0.7,
                
                "preprocessing": {
                    "enabled": True,
                    "grayscale": True,
                    "threshold": True,
                    "denoise": True,
                    "morphology": True,
                    "resize": [200, 80]
                },
                
                "tesseract": {
                    "path": "",
                    "data_path": "",
                    "config": "--psm 8 --oem 3"
                },
                
                "easyocr": {
                    "gpu": False,
                    "model_storage_directory": "./data/models/easyocr"
                }
            },
            
            "users": [
                {
                    "id": 1,
                    "username": "default_user",
                    "game_account": "",
                    "enabled": True,
                    "created_at": datetime.now().strftime("%Y-%m-%d"),
                    "last_used": "",
                    "statistics": {
                        "total_captchas": 0,
                        "successful": 0,
                        "failed": 0,
                        "accuracy": 0.0,
                        "total_time": 0.0
                    }
                }
            ],
            
            "system": {
                "log_level": "INFO",
                "log_file": "./data/logs/stonecaptcha.log",
                "max_log_size": 10485760,
                "max_log_files": 10,
                
                "auto_update": True,
                "update_channel": "stable",
                "check_update_interval": 86400,
                
                "start_minimized": False,
                "minimize_to_tray": True,
                "close_to_tray": True,
                
                "performance": {
                    "max_threads": 4,
                    "cache_size": 100,
                    "cleanup_interval": 3600
                }
            },
            
            "user_interface": {
                "theme": "dark",
                "language": "zh_CN",
                "font_family": "Microsoft YaHei",
                "font_size": 12,
                
                "window": {
                    "width": 800,
                    "height": 600,
                    "maximized": False,
                    "position": "center"
                },
                
                "notifications": {
                    "enabled": True,
                    "sound": True,
                    "duration": 3000
                }
            },
            
            "advanced": {
                "debug_mode": False,
                "developer_mode": False,
                "experimental_features": False,
                
                "captcha_database": {
                    "enabled": True,
                    "auto_collect": True,
                    "auto_train": False,
                    "storage_path": "./data/captcha_database"
                },
                
                "machine_learning": {
                    "enabled": False,
                    "model_path": "./data/models/ml",
                    "training_interval": 604800,
                    "min_samples": 1000
                }
            }
        }
        
        return default_config
    
    def _calculate_config_hash(self, config: Dict[str, Any]) -> str:
        """计算配置哈希"""
        config_copy = config.copy()
        
        # 移除可能变化的字段
        for field in ["last_modified", "last_used"]:
            if field in config_copy:
                del config_copy[field]
        
        # 移除用户统计中的时间字段
        if "users" in config_copy:
            for user in config_copy["users"]:
                if "last_used" in user:
                    user["last_used"] = ""
        
        # 计算哈希
        config_str = json.dumps(config_copy, sort_keys=True)
        return hashlib.md5(config_str.encode()).hexdigest()
    
    def _create_backup(self) -> bool:
        """创建备份"""
        try:
            if not self.config_file.exists():
                return False
            
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            backup_file = self.backup_dir / f"config_backup_{timestamp}.json"
            
            shutil.copy2(self.config_file, backup_file)
            
            # 限制备份文件数量
            backup_files = sorted(self.backup_dir.glob("config_backup_*.json"))
            if len(backup_files) > 20:  # 优化版保留更多备份
                for old_backup in backup_files[:-20]:
                    old_backup.unlink()
            
            self.logger.info(f"配置文件备份创建成功: {backup_file}")
            return True
            
        except Exception as e:
            self.logger.error(f"创建备份失败: {e}")
            return False
    
    def _load_history(self) -> List[Dict[str, Any]]:
        """加载历史"""
        try:
            if self.history_file.exists():
                with open(self.history_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            else:
                return []
        except Exception as e:
            self.logger.error(f"加载历史失败: {e}")
            return []
    
    def _record_config_change(self, old_hash: str, new_hash: str) -> None:
        """记录配置变更"""
        try:
            change_record = {
                "timestamp": datetime.now().isoformat(),
                "old_hash": old_hash,
                "new_hash": new_hash,
                "description": "配置变更"
            }
            
            self.history.append(change_record)
            
            # 限制历史记录数量
            if len(self.history) > 100:  # 优化版保留更多历史
                self.history = self.history[-100:]
            
            with open(self.history_file, 'w', encoding='utf-8') as f:
                json.dump(self.history, f, indent=2, ensure_ascii=False)
            
            self.logger.info("配置变更已记录")
            
        except Exception as e:
            self.logger.error(f"记录配置变更失败: {e}")
    
    def _fix_config(self, config: Dict[str, Any]) -> Dict[str, Any]:
        """修复配置"""
        try:
            fixed_config = config.copy()
            
            # 确保版本字段存在
            if "version" not in fixed_config:
                fixed_config["version"] = self.CONFIG_VERSION
            
            # 确保描述字段存在
            if "description" not in fixed_config:
                fixed_config["description"] = "修复后的配置"
            
            # 修复各部分的配置
            default_config = self.create_default_config()
            
            for section in ["game", "ocr", "system", "user_interface", "advanced"]:
                if section not in fixed_config:
                    fixed_config[section] = default_config.get(section, {})
                else:
                    section_default = default_config.get(section, {})
                    for key, value in section_default.items():
                        if key not in fixed_config[section]:
                            fixed_config[section][key] = value
            
            self.logger.info("配置修复完成")
            return fixed_config
            
        except Exception as e:
            self.logger.error(f"配置修复失败: {e}")
            return config
    
    def _migrate_config(self, config: Dict[str, Any]) -> Dict[str, Any]:
        """迁移配置"""
        try:
            migrated_config = config.copy()
            old_version = config.get("version", "0.0.0")
            
            self.logger.info(f"开始配置迁移: {old_version} -> {self.CONFIG_VERSION}")
            
            # 版本迁移逻辑
            if old_version.startswith("1."):
                # 从1.x版本迁移到2.0.0
                migrated_config["version"] = self.CONFIG_VERSION
                
                # 添加新字段
                default_config = self.create_default_config()
                
                # 确保所有字段都存在
                for section in default_config:
                    if section not in migrated_config:
                        migrated_config[section] = default_config[section]
                    else:
                        for key, value in default_config[section].items():
                            if key not in migrated_config[section]:
                                migrated_config[section][key] = value
                
                # 添加性能配置（如果不存在）
                if "performance" not in migrated_config.get("system", {}):
                    migrated_config.setdefault("system", {})["performance"] = {
                        "max_threads": 4,
                        "cache_size": 100,
                        "cleanup_interval": 3600
                    }
            
            self.logger.info(f"配置迁移完成: {old_version} -> {migrated_config['version']}")
            return migrated_config
            
        except Exception as e:
            self.logger.error(f"配置迁移失败: {e}")
            return config
    
    # 用户管理方法
    def add_user(self, username: str, game_account: str = "") -> bool:
        """添加用户"""
        try:
            if self.config is None:
                self.load_config()
            
            # 获取下一个用户ID
            user_ids = [user["id"] for user in self.config.get("users", [])]
            next_id = max(user_ids) + 1 if user_ids else 1
            
            # 创建新用户
            new_user = {
                "id": next_id,
                "username": username,
                "game_account": game_account,
                "enabled": True,
                "created_at": datetime.now().strftime("%Y-%m-%d"),
                "last_used": "",
                "statistics": {
                    "total_captchas": 0,
                    "successful": 0,
                    "failed": 0,
                    "accuracy": 0.0,
                    "total_time": 0.0
                }
            }
            
            # 添加用户
            if "users" not in self.config:
                self.config["users"] = []
            
            self.config["users"].append(new_user)
            
            # 保存配置
            if self.save_config():
                self.logger.info(f"用户添加成功: {username} (ID: {next_id})")
                return True
            else:
                self.logger.error("用户添加失败：配置保存失败")
                return False
            
        except Exception as e:
            self.logger.error(f"添加用户失败: {e}")
            return False
    
    def remove_user(self, user_id: int) -> bool:
        """移除用户"""
        try:
            if self.config is None:
                self.load_config()
            
            # 查找用户
            users = self.config.get("users", [])
            user_index = next((i for i, user in enumerate(users) if user["id"] == user_id), -1)
            
            if user_index == -1:
                self.logger.error(f"用户不存在: ID={user_id}")
                return False
            
            # 移除用户
            removed_user = users.pop(user_index)
            self.config["users"] = users
            
            # 保存配置
            if self.save_config():
                self.logger.info(f"用户移除成功: {removed_user['username']} (ID: {user_id})")
                return True
            else:
                self.logger.error("用户移除失败：配置保存失败")
                return False
            
        except Exception as e:
            self.logger.error(f"移除用户失败: {e}")
            return False
    
    def get_user_by_id(self, user_id: int) -> Optional[Dict[str, Any]]:
        """获取用户"""
        try:
            if self.config is None:
                self.load_config()
            
            users = self.config.get("users", [])
            return next((user for user in users if user["id"] == user_id), None)
            
        except Exception as e:
            self.logger.error(f"获取用户信息失败: {e}")
            return None
    
    def get_enabled_users(self) -> List[Dict[str, Any]]:
        """获取启用用户"""
        try:
            if self.config is None:
                self.load_config()
            
            users = self.config.get("users", [])
            return [user for user in users if user.get("enabled", False)]
            
        except Exception as e:
            self.logger.error(f"获取启用用户失败: {e}")
            return []
    
    def update_user_statistics(self, user_id: int, successful: bool, processing_time: float) -> bool:
        """更新用户统计"""
        try:
            if self.config is None:
                self.load_config()
            
            # 查找用户
            users = self.config.get("users", [])
            user = next((u for u in users if u["id"] == user_id), None)
            
            if user is None:
                self.logger.error(f"用户不存在: ID={user_id}")
                return False
            
            # 更新统计信息
            stats = user["statistics"]
            stats["total_captchas"] += 1
            stats["total_time"] += processing_time
            
            if successful:
                stats["successful"] += 1
            else:
                stats["failed"] += 1
            
            # 计算准确率
            if stats["total_captchas"] > 0:
                stats["accuracy"] = stats["successful"] / stats["total_captchas"]
            
            # 更新最后使用时间
            user["last_used"] = datetime.now().isoformat()
            
            # 保存配置
            if self.save_config():
                self.logger.debug(f"用户统计更新成功: ID={user_id}")
                return True
            else:
                self.logger.error("用户统计更新失败：配置保存失败")
                return False
            
        except Exception as e:
            self.logger.error(f"更新用户统计失败: {e}")
            return False
    
    def get_config_summary(self) -> Dict[str, Any]:
        """获取配置摘要"""
        if self.config is None:
            self.load_config()
        
        return {
            "version": self.config.get("version", "未知"),
            "description": self.config.get("description", ""),
            "game_window": self.config.get("game", {}).get("window_title", "未知"),
            "ocr_engine": self.config.get("ocr", {}).get("primary_engine", "未知"),
            "user_count": len(self.config.get("users", [])),
            "enabled_user_count": len(self.get_enabled_users()),
            "last_modified": self.config.get("last_modified", ""),
            "config_hash": self.config_hash,
            "health_score": self.get_config_health_check().get("health_score", 0)
        }
    
    def get_config_history(self, limit: int = 10) -> List[Dict[str, Any]]:
        """获取配置历史"""
        return self.history[-limit:] if limit > 0 else self.history
    
    def restore_backup(self, backup_file: str) -> bool:
        """恢复备份"""
        from .advanced_config_manager import AdvancedConfigManager
        base_manager = AdvancedConfigManager(str(self.config_dir))
        return base_manager.restore_backup(backup_file)
    
    def reset_to_default(self) -> bool:
        """重置为默认配置"""
        self.config = self.create_default_config()
        return self.save_config()
    
    def export_config(self, export_path: str) -> bool:
        """导出配置"""
        return self.export_config_with_metadata(export_path, include_history=False, include_templates=False)
    
    def import_config(self, import_path: str) -> bool:
        """导入配置"""
        from .advanced_config_manager import AdvancedConfigManager
        base_manager = AdvancedConfigManager(str(self.config_dir))
        return base_manager.import_config(import_path)


# 测试代码
if __name__ == "__main__":
    import sys
    
    # 设置日志
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    print("=== 优化版高级配置管理器测试 ===")
    
    # 创建优化版配置管理器实例
    config_manager = AdvancedConfigManagerOptimized(
        enable_cache=True,
        enable_encryption=False  # 测试时不启用加密，避免依赖问题
    )
    
    # 测试1: 加载配置
    print("\n1. 加载配置（带缓存）...")
    config = config_manager.load_config()
    print(f"   配置加载成功，版本: {config.get('version')}")
    
    # 测试2: 详细验证配置
    print("\n2. 详细验证配置...")
    validation = config_manager.validate_config_detailed(config)
    print(f"   验证结果: {'通过' if validation['valid'] else '失败'}")
    print(f"   错误数: {validation['error_count']}, 警告数: {validation['warning_count']}")
    
    # 测试3: 配置健康检查
    print("\n3. 配置健康检查...")
    health_check = config_manager.get_config_health_check()
    print(f"   健康分数: {health_check['health_score']}/100")
    print(f"   健康状态: {health_check['health_status']}")
    
    # 测试4: 从模板创建配置
    print("\n4. 从模板创建配置...")
    from advanced_config_manager_optimized import ConfigTemplateType
    gaming_config = config_manager.create_config_from_template(ConfigTemplateType.GAMING)
    print(f"   游戏优化配置创建成功")
    print(f"   检查间隔: {gaming_config['game']['check_interval']}秒")
    print(f"   最大线程数: {gaming_config['system']['performance']['max_threads']}")
    
    # 测试5: 批量操作
    print("\n5. 批量操作测试...")
    # 先添加一些测试用户
    config_manager.add_user("batch_user1", "account1")
    config_manager.add_user("batch_user2", "account2")
    config_manager.add_user("batch_user3", "account3")
    
    # 批量启用用户
    batch_result = config_manager.batch_operation("enable", [2, 3, 4])
    print(f"   批量操作结果: 成功 {batch_result['success_count']}, 失败 {batch_result['failed_count']}")
    
    # 测试6: 性能统计
    print("\n6. 性能统计...")
    stats = config_manager.get_performance_stats()
    print(f"   缓存命中率: {stats['cache_info']['hit_rate']:.2%}")
    print(f"   加载次数: {stats['operation_counts']['load']}")
    print(f"   保存次数: {stats['operation_counts']['save']}")
    
    # 测试7: 导出配置（包含元数据）
    print("\n7. 导出配置（包含元数据）...")
    export_path = "/tmp/test_config_export_full.json"
    if config_manager.export_config_with_metadata(export_path, include_history=True):
        print(f"   配置导出成功: {export_path}")
        
        # 检查导出文件内容
        import json
        with open(export_path, 'r') as f:
            export_data = json.load(f)
        print(f"   导出包含: {', '.join(export_data['metadata']['includes'])}")
    else:
        print("   配置导出失败")
    
    # 测试8: 自动修复配置
    print("\n8. 自动修复配置测试...")
    # 故意破坏配置
    broken_config = config.copy()
    del broken_config["game"]
    config_manager.config = broken_config
    
    fix_report = config_manager.auto_fix_config()
    print(f"   修复了 {len(fix_report['fixed_issues'])} 个问题")
    print(f"   剩余 {len(fix_report['remaining_issues'])} 个问题")
    print(f"   备份创建: {'成功' if fix_report['backup_created'] else '失败'}")
    
    # 恢复原始配置
    config_manager.config = config
    config_manager.save_config()
    
    print("\n=== 优化版测试完成 ===")
    print("优化版高级配置管理器功能完整，性能优化功能正常。")
    
    # 显示优化特性总结
    print("\n🎯 优化特性总结:")
    print("1. ✅ 缓存机制 - 提高配置加载速度")
    print("2. ✅ 加密支持 - 增强配置安全性")
    print("3. ✅ 模板系统 - 快速创建标准配置")
    print("4. ✅ 批量操作 - 高效管理多用户")
    print("5. ✅ 健康检查 - 自动检测配置问题")
    print("6. ✅ 详细验证 - 提供错误和警告信息")
    print("7. ✅ 性能统计 - 监控系统运行状态")
    print("8. ✅ 自动修复 - 智能修复配置问题")
    print("9. ✅ 异步备份 - 不阻塞主操作")
    print("10. ✅ 元数据导出 - 完整的数据导出")

