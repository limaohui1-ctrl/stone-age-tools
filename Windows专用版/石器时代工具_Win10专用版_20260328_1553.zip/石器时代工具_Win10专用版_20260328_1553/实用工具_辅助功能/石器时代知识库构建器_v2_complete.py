    def generate_analysis_report(self, all_analysis):
        """生成分析报告"""
        report_file = os.path.join(self.knowledge_dir, "分析结果", "脚本分析报告.md")
        
        with open(report_file, 'w', encoding='utf-8') as f:
            f.write("# 石器时代脚本分析报告 v2.0\n\n")
            f.write(f"**分析时间**: {time.strftime('%Y-%m-%d %H:%M:%S')}\n")
            f.write(f"**分析文件数**: {len(all_analysis)}\n\n")
            
            f.write("## 文件分析详情\n\n")
            
            total_size = 0
            total_lines = 0
            
            for analysis in all_analysis:
                f.write(f"### {analysis['file']}\n")
                f.write(f"- **大小**: {analysis['size']} 字节\n")
                f.write(f"- **行数**: {analysis['lines']} 行\n")
                
                total_size += analysis['size']
                total_lines += analysis['lines']
                
                # 各类型数据统计
                f.write(f"- **地图ID**: {len(analysis['maps'])} 个\n")
                if analysis['maps']:
                    f.write(f"  - {', '.join(analysis['maps'][:10])}")
                    if len(analysis['maps']) > 10:
                        f.write(f" ... 等 {len(analysis['maps'])} 个")
                    f.write("\n")
                
                f.write(f"- **NPC**: {len(analysis['npcs'])} 个\n")
                if analysis['npcs']:
                    f.write(f"  - {', '.join(analysis['npcs'][:10])}")
                    if len(analysis['npcs']) > 10:
                        f.write(f" ... 等 {len(analysis['npcs'])} 个")
                    f.write("\n")
                
                f.write(f"- **宠物**: {len(analysis['pets'])} 个\n")
                if analysis['pets']:
                    f.write(f"  - {', '.join(analysis['pets'][:10])}")
                    if len(analysis['pets']) > 10:
                        f.write(f" ... 等 {len(analysis['pets'])} 个")
                    f.write("\n")
                
                f.write(f"- **坐标**: {len(analysis['coordinates'])} 个\n")
                if analysis['coordinates']:
                    f.write(f"  - {', '.join(analysis['coordinates'][:10])}")
                    if len(analysis['coordinates']) > 10:
                        f.write(f" ... 等 {len(analysis['coordinates'])} 个")
                    f.write("\n")
                
                f.write(f"- **物品**: {len(analysis['items'])} 个\n")
                if analysis['items']:
                    f.write(f"  - {', '.join(analysis['items'][:10])}")
                    if len(analysis['items']) > 10:
                        f.write(f" ... 等 {len(analysis['items'])} 个")
                    f.write("\n")
                
                f.write(f"- **命令**: {len(analysis['commands'])} 个\n")
                if analysis['commands']:
                    f.write(f"  - 示例: {analysis['commands'][0]}\n")
                
                f.write("\n")
            
            f.write("## 总体统计\n\n")
            f.write(f"- **总文件数**: {len(all_analysis)}\n")
            f.write(f"- **总大小**: {total_size} 字节 ({total_size/1024:.1f} KB)\n")
            f.write(f"- **总行数**: {total_lines} 行\n")
            f.write(f"- **平均文件大小**: {total_size/len(all_analysis):.0f} 字节\n")
            f.write(f"- **平均行数**: {total_lines/len(all_analysis):.0f} 行\n")
        
        print(f"📊 分析报告已生成: {report_file}")
    
    def create_knowledge_graph(self):
        """创建知识图谱"""
        graph_file = os.path.join(self.knowledge_dir, "知识图谱", "知识图谱.md")
        
        with open(graph_file, 'w', encoding='utf-8') as f:
            f.write("# 石器时代知识图谱 v2.0\n\n")
            f.write(f"**生成时间**: {time.strftime('%Y-%m-%d %H:%M:%S')}\n\n")
            
            f.write("## 知识图谱结构\n\n")
            f.write("```mermaid\n")
            f.write("graph TD\n")
            
            # 添加节点
            f.write("    A[石器时代游戏]\n")
            
            # 地图节点
            if self.knowledge_base['maps']:
                f.write("    A --> B[地图系统]\n")
                for i, map_id in enumerate(self.knowledge_base['maps'][:5], 1):
                    f.write(f"    B --> B{i}[地图{map_id}]\n")
                if len(self.knowledge_base['maps']) > 5:
                    f.write(f"    B --> B更多[等{len(self.knowledge_base['maps'])-5}个地图]\n")
            
            # NPC节点
            if self.knowledge_base['npcs']:
                f.write("    A --> C[NPC系统]\n")
                for i, npc in enumerate(self.knowledge_base['npcs'][:5], 1):
                    f.write(f"    C --> C{i}[{npc}]\n")
                if len(self.knowledge_base['npcs']) > 5:
                    f.write(f"    C --> C更多[等{len(self.knowledge_base['npcs'])-5}个NPC]\n")
            
            # 宠物节点
            if self.knowledge_base['pets']:
                f.write("    A --> D[宠物系统]\n")
                for i, pet in enumerate(self.knowledge_base['pets'][:5], 1):
                    f.write(f"    D --> D{i}[{pet}]\n")
                if len(self.knowledge_base['pets']) > 5:
                    f.write(f"    D --> D更多[等{len(self.knowledge_base['pets'])-5}个宠物]\n")
            
            # 坐标节点
            if self.knowledge_base['coordinates']:
                f.write("    A --> E[坐标系统]\n")
                for i, coord in enumerate(self.knowledge_base['coordinates'][:5], 1):
                    f.write(f"    E --> E{i}[{coord}]\n")
                if len(self.knowledge_base['coordinates']) > 5:
                    f.write(f"    E --> E更多[等{len(self.knowledge_base['coordinates'])-5}个坐标]\n")
            
            # 脚本节点
            if self.knowledge_base['scripts']:
                f.write("    A --> F[脚本系统]\n")
                for i, script in enumerate(self.knowledge_base['scripts'][:5], 1):
                    f.write(f"    F --> F{i}[{script['name']}]\n")
                if len(self.knowledge_base['scripts']) > 5:
                    f.write(f"    F --> F更多[等{len(self.knowledge_base['scripts'])-5}个脚本]\n")
            
            f.write("```\n\n")
            
            f.write("## 知识关系\n\n")
            f.write("### 地图与坐标关系\n")
            if self.knowledge_base['maps'] and self.knowledge_base['coordinates']:
                f.write("地图系统中的每个地图都包含多个坐标点，用于角色移动和NPC定位。\n\n")
            
            f.write("### NPC与脚本关系\n")
            if self.knowledge_base['npcs'] and self.knowledge_base['scripts']:
                f.write("脚本中频繁引用NPC进行对话、任务交接等操作。\n\n")
            
            f.write("### 宠物与培养关系\n")
            if self.knowledge_base['pets']:
                f.write("宠物系统涉及宠物的培养、战斗和进化，是游戏的核心玩法之一。\n\n")
            
            f.write("## 知识应用\n\n")
            f.write("1. **脚本开发**: 基于知识库开发新的游戏脚本\n")
            f.write("2. **游戏攻略**: 制作详细的地图、NPC、宠物攻略\n")
            f.write("3. **数据分析**: 分析游戏机制和玩家行为\n")
            f.write("4. **教学材料**: 制作石器时代脚本开发教程\n")
        
        print(f"🕸️  知识图谱已创建: {graph_file}")
    
    def create_ng25_adapter(self):
        """创建NG25私服适配器"""
        ng25_dir = os.path.join(self.knowledge_dir, "NG25适配")
        os.makedirs(ng25_dir, exist_ok=True)
        
        # 创建名称映射文件
        mapping_file = os.path.join(ng25_dir, "名称映射.json")
        
        # 基于已有知识创建映射
        mapping = {
            "metadata": {
                "name": "NG25私服名称映射 v2.0",
                "created_at": time.strftime("%Y-%m-%d %H:%M:%S"),
                "description": "官方名称到NG25私服名称的映射"
            },
            "maps": {},
            "npcs": {},
            "pets": {},
            "items": {}
        }
        
        # 为每个地图创建映射
        for map_id in self.knowledge_base['maps']:
            mapping['maps'][map_id] = f"NG25_{map_id}"
        
        # 为每个NPC创建映射
        for npc in self.knowledge_base['npcs']:
            mapping['npcs'][npc] = f"NG25_{npc}"
        
        # 为每个宠物创建映射
        for pet in self.knowledge_base['pets']:
            mapping['pets'][pet] = f"NG25_{pet}"
        
        # 为每个物品创建映射
        for item in self.knowledge_base['items']:
            mapping['items'][item] = f"NG25_{item}"
        
        # 保存映射文件
        with open(mapping_file, 'w', encoding='utf-8') as f:
            json.dump(mapping, f, ensure_ascii=False, indent=2)
        
        # 创建适配器脚本
        adapter_file = os.path.join(ng25_dir, "NG25适配器.py")
        with open(adapter_file, 'w', encoding='utf-8') as f:
            f.write('''#!/usr/bin/env python3
"""
NG25私服适配器 v2.0
将官方脚本转换为NG25私服可用的脚本
"""

import json
import re
import os

class NG25Adapter:
    def __init__(self, mapping_file="名称映射.json"):
        """初始化适配器"""
        self.mapping_file = mapping_file
        self.load_mappings()
    
    def load_mappings(self):
        """加载名称映射"""
        try:
            with open(self.mapping_file, 'r', encoding='utf-8') as f:
                self.mappings = json.load(f)
            print(f"✅ 已加载 {len(self.mappings.get('maps', {}))} 个地图映射")
            print(f"✅ 已加载 {len(self.mappings.get('npcs', {}))} 个NPC映射")
            print(f"✅ 已加载 {len(self.mappings.get('pets', {}))} 个宠物映射")
            print(f"✅ 已加载 {len(self.mappings.get('items', {}))} 个物品映射")
        except Exception as e:
            print(f"❌ 加载映射文件失败: {e}")
            self.mappings = {}
    
    def adapt_script(self, script_content):
        """适配脚本内容"""
        adapted = script_content
        
        # 替换地图
        for official, ng25 in self.mappings.get('maps', {}).items():
            pattern = rf'\\b{official}\\b'
            adapted = re.sub(pattern, ng25, adapted)
        
        # 替换NPC
        for official, ng25 in self.mappings.get('npcs', {}).items():
            pattern = rf'\\b{official}\\b'
            adapted = re.sub(pattern, ng25, adapted)
        
        # 替换宠物
        for official, ng25 in self.mappings.get('pets', {}).items():
            pattern = rf'\\b{official}\\b'
            adapted = re.sub(pattern, ng25, adapted)
        
        # 替换物品
        for official, ng25 in self.mappings.get('items', {}).items():
            pattern = rf'\\b{official}\\b'
            adapted = re.sub(pattern, ng25, adapted)
        
        return adapted
    
    def adapt_file(self, input_file, output_file=None):
        """适配整个文件"""
        try:
            with open(input_file, 'r', encoding='utf-8') as f:
                content = f.read()
            
            adapted = self.adapt_script(content)
            
            if output_file is None:
                output_file = input_file.replace('.asc', '_NG25.asc')
            
            with open(output_file, 'w', encoding='utf-8') as f:
                f.write(adapted)
            
            print(f"✅ 文件已适配: {input_file} -> {output_file}")
            return True
            
        except Exception as e:
            print(f"❌ 适配文件失败 {input_file}: {e}")
            return False

def main():
    """主函数"""
    print("🔄 NG25私服适配器 v2.0 启动")
    print("="*50)
    
    adapter = NG25Adapter()
    
    # 示例使用
    print("\\n使用方法:")
    print("1. 将官方脚本放在当前目录")
    print("2. 运行: python NG25适配器.py <输入文件> [输出文件]")
    print("3. 适配后的脚本将保存为 *_NG25.asc")
    
    print("\\n已加载的映射:")
    if adapter.mappings:
        for category, items in adapter.mappings.items():
            if category != 'metadata':
                print(f"  {category}: {len(items)} 个映射")

if __name__ == "__main__":
    main()
''')
        
        print(f"🔄 NG25适配器已创建:")
        print(f"   📄 映射文件: {mapping_file}")
        print(f"   📄 适配器脚本: {adapter_file}")
        
        return mapping_file, adapter_file

def main():
    """主函数"""
    print("🚀 石器时代知识库构建器 v2.0 启动")
    print("="*60)
    
    builder = StoneAgeKnowledgeBuilder()
    
    # 构建知识库
    knowledge_base = builder.build_knowledge_base()
    
    print("\n" + "="*60)
    print("🎉 知识库构建完成!")
    print("="*60)
    
    # 显示统计信息
    print("📊 知识库统计:")
    print(f"  📍 地图: {len(knowledge_base['maps'])} 个")
    print(f"  👤 NPC: {len(knowledge_base['npcs'])} 个")
    print(f"  🐾 宠物: {len(knowledge_base['pets'])} 个")
    print(f"  📍 坐标: {len(knowledge_base['coordinates'])} 个")
    print(f"  🎒 物品: {len(knowledge_base['items'])} 个")
    print(f"  📜 脚本: {len(knowledge_base['scripts'])} 个")
    
    print("\n📁 生成的文件:")
    print(f"  📄 知识库JSON: {builder.knowledge_dir}/知识库.json")
    print(f"  📄 知识库MD: {builder.knowledge_dir}/知识库.md")
    print(f"  📄 分析报告: {builder.knowledge_dir}/分析结果/脚本分析报告.md")
    print(f"  📄 知识图谱: {builder.knowledge_dir}/知识图谱/知识图谱.md")
    print(f"  📄 NG25映射: {builder.knowledge_dir}/NG25适配/名称映射.json")
    print(f"  📄 NG25适配器: {builder.knowledge_dir}/NG25适配/NG25适配器.py")
    
    print("\n💡 下一步建议:")
    print("1. 查看知识库文件，了解游戏结构")
    print("2. 使用NG25适配器转换官方脚本")
    print("3. 基于知识库开发新的游戏脚本")
    print("4. 定期更新知识库内容")
    print("5. 将知识库用于脚本开发和教学")

if __name__ == "__main__":
    main()