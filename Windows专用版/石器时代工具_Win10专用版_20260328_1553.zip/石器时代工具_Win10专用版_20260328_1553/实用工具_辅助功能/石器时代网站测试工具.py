#!/usr/bin/env python3
"""
石器时代网站测试工具
用于系统化测试石器时代相关网站的可访问性
"""

import requests
import time
from datetime import datetime
import json
import os

class StoneAgeWebsiteTester:
    def __init__(self):
        self.results_dir = "/root/.openclaw/workspace/石器时代网站测试结果"
        self.create_results_dir()
        
        # 测试网站列表（基于已知的石器时代相关网站）
        self.websites = [
            # 游戏官方网站和论坛
            {"name": "百度贴吧-石器时代", "url": "https://tieba.baidu.com/f?kw=石器时代"},
            {"name": "17173石器时代专区", "url": "https://news.17173.com/z/zt/shared/shared_shiqishidai.shtml"},
            {"name": "多玩游戏石器时代", "url": "https://www.duowan.com/tag/25433.html"},
            {"name": "游民星空石器时代", "url": "https://www.gamersky.com/z/shared/shared_shiqishidai/"},
            
            # NG25私服相关
            {"name": "NG25私服论坛", "url": "https://bbs.ng25.com/"},
            {"name": "石器时代私服大全", "url": "https://www.shiqisf.com/"},
            
            # 脚本和工具网站
            {"name": "ASSA脚本论坛", "url": "https://bbs.assa.com/"},
            {"name": "石器时代脚本分享", "url": "https://www.shiqijiaoben.com/"},
            
            # 攻略和资料网站
            {"name": "石器时代攻略站", "url": "https://www.shiqigonglue.com/"},
            {"name": "石器时代资料库", "url": "https://www.stoneagewiki.com/"},
            
            # 备用测试网站
            {"name": "百度首页", "url": "https://www.baidu.com", "control": True},
        ]
        
        self.headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        }
        
    def create_results_dir(self):
        """创建结果目录"""
        if not os.path.exists(self.results_dir):
            os.makedirs(self.results_dir)
            print(f"创建结果目录: {self.results_dir}")
    
    def test_website(self, website):
        """测试单个网站的可访问性"""
        name = website["name"]
        url = website["url"]
        is_control = website.get("control", False)
        
        print(f"测试网站: {name}")
        print(f"URL: {url}")
        
        result = {
            "name": name,
            "url": url,
            "timestamp": datetime.now().isoformat(),
            "is_control": is_control
        }
        
        try:
            start_time = time.time()
            response = requests.get(url, headers=self.headers, timeout=10)
            elapsed_time = time.time() - start_time
            
            result["status_code"] = response.status_code
            result["response_time"] = round(elapsed_time, 3)
            result["content_length"] = len(response.content)
            result["success"] = True
            
            # 分析响应内容
            if response.status_code == 200:
                content = response.text.lower()
                result["has_stoneage_content"] = any(keyword in content for keyword in ["石器时代", "stoneage", "石器的时代"])
                result["has_game_content"] = any(keyword in content for keyword in ["游戏", "game", "攻略", "guide"])
                
                print(f"  状态: ✅ 成功 (HTTP {response.status_code}, {elapsed_time:.3f}s)")
                if result["has_stoneage_content"]:
                    print(f"  内容: 包含石器时代相关内容")
                elif result["has_game_content"]:
                    print(f"  内容: 包含游戏相关内容")
                else:
                    print(f"  内容: 未检测到游戏相关内容")
            else:
                print(f"  状态: ⚠️ HTTP {response.status_code} (非200)")
                
        except requests.exceptions.Timeout:
            result["status_code"] = None
            result["error"] = "请求超时"
            result["success"] = False
            print(f"  状态: ❌ 请求超时")
            
        except requests.exceptions.ConnectionError:
            result["status_code"] = None
            result["error"] = "连接错误"
            result["success"] = False
            print(f"  状态: ❌ 连接错误")
            
        except Exception as e:
            result["status_code"] = None
            result["error"] = str(e)
            result["success"] = False
            print(f"  状态: ❌ 错误: {e}")
        
        print()
        return result
    
    def run_tests(self):
        """运行所有测试"""
        print("=" * 60)
        print("石器时代网站可访问性测试")
        print(f"开始时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        print("=" * 60)
        print()
        
        all_results = []
        
        for website in self.websites:
            result = self.test_website(website)
            all_results.append(result)
            
            # 避免请求过于频繁
            time.sleep(1)
        
        # 保存结果
        self.save_results(all_results)
        
        # 生成报告
        self.generate_report(all_results)
        
        return all_results
    
    def save_results(self, results):
        """保存测试结果到JSON文件"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"website_test_results_{timestamp}.json"
        filepath = os.path.join(self.results_dir, filename)
        
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(results, f, ensure_ascii=False, indent=2)
        
        print(f"测试结果已保存: {filepath}")
    
    def generate_report(self, results):
        """生成测试报告"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"website_test_report_{timestamp}.md"
        filepath = os.path.join(self.results_dir, filename)
        
        # 统计信息
        total = len(results)
        successful = sum(1 for r in results if r.get("success") and r.get("status_code") == 200)
        failed = total - successful
        
        # 石器时代相关内容统计
        stoneage_sites = sum(1 for r in results if r.get("has_stoneage_content", False))
        game_sites = sum(1 for r in results if r.get("has_game_content", False))
        
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write("# 石器时代网站可访问性测试报告\n\n")
            f.write(f"**生成时间**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
            f.write(f"**测试网站数量**: {total}\n\n")
            
            f.write("## 📊 测试概览\n\n")
            f.write(f"- **成功访问**: {successful}/{total} ({successful/total*100:.1f}%)\n")
            f.write(f"- **访问失败**: {failed}/{total} ({failed/total*100:.1f}%)\n")
            f.write(f"- **包含石器时代内容**: {stoneage_sites} 个网站\n")
            f.write(f"- **包含游戏内容**: {game_sites} 个网站\n\n")
            
            f.write("## 📋 详细测试结果\n\n")
            f.write("| 网站名称 | URL | 状态 | 响应时间 | 内容检测 |\n")
            f.write("|----------|-----|------|----------|----------|\n")
            
            for result in results:
                name = result["name"]
                url = result["url"]
                
                # 状态
                if result.get("success") and result.get("status_code") == 200:
                    status = f"✅ HTTP {result['status_code']}"
                elif result.get("success"):
                    status = f"⚠️ HTTP {result.get('status_code', 'N/A')}"
                else:
                    status = f"❌ {result.get('error', '未知错误')}"
                
                # 响应时间
                response_time = result.get("response_time", "N/A")
                if isinstance(response_time, (int, float)):
                    response_time = f"{response_time}s"
                
                # 内容检测
                if result.get("has_stoneage_content"):
                    content = "石器时代内容"
                elif result.get("has_game_content"):
                    content = "游戏内容"
                else:
                    content = "未检测到"
                
                f.write(f"| {name} | {url} | {status} | {response_time} | {content} |\n")
            
            f.write("\n## 🎯 推荐网站\n\n")
            
            # 推荐可访问且包含石器时代内容的网站
            recommended = [r for r in results if r.get("has_stoneage_content") and r.get("success") and r.get("status_code") == 200]
            
            if recommended:
                f.write("以下网站可访问且包含石器时代相关内容，建议优先使用：\n\n")
                for site in recommended:
                    f.write(f"1. **{site['name']}** - {site['url']}\n")
                    f.write(f"   - 响应时间: {site['response_time']}s\n")
                    f.write(f"   - 内容长度: {site['content_length']} 字节\n\n")
            else:
                f.write("⚠️ 未找到包含石器时代相关内容的可访问网站。\n\n")
            
            f.write("## 🔧 后续建议\n\n")
            f.write("1. **扩展测试范围**: 测试更多石器时代相关网站\n")
            f.write("2. **内容深度分析**: 对可访问网站进行内容深度分析\n")
            f.write("3. **定期监控**: 建立网站可访问性定期监控机制\n")
            f.write("4. **备用方案**: 准备网站不可访问时的备用资料源\n")
        
        print(f"测试报告已生成: {filepath}")
        
        # 打印摘要
        print("\n" + "=" * 60)
        print("测试摘要:")
        print(f"  总测试网站: {total}")
        print(f"  成功访问: {successful} ({successful/total*100:.1f}%)")
        print(f"  包含石器时代内容: {stoneage_sites}")
        print(f"  包含游戏内容: {game_sites}")
        
        if recommended:
            print(f"\n推荐网站 ({len(recommended)} 个):")
            for site in recommended:
                print(f"  • {site['name']}")
        else:
            print("\n⚠️ 未找到推荐网站")
        
        print("=" * 60)

def main():
    """主函数"""
    tester = StoneAgeWebsiteTester()
    
    try:
        results = tester.run_tests()
        
        # 返回推荐网站列表
        recommended = [r for r in results if r.get("has_stoneage_content") and r.get("success") and r.get("status_code") == 200]
        
        if recommended:
            print("\n🎯 下一步行动建议:")
            print("1. 使用web-content-fetcher测试推荐网站的抓取能力")
            print("2. 对推荐网站进行内容深度分析")
            print("3. 建立石器时代资料收集工作流")
        else:
            print("\n⚠️ 需要调整策略:")
            print("1. 寻找更多石器时代相关网站")
            print("2. 测试不同的抓取服务和策略")
            print("3. 考虑使用搜索引擎API获取资料")
            
    except KeyboardInterrupt:
        print("\n测试被用户中断")
    except Exception as e:
        print(f"\n测试过程中发生错误: {e}")

if __name__ == "__main__":
    main()