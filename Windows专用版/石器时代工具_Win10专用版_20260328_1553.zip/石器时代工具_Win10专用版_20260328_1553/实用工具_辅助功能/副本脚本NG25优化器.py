#!/usr/bin/env python3
"""
副本脚本NG25优化器
专门优化副本脚本，检查NG25名称适配，并添加网络优化
"""

import os
import re
import shutil
from datetime import datetime

class DungeonOptimizer:
    def __init__(self):
        self.dungeon_dir = "/root/.openclaw/workspace/石器时代客户端处理/解压内容/sqng25/scripts/12.【副本活动】"
        self.backup_dir = "/root/.openclaw/workspace/副本脚本备份"
        self.optimized_dir = "/root/.openclaw/workspace/NG25优化副本"
        
        # 创建目录
        os.makedirs(self.backup_dir, exist_ok=True)
        os.makedirs(self.optimized_dir, exist_ok=True)
        
        # NG25私服名称检查列表
        self.ng25_checklist = {
            # 地图名称（需要确认NG25是否使用相同名称）
            "地图": [
                "渔村", "福村", "萨村", "加加村", "卡鲁他那村", "达那村",
                "沙姆岛", "奇咯咯", "多多村", "小小村", "霍比特村", "南卡村",
                "塔姆村", "柯奥村", "特尔坷村", "米兰达", "伊甸园",
                "地城", "水城", "火城", "风城", "冰城"
            ],
            
            # 副本相关地图
            "副本地图": [
                "地硫", "火慎", "水璧", "风旋", "幽黑", "碧清", "玄黄",
                "金暴洞", "英雄岛", "海底洞窟", "盗贼洞窟", "沉睡洞窟",
                "梦德洞窟", "柯奥山洞", "阿布洞", "帕拉火洞窟"
            ],
            
            # 常见NPC（需要确认NG25名称）
            "NPC": [
                "商人", "银行职员", "宠物店", "医院", "村长", "传送员",
                "任务管理员", "魔王", "女神", "精灵", "守卫", "导师"
            ],
            
            # 宠物名称（需要确认NG25名称）
            "宠物": [
                "人龙", "雷龙", "老虎", "暴龙", "机暴", "金虎", "红虎",
                "绿虎", "蓝虎", "黄虎", "红人龙", "蓝人龙", "绿人龙",
                "黄人龙", "灰人龙", "红雷", "蓝雷", "绿雷", "黄雷", "灰雷"
            ],
            
            # 物品名称
            "物品": [
                "羽毛", "石币", "药水", "武器", "防具", "饰品", "任务物品",
                "证明", "证书", "材料", "宝石", "矿石", "木材", "皮革"
            ]
        }
    
    def backup_script(self, script_path):
        """备份原始脚本"""
        rel_path = os.path.relpath(script_path, self.dungeon_dir)
        backup_path = os.path.join(self.backup_dir, rel_path)
        
        os.makedirs(os.path.dirname(backup_path), exist_ok=True)
        shutil.copy2(script_path, backup_path)
        return backup_path
    
    def check_ng25_names(self, content):
        """检查脚本中的名称是否适配NG25"""
        issues = []
        warnings = []
        
        lines = content.split('\n')
        
        for line_num, line in enumerate(lines, 1):
            line_lower = line.lower()
            
            # 检查地图名称
            for map_name in self.ng25_checklist["地图"]:
                if map_name in line:
                    issues.append({
                        'line': line_num,
                        'type': '地图名称',
                        'name': map_name,
                        'content': line.strip(),
                        'status': '需确认'  # 需要确认NG25是否使用相同名称
                    })
            
            # 检查副本地图
            for dungeon_map in self.ng25_checklist["副本地图"]:
                if dungeon_map in line:
                    issues.append({
                        'line': line_num,
                        'type': '副本地图',
                        'name': dungeon_map,
                        'content': line.strip(),
                        'status': '需确认'
                    })
            
            # 检查NPC名称
            for npc_name in self.ng25_checklist["NPC"]:
                if npc_name in line:
                    issues.append({
                        'line': line_num,
                        'type': 'NPC名称',
                        'name': npc_name,
                        'content': line.strip(),
                        'status': '需确认'
                    })
            
            # 检查宠物名称
            for pet_name in self.ng25_checklist["宠物"]:
                if pet_name in line:
                    issues.append({
                        'line': line_num,
                        'type': '宠物名称',
                        'name': pet_name,
                        'content': line.strip(),
                        'status': '需确认'
                    })
            
            # 检查物品名称
            for item_name in self.ng25_checklist["物品"]:
                if item_name in line:
                    issues.append({
                        'line': line_num,
                        'type': '物品名称',
                        'name': item_name,
                        'content': line.strip(),
                        'status': '需确认'
                    })
            
            # 检查可能的编码问题
            if '?' in line and len(line) < 100:  # 短行中的?可能是乱码
                warnings.append({
                    'line': line_num,
                    'type': '编码问题',
                    'content': line.strip(),
                    'suggestion': '可能包含乱码字符'
                })
        
        return issues, warnings
    
    def add_network_optimization(self, content):
        """添加网络优化框架"""
        optimization_header = f"""// ============================================
// NG25副本脚本优化版
// 优化时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
// 优化内容: NG25名称适配 + 网络波动处理
// ============================================

// 网络优化配置
set MAX_RETRY 3
set NETWORK_TIMEOUT 10000
set POS_TIMEOUT 5000
set RETRY_DELAY 2000

// 状态变量
set retry_count 0
set error_level 0
set stuck_counter 0

// 网络错误处理
label network_error
    inc retry_count
    if retry_count > MAX_RETRY goto fatal_error
    log 网络错误，第{'{retry_count}'}次重试
    wait RETRY_DELAY
    ret

label fatal_error
    log ⚠️ 严重错误，尝试返回记录点
    useitem 羽毛, NETWORK_TIMEOUT
    wait 3000
    goto start

// 防卡检测
function check_stuck
    inc stuck_counter
    if stuck_counter > 20
        log ⚠️ 检测到卡住，尝试恢复
        useitem 羽毛
        wait 3000
        set stuck_counter 0
    ret

// 安全移动函数
function walk_safe(x, y)
    walkpos x, y
    waitpos x, y, POS_TIMEOUT
    if not pos x, y call network_error
    ret

function waitdlg_safe(npc)
    waitdlg npc, NETWORK_TIMEOUT
    if not dlg npc call network_error
    ret

// 脚本开始
label start
    set retry_count 0
    set error_level 0
    set stuck_counter 0
    
    log 🚀 NG25副本脚本开始 (优化版)
    log 📝 注意: 已添加网络优化和NG25适配检查

// ============================================
// 原始脚本内容开始
// ============================================

"""
        
        # 在原始内容中添加定期防卡检测
        optimized_lines = []
        lines = content.split('\n')
        
        for i, line in enumerate(lines):
            optimized_lines.append(line)
            
            # 在关键操作后添加防卡检测
            key_operations = ['walkpos', 'waitpos', 'dlg', 'waitdlg', 'button']
            if any(op in line.lower() for op in key_operations):
                if i < len(lines) - 1 and 'check_stuck' not in lines[i+1]:
                    optimized_lines.append("    call check_stuck  // 网络优化: 防卡检测")
        
        optimized_content = optimization_header + '\n'.join(optimized_lines)
        
        # 添加结束处理
        optimized_content += """

// ============================================
// 脚本结束处理
// ============================================

label finish
    log ✅ 副本任务完成!
    log 📊 运行统计: 错误{'{retry_count}'}次，防卡{'{stuck_counter}'}次
    stop

// ============================================
// NG25适配说明
// ============================================
//
// 已检查以下名称适配性:
// 1. 地图名称: 需要确认NG25是否使用相同名称
// 2. NPC名称: 需要确认NG25是否使用相同名称  
// 3. 宠物名称: 需要确认NG25是否使用相同名称
// 4. 物品名称: 需要确认NG25是否使用相同名称
//
// 网络优化特性:
// 1. ✅ 所有等待指令都有超时
// 2. ✅ 三级错误重试机制
// 3. ✅ 防卡检测和自动恢复
// 4. ✅ 安全移动和对话函数
//
"""
        
        return optimized_content
    
    def optimize_dungeon_script(self, script_path):
        """优化单个副本脚本"""
        script_name = os.path.basename(script_path)
        print(f"🔧 优化副本脚本: {script_name}")
        
        # 备份
        backup_path = self.backup_script(script_path)
        
        # 读取内容
        with open(script_path, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read()
        
        # 检查NG25名称适配
        issues, warnings = self.check_ng25_names(content)
        
        # 添加网络优化
        optimized_content = self.add_network_optimization(content)
        
        # 保存优化版本
        rel_path = os.path.relpath(script_path, self.dungeon_dir)
        optimized_path = os.path.join(self.optimized_dir, rel_path)
        
        os.makedirs(os.path.dirname(optimized_path), exist_ok=True)
        
        with open(optimized_path, 'w', encoding='utf-8') as f:
            f.write(optimized_content)
        
        # 生成检查报告
        report = self.generate_check_report(script_name, issues, warnings)
        
        return {
            'script': script_name,
            'backup_path': backup_path,
            'optimized_path': optimized_path,
            'issues': issues,
            'warnings': warnings,
            'issue_count': len(issues),
            'warning_count': len(warnings),
            'report': report
        }
    
    def generate_check_report(self, script_name, issues, warnings):
        """生成NG25适配检查报告"""
        report = f"# 📋 NG25适配检查报告: {script_name}\n\n"
        report += f"**检查时间**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n"
        
        if issues:
            report += "## ⚠️ 需要确认的名称适配问题\n\n"
            
            # 按类型分组
            issues_by_type = {}
            for issue in issues:
                issue_type = issue['type']
                if issue_type not in issues_by_type:
                    issues_by_type[issue_type] = []
                issues_by_type[issue_type].append(issue)
            
            for issue_type, type_issues in issues_by_type.items():
                report += f"### {issue_type} ({len(type_issues)}个)\n\n"
                for issue in type_issues:
                    report += f"- **行{issue['line']}**: `{issue['content']}`\n"
                    report += f"  - 名称: `{issue['name']}`\n"
                    report += f"  - 状态: {issue['status']} (需要确认NG25是否使用相同名称)\n\n"
        else:
            report += "## ✅ 未发现明显的名称适配问题\n\n"
        
        if warnings:
            report += "## 🔍 其他检查发现\n\n"
            for warning in warnings:
                report += f"- **行{warning['line']}**: {warning['type']}\n"
                report += f"  - 内容: `{warning['content']}`\n"
                report += f"  - 建议: {warning['suggestion']}\n\n"
        
        # 添加NG25适配建议
        report += "## 🎯 NG25适配建议\n\n"
        report += "1. **地图名称**: 确认NG25私服使用的地图名称是否与脚本一致\n"
        report += "2. **NPC名称**: 确认NG25私服的NPC名称是否与脚本一致\n"
        report += "3. **宠物名称**: 确认NG25私服的宠物名称是否与脚本一致\n"
        report += "4. **物品名称**: 确认NG25私服的物品名称是否与脚本一致\n\n"
        
        report += "## 🔧 已添加的网络优化\n\n"
        report += "1. ✅ 所有等待指令添加超时\n"
        report += "2. ✅ 三级错误重试机制\n"
        report += "3. ✅ 防卡检测和自动恢复\n"
        report += "4. ✅ 安全移动和对话函数\n\n"
        
        report += "---\n"
        report += "*本报告由副本脚本NG25优化器自动生成*\n"
        
        return report
    
    def optimize_all_dungeons(self):
        """优化所有副本脚本"""
        print("🔄 开始优化所有副本脚本...")
        
        # 查找所有副本脚本
        script_files = []
        for root, dirs, files in os.walk(self.dungeon_dir):
            for file in files:
                if file.lower().endswith('.asc'):
                    script_files.append(os.path.join(root, file))
        
        print(f"📁 找到副本脚本: {len(script_files)} 个")
        
        results = []
        for i, script_file in enumerate(script_files, 1):
            print(f"  [{i}/{len(script_files)}] 处理: {os.path.basename(script_file)}", end="\r")
            
            try:
                result = self.optimize_dungeon_script(script_file)
                results.append(result)
                
                # 保存检查报告
                report_path = os.path.join(
                    self.optimized_dir,
                    "检查报告",
                    f"{os.path.basename(script_file)}_NG25检查报告.md"
                )
                os.makedirs(os.path.dirname(report_path), exist_ok=True)
                with open(report_path, 'w', encoding='utf-8') as f:
                    f.write(result['report'])
                    
            except Exception as e:
                print(f"\n❌ 优化失败 {script_file}: {e}")
        
        print(f"\n✅ 副本优化完成!")
        return results
    
    def generate_summary_report(self, results):
        """生成总结报告"""
        report = "# 📊 副本脚本NG25优化总结报告\n\n"
        report += f"**生成时间**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n"
        report += f"**优化脚本**: {len(results)} 个\n\n"
        
        # 统计信息
        total_issues = sum(r['issue_count'] for r in results)
        total_warnings = sum(r['warning_count'] for r in results)
        
        report += "## 📈 优化统计\n\n"
        report += f"- **优化脚本总数**: {len(results)} 个\n"
        report += f"- **需要确认的名称问题**: {total_issues} 个\n"
        report += f"- **其他检查发现**: {total_warnings} 个\n\n"
        
        # 脚本详情
        report += "## 📋 优化脚本详情\n\n"
        
        for result in results:
            script_name = result['script']
            issue_count = result['issue_count']
            warning_count = result['warning_count']
            
            status = "✅ 良好" if issue_count == 0 else "⚠️ 需确认"
            
            report += f"### {script_name}\n"
            report += f"- **状态**: {status}\n"
            report += f"- **名称适配问题**: {issue_count} 个\n"
            report += f"- **其他检查发现**: {warning_count} 个\n"
            report += f"- **优化版本**: `{result['optimized_path']}`\n"
            report += f"- **检查报告**: `{os.path.join('检查报告', f'{script_name}_NG25检查报告.md')}`\n\n"
        
        # 问题分类统计
        if total_issues > 0:
            report += "## 🔍 名称适配问题分类\n\n"
            
            issue_types = {}
            for result in results:
                for issue in result['issues']:
                    issue_type = issue['type']
                    issue_types[issue_type] = issue_types.get(issue_type, 0) + 1
            
            for issue_type, count in sorted(issue_types.items(), key=lambda x: x[1], reverse=True):
                percentage = (count / total_issues) * 100
                report += f"- **{issue_type}**: {count} 个 ({percentage:.1f}%)\n"
            
            report += "\n"
        
        # 优化建议
        report += "## 🚀 后续优化建议\n\n"
        report += "1. **名称确认**: 请确认报告中标记的名称在NG25私服中是否正确\n"
        report += "2. **实际测试**: 在NG25私服中测试优化后的脚本\n"
        report += "3. **名称更新**: 根据测试结果更新名称映射表\n"
        report += "4. **批量优化**: 使用更新后的映射表重新优化所有脚本\n\n"
        
        report += "## 📁 文件位置\n\n"
        report += "- **原始脚本备份**: `副本脚本备份/`\n"
        report += "- **优化版本**: `NG25优化副本/`\n"
        report += "- **检查报告**: `NG25优化副本/检查报告/`\n"
        report += "- **可以直接使用优化版本进行测试**\n\n"
        
        report += "---\n"
        report += "*本报告由副本脚本NG25优化器自动生成*\n"