#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
OCR多引擎支持模块 - 支持Tesseract, EasyOCR, PaddleOCR等多种OCR引擎
"""

import os
import sys
import time
import logging
from typing import Optional, List, Tuple, Dict, Any
from pathlib import Path
from dataclasses import dataclass
from enum import Enum
import json

# OCR引擎类型
class OCREngineType(Enum):
    TESSERACT = "tesseract"
    EASYOCR = "easyocr"
    PADDLEOCR = "paddleocr"
    ALL = "all"  # 使用所有可用引擎

@dataclass
class OCRResult:
    """OCR识别结果"""
    text: str
    confidence: float
    engine: str
    processing_time: float
    raw_result: Any = None
    preprocessed_image: Any = None
    
    def __str__(self):
        return f"{self.text} ({self.confidence:.1%}) - {self.engine} ({self.processing_time:.2f}s)"

class OCRMultiEngine:
    """OCR多引擎管理器"""
    
    def __init__(self, config_path: Optional[str] = None):
        """
        初始化OCR多引擎管理器
        
        Args:
            config_path: 配置文件路径
        """
        self.logger = logging.getLogger(__name__)
        self.config = self._load_config(config_path)
        
        # 可用引擎
        self.available_engines = []
        self.engines = {}
        
        # 初始化引擎
        self._init_engines()
        
        # 统计信息
        self.stats = {
            'total_recognitions': 0,
            'successful_recognitions': 0,
            'failed_recognitions': 0,
            'engine_usage': {},
            'average_confidence': 0.0,
            'total_processing_time': 0.0
        }
        
        # 缓存
        self.cache_enabled = self.config.get('cache_enabled', True)
        self.result_cache = {}
        self.cache_max_size = self.config.get('cache_max_size', 100)
        
        self.logger.info(f"OCR多引擎管理器初始化完成，可用引擎: {self.available_engines}")
    
    def _load_config(self, config_path: Optional[str]) -> dict:
        """加载配置"""
        default_config = {
            'primary_engine': 'tesseract',
            'fallback_engines': ['easyocr', 'paddleocr'],
            'language': 'eng',
            'character_whitelist': 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789',
            'confidence_threshold': 0.7,
            
            'preprocessing': {
                'enabled': True,
                'grayscale': True,
                'threshold': True,
                'denoise': True,
                'morphology': True,
                'resize': [200, 80]
            },
            
            'tesseract': {
                'path': None,
                'data_path': None,
                'config': '--psm 8 --oem 3',
                'timeout': 10
            },
            
            'easyocr': {
                'gpu': False,
                'model_storage_directory': None,
                'timeout': 15
            },
            
            'paddleocr': {
                'use_angle_cls': True,
                'lang': 'en',
                'use_gpu': False,
                'timeout': 20
            },
            
            'ensemble': {
                'enabled': True,
                'method': 'confidence',  # confidence, voting, weighted
                'min_agreement': 2,
                'confidence_weight': 0.6
            },
            
            'performance': {
                'cache_enabled': True,
                'cache_max_size': 100,
                'parallel_processing': False,
                'max_workers': 4
            }
        }
        
        # 在实际版本中，这里会从配置文件加载
        return default_config
    
    def _init_engines(self):
        """初始化OCR引擎"""
        # 初始化Tesseract
        if self._init_tesseract():
            self.available_engines.append(OCREngineType.TESSERACT.value)
        
        # 初始化EasyOCR
        if self._init_easyocr():
            self.available_engines.append(OCREngineType.EASYOCR.value)
        
        # 初始化PaddleOCR
        if self._init_paddleocr():
            self.available_engines.append(OCREngineType.PADDLEOCR.value)
    
    def _init_tesseract(self) -> bool:
        """初始化Tesseract引擎"""
        try:
            import pytesseract
            
            # 设置Tesseract路径
            tesseract_path = self.config['tesseract'].get('path')
            if tesseract_path and os.path.exists(tesseract_path):
                pytesseract.pytesseract.tesseract_cmd = tesseract_path
            
            # 检查Tesseract是否可用
            try:
                pytesseract.get_tesseract_version()
                self.engines['tesseract'] = {
                    'module': pytesseract,
                    'config': self.config['tesseract']
                }
                self.logger.info("Tesseract引擎初始化成功")
                return True
            except Exception as e:
                self.logger.warning(f"Tesseract不可用: {e}")
                return False
                
        except ImportError:
            self.logger.warning("pytesseract未安装，Tesseract引擎不可用")
            return False
    
    def _init_easyocr(self) -> bool:
        """初始化EasyOCR引擎"""
        try:
            import easyocr
            
            # 检查GPU支持
            gpu = self.config['easyocr'].get('gpu', False)
            
            # 初始化Reader
            reader = easyocr.Reader(
                ['en'],
                gpu=gpu,
                model_storage_directory=self.config['easyocr'].get('model_storage_directory')
            )
            
            self.engines['easyocr'] = {
                'reader': reader,
                'config': self.config['easyocr']
            }
            
            self.logger.info("EasyOCR引擎初始化成功")
            return True
            
        except ImportError:
            self.logger.warning("easyocr未安装，EasyOCR引擎不可用")
            return False
        except Exception as e:
            self.logger.warning(f"EasyOCR初始化失败: {e}")
            return False
    
    def _init_paddleocr(self) -> bool:
        """初始化PaddleOCR引擎"""
        try:
            from paddleocr import PaddleOCR
            
            # 初始化PaddleOCR
            ocr = PaddleOCR(
                use_angle_cls=self.config['paddleocr'].get('use_angle_cls', True),
                lang=self.config['paddleocr'].get('lang', 'en'),
                use_gpu=self.config['paddleocr'].get('use_gpu', False),
                show_log=False
            )
            
            self.engines['paddleocr'] = {
                'ocr': ocr,
                'config': self.config['paddleocr']
            }
            
            self.logger.info("PaddleOCR引擎初始化成功")
            return True
            
        except ImportError:
            self.logger.warning("paddleocr未安装，PaddleOCR引擎不可用")
            return False
        except Exception as e:
            self.logger.warning(f"PaddleOCR初始化失败: {e}")
            return False
    
    def preprocess_image(self, image):
        """
        图像预处理
        
        Args:
            image: 输入图像（可以是文件路径或numpy数组）
            
        Returns:
            预处理后的图像
        """
        try:
            import cv2
            import numpy as np
            
            # 如果是文件路径，读取图像
            if isinstance(image, str) and os.path.exists(image):
                img = cv2.imread(image)
                if img is None:
                    raise ValueError(f"无法读取图像: {image}")
            elif isinstance(image, np.ndarray):
                img = image.copy()
            else:
                raise ValueError(f"不支持的图像类型: {type(image)}")
            
            # 检查预处理配置
            if not self.config['preprocessing']['enabled']:
                return img
            
            # 转换为灰度图
            if len(img.shape) == 3 and self.config['preprocessing']['grayscale']:
                gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            else:
                gray = img if len(img.shape) == 2 else cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            
            # 二值化
            if self.config['preprocessing']['threshold']:
                # 自适应阈值
                binary = cv2.adaptiveThreshold(
                    gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
                    cv2.THRESH_BINARY, 11, 2
                )
            else:
                binary = gray
            
            # 去噪
            if self.config['preprocessing']['denoise']:
                denoised = cv2.fastNlMeansDenoising(binary, h=10)
            else:
                denoised = binary
            
            # 形态学操作
            if self.config['preprocessing']['morphology']:
                kernel = np.ones((2, 2), np.uint8)
                morphed = cv2.morphologyEx(denoised, cv2.MORPH_CLOSE, kernel)
                morphed = cv2.morphologyEx(morphed, cv2.MORPH_OPEN, kernel)
            else:
                morphed = denoised
            
            # 调整尺寸
            if self.config['preprocessing']['resize']:
                target_size = tuple(self.config['preprocessing']['resize'])
                resized = cv2.resize(morphed, target_size, interpolation=cv2.INTER_CUBIC)
            else:
                resized = morphed
            
            return resized
            
        except Exception as e:
            self.logger.error(f"图像预处理失败: {e}")
            return image
    
    def recognize_with_tesseract(self, image, preprocessed: bool = False) -> Optional[OCRResult]:
        """使用Tesseract识别"""
        if 'tesseract' not in self.engines:
            return None
        
        try:
            import pytesseract
            from PIL import Image
            
            start_time = time.time()
            
            # 预处理图像
            if not preprocessed:
                processed_image = self.preprocess_image(image)
            else:
                processed_image = image
            
            # 转换为PIL Image
            if isinstance(processed_image, str):
                pil_image = Image.open(processed_image)
            else:
                pil_image = Image.fromarray(processed_image)
            
            # 配置参数
            config = self.config['tesseract']['config']
            whitelist = self.config['character_whitelist']
            config += f' -c tessedit_char_whitelist={whitelist}'
            
            # 识别
            text = pytesseract.image_to_string(
                pil_image,
                config=config,
                lang=self.config['language']
            ).strip()
            
            # 获取置信度（Tesseract不直接提供置信度）
            # 这里使用简单的启发式方法
            confidence = 0.8 if len(text) >= 4 else 0.5
            
            processing_time = time.time() - start_time
            
            result = OCRResult(
                text=text,
                confidence=confidence,
                engine='tesseract',
                processing_time=processing_time,
                preprocessed_image=processed_image
            )
            
            self._update_stats('tesseract', True, confidence, processing_time)
            return result
            
        except Exception as e:
            self.logger.error(f"Tesseract识别失败: {e}")
            self._update_stats('tesseract', False, 0, 0)
            return None
    
    def recognize_with_easyocr(self, image, preprocessed: bool = False) -> Optional[OCRResult]:
        """使用EasyOCR识别"""
        if 'easyocr' not in self.engines:
            return None
        
        try:
            start_time = time.time()
            
            # 预处理图像
            if not preprocessed:
                processed_image = self.preprocess_image(image)
            else:
                processed_image = image
            
            # 确保是numpy数组
            if isinstance(processed_image, str):
                import cv2
                processed_image = cv2.imread(processed_image)
            
            # 识别
            reader = self.engines['easyocr']['reader']
            results = reader.readtext(
                processed_image,
                detail=1,
                paragraph=False
            )
            
            # 提取文本和置信度
            if results:
                # 合并所有检测结果
                texts = []
                confidences = []
                
                for result in results:
                    bbox, text, confidence = result
                    texts.append(text.strip())
                    confidences.append(confidence)
                
                combined_text = ''.join(texts)
                avg_confidence = sum(confidences) / len(confidences) if confidences else 0
            else:
                combined_text = ""
                avg_confidence = 0
            
            processing_time = time.time() - start_time
            
            result = OCRResult(
                text=combined_text,
                confidence=avg_confidence,
                engine='easyocr',
                processing_time=processing_time,
                raw_result=results,
                preprocessed_image=processed_image
            )
            
            self._update_stats('easyocr', True, avg_confidence, processing_time)
            return result
            
        except Exception as e:
            self.logger.error(f"EasyOCR识别失败: {e}")
            self._update_stats('easyocr', False, 0, 0)
            return None
    
    def recognize_with_paddleocr(self, image, preprocessed: bool = False) -> Optional[OCRResult]:
        """使用PaddleOCR识别"""
        if 'paddleocr' not in self.engines:
            return None
        
        try:
            start_time = time.time()
            
            # 预处理图像
            if not preprocessed:
                processed_image = self.preprocess_image(image)
            else:
                processed_image = image
            
            # 确保是文件路径（PaddleOCR需要文件路径）
            if isinstance(processed_image, str):
                image_path = processed_image
            else:
                # 保存临时文件
                import cv2
                temp_dir = Path.home() / "StoneCaptcha" / "temp"
                temp_dir.mkdir(parents=True, exist_ok=True)
                image_path = str(temp_dir / f"temp_{int(time.time())}.png")
                cv2.imwrite(image_path, processed_image)
            
            # 识别
            ocr = self.engines['paddleocr']['ocr']
            result = ocr.ocr(image_path, cls=True)
            
            # 提取文本和置信度
            if result and result[0]:
                texts = []
                confidences = []
                
                for line in result[0]:
                    text_info = line[1]
                    text = text_info[0]
                    confidence = text_info[1]
                    
                    texts.append(text.strip())
                    confidences.append(confidence)
                
                combined_text = ''.join(texts)
                avg_confidence = sum(confidences) / len(confidences) if confidences else 0
            else:
                combined_text = ""
                avg_confidence = 0
            
            processing_time = time.time() - start_time
            
            result_obj = OCRResult(
                text=combined_text,
                confidence=avg_confidence,
                engine='paddleocr',
                processing_time=processing_time,
                raw_result=result,
                preprocessed_image=processed_image
            )
            
            self._update_stats('paddleocr', True, avg_confidence, processing_time)
            return result_obj
            
        except Exception as e:
            self.logger.error(f"PaddleOCR识别失败: {e}")
            self._update_stats('paddleocr', False, 0, 0)
            return None
    
    def recognize(self, image, engine: str = 'auto', use_cache: bool = True) -> Optional[OCRResult]:
        """
        识别验证码
        
        Args:
            image: 输入图像
            engine: 引擎类型 ('auto', 'tesseract', 'easyocr', 'paddleocr', 'all')
            use_cache: 是否使用缓存
            
        Returns:
            OCR识别结果
        """
        # 检查缓存
        cache_key = None
        if use_cache and self.cache_enabled:
            import hashlib
            if isinstance(image, str):
                cache_key = hashlib.md5(image.encode()).hexdigest()
            else:
                import numpy as np
                cache_key = hashlib.md5(image.tobytes()).hexdigest()
            
            if cache_key in self.result_cache:
                self.logger.debug(f"从缓存获取结果: {cache_key}")
                return self.result_cache[cache_key]
        
        # 确定使用的引擎
        if engine == 'auto':
            engine = self.config['primary_engine']
        
        # 执行识别
        result = None
        
        if engine == 'tesseract':
            result = self.recognize_with_tesseract(image)
        elif engine == 'easyocr':
            result = self.recognize_with_easyocr(image)
        elif engine == 'paddleocr':
            result = self.recognize_with_paddleocr(image)
        elif engine == 'all':
            result = self.recognize_with_all_engines(image)
        else:
            self.logger.error(f"不支持的引擎: {engine}")
            return None
        
        # 更新统计
        self.stats['total_recognitions'] += 1
        if result and result.text:
            self.stats['successful_recognitions'] += 1
        else:
            self.stats['failed_recognitions'] += 1
        
        # 保存到缓存
        if result and use_cache and self.cache_enabled and cache_key:
            self.result_cache[cache_key] = result
            
            # 限制缓存大小
            if len(self.result_cache) > self.cache_max_size:
                # 移除最旧的条目
                oldest_key = next(iter(self.result_cache))
                del self.result_cache[oldest_key]
        
        return result
    
    def recognize_with_all_engines(self, image) -> Optional[OCRResult]:
        """
        使用所有可用引擎识别，并组合结果
        
        Args:
            image: 输入图像
            
        Returns:
            组合后的OCR识别结果
        """
        if not self.available_engines:
            self.logger.error("没有可用的OCR引擎")
            return None
        
        # 收集所有引擎的结果
        all_results = []
        
        # 预处理图像（只做一次）
        processed_image = self.preprocess_image(image)
        
        # 并行或顺序执行
        if self.config['performance']['parallel_processing']:
            # 并行执行（需要实现线程池）
            results = self._recognize_parallel(processed_image)
        else:
            # 顺序执行
            results = []
            for engine_name in self.available_engines:
                if engine_name == 'tesseract':
                    result = self.recognize_with_tesseract(processed_image, preprocessed=True)
                elif engine_name == 'easyocr':
                    result = self.recognize_with_easyocr(processed_image, preprocessed=True)
                elif engine_name == 'paddleocr':
                    result = self.recognize_with_paddleocr(processed_image, preprocessed=True)
                
                if result and result.text:
                    results.append(result)
        
        if not results:
            return None
        
        # 组合结果
        if len(results) == 1:
            return results[0]
        
        # 使用集成方法组合多个结果
        ensemble_method = self.config['ensemble']['method']
        
        if ensemble_method == 'confidence':
            return self._ensemble_by_confidence(results)
        elif ensemble_method == 'voting':
            return self._ensemble_by_voting(results)
        elif ensemble_method == 'weighted':
            return self._ensemble_by_weighted(results)
        else:
            # 默认使用置信度最高的结果
            return self._ensemble_by_confidence(results)
    
    def _ensemble_by_confidence(self, results: List[OCRResult]) -> OCRResult:
        """根据置信度组合结果"""
        # 选择置信度最高的结果
        best_result = max(results, key=lambda r: r.confidence)
        
        # 创建组合结果
        combined = OCRResult(
            text=best_result.text,
            confidence=best_result.confidence,
            engine='ensemble',
            processing_time=sum(r.processing_time for r in results),
            raw_result={'all_results': results, 'method': 'confidence'}
        )
        
        return combined
    
    def _ensemble_by_voting(self, results: List[OCRResult]) -> OCRResult:
        """根据投票组合结果"""
        # 统计每个文本的出现次数
        text_counts = {}
        text_confidences = {}
        
        for result in results:
            text = result.text
            if text:
                text_counts[text] = text_counts.get(text, 0) + 1
                if text not in text_confidences:
                    text_confidences[text] = []
                text_confidences[text].append(result.confidence)
        
        if not text_counts:
            return self._ensemble_by_confidence(results)
        
        # 选择出现次数最多的文本
        max_count = max(text_counts.values())
        candidate_texts = [text for text, count in text_counts.items() if count == max_count]
        
        # 如果有多个候选，选择置信度最高的
        if len(candidate_texts) == 1:
            selected_text = candidate_texts[0]
        else:
            # 计算每个候选的平均置信度
            candidate_scores = {}
            for text in candidate_texts:
                avg_confidence = sum(text_confidences[text]) / len(text_confidences[text])
                candidate_scores[text] = avg_confidence
            
            selected_text = max(candidate_scores.items(), key=lambda x: x[1])[0]
        
        # 计算平均置信度
        avg_confidence = sum(text_confidences[selected_text]) / len(text_confidences[selected_text])
        
        # 创建组合结果
        combined = OCRResult(
            text=selected_text,
            confidence=avg_confidence,
            engine='ensemble',
            processing_time=sum(r.processing_time for r in results),
            raw_result={
                'all_results': results,
                'text_counts': text_counts,
                'method': 'voting'
            }
        )
        
        return combined
    
    def _ensemble_by_weighted(self, results: List[OCRResult]) -> OCRResult:
        """根据加权组合结果"""
        # 为每个引擎分配权重
        engine_weights = {
            'tesseract': 0.4,
            'easyocr': 0.3,
            'paddleocr': 0.3
        }
        
        # 收集所有可能的文本
        all_texts = {}
        
        for result in results:
            text = result.text
            if not text:
                continue
            
            # 计算该结果的权重
            weight = engine_weights.get(result.engine, 0.3) * result.confidence
            
            if text not in all_texts:
                all_texts[text] = {
                    'total_weight': 0,
                    'confidences': [],
                    'engines': []
                }
            
            all_texts[text]['total_weight'] += weight
            all_texts[text]['confidences'].append(result.confidence)
            all_texts[text]['engines'].append(result.engine)
        
        if not all_texts:
            return self._ensemble_by_confidence(results)
        
        # 选择权重最高的文本
        selected_text = max(all_texts.items(), key=lambda x: x[1]['total_weight'])[0]
        text_info = all_texts[selected_text]
        
        # 计算加权置信度
        weighted_confidence = text_info['total_weight'] / sum(
            engine_weights.get(engine, 0.3) for engine in text_info['engines']
        )
        
        # 创建组合结果
        combined = OCRResult(
            text=selected_text,
            confidence=weighted_confidence,
            engine='ensemble',
            processing_time=sum(r.processing_time for r in results),
            raw_result={
                'all_results': results,
                'all_texts': all_texts,
                'method': 'weighted'
            }
        )
        
        return combined
    
    def _recognize_parallel(self, image):
        """并行识别（占位符，需要实现线程池）"""
        # 在实际版本中，这里会使用concurrent.futures实现并行处理
        # 暂时返回空列表
        return []
    
    def _update_stats(self, engine: str, success: bool, confidence: float, processing_time: float):
        """更新统计信息"""
        # 更新引擎使用统计
        if engine not in self.stats['engine_usage']:
            self.stats['engine_usage'][engine] = {
                'count': 0,
                'success': 0,
                'total_confidence': 0,
                'total_time': 0
            }
        
        stats = self.stats['engine_usage'][engine]
        stats['count'] += 1
        
        if success:
            stats['success'] += 1
            stats['total_confidence'] += confidence
            stats['total_time'] += processing_time
        
        # 更新平均置信度
        total_success = sum(s['success'] for s in self.stats['engine_usage'].values())
        total_confidence = sum(s['total_confidence'] for s in self.stats['engine_usage'].values())
        
        if total_success > 0:
            self.stats['average_confidence'] = total_confidence / total_success
        
        # 更新总处理时间
        self.stats['total_processing_time'] = sum(
            s['total_time'] for s in self.stats['engine_usage'].values()
        )
    
    def get_performance_stats(self) -> Dict[str, Any]:
        """获取性能统计"""
        # 计算成功率
        total = self.stats['total_recognitions']
        success = self.stats['successful_recognitions']
        success_rate = success / total if total > 0 else 0
        
        # 计算引擎详细统计
        engine_details = {}
        for engine, stats in self.stats['engine_usage'].items():
            engine_success_rate = stats['success'] / stats['count'] if stats['count'] > 0 else 0
            avg_confidence = stats['total_confidence'] / stats['success'] if stats['success'] > 0 else 0
            avg_time = stats['total_time'] / stats['count'] if stats['count'] > 0 else 0
            
            engine_details[engine] = {
                'usage_count': stats['count'],
                'success_rate': engine_success_rate,
                'average_confidence': avg_confidence,
                'average_time': avg_time
            }
        
        return {
            'timestamp': time.time(),
            'total_recognitions': total,
            'successful_recognitions': success,
            'failed_recognitions': self.stats['failed_recognitions'],
            'success_rate': success_rate,
            'average_confidence': self.stats['average_confidence'],
            'total_processing_time': self.stats['total_processing_time'],
            'engine_details': engine_details,
            'available_engines': self.available_engines,
            'cache_enabled': self.cache_enabled,
            'cache_size': len(self.result_cache),
            'cache_max_size': self.cache_max_size
        }
    
    def optimize_engine_selection(self) -> Dict[str, Any]:
        """
        基于性能统计优化引擎选择
        
        Returns:
            优化建议
        """
        stats = self.get_performance_stats()
        
        suggestions = []
        recommendations = []
        
        # 分析每个引擎的性能
        best_engine = None
        best_score = 0
        
        for engine, details in stats['engine_details'].items():
            # 计算综合评分（成功率 * 置信度 / 时间）
            if details['average_time'] > 0:
                score = (details['success_rate'] * details['average_confidence']) / details['average_time']
            else:
                score = details['success_rate'] * details['average_confidence']
            
            if score > best_score:
                best_score = score
                best_engine = engine
        
        # 生成建议
        current_primary = self.config['primary_engine']
        
        if best_engine and best_engine != current_primary:
            suggestions.append(f"建议将主引擎从 '{current_primary}' 改为 '{best_engine}'")
            recommendations.append({
                'current_primary': current_primary,
                'recommended_primary': best_engine,
                'reason': f"综合评分更高 ({best_score:.3f})"
            })
        
        # 检查是否需要启用集成
        if len(self.available_engines) >= 2 and not self.config['ensemble']['enabled']:
            suggestions.append("建议启用多引擎集成以提高识别准确率")
        
        # 检查缓存效果
        cache_hit_rate = 0  # 在实际版本中需要计算缓存命中率
        if cache_hit_rate < 0.1 and self.cache_enabled:
            suggestions.append("缓存命中率较低，考虑调整缓存策略")
        
        return {
            'suggestions': suggestions,
            'recommendations': recommendations,
            'current_config': {
                'primary_engine': current_primary,
                'fallback_engines': self.config['fallback_engines'],
                'ensemble_enabled': self.config['ensemble']['enabled']
            },
            'performance_summary': {
                'best_engine': best_engine,
                'best_score': best_score,
                'overall_success_rate': stats['success_rate'],
                'average_confidence': stats['average_confidence']
            }
        }
    
    def benchmark_engines(self, test_images: List[str], ground_truth: Dict[str, str]) -> Dict[str, Any]:
        """
        基准测试所有引擎
        
        Args:
            test_images: 测试图像路径列表
            ground_truth: 真实标签字典 {图像路径: 真实文本}
            
        Returns:
            基准测试结果
        """
        results = {
            'engines': {},
            'overall': {
                'total_images': len(test_images),
                'test_start_time': time.time()
            }
        }
        
        # 测试每个引擎
        for engine_name in self.available_engines:
            engine_results = {
                'correct': 0,
                'incorrect': 0,
                'failed': 0,
                'total_time': 0,
                'details': []
            }
            
            for image_path in test_images:
                truth = ground_truth.get(image_path, "")
                
                try:
                    start_time = time.time()
                    result = self.recognize(image_path, engine=engine_name, use_cache=False)
                    processing_time = time.time() - start_time
                    
                    engine_results['total_time'] += processing_time
                    
                    if result and result.text:
                        is_correct = (result.text == truth)
                        
                        if is_correct:
                            engine_results['correct'] += 1
                        else:
                            engine_results['incorrect'] += 1
                        
                        engine_results['details'].append({
                            'image': image_path,
                            'predicted': result.text,
                            'truth': truth,
                            'correct': is_correct,
                            'confidence': result.confidence,
                            'processing_time': processing_time
                        })
                    else:
                        engine_results['failed'] += 1
                        engine_results['details'].append({
                            'image': image_path,
                            'predicted': '',
                            'truth': truth,
                            'correct': False,
                            'confidence': 0,
                            'processing_time': processing_time,
                            'error': '识别失败'
                        })
                        
                except Exception as e:
                    engine_results['failed'] += 1
                    engine_results['details'].append({
                        'image': image_path,
                        'predicted': '',
                        'truth': truth,
                        'correct': False,
                        'confidence': 0,
                        'processing_time': 0,
                        'error': str(e)
                    })
            
            # 计算统计
            total_attempts = engine_results['correct'] + engine_results['incorrect'] + engine_results['failed']
            accuracy = engine_results['correct'] / total_attempts if total_attempts > 0 else 0
            avg_time = engine_results['total_time'] / total_attempts if total_attempts > 0 else 0
            
            results['engines'][engine_name] = {
                'accuracy': accuracy,
                'correct': engine_results['correct'],
                'incorrect': engine_results['incorrect'],
                'failed': engine_results['failed'],
                'average_time': avg_time,
                'total_time': engine_results['total_time'],
                'details': engine_results['details']
            }
        
        # 测试集成方法
        if len(self.available_engines) >= 2 and self.config['ensemble']['enabled']:
            ensemble_results = {
                'correct': 0,
                'incorrect': 0,
                'failed': 0,
                'total_time': 0,
                'details': []
            }
            
            for image_path in test_images:
                truth = ground_truth.get(image_path, "")
                
                try:
                    start_time = time.time()
                    result = self.recognize(image_path, engine='all', use_cache=False)
                    processing_time = time.time() - start_time
                    
                    ensemble_results['total_time'] += processing_time
                    
                    if result and result.text:
                        is_correct = (result.text == truth)
                        
                        if is_correct:
                            ensemble_results['correct'] += 1
                        else:
                            ensemble_results['incorrect'] += 1
                        
                        ensemble_results['details'].append({
                            'image': image_path,
                            'predicted': result.text,
                            'truth': truth,
                            'correct': is_correct,
                            'confidence': result.confidence,
                            'processing_time': processing_time
                        })
                    else:
                        ensemble_results['failed'] += 1
                        
                except Exception as e:
                    ensemble_results['failed'] += 1
            
            total_attempts = ensemble_results['correct'] + ensemble_results['incorrect'] + ensemble_results['failed']
            accuracy = ensemble_results['correct'] / total_attempts if total_attempts > 0 else 0
            avg_time = ensemble_results['total_time'] / total_attempts if total_attempts > 0 else 0
            
            results['engines']['ensemble'] = {
                'accuracy': accuracy,
                'correct': ensemble_results['correct'],
                'incorrect': ensemble_results['incorrect'],
                'failed': ensemble_results['failed'],
                'average_time': avg_time,
                'total_time': ensemble_results['total_time'],
                'details': ensemble_results['details']
            }
        
        results['overall']['test_end_time'] = time.time()
        results['overall']['test_duration'] = results['overall']['test_end_time'] - results['overall']['test_start_time']
        
        return results
    
    def save_config(self, config_path: str) -> bool:
        """保存配置到文件"""
        try:
            config_dir = os.path.dirname(config_path)
            if config_dir:
                os.makedirs(config_dir, exist_ok=True)
            
            with open(config_path, 'w', encoding='utf-8') as f:
                json.dump(self.config, f, indent=2, ensure_ascii=False)
            
            self.logger.info(f"配置已保存: {config_path}")
            return True
            
        except Exception as e:
            self.logger.error(f"保存配置失败: {e}")
            return False
    
    def load_config(self, config_path: str) -> bool:
        """从文件加载配置"""
        try:
            if not os.path.exists(config_path):
                self.logger.warning(f"配置文件不存在: {config_path}")
                return False
            
            with open(config_path, 'r', encoding='utf-8') as f:
                loaded_config = json.load(f)
            
            # 更新配置
            self.config.update(loaded_config)
            
            # 重新初始化引擎
            self._init_engines()
            
            self.logger.info(f"配置已加载: {config_path}")
            return True
            
        except Exception as e:
            self.logger.error(f"加载配置失败: {e}")
            return False


# 测试函数
def test_ocr_multi_engine():
    """测试OCR多引擎模块"""
    print("🔤 测试OCR多引擎模块")
    print("=" * 50)
    
    # 创建OCR多引擎实例
    ocr = OCRMultiEngine()
    
    print(f"✅ 可用引擎: {ocr.available_engines}")
    
    if not ocr.available_engines:
        print("❌ 没有可用的OCR引擎")
        print("💡 请安装至少一个OCR引擎:")
        print("   • Tesseract: pip install pytesseract")
        print("   • EasyOCR: pip install easyocr")
        print("   • PaddleOCR: pip install paddleocr")
        return
    
    # 创建测试目录
    test_dir = Path.home() / "StoneCaptcha" / "test_captchas"
    test_dir.mkdir(parents=True, exist_ok=True)
    
    print(f"\n📁 测试目录: {test_dir}")
    print("💡 请将验证码图片放入该目录进行测试")
    
    # 检查测试图片
    image_files = []
    for ext in ['.png', '.jpg', '.jpeg', '.bmp']:
        image_files.extend([f for f in test_dir.glob(f"*{ext}")])
    
    if image_files:
        print(f"\n📸 找到 {len(image_files)} 个测试图片")
        
        # 测试每个引擎
        for engine_name in ocr.available_engines:
            print(f"\n🔧 测试 {engine_name} 引擎:")
            
            test_image = str(image_files[0])  # 使用第一个图片测试
            print(f"   测试图片: {Path(test_image).name}")
            
            start_time = time.time()
            result = ocr.recognize(test_image, engine=engine_name)
            processing_time = time.time() - start_time
            
            if result:
                print(f"   识别结果: {result.text}")
                print(f"   置信度: {result.confidence:.1%}")
                print(f"   处理时间: {processing_time:.2f}秒")
            else:
                print("   识别失败")
        
        # 测试集成识别
        if len(ocr.available_engines) >= 2:
            print(f"\n🎯 测试集成识别 (使用所有引擎):")
            
            start_time = time.time()
            result = ocr.recognize(test_image, engine='all')
            processing_time = time.time() - start_time
            
            if result:
                print(f"   集成结果: {result.text}")
                print(f"   置信度: {result.confidence:.1%}")
                print(f"   处理时间: {processing_time:.2f}秒")
                print(f"   使用引擎: {result.engine}")
            else:
                print("   集成识别失败")
        
        # 显示性能统计
        print(f"\n📊 性能统计:")
        stats = ocr.get_performance_stats()
        print(f"   总识别次数: {stats['total_recognitions']}")
        print(f"   成功率: {stats['success_rate']:.1%}")
        print(f"   平均置信度: {stats['average_confidence']:.1%}")
        print(f"   总处理时间: {stats['total_processing_time']:.2f}秒")
        
        # 引擎详细统计
        print(f"\n🔧 引擎详细统计:")
        for engine, details in stats['engine_details'].items():
            print(f"   {engine}:")
            print(f"     使用次数: {details['usage_count']}")
            print(f"     成功率: {details['success_rate']:.1%}")
            print(f"     平均置信度: {details['average_confidence']:.1%}")
            print(f"     平均时间: {details['average_time']:.2f}秒")
        
        # 优化建议
        print(f"\n💡 优化建议:")
        suggestions = ocr.optimize_engine_selection()
        for suggestion in suggestions['suggestions']:
            print(f"   • {suggestion}")
        
        if suggestions['recommendations']:
            print(f"\n🎯 推荐配置:")
            for rec in suggestions['recommendations']:
                print(f"   • {rec['reason']}")
                print(f"     当前主引擎: {rec['current_primary']}")
                print(f"     推荐主引擎: {rec['recommended_primary']}")
        
    else:
        print("\n📝 测试目录为空，请添加验证码图片")
        print("💡 支持的格式: PNG, JPG, JPEG, BMP")
    
    print("\n" + "=" * 50)
    print("OCR多引擎模块测试完成")


# 基准测试函数
def benchmark_ocr_engines():
    """基准测试OCR引擎"""
    print("📈 OCR引擎基准测试")
    print("=" * 50)
    
    # 创建OCR实例
    ocr = OCRMultiEngine()
    
    if len(ocr.available_engines) < 2:
        print("❌ 需要至少2个引擎进行基准测试")
        return
    
    # 创建测试数据集
    test_dir = Path.home() / "StoneCaptcha" / "benchmark"
    test_dir.mkdir(parents=True, exist_ok=True)
    
    print(f"📁 基准测试目录: {test_dir}")
    print("💡 请将测试图片和labels.txt文件放入该目录")
    
    # 检查测试数据
    labels_file = test_dir / "labels.txt"
    
    if labels_file.exists():
        # 读取标签
        ground_truth = {}
        with open(labels_file, 'r', encoding='utf-8') as f:
            for line in f:
                if ':' in line:
                    filename, truth = line.strip().split(':', 1)
                    ground_truth[str(test_dir / filename.strip())] = truth.strip()
        
        test_images = list(ground_truth.keys())
        
        if test_images:
            print(f"\n📊 找到 {len(test_images)} 个测试样本")
            
            # 运行基准测试
            print("⏳ 运行基准测试，请稍候...")
            results = ocr.benchmark_engines(test_images, ground_truth)
            
            # 显示结果
            print(f"\n🎯 基准测试结果:")
            print(f"   总测试图片: {results['overall']['total_images']}")
            print(f"   测试时长: {results['overall']['test_duration']:.2f}秒")
            
            print(f"\n🔧 引擎性能排名:")
            engine_results = []
            for engine_name, engine_stats in results['engines'].items():
                if engine_name != 'ensemble':
                    engine_results.append((engine_name, engine_stats['accuracy'], engine_stats['average_time']))
            
            # 按准确率排序
            engine_results.sort(key=lambda x: x[1], reverse=True)
            
            for i, (engine_name, accuracy, avg_time) in enumerate(engine_results, 1):
                print(f"   {i}. {engine_name}:")
                print(f"      准确率: {accuracy:.1%}")
                print(f"      平均时间: {avg_time:.2f}秒")
            
            # 集成结果
            if 'ensemble' in results['engines']:
                ensemble_stats = results['engines']['ensemble']
                print(f"\n🎯 集成方法结果:")
                print(f"   准确率: {ensemble_stats['accuracy']:.1%}")
                print(f"   平均时间: {ensemble_stats['average_time']:.2f}秒")
                
                # 比较集成与最佳单个引擎
                best_engine, best_accuracy, _ = engine_results[0]
                if ensemble_stats['accuracy'] > best_accuracy:
                    improvement = (ensemble_stats['accuracy'] - best_accuracy) * 100
                    print(f"   ✅ 集成比最佳单个引擎({best_engine})准确率高 {improvement:.1f}%")
                else:
                    print(f"   ⚠️  集成未超过最佳单个引擎({best_engine})")
            
            # 生成报告
            report_file = test_dir / "benchmark_report.json"
            with open(report_file, 'w', encoding='utf-8') as f:
                json.dump(results, f, indent=2, ensure_ascii=False)
            
            print(f"\n📄 详细报告已保存: {report_file}")
            
        else:
            print("❌ 未找到测试图片")
    else:
        print("❌ 未找到labels.txt文件")
        print("💡 请创建labels.txt文件，格式: 文件名:真实文本")


if __name__ == "__main__":
    # 设置日志
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    print("选择测试模式:")
    print("  1. 基本功能测试")
    print("  2. 基准测试")
    
    try:
        choice = input("请输入选择 (1/2): ").strip()
        
        if choice == "1":
            test_ocr_multi_engine()
        elif choice == "2":
            benchmark_ocr_engines()
        else:
            print("❌ 无效选择")
    except KeyboardInterrupt:
        print("\n测试被用户中断")
