#!/usr/bin/env python3
"""
三楼脚本深度分析器
基于系统化优化方案的深度分析工具
"""

import os
import re
from datetime import datetime
from pathlib import Path

class ThirdFloorScriptAnalyzer:
    def __init__(self):
        self.script_dir = Path("/root/.openclaw/qqbot/downloads/三楼")
        self.base_dir = Path("/root/.openclaw/workspace/石器时代知识库")
        self.analysis_dir = self.base_dir / "分析报告" / "三楼脚本"
        
        # 创建分析目录
        self.analysis_dir.mkdir(parents=True, exist_ok=True)
        
        # 获取所有脚本文件
        self.script_files = list(self.script_dir.glob("*.asc"))
        print(f"🔍 发现 {len(self.script_files)} 个三楼脚本文件")
    
    def analyze_all_scripts(self):
        """分析所有脚本"""
        print("=" * 60)
        print("🎯 开始深度分析所有三楼脚本")
        print("=" * 60)
        
        summary_report = self.create_summary_report_header()
        individual_reports = []
        
        for script_file in self.script_files:
            print(f"\n📄 分析: {script_file.name}")
            analysis = self.analyze_single_script(script_file)
            individual_reports.append(analysis)
            
            # 添加到总结报告
            summary_report += self.add_to_summary(script_file.name, analysis)
        
        # 生成综合报告
        summary_report += self.generate_comprehensive_analysis(individual_reports)
        
        # 保存报告
        summary_path = self.analysis_dir / "三楼脚本深度分析总结报告.md"
        with open(summary_path, 'w', encoding='utf-8') as f:
            f.write(summary_report)
        
        print(f"\n✅ 深度分析完成!")
        print(f"📄 总结报告: {summary_path}")
        print("=" * 60)
        
        return summary_path
    
    def analyze_single_script(self, script_path):
        """分析单个脚本"""
        with open(script_path, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read()
        
        lines = content.split('\n')
        
        analysis = {
            'file_name': script_path.name,
            'file_size': os.path.getsize(script_path),
            'total_lines': len(lines),
            'set_count': content.count('set '),
            'let_count': content.count('let '),
            'delay_count': len(re.findall(r'delay\s+\d+', content)),
            'goto_count': content.count('goto '),
            'if_count': content.count('if '),
            'comment_count': len([l for l in lines if l.strip().startswith("'")]),
            'function_count': len(re.findall(r'function\s+\S+', content)),
            'label_count': len(re.findall(r'label\s+\S+', content)),
            'time_parameters': [],
            'error_handling': [],
            'config_items': [],
            'script_type': self.classify_script_type(script_path.name, content),
            'complexity_score': 0
        }
        
        # 分析时间参数
        delay_matches = re.finditer(r'delay\s+(\d+)', content)
        for match in delay_matches:
            ms = int(match.group(1))
            analysis['time_parameters'].append({
                'ms': ms,
                'type': self.classify_delay_time(ms)
            })
        
        # 分析错误处理
        error_patterns = [
            (r'goto.*错误', '错误跳转'),
            (r'goto.*失败', '失败跳转'),
            (r'goto.*超时', '超时跳转'),
            (r'if.*>.*60', '超时检测'),
            (r'if.*>.*30', '时间检测')
        ]
        
        for pattern, error_type in error_patterns:
            matches = re.findall(pattern, content)
            if matches:
                analysis['error_handling'].append({
                    'type': error_type,
                    'count': len(matches)
                })
        
        # 分析配置项
        config_lines = []
        for i, line in enumerate(lines, 1):
            if '修改' in line or '改为' in line or '配置' in line or 'let @d' in line:
                config_lines.append((i, line[:80]))
        
        analysis['config_items'] = config_lines
        
        # 计算复杂度分数
        analysis['complexity_score'] = self.calculate_complexity_score(analysis)
        
        # 生成单个脚本报告
        self.generate_individual_report(script_path.name, analysis)
        
        return analysis
    
    def classify_script_type(self, file_name, content):
        """分类脚本类型"""
        if '宠物楼' in file_name or '宠物' in content:
            return '宠物脚本'
        elif '道具楼' in file_name or '道具' in content:
            return '道具脚本'
        elif '试炼' in file_name or '试练' in content:
            return '试炼脚本'
        elif '组队' in file_name or 'join' in content:
            return '组队脚本'
        elif '验证码' in file_name:
            return '验证脚本'
        elif '守卫' in file_name:
            return '守卫脚本'
        else:
            return '通用脚本'
    
    def classify_delay_time(self, ms):
        """分类延迟时间"""
        if ms < 100:
            return "instant"
        elif ms < 1000:
            return "fast"
        elif ms < 5000:
            return "medium"
        else:
            return "slow"
    
    def calculate_complexity_score(self, analysis):
        """计算复杂度分数"""
        score = 0
        score += analysis['total_lines'] * 0.1
        score += analysis['set_count'] * 0.5
        score += analysis['let_count'] * 0.3
        score += analysis['delay_count'] * 0.2
        score += analysis['goto_count'] * 0.4
        score += analysis['if_count'] * 0.3
        score += analysis['function_count'] * 1.0
        score += analysis['label_count'] * 0.5
        
        # 根据脚本类型调整
        if analysis['script_type'] == '组队脚本':
            score *= 1.5
        elif analysis['script_type'] == '宠物脚本':
            score *= 1.3
        elif analysis['script_type'] == '道具脚本':
            score *= 1.2
        
        return round(score, 2)
    
    def create_summary_report_header(self):
        """创建总结报告头部"""
        return f"""# 📊 三楼脚本深度分析总结报告

## 📋 报告信息
- **分析时间**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
- **脚本目录**: {self.script_dir}
- **分析工具**: 三楼脚本深度分析器.py
- **分析原则**: 基于系统化优化方案的深度分析

## 📈 脚本概览

| 脚本名称 | 类型 | 大小 | 行数 | SET | LET | DELAY | 复杂度 |
|----------|------|------|------|-----|-----|-------|--------|
"""
    
    def add_to_summary(self, file_name, analysis):
        """添加到总结报告"""
        return f"| {file_name} | {analysis['script_type']} | {analysis['file_size']}B | {analysis['total_lines']} | {analysis['set_count']} | {analysis['let_count']} | {analysis['delay_count']} | {analysis['complexity_score']} |\n"
    
    def generate_comprehensive_analysis(self, individual_reports):
        """生成综合分析"""
        report = """

## 📊 综合分析结果

### 1. 脚本类型分布
"""
        
        # 统计类型分布
        type_dist = {}
        for analysis in individual_reports:
            script_type = analysis['script_type']
            type_dist[script_type] = type_dist.get(script_type, 0) + 1
        
        for script_type, count in type_dist.items():
            report += f"- **{script_type}**: {count} 个 ({count/len(individual_reports)*100:.1f}%)\n"
        
        report += """
### 2. 复杂度分析
"""
        
        # 复杂度统计
        complexity_scores = [a['complexity_score'] for a in individual_reports]
        avg_complexity = sum(complexity_scores) / len(complexity_scores)
        max_complexity = max(complexity_scores)
        min_complexity = min(complexity_scores)
        
        report += f"- **平均复杂度**: {avg_complexity:.2f}\n"
        report += f"- **最高复杂度**: {max_complexity:.2f}\n"
        report += f"- **最低复杂度**: {min_complexity:.2f}\n"
        
        # 复杂度分布
        report += "- **复杂度分布**:\n"
        for score in [10, 20, 30, 40, 50]:
            count = len([s for s in complexity_scores if s >= score])
            report += f"  - ≥{score}: {count} 个脚本\n"
        
        report += """
### 3. 时间参数分析
"""
        
        # 时间参数统计
        total_delays = sum(a['delay_count'] for a in individual_reports)
        time_types = {'instant': 0, 'fast': 0, 'medium': 0, 'slow': 0}
        
        for analysis in individual_reports:
            for time_param in analysis['time_parameters']:
                time_types[time_param['type']] += 1
        
        report += f"- **总DELAY指令**: {total_delays} 个\n"
        for time_type, count in time_types.items():
            if total_delays > 0:
                percentage = count / total_delays * 100
                report += f"- **{time_type}延迟**: {count} 个 ({percentage:.1f}%)\n"
        
        report += """
### 4. 错误处理分析
"""
        
        # 错误处理统计
        total_errors = sum(len(a['error_handling']) for a in individual_reports)
        error_types = {}
        
        for analysis in individual_reports:
            for error in analysis['error_handling']:
                error_type = error['type']
                error_types[error_type] = error_types.get(error_type, 0) + error['count']
        
        report += f"- **总错误处理点**: {total_errors} 个\n"
        for error_type, count in error_types.items():
            report += f"- **{error_type}**: {count} 个\n"
        
        report += """
### 5. 配置项分析
"""
        
        # 配置项统计
        total_configs = sum(len(a['config_items']) for a in individual_reports)
        report += f"- **总配置项**: {total_configs} 个\n"
        
        # 配置最多的脚本
        config_counts = [(a['file_name'], len(a['config_items'])) for a in individual_reports]
        config_counts.sort(key=lambda x: x[1], reverse=True)
        
        report += "- **配置最多的脚本**:\n"
        for file_name, count in config_counts[:5]:
            if count > 0:
                report += f"  - {file_name}: {count} 个配置项\n"
        
        report += """
## 🎯 优化建议

### 1. 优化优先级排序
基于复杂度分析，建议按以下优先级优化:
"""
        
        # 按复杂度排序
        sorted_reports = sorted(individual_reports, key=lambda x: x['complexity_score'], reverse=True)
        
        for i, analysis in enumerate(sorted_reports[:10], 1):
            report += f"{i}. **{analysis['file_name']}** (复杂度: {analysis['complexity_score']}, 类型: {analysis['script_type']})\n"
        
        report += """
### 2. 不同类型脚本的优化重点
"""
        
        # 不同类型脚本的优化重点
        optimization_focus = {
            '组队脚本': '时间检测增强、队友状态监控、网络同步优化',
            '宠物脚本': '宠物状态监控、技能使用优化、培养流程自动化',
            '道具脚本': '物品管理优化、楼层切换检测、错误自动恢复',
            '试炼脚本': 'Boss检测优化、战斗策略优化、状态恢复',
            '守卫脚本': '位置检测优化、战斗循环优化、状态重置',
            '验证脚本': '验证码识别优化、错误重试机制、用户交互优化',
            '通用脚本': '网络稳定性优化、错误处理增强、运行状态监控'
        }
        
        for script_type, focus in optimization_focus.items():
            if script_type in type_dist:
                report += f"- **{script_type}** ({type_dist[script_type]}个): {focus}\n"
        
        report += """
### 3. 网络优化策略
"""
        
        # 基于时间参数的网络优化策略
        if total_delays > 0:
            instant_percent = time_types['instant'] / total_delays * 100
            slow_percent = time_types['slow'] / total_delays * 100
            
            report += f"- **即时操作** ({instant_percent:.1f}%): 保持原delay时间，添加快速失败检测\n"
            report += f"- **快速响应** ({time_types['fast']/total_delays*100:.1f}%): 添加网络波动检测，1.2倍超时\n"
            report += f"- **中等等待** ({time_types['medium']/total_delays*100:.1f}%): 添加重试机制，1.5倍超时\n"
            report += f"- **长等待** ({slow_percent:.1f}%): 添加详细监控，2.0倍超时，多级重试\n"
        
        report += """
### 4. 错误处理增强
"""
        
        if total_errors > 0:
            report += "- **现有错误处理**: 保留所有原错误处理逻辑\n"
            report += "- **增强建议**: 在原有错误处理基础上添加网络错误检测\n"
            report += "- **监控系统**: 添加错误发生频率和类型的监控\n"
        else:
            report += "- **现状**: 脚本缺乏明显的错误处理机制\n"
            report += "- **建议**: 添加基础的四级错误处理系统\n"
            report += "- **重点**: 网络超时、位置检测、状态验证\n"
        
        report += """
## 🚀 实施计划

### 第1批优化 (高优先级)
1. **组队脚本系列** - 解决30分钟检测和网络同步问题
2. **宠物楼主脚本** - 大型脚本，网络优化需求高
3. **道具楼主脚本** - 多层结构，错误恢复需求高

### 第2批优化 (中优先级)
1. **各楼层守卫脚本** - 标准化优化模板
2. **试炼脚本系列** - Boss战斗优化
3. **验证码脚本** - 用户交互优化

### 第3批优化 (低优先级)
1. **辅助脚本** - 简单功能增强
2. **测试脚本** - 基础网络优化

## 📚 学习要点

### 从三楼脚本中学到的
1. **模块化设计**: 主脚本+子脚本的层次结构
2. **时间控制经验**: 不同操作的不同等待时间
3. **错误处理模式**: 简单的超时检测和跳转
4. **配置管理**: 清晰的用户配置说明

### 优化技术积累
1. **脚本分析技术**: 快速识别脚本类型和复杂度
2. **时间参数分析**: 分类和统计delay指令
3. **错误处理识别**: 检测原脚本的错误处理逻辑
4. **优化策略制定**: 基于分析的针对性优化方案

---

*本报告基于系统化优化方案的深度分析原则生成，为三楼脚本的优化工作提供科学依据。*
"""
        
        return report
    
    def generate_individual_report(self, file_name, analysis):
        """生成单个脚本报告"""
        report_dir = self.analysis_dir / "详细报告"
        report_dir.mkdir(parents=True, exist_ok=True)
        
        report_path = report_dir / f"{file_name}_分析报告.md"
        
        report = f"""# 📄 脚本深度分析报告: {file_name}

## 📋 基本信息
- **文件名称**: {file_name}
- **文件大小**: {analysis['file_size']} 字节
- **总行数**: {analysis['total_lines']} 行
- **脚本类型**: {analysis['script_type']}
- **复杂度评分**: {analysis['complexity_score']}

## 📊 指令统计
- **SET指令**: {analysis['set_count']} 个 (游戏设置)
- **LET指令**: {analysis['let_count']} 个 (变量赋值)
- **DELAY指令**: {analysis['delay_count']} 个 (时间控制)
- **GOTO指令**: {analysis['goto_count']} 个 (流程跳转)
- **IF指令**: {analysis['if_count']} 个 (条件判断)
- **函数定义**: {analysis['function_count']} 个
- **标签定义**: {analysis['label_count']} 个
- **作者注释**: {analysis['comment_count']} 处

## ⏰ 时间参数分析
"""
        
        if analysis['time_parameters']:
            time_stats = {'instant': 0, 'fast': 0, 'medium': 0, 'slow': 0}
            for param in analysis['time_parameters']:
                time_stats[param['type']] += 1
            
            for time_type, count in time_stats.items():
                if count > 0:
                    percentage = count / len(analysis['time_parameters']) * 100
                    report += f"- **{time_type}延迟**: {count} 个 ({percentage:.1f}%)\n"
        else:
            report += "未发现DELAY指令\n"
        
        report += """
## 🚨 错误处理分析
"""
        
        if analysis['error_handling']:
            for error in analysis['error_handling']:
                report += f"- **{error['type']}**: {error['count']} 处\n"
        else:
            report += "未发现明显的错误处理机制\n"
        
        report += """
## ⚙️ 配置项分析
"""
        
        if analysis['config_items']:
            report += f"发现 {len(analysis['config_items'])} 个配置项:\n"
            for line_num, config_line in analysis['config_items'][:5]:  # 显示前5个
                report += f"- 行{line_num}: {config_line}\n"
            if len(analysis['config_items']) > 5:
                report += f"- ... 还有 {len(analysis['config_items']) - 5} 个配置项\n"
        else:
            report += "未发现明显的配置项\n"
        
        report += f"""
## 🎯 优化建议

### 1. 优化优先级
**复杂度评分**: {analysis['complexity_score']}
**优化级别**: {'高' if analysis['complexity_score'] > 30 else '中' if analysis['complexity_score'] > 15 else '低'}

### 2. 优化重点
基于脚本类型 **{analysis['script_type']}**，建议优化:
"""
        
        # 根据脚本类型提供优化建议
        optimization_suggestions = {
            '宠物脚本': [
                "宠物状态实时监控",
                "技能使用优化和冷却管理",
                "培养流程自动化增强",
                "宠物异常状态处理"
            ],
            '道具脚本': [
                "物品管理优化",
                "楼层切换防卡检测",
                "错误自动返回和恢复",
                "运行状态监控"
            ],
            '组队脚本': [
                "时间检测增强 (30分钟检测)",
                "队友状态监控",
                "网络同步优化",
                "队伍解散自动恢复"
            ],
            '试炼脚本': [
                "Boss检测优化",
                "战斗策略智能调整",
                "状态恢复和补给管理",
                "错误重试机制"
            ],
            '守卫脚本': [
                "位置检测优化",
                "战斗循环效率提升",
                "状态重置和恢复",
                "网络波动处理"
            ],
            '验证脚本': [
                "验证码识别优化",
                "用户交互体验改善",
                "错误重试机制",
                "超时处理优化"
            ],
            '通用脚本': [
                "网络稳定性优化",
                "基础错误处理增强",
                "运行状态监控",
                "性能优化"
            ]
        }
        
        suggestions = optimization_suggestions.get(analysis['script_type'], optimization_suggestions['通用脚本'])
        for suggestion in suggestions:
            report += f"- {suggestion}\n"
        
        report += """
### 3. 网络优化策略
"""
        
        if analysis['delay_count'] > 0:
            report += f"- **总DELAY指令**: {analysis['delay_count']} 个\n"
            report += "- **优化策略**:\n"
            report += "  - 每3-5个delay插入一次安全调用\n"
            report += "  - 长等待添加多级重试机制\n"
            report += "  - 添加网络状态监控\n"
        else:
            report += "- 脚本无DELAY指令，网络优化需求较低\n"
        
        report += """
### 4. 错误处理增强
"""
        
        if analysis['error_handling']:
            report += "- **现有错误处理**: 保留所有原错误处理逻辑\n"
            report += "- **增强建议**: 添加网络错误检测和自动恢复\n"
        else:
            report += "- **现状**: 缺乏明显的错误处理机制\n"
            report += "- **建议**: 添加基础的四级错误处理系统\n"
        
        report += """
## 🔧 具体优化方案

### 1. 网络优化函数
```asca
// 安全延迟函数 (根据脚本类型调整参数)
function delay_safe_{file_base}(base_ms)
    set local_retry 0
    set timeout_ms = base_ms * {1.5 if analysis['script_type'] in ['组队脚本', '宠物脚本'] else 1.2}
    
label delay_retry
    delay base_ms
    
    inc local_retry
    if local_retry > {3 if analysis['delay_count'] > 20 else 2}
        log ⚠️ 网络延迟: 原delay base_ms 多次失败
        ret
    
    ret
```

### 2. 状态监控系统
```asca
// {file_name}专用监控
function monitor_{file_base}_status
    log 📊 {analysis['script_type']}监控: 步骤计数，错误级别
    ret
```

### 3. 错误处理增强
```asca
// 增强错误处理
function handle_{file_base}_error(error_type)
    if error_type == "network"
        call network_error_recovery
    elif error_type == "position"
        call position_error_recovery
    elif error_type == "state"
        call state_error_recovery
    ret
```

## 🚀 实施步骤

### 阶段1: 深度分析 (已完成)
- ✅ 脚本基础信息分析
- ✅ 指令统计和分类
- ✅ 时间参数分析
- ✅ 错误处理识别

### 阶段2: 优化设计
1. 基于分析结果设计优化方案
2. 创建脚本专用优化函数
3. 制定优化插入策略
4. 准备优化模板

### 阶段3: 优化实施
1. 创建优化版本脚本
2. 智能插入优化代码
3. 保持原脚本结构完整
4. 添加优化说明和日志

### 阶段4: 测试验证
1. 功能一致性测试
2. 网络优化效果测试
3. 性能影响评估
4. 生成测试报告

---

*本报告基于系统化优化方案的深度分析原则生成，为{file_name}的优化提供科学依据。*
"""
        
        # 替换文件名变量
        file_base = file_name.replace('.asc', '').replace(' ', '_')
        report = report.replace('{file_base}', file_base)
        report = report.replace('{file_name}', file_name)
        
        with open(report_path, 'w', encoding='utf-8') as f:
            f.write(report)
        
        print(f"  📄 生成详细报告: {report_path.name}")

def main():
    """主函数"""
    analyzer = ThirdFloorScriptAnalyzer()
    summary_path = analyzer.analyze_all_scripts()
    
    print(f"\n🎉 深度分析完成!")
    print(f"📊 总结报告: {summary_path}")
    print("=" * 60)
    print("下一步: 基于分析结果制定优化策略")

if __name__ == "__main__":
    main()