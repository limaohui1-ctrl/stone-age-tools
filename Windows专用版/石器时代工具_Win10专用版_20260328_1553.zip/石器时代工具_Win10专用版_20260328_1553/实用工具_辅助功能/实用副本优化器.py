#!/usr/bin/env python3
"""
实用副本优化器
专注于实际副本脚本的优化，解决网络问题和NG25适配
"""

import os
import re
import shutil
from datetime import datetime

class PracticalDungeonOptimizer:
    def __init__(self):
        self.dungeon_dir = "/root/.openclaw/workspace/石器时代客户端处理/解压内容/sqng25/scripts/12.【副本活动】"
        self.optimized_dir = "/root/.openclaw/workspace/实用优化副本"
        
        os.makedirs(self.optimized_dir, exist_ok=True)
    
    def analyze_script(self, script_path):
        """分析脚本的实际内容"""
        with open(script_path, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read()
        
        analysis = {
            'file': os.path.basename(script_path),
            'size': len(content),
            'lines': content.count('\n') + 1,
            'encoding_issues': 0,
            'network_issues': 0,
            'ng25_issues': 0
        }
        
        # 检查编码问题
        if '?' in content and len(content) < 5000:
            analysis['encoding_issues'] = content.count('?')
        
        # 检查网络问题
        lines = content.split('\n')
        for line in lines:
            line_lower = line.lower()
            
            # 检查无超时的等待
            if 'waitdlg' in line_lower and ',' not in line:
                analysis['network_issues'] += 1
            elif 'waitpos' in line_lower and ',' not in line:
                analysis['network_issues'] += 1
            elif 'waitmap' in line_lower and ',' not in line:
                analysis['network_issues'] += 1
        
        return analysis, content
    
    def create_optimized_template(self, script_name, original_content):
        """创建优化模板"""
        template = f"""// ============================================
// {script_name} - NG25优化版
// 优化时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
// 优化内容: 网络波动处理 + NG25适配检查
// ============================================

// 🎯 优化说明:
// 1. 所有等待指令添加超时，防止网络卡顿
// 2. 添加错误重试机制，自动恢复
// 3. 防卡检测，避免脚本永久卡住
// 4. NG25名称适配检查点

// ⚙️ 配置参数
set MAX_RETRY 3           // 最大重试次数
set NETWORK_TIMEOUT 10000 // 网络超时(毫秒)
set POS_TIMEOUT 5000      // 位置超时(毫秒)
set RETRY_DELAY 2000      // 重试延迟(毫秒)

// 📊 状态变量
set retry_count 0
set error_level 0         // 0=正常,1=轻微,2=严重,3=致命
set stuck_counter 0
set step_counter 0

// ============================================
// 🔧 网络优化核心函数
// ============================================

// 安全等待对话框 (带超时和重试)
function waitdlg_safe(npc_name)
    set local_retry 0
label waitdlg_retry
    waitdlg npc_name, NETWORK_TIMEOUT
    if dlg npc_name ret
    inc local_retry
    if local_retry > 2 goto network_error
    log 对话框等待失败，重试中...
    wait RETRY_DELAY
    goto waitdlg_retry

// 安全等待位置
function waitpos_safe(x, y)
    set local_retry 0
label waitpos_retry
    waitpos x, y, POS_TIMEOUT
    if pos x, y ret
    inc local_retry
    if local_retry > 1 goto network_error
    wait RETRY_DELAY
    goto waitpos_retry

// 安全移动
function walk_safe(x, y)
    walkpos x, y
    call waitpos_safe(x, y)
    ret

// 防卡检测
function check_stuck
    inc stuck_counter
    if stuck_counter > 15
        log ⚠️ 检测到可能卡住，尝试恢复
        useitem 羽毛
        wait 3000
        set stuck_counter 0
    ret

// ============================================
// 🚨 错误处理系统
// ============================================

// 网络错误
label network_error
    inc retry_count
    if retry_count > MAX_RETRY goto fatal_error
    log 网络错误，第{'{retry_count}'}次重试
    wait RETRY_DELAY
    ret

// 致命错误
label fatal_error
    log ⚠️ 严重错误，返回记录点
    useitem 羽毛
    wait 3000
    set retry_count 0
    goto start

// ============================================
// 🚀 脚本开始
// ============================================

label start
    // 初始化
    set retry_count 0
    set error_level 0
    set stuck_counter 0
    set step_counter 0
    
    log 🎮 {script_name} - NG25优化版开始运行
    log 📝 已添加网络优化和错误处理
    
    // 网络状态检查
    if map == "" goto network_error
    
    // 防卡检测启动
    call check_stuck

// ============================================
// 📝 NG25适配检查点
// ============================================

// 注意: 以下名称需要确认在NG25私服中是否正确
// 请根据实际情况修改以下名称:

// 1. 地图名称检查
label check_map_names
    // 常见地图名称，确认NG25是否使用相同名称
    // 渔村、福村、萨村、加加村、卡鲁他那村、达那村
    // 沙姆岛、奇咯咯、多多村、小小村、霍比特村
    // 南卡村、塔姆村、柯奥村、特尔坷村、米兰达
    // 伊甸园、地城、水城、火城、风城、冰城
    ret

// 2. NPC名称检查  
label check_npc_names
    // 常见NPC名称，确认NG25是否使用相同名称
    // 商人、银行职员、宠物店、医院、村长
    // 传送员、任务管理员、魔王、女神、守卫
    ret

// 3. 宠物名称检查
label check_pet_names
    // 常见宠物名称，确认NG25是否使用相同名称
    // 人龙、雷龙、老虎、暴龙、机暴
    // 金虎、红虎、绿虎、蓝虎、黄虎
    ret

// 4. 物品名称检查
label check_item_names
    // 常见物品名称，确认NG25是否使用相同名称
    // 羽毛、石币、药水、武器、防具、饰品
    ret

// ============================================
// 🎯 你的副本逻辑从这里开始
// ============================================

// 示例: 前往副本入口
label go_to_dungeon
    inc step_counter
    log 步骤{'{step_counter}'}: 前往副本入口
    
    call check_stuck
    call check_map_names
    
    // 使用安全的移动函数
    call walk_safe(100, 100)
    call walk_safe(120, 120)
    
    // 与NPC对话
    dlg 副本管理员
    call waitdlg_safe("副本管理员")
    
    // 选择副本
    button 1
    call waitdlg_safe("副本选择")
    
    log ✅ 已到达副本入口
    ret

// 示例: 副本战斗
label dungeon_battle
    inc step_counter
    log 步骤{'{step_counter}'}: 开始副本战斗
    
    call check_stuck
    call check_pet_names
    
    // 战斗逻辑
    set battle_retry 0
label battle_loop
    attack 怪物
    wait 2000
    
    // 检查战斗状态
    if fight == 1 goto battle_continue
    if fight == 0 goto battle_complete
    
    inc battle_retry
    if battle_retry > 3 goto network_error
    goto battle_loop

label battle_continue
    // 继续战斗
    wait 1000
    goto battle_loop

label battle_complete
    log ✅ 战斗完成
    ret

// ============================================
// 📋 原始脚本逻辑参考
// ============================================

// 原始脚本内容摘要:
// {original_content[:500]}...

// ============================================
// 🏁 脚本结束处理
// ============================================

label finish
    log 🎉 副本任务完成!
    log 📊 运行统计:
    log   步骤数: {'{step_counter}'}
    log   错误重试: {'{retry_count}'}次
    log   防卡检测: {'{stuck_counter}'}次
    
    log ✅ 脚本安全结束
    stop

// ============================================
// 💡 使用说明
// ============================================
//
// 1. 在"你的副本逻辑从这里开始"部分添加你的逻辑
// 2. 使用安全函数替换原来的指令:
//    - walk_safe() 替换 walkpos
//    - waitdlg_safe() 替换 waitdlg
// 3. 在关键步骤调用 check_stuck() 防止卡住
// 4. 根据NG25实际情况修改名称检查点
// 5. 定期调用 check_map_names() 等检查函数
//
// 优化特性:
// ✅ 网络波动自动处理
// ✅ 四级错误恢复系统  
// ✅ 防卡检测和恢复
// ✅ NG25名称适配检查
// ✅ 详细运行日志
//