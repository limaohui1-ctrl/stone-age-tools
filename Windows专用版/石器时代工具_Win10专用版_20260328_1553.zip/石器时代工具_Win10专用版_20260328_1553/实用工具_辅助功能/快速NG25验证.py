#!/usr/bin/env python3
"""
快速NG25验证工具
快速检查脚本中的名称适配情况
"""

import os
import re
from datetime import datetime

def check_script_names(script_path):
    """检查脚本中的名称"""
    with open(script_path, 'r', encoding='utf-8', errors='ignore') as f:
        content = f.read()
    
    # 提取中文名称
    chinese_pattern = re.compile(r'[\u4e00-\u9fff]{2,}')
    all_names = chinese_pattern.findall(content)
    
    # 分类名称
    categories = {
        '地图': [],
        'NPC': [],
        '宠物': [],
        '物品': [],
        '其他': []
    }
    
    for name in set(all_names):  # 去重
        # 地图特征
        if any(word in name for word in ['村', '城', '岛', '洞', '窟', '楼', '层', '道', '路']):
            categories['地图'].append(name)
        # NPC特征
        elif any(word in name for word in ['商', '员', '店', '院', '长', '神', '王', '卫', '师', '人']):
            categories['NPC'].append(name)
        # 宠物特征
        elif any(word in name for word in ['龙', '虎', '暴', '兽', '宠', '物', '鸡', '狗', '猫', '鱼']):
            categories['宠物'].append(name)
        # 物品特征
        elif any(word in name for word in ['羽', '币', '药', '器', '具', '饰', '证', '石', '材', '水']):
            categories['物品'].append(name)
        else:
            categories['其他'].append(name)
    
    # 排序
    for key in categories:
        categories[key].sort()
    
    return categories

def generate_check_report(script_path, categories):
    """生成检查报告"""
    script_name = os.path.basename(script_path)
    
    report = f"# 🔍 NG25名称检查报告: {script_name}\n\n"
    report += f"**检查时间**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n"
    
    # 统计
    total_names = sum(len(names) for names in categories.values())
    
    report += "## 📊 名称统计\n\n"
    report += f"- **提取名称总数**: {total_names} 个\n"
    
    for category, names in categories.items():
        if names:
            count = len(names)
            percentage = (count / total_names * 100) if total_names > 0 else 0
            report += f"- **{category}**: {count} 个 ({percentage:.1f}%)\n"
    
    report += "\n"
    
    # 详细列表
    for category, names in categories.items():
        if names:
            report += f"## 📋 {category}名称列表\n\n"
            
            # 分组显示，每行5个
            for i in range(0, len(names), 5):
                line_names = names[i:i+5]
                report += " ".join([f"`{name}`" for name in line_names]) + "\n"
            
            report += "\n"
    
    # NG25适配建议
    report += "## 🎯 NG25适配检查清单\n\n"
    
    report += "请逐一检查以下名称在NG25私服中是否可用:\n\n"
    
    check_categories = ['地图', 'NPC', '宠物', '物品']
    for category in check_categories:
        if categories[category]:
            report += f"### {category}名称检查\n\n"
            for name in categories[category]:
                report += f"- [ ] `{name}` - 在NG25中测试是否可用\n"
            report += "\n"
    
    # 检查方法
    report += "## 🔧 检查方法\n\n"
    report += "1. **地图名称**: 尝试使用羽毛传送到该地图\n"
    report += "2. **NPC名称**: 尝试与该NPC对话\n"
    report += "3. **宠物名称**: 尝试捕捉或查看该宠物\n"
    report += "4. **物品名称**: 尝试购买或使用该物品\n\n"
    
    report += "## 📝 记录结果\n\n"
    report += "将检查结果记录如下:\n\n"
    report += "```\n"
    report += "确认可用的名称:\n"
    report += "- 地图: \n"
    report += "- NPC: \n"
    report += "- 宠物: \n"
    report += "- 物品: \n\n"
    
    report += "需要修改的名称 (原名称 → NG25名称):\n"
    report += "- 地图: \n"
    report += "- NPC: \n"
    report += "- 宠物: \n"
    report += "- 物品: \n"
    report += "```\n\n"
    
    report += "---\n"
    report += "*本报告由快速NG25验证工具生成*\n"
    
    return report

def main():
    print("🔍 快速NG25名称检查工具")
    print("=" * 60)
    
    # 检查所有副本脚本
    scripts_dir = "/root/.openclaw/workspace/石器时代客户端处理/解压内容/sqng25/scripts/12.【副本活动】"
    
    script_files = []
    for root, dirs, files in os.walk(scripts_dir):
        for file in files:
            if file.lower().endswith('.asc'):
                script_files.append(os.path.join(root, file))
    
    print(f"找到副本脚本: {len(script_files)} 个")
    print()
    
    all_reports = []
    
    for script_file in script_files:
        script_name = os.path.basename(script_file)
        print(f"检查: {script_name}")
        
        try:
            # 检查名称
            categories = check_script_names(script_file)
            
            # 生成报告
            report = generate_check_report(script_file, categories)
            all_reports.append((script_name, report, categories))
            
            # 显示简要结果
            total_names = sum(len(names) for names in categories.values())
            print(f"  提取名称: {total_names} 个")
            
            for category, names in categories.items():
                if names:
                    print(f"  {category}: {len(names)} 个")
            
        except Exception as e:
            print(f"  ❌ 检查失败: {e}")
        
        print()
    
    # 保存报告
    output_dir = "/root/.openclaw/workspace/NG25名称检查报告"
    os.makedirs(output_dir, exist_ok=True)
    
    for script_name, report, categories in all_reports:
        report_path = os.path.join(output_dir, f"{script_name}_检查报告.md")
        
        with open(report_path, 'w', encoding='utf-8') as f:
            f.write(report)
        
        print(f"📄 报告已保存: {report_path}")
    
    # 生成总结报告
    if all_reports:
        generate_summary_report(all_reports, output_dir)
    
    print()
    print("=" * 60)
    print("🎉 名称检查完成!")
    print(f"📁 报告位置: {output_dir}")

def generate_summary_report(all_reports, output_dir):
    """生成总结报告"""
    report = "# 📊 NG25名称检查总结报告\n\n"
    report += f"**生成时间**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n"
    report += f"**检查脚本**: {len(all_reports)} 个\n\n"
    
    # 总体统计
    total_scripts = len(all_reports)
    total_names = 0
    
    category_totals = {
        '地图': 0,
        'NPC': 0,
        '宠物': 0,
        '物品': 0,
        '其他': 0
    }
    
    for script_name, _, categories in all_reports:
        for category, names in categories.items():
            count = len(names)
            category_totals[category] += count
            total_names += count
    
    report += "## 📈 总体统计\n\n"
    report += f"- **检查脚本总数**: {total_scripts} 个\n"
    report += f"- **提取名称总数**: {total_names} 个\n\n"
    
    report += "## 📋 名称分类统计\n\n"
    for category, total in category_totals.items():
        if total > 0:
            percentage = (total / total_names * 100) if total_names > 0 else 0
            report += f"- **{category}**: {total} 个 ({percentage:.1f}%)\n"
    
    report += "\n"
    
    # 各脚本详情
    report += "## 📋 各脚本检查结果\n\n"
    
    for script_name, _, categories in all_reports:
        script_total = sum(len(names) for names in categories.values())
        
        report += f"### {script_name}\n"
        report += f"- **总名称数**: {script_total} 个\n"
        
        for category, names in categories.items():
            if names:
                report += f"- **{category}**: {len(names)} 个\n"
        
        report += "\n"
    
    # 后续步骤
    report += "## 🚀 后续步骤\n\n"
    report += "1. **逐一检查**: 根据各脚本的检查报告，逐一验证名称\n"
    report += "2. **记录结果**: 在检查报告中记录验证结果\n"
    report += "3. **更新脚本**: 根据验证结果更新脚本中的名称\n"
    report += "4. **测试运行**: 在NG25私服中测试更新后的脚本\n\n"
    
    report += "## 💡 检查提示\n\n"
    report += "- 优先检查高频使用的名称\n"
    report += "- 注意地图传送点的名称差异\n"
    report += "- 记录NPC对话选项的准确名称\n"
    report += "- 验证宠物捕捉指令的正确性\n\n"
    
    report += "---\n"
    report += "*本报告由快速NG25验证工具生成*\n"
    
    summary_path = os.path.join(output_dir, "检查总结报告.md")
    with open(summary_path, 'w', encoding='utf-8') as f:
        f.write(report)
    
    print(f"📊 总结报告已保存: {summary_path}")

if __name__ == "__main__":
    main()