#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
石器时代私服名称替换工具
功能：将官服的地图NPC名称和宠物名称替换为私服的名称
"""

import os
import re
import json
from pathlib import Path

class 石器时代名称替换器:
    def __init__(self):
        self.地图NPC映射 = {}
        self.宠物名称映射 = {}
        self.加载映射数据()
        
    def 加载映射数据(self):
        """加载官服到私服的名称映射数据"""
        try:
            # 加载地图NPC映射 - 尝试多种编码
            npc文件路径 = Path(__file__).parent / "官服-私服_地图NPC对比.txt"
            for 编码 in ['gb2312', 'gbk', 'utf-8', 'utf-8-sig']:
                try:
                    with open(npc文件路径, 'r', encoding=编码) as f:
                        for line in f:
                            line = line.strip()
                            if line:
                                # 尝试多种分隔符：空格、制表符、全角空格
                                for sep in [' ', '\t', '　']:
                                    if sep in line:
                                        官服名称, 私服名称 = line.split(sep, 1)
                                        self.地图NPC映射[官服名称.strip()] = 私服名称.strip()
                                        break
                    print(f"地图NPC映射使用 {编码} 编码加载成功")
                    break
                except UnicodeDecodeError:
                    continue
            
            print(f"已加载 {len(self.地图NPC映射)} 个地图NPC名称映射")
            
            # 加载宠物名称映射 - 尝试多种编码
            宠物文件路径 = Path(__file__).parent / "官服-私服_宠物名称替换.txt"
            for 编码 in ['gb2312', 'gbk', 'utf-8', 'utf-8-sig']:
                try:
                    with open(宠物文件路径, 'r', encoding=编码) as f:
                        for line in f:
                            line = line.strip()
                            if line and ',' in line:
                                官服名称, 私服名称 = line.split(',', 1)
                                self.宠物名称映射[官服名称.strip()] = 私服名称.strip()
                    print(f"宠物名称映射使用 {编码} 编码加载成功")
                    break
                except UnicodeDecodeError:
                    continue
            
            print(f"已加载 {len(self.宠物名称映射)} 个宠物名称映射")
            
            # 显示一些示例映射
            print("\n=== 映射数据示例 ===")
            print("地图NPC映射示例:")
            for i, (官服, 私服) in enumerate(list(self.地图NPC映射.items())[:5]):
                print(f"  {官服} -> {私服}")
            
            print("\n宠物名称映射示例:")
            for i, (官服, 私服) in enumerate(list(self.宠物名称映射.items())[:5]):
                print(f"  {官服} -> {私服}")
            
        except Exception as e:
            print(f"加载映射数据时出错: {e}")
            import traceback
            traceback.print_exc()
            
    def 替换ASSA脚本(self, 脚本内容):
        """替换ASSA脚本中的官服名称为私服名称"""
        替换后内容 = 脚本内容
        
        # 先替换宠物名称（因为宠物名称可能包含在地图NPC名称中）
        for 官服名称, 私服名称 in self.宠物名称映射.items():
            if 官服名称 and 私服名称:
                # 直接替换，中文不需要单词边界
                替换后内容 = 替换后内容.replace(官服名称, 私服名称)
        
        # 替换地图NPC名称
        for 官服名称, 私服名称 in self.地图NPC映射.items():
            if 官服名称 and 私服名称:
                # 直接替换，中文不需要单词边界
                替换后内容 = 替换后内容.replace(官服名称, 私服名称)
        
        return 替换后内容
    
    def 替换LUA脚本(self, 脚本内容):
        """替换LUA脚本中的官服名称为私服名称"""
        # LUA脚本的替换逻辑与ASSA类似
        return self.替换ASSA脚本(脚本内容)
    
    def 处理脚本文件(self, 输入文件路径, 输出文件路径=None):
        """处理单个脚本文件"""
        try:
            with open(输入文件路径, 'r', encoding='utf-8') as f:
                原始内容 = f.read()
            
            替换后内容 = self.替换ASSA脚本(原始内容)
            
            if 输出文件路径 is None:
                输出文件路径 = 输入文件路径.replace('.', '_私服.')
            
            with open(输出文件路径, 'w', encoding='utf-8') as f:
                f.write(替换后内容)
            
            print(f"已处理文件: {输入文件路径}")
            print(f"输出文件: {输出文件路径}")
            
            # 统计替换次数
            替换统计 = self.统计替换次数(原始内容, 替换后内容)
            print(f"替换统计: {替换统计}")
            
            return True
            
        except Exception as e:
            print(f"处理文件 {输入文件路径} 时出错: {e}")
            return False
    
    def 统计替换次数(self, 原始内容, 替换后内容):
        """统计替换的次数"""
        统计结果 = {
            '地图NPC替换': 0,
            '宠物名称替换': 0,
            '总替换': 0
        }
        
        # 统计宠物名称替换
        for 官服名称, 私服名称 in self.宠物名称映射.items():
            if 官服名称 and 私服名称:
                次数 = 原始内容.count(官服名称)
                if 次数 > 0:
                    统计结果['宠物名称替换'] += 次数
                    统计结果['总替换'] += 次数
        
        # 统计地图NPC替换
        for 官服名称, 私服名称 in self.地图NPC映射.items():
            if 官服名称 and 私服名称:
                次数 = 原始内容.count(官服名称)
                if 次数 > 0:
                    统计结果['地图NPC替换'] += 次数
                    统计结果['总替换'] += 次数
        
        return 统计结果
    
    def 批量处理目录(self, 输入目录, 输出目录=None, 文件扩展名=['.asc', '.lua', '.txt']):
        """批量处理目录中的所有脚本文件"""
        if 输出目录 is None:
            输出目录 = 输入目录 + "_私服"
        
        Path(输出目录).mkdir(parents=True, exist_ok=True)
        
        处理文件列表 = []
        for 扩展 in 文件扩展名:
            for 文件 in Path(输入目录).glob(f"*{扩展}"):
                处理文件列表.append(文件)
        
        print(f"找到 {len(处理文件列表)} 个待处理文件")
        
        成功计数 = 0
        for 输入文件 in 处理文件列表:
            输出文件 = Path(输出目录) / 输入文件.name
            if self.处理脚本文件(str(输入文件), str(输出文件)):
                成功计数 += 1
        
        print(f"\n批量处理完成: {成功计数}/{len(处理文件列表)} 个文件处理成功")
        return 成功计数
    
    def 生成替换规则文档(self):
        """生成替换规则的详细文档"""
        文档内容 = """# 石器时代私服名称替换规则文档

## 概述
本文档记录了官服到私服的地图NPC和宠物名称替换规则。

## 地图NPC名称替换规则
| 官服名称 | 私服名称 |
|----------|----------|
"""
        
        for 官服名称, 私服名称 in sorted(self.地图NPC映射.items()):
            文档内容 += f"| {官服名称} | {私服名称} |\n"
        
        文档内容 += "\n## 宠物名称替换规则\n| 官服名称 | 私服名称 |\n|----------|----------|\n"
        
        for 官服名称, 私服名称 in sorted(self.宠物名称映射.items()):
            文档内容 += f"| {官服名称} | {私服名称} |\n"
        
        文档内容 += f"""
## 统计信息
- 地图NPC映射数量: {len(self.地图NPC映射)}
- 宠物名称映射数量: {len(self.宠物名称映射)}
- 总映射数量: {len(self.地图NPC映射) + len(self.宠物名称映射)}

## 使用说明
1. 使用 `名称替换工具.py` 处理脚本文件
2. 支持ASSA脚本(.asc)和LUA脚本(.lua)
3. 支持批量处理目录
4. 替换时会确保完整单词匹配，避免误替换

## 注意事项
1. 替换是单向的（官服 → 私服）
2. 建议在处理前备份原始文件
3. 处理完成后请检查替换结果
"""
        
        输出路径 = Path(__file__).parent / "替换规则文档.md"
        with open(输出路径, 'w', encoding='utf-8') as f:
            f.write(文档内容)
        
        print(f"已生成替换规则文档: {输出路径}")
        return 输出路径

def 主函数():
    """主函数：提供命令行界面"""
    import sys
    
    替换器 = 石器时代名称替换器()
    
    if len(sys.argv) < 2:
        print("""
石器时代私服名称替换工具
用法:
  python 名称替换工具.py [命令] [参数]
  
命令:
  help                   显示帮助信息
  stats                  显示映射统计信息
  doc                    生成替换规则文档
  process <文件>         处理单个文件
  batch <目录>           批量处理目录
  test <文本>            测试替换效果
  
示例:
  python 名称替换工具.py stats
  python 名称替换工具.py process 脚本示例/补灵石.asc
  python 名称替换工具.py batch 脚本示例
  python 名称替换工具.py test "去萨姆吉尔村找护士"
""")
        return
    
    命令 = sys.argv[1]
    
    if 命令 == 'help':
        print("帮助信息已显示")
        
    elif 命令 == 'stats':
        print(f"地图NPC映射数量: {len(替换器.地图NPC映射)}")
        print(f"宠物名称映射数量: {len(替换器.宠物名称映射)}")
        print(f"总映射数量: {len(替换器.地图NPC映射) + len(替换器.宠物名称映射)}")
        
    elif 命令 == 'doc':
        文档路径 = 替换器.生成替换规则文档()
        print(f"已生成文档: {文档路径}")
        
    elif 命令 == 'process' and len(sys.argv) >= 3:
        输入文件 = sys.argv[2]
        输出文件 = sys.argv[3] if len(sys.argv) >= 4 else None
        替换器.处理脚本文件(输入文件, 输出文件)
        
    elif 命令 == 'batch' and len(sys.argv) >= 3:
        输入目录 = sys.argv[2]
        输出目录 = sys.argv[3] if len(sys.argv) >= 4 else None
        替换器.批量处理目录(输入目录, 输出目录)
        
    elif 命令 == 'test' and len(sys.argv) >= 3:
        测试文本 = ' '.join(sys.argv[2:])
        替换后文本 = 替换器.替换ASSA脚本(测试文本)
        print(f"原始文本: {测试文本}")
        print(f"替换后文本: {替换后文本}")
        
    else:
        print(f"未知命令: {命令}")
        print("使用 'python 名称替换工具.py help' 查看帮助")

if __name__ == "__main__":
    主函数()