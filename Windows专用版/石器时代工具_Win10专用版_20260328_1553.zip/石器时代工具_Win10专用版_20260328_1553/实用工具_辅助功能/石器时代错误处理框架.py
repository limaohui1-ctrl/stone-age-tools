#!/usr/bin/env python3
"""
石器时代错误处理框架
四级错误处理系统：致命、严重、一般、提示
"""

import json
import os
from datetime import datetime
from enum import Enum
from typing import Dict, List, Optional, Any

class ErrorLevel(Enum):
    """错误级别枚举"""
    FATAL = "fatal"      # 致命错误 - 脚本必须停止
    SEVERE = "severe"    # 严重错误 - 功能严重受限
    GENERAL = "general"  # 一般错误 - 功能部分受限，可恢复
    INFO = "info"        # 提示信息 - 状态反馈，不影响功能
    
    def get_display_name(self):
        """获取显示名称"""
        names = {
            "fatal": "致命错误",
            "severe": "严重错误", 
            "general": "一般错误",
            "info": "提示信息"
        }
        return names.get(self.value, self.value)
    
    def get_color_code(self):
        """获取颜色代码（用于ASSA脚本）"""
        colors = {
            "fatal": "0xFF0000",    # 红色
            "severe": "0xFF6600",   # 橙色
            "general": "0xFFFF00",  # 黄色
            "info": "0x00FF00"      # 绿色
        }
        return colors.get(self.value, "0xFFFFFF")

class StoneAgeError:
    """石器时代错误类"""
    
    def __init__(self, 
                 level: ErrorLevel,
                 code: str,
                 message: str,
                 context: Dict[str, Any] = None,
                 recovery_suggestion: str = None,
                 timestamp: str = None):
        
        self.level = level
        self.code = code
        self.message = message
        self.context = context or {}
        self.recovery_suggestion = recovery_suggestion
        self.timestamp = timestamp or datetime.now().isoformat()
        
        # 错误ID格式: LEVEL-CODE-TIMESTAMP
        self.error_id = f"{level.value.upper()}-{code}-{datetime.now().strftime('%Y%m%d%H%M%S')}"
    
    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return {
            "error_id": self.error_id,
            "level": self.level.value,
            "level_display": self.level.get_display_name(),
            "code": self.code,
            "message": self.message,
            "context": self.context,
            "recovery_suggestion": self.recovery_suggestion,
            "timestamp": self.timestamp,
            "color_code": self.level.get_color_code()
        }
    
    def to_assascript(self) -> str:
        """转换为ASSA脚本格式"""
        color = self.level.get_color_code()
        level_name = self.level.get_display_name()
        
        assa_code = f"""
// ============================================
// 错误处理: {level_name}
// 错误ID: {self.error_id}
// 时间: {self.timestamp}
// ============================================

// 显示错误信息
print("错误级别: {level_name}", {color})
print("错误代码: {self.code}", {color})
print("错误信息: {self.message}", {color})
"""
        
        if self.context:
            assa_code += f'print("错误上下文: {json.dumps(self.context, ensure_ascii=False)}", {color})\n'
        
        if self.recovery_suggestion:
            assa_code += f'print("恢复建议: {self.recovery_suggestion}", {color})\n'
        
        # 根据错误级别添加不同的处理逻辑
        if self.level == ErrorLevel.FATAL:
            assa_code += f"""
// 致命错误 - 停止脚本执行
print("脚本因致命错误停止执行", {color})
stop
"""
        elif self.level == ErrorLevel.SEVERE:
            assa_code += f"""
// 严重错误 - 尝试恢复或等待用户干预
print("严重错误，建议检查后继续", {color})
wait 5000  // 等待5秒让用户查看错误
// 可以在这里添加恢复逻辑或跳转到错误处理标签
"""
        elif self.level == ErrorLevel.GENERAL:
            assa_code += f"""
// 一般错误 - 继续执行但记录错误
print("一般错误，继续执行但功能可能受限", {color})
// 可以在这里添加降级处理逻辑
"""
        elif self.level == ErrorLevel.INFO:
            assa_code += f"""
// 提示信息 - 仅记录，不影响执行
print("提示信息: {self.message}", {color})
// 继续正常执行
"""
        
        assa_code += "// ============================================\n"
        return assa_code
    
    def __str__(self) -> str:
        return f"[{self.level.get_display_name()}] {self.code}: {self.message}"

class ErrorHandler:
    """错误处理器"""
    
    def __init__(self):
        self.data_dir = "/root/.openclaw/workspace/错误处理数据"
        self.create_data_dir()
        
        # 错误定义文件
        self.error_definitions_file = os.path.join(self.data_dir, "error_definitions.json")
        self.error_history_file = os.path.join(self.data_dir, "error_history.json")
        
        # 预定义错误类型
        self.predefined_errors = {
            # 坐标相关错误
            "COORD_INVALID": {
                "level": ErrorLevel.FATAL,
                "message": "坐标无效或超出地图范围",
                "recovery": "检查坐标值，确保在地图有效范围内"
            },
            "COORD_NOT_FOUND": {
                "level": ErrorLevel.SEVERE,
                "message": "无法到达指定坐标",
                "recovery": "检查路径是否被阻挡，尝试重新计算路径"
            },
            
            # NPC相关错误
            "NPC_NOT_FOUND": {
                "level": ErrorLevel.SEVERE,
                "message": "NPC未找到或不在预期位置",
                "recovery": "检查NPC名称和位置，等待NPC出现或重新搜索"
            },
            "NPC_DIALOG_FAILED": {
                "level": ErrorLevel.GENERAL,
                "message": "与NPC对话失败",
                "recovery": "重新尝试对话，检查网络连接"
            },
            
            # 网络和连接错误
            "NETWORK_TIMEOUT": {
                "level": ErrorLevel.GENERAL,
                "message": "网络连接超时",
                "recovery": "检查网络连接，等待后重试"
            },
            "CONNECTION_LOST": {
                "level": ErrorLevel.SEVERE,
                "message": "游戏连接丢失",
                "recovery": "重新连接游戏，检查游戏客户端状态"
            },
            
            # 物品和道具错误
            "ITEM_NOT_FOUND": {
                "level": ErrorLevel.GENERAL,
                "message": "所需物品未找到",
                "recovery": "检查背包，购买或获取所需物品"
            },
            "ITEM_INSUFFICIENT": {
                "level": ErrorLevel.INFO,
                "message": "物品数量不足",
                "recovery": "收集更多所需物品"
            },
            
            # 脚本逻辑错误
            "SCRIPT_LOGIC_ERROR": {
                "level": ErrorLevel.FATAL,
                "message": "脚本逻辑错误",
                "recovery": "检查脚本逻辑，修复错误后重新执行"
            },
            "STATE_MISMATCH": {
                "level": ErrorLevel.SEVERE,
                "message": "游戏状态与预期不符",
                "recovery": "检查当前游戏状态，调整脚本逻辑"
            },
            
            # 系统错误
            "MEMORY_LOW": {
                "level": ErrorLevel.INFO,
                "message": "系统内存不足",
                "recovery": "关闭不必要的程序，释放内存"
            },
            "DISK_SPACE_LOW": {
                "level": ErrorLevel.INFO,
                "message": "磁盘空间不足",
                "recovery": "清理磁盘空间"
            }
        }
        
        # 加载或初始化数据
        self.error_definitions = self.load_error_definitions()
        self.error_history = self.load_error_history()
    
    def create_data_dir(self):
        """创建数据目录"""
        if not os.path.exists(self.data_dir):
            os.makedirs(self.data_dir)
            print(f"创建数据目录: {self.data_dir}")
    
    def load_error_definitions(self) -> Dict:
        """加载错误定义"""
        if os.path.exists(self.error_definitions_file):
            try:
                with open(self.error_definitions_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except:
                return self.predefined_errors
        else:
            return self.predefined_errors
    
    def load_error_history(self) -> List[Dict]:
        """加载错误历史"""
        if os.path.exists(self.error_history_file):
            try:
                with open(self.error_history_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except:
                return []
        else:
            return []
    
    def save_data(self):
        """保存所有数据"""
        # 保存错误定义
        with open(self.error_definitions_file, 'w', encoding='utf-8') as f:
            json.dump(self.error_definitions, f, ensure_ascii=False, indent=2)
        
        # 保存错误历史
        with open(self.error_history_file, 'w', encoding='utf-8') as f:
            json.dump(self.error_history, f, ensure_ascii=False, indent=2)
    
    def create_error(self, 
                    level: ErrorLevel,
                    code: str,
                    message: str,
                    context: Dict[str, Any] = None,
                    recovery_suggestion: str = None) -> StoneAgeError:
        """创建错误对象"""
        
        # 如果提供了错误代码，尝试使用预定义的消息和恢复建议
        if code in self.error_definitions:
            error_def = self.error_definitions[code]
            if not message:
                message = error_def.get("message", "")
            if not recovery_suggestion:
                recovery_suggestion = error_def.get("recovery", "")
            if not level:
                level_str = error_def.get("level", "general")
                level = ErrorLevel(level_str)
        
        error = StoneAgeError(
            level=level,
            code=code,
            message=message,
            context=context,
            recovery_suggestion=recovery_suggestion
        )
        
        # 记录到历史
        self.error_history.append(error.to_dict())
        self.save_data()
        
        return error
    
    def handle_error(self, error: StoneAgeError) -> str:
        """处理错误并返回ASSA脚本代码"""
        # 记录错误
        print(f"处理错误: {error}")
        
        # 根据错误级别采取不同行动
        if error.level == ErrorLevel.FATAL:
            print("🔴 致命错误 - 脚本需要停止")
        elif error.level == ErrorLevel.SEVERE:
            print("🟠 严重错误 - 需要用户干预")
        elif error.level == ErrorLevel.GENERAL:
            print("🟡 一般错误 - 功能受限但可继续")
        elif error.level == ErrorLevel.INFO:
            print("🟢 提示信息 - 仅记录")
        
        # 返回ASSA脚本代码
        return error.to_assascript()
    
    def generate_error_report(self, hours: int = 24) -> str:
        """生成错误报告"""
        now = datetime.now()
        cutoff_time = now.timestamp() - (hours * 3600)
        
        # 过滤指定时间内的错误
        recent_errors = []
        for error in self.error_history:
            try:
                error_time = datetime.fromisoformat(error["timestamp"]).timestamp()
                if error_time >= cutoff_time:
                    recent_errors.append(error)
            except:
                continue
        
        # 按级别统计
        level_stats = {}
        for error in recent_errors:
            level = error["level"]
            level_stats[level] = level_stats.get(level, 0) + 1
        
        # 生成报告
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        report_file = os.path.join(self.data_dir, f"error_report_{timestamp}.md")
        
        with open(report_file, 'w', encoding='utf-8') as f:
            f.write("# 石器时代错误处理报告\n\n")
            f.write(f"**生成时间**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
            f.write(f"**统计时段**: 最近 {hours} 小时\n")
            f.write(f"**错误总数**: {len(recent_errors)}\n\n")
            
            f.write("## 📊 错误统计\n\n")
            f.write("| 错误级别 | 数量 | 百分比 |\n")
            f.write("|----------|------|--------|\n")
            
            total = len(recent_errors)
            for level, count in sorted(level_stats.items(), key=lambda x: x[1], reverse=True):
                percentage = (count / total * 100) if total > 0 else 0
                level_name = ErrorLevel(level).get_display_name()
                f.write(f"| {level_name} | {count} | {percentage:.1f}% |\n")
            
            f.write("\n## 📋 错误详情\n\n")
            
            if recent_errors:
                f.write("| 时间 | 级别 | 代码 | 信息 | 恢复建议 |\n")
                f.write("|------|------|------|------|----------|\n")
                
                for error in sorted(recent_errors, key=lambda x: x["timestamp"], reverse=True)[:20]:  # 显示最近20个
                    time_str = error["timestamp"][11:19]  # 只显示时间部分
                    level_name = error["level_display"]
                    code = error["code"]
                    message = error["message"][:30] + "..." if len(error["message"]) > 30 else error["message"]
                    recovery = error.get("recovery_suggestion", "无")[:30] + "..." if len(error.get("recovery_suggestion", "")) > 30 else error.get("recovery_suggestion", "无")
                    
                    f.write(f"| {time_str} | {level_name} | {code} | {message} | {recovery} |\n")
            else:
                f.write("⚠️ 最近 {hours} 小时内没有错误记录\n\n")
            
            f.write("\n## 🔧 错误处理建议\n\n")
            
            if level_stats.get("fatal", 0) > 0:
                f.write("### 🔴 致命错误处理\n")
                f.write(f"- 数量: {level_stats.get('fatal', 0)} 个\n")
                f.write("- 建议: 检查脚本逻辑，修复导致脚本停止的错误\n\n")
            
            if level_stats.get("severe", 0) > 0:
                f.write("### 🟠 严重错误处理\n")
                f.write(f"- 数量: {level_stats.get('severe', 0)} 个\n")
                f.write("- 建议: 优化错误恢复逻辑，减少用户干预需求\n\n")
            
            if level_stats.get("general", 0) > 0:
                f.write("### 🟡 一般错误处理\n")
                f.write(f"- 数量: {level_stats.get('general', 0)} 个\n")
                f.write("- 建议: 实现自动恢复机制，提高脚本健壮性\n\n")
            
            if level_stats.get("info", 0) > 0:
                f.write("### 🟢 提示信息\n")
                f.write(f"- 数量: {level_stats.get('info', 0)} 个\n")
                f.write("- 建议: 保持当前记录，用于脚本状态监控\n\n")
            
            f.write("## 🚀 改进建议\n\n")
            f.write("1. **错误预防**: 在脚本中添加更多验证逻辑\n")
            f.write("2. **自动恢复**: 为常见错误实现自动恢复机制\n")
            f.write("3. **错误监控**: 建立错误监控和报警系统\n")
            f.write("4. **脚本优化**: 根据错误统计优化脚本逻辑\n")
            f.write("5. **用户反馈**: 收集用户反馈改进错误处理\n")
        
        print(f"错误报告已生成: {report_file}")
        return report_file
    
    def generate_assascript_template(self) -> str:
        """生成ASSA脚本错误处理模板"""
        template_file = os.path.join(self.data_dir, "error_handling_template.asc")
        
        template = f"""// ============================================
// 石器时代脚本错误处理模板
// 基于四级错误处理系统
// 生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
// ============================================

// 错误处理函数定义
function HandleError(level, code, message, context, recovery)
    // 根据错误级别选择颜色
    if level == "fatal"
        color = 0xFF0000  // 红色
        levelName = "致命错误"
    elseif level == "severe"
        color = 0xFF6600  // 橙色
        levelName = "严重错误"
    elseif level == "general"
        color = 0xFFFF00  // 黄色
        levelName = "一般错误"
    else
        color = 0x00FF00  // 绿色
        levelName = "提示信息"
    endif
    
    // 显示错误信息
    print("[" + levelName + "] " + code + ": " + message, color)
    
    if context != ""
        print("上下文: " + context, color)
    endif
    
    if recovery != ""
        print("恢复建议: " + recovery, color)
    endif
    
    // 根据错误级别采取不同行动
    if level == "fatal"
        print("脚本因致命错误停止执行", color)
        stop
    elseif level == "severe"
        print("严重错误，等待5秒后尝试恢复...", color)
        wait 5000
        // 可以跳转到恢复标签
        // goto RecoveryLabel
    elseif level == "general"
        print("一般错误，继续执行但功能可能受限", color)
        // 继续执行，但记录错误
    else
        print("提示信息，继续正常执行", color)
    endif
endfunction

// ============================================
// 预定义错误处理函数
// ============================================

// 坐标错误处理
function HandleCoordError(x, y, mapName)
    // 检查坐标是否有效
    if x < 0 or y < 0
        HandleError("fatal", "COORD_INVALID", "坐标值为负数: (" + x + "," + y + ")", "地图: " + mapName, "检查坐标计算逻辑")
        return false
    endif
    
    // 这里可以添加更多坐标验证逻辑
    // ...
    
    return true
endfunction

// NPC错误处理
function HandleNPCError(npcName, expectedLocation)
    print("正在寻找NPC: " + npcName, 0xFFFFFF)
    
    // 尝试查找NPC
    // 如果找不到，报告错误
    if npcNotFound
        HandleError("severe", "NPC_NOT_FOUND", "未找到NPC: " + npcName, "预期位置: " + expectedLocation, "等待NPC出现或重新搜索")
        return false
    endif
    
    return true
endfunction

// 网络错误处理
function HandleNetworkError()
    // 检查网络连接
    if networkTimeout
        HandleError("general", "NETWORK_TIMEOUT", "网络连接超时", "", "等待3秒后重试")
        wait 3000
        return false
    endif
    
    if connectionLost
        HandleError("severe", "CONNECTION_LOST", "游戏连接丢失", "", "检查游戏客户端状态")
        return false
    endif
    
    return true
endfunction

// 物品错误处理
function HandleItemError(itemName, requiredAmount)
    currentAmount = GetItemCount(itemName)
    
    if currentAmount < requiredAmount
        HandleError("info", "ITEM_INSUFFICIENT", "物品数量不足: " + itemName, "当前: " + currentAmount + ", 需要: " + requiredAmount, "收集更多" + itemName)
        return false
    endif
    
    return true
endfunction

// ============================================
// 错误恢复函数
// ============================================

label RecoveryLabel
// 错误恢复逻辑从这里开始

// 示例恢复逻辑
function TryRecoverFromError(errorCode)
    print("尝试从错误恢复: " + errorCode, 0xFFFFFF)
    
    if errorCode == "NETWORK_TIMEOUT"
        // 网络超时恢复
        wait 5000
        print("网络恢复尝试完成", 0x00FF00)
        return true
    elseif errorCode == "NPC_NOT_FOUND"
        // NPC未找到恢复
        print("重新搜索NPC...", 0xFFFF00)
        // 重新搜索逻辑
        return true
    endif
    
    return false
endfunction

// ============================================
// 错误监控和报告
// ============================================

// 错误计数器
errorCountFatal = 0
errorCountSevere = 0
errorCountGeneral = 0
errorCountInfo = 0

// 错误记录函数
function RecordError(level)
    if level == "fatal"
        errorCountFatal = errorCountFatal + 1
    elseif level == "severe"
        errorCountSevere = errorCountSevere + 1
    elseif level == "general"
        errorCountGeneral = errorCountGeneral + 1
    else
        errorCountInfo = errorCountInfo + 1
    endif
endfunction

// 生成错误报告
function GenerateErrorReport()
    totalErrors = errorCountFatal + errorCountSevere + errorCountGeneral + errorCountInfo
    
    print("=== 错误统计报告 ===", 0xFFFFFF)
    print("运行时间: " + GetCurrentTime(), 0xFFFFFF)
    print("总错误数: " + totalErrors, 0xFFFFFF)
    print("致命错误: " + errorCountFatal, 0xFF0000)
    print("严重错误: " + errorCountSevere, 0xFF6600)
    print("一般错误: " + errorCountGeneral, 0xFFFF00)
    print("提示信息: " + errorCountInfo, 0x00FF00)
    
    if errorCountFatal > 0
        print("警告: 存在致命错误，建议检查脚本", 0xFF0000)
    endif
    
    if errorCountSevere > 3
        print("警告: 严重错误较多，建议优化脚本", 0xFF6600)
    endif
endfunction

// ============================================
// 脚本主程序示例
// ============================================

label Main
print("脚本开始执行...", 0x00FF00)

// 示例：坐标验证
if not HandleCoordError(89, 51, "渔村")
    // 坐标无效，脚本可能无法继续
    stop
endif

// 示例：NPC查找
if not HandleNPCError("渔村村长", "渔村(67,53)")
    // NPC未找到，尝试恢复
    if not TryRecoverFromError("NPC_NOT_FOUND")
        HandleError("severe", "RECOVERY_FAILED", "无法从NPC错误恢复", "", "手动干预或重新启动脚本")
    endif
endif

// 示例：网络检查
if not HandleNetworkError()
    // 网络问题，等待后重试
    wait 3000
    goto Main  // 重新开始
endif

// 示例：物品检查
if not HandleItemError("肉", 5)
    // 物品不足，尝试获取
    print("物品不足，尝试获取...", 0xFFFF00)
    // 获取物品的逻辑
endif

// 正常执行逻辑
print("脚本正常执行中...", 0x00FF00)

// 脚本结束时生成错误报告
call GenerateErrorReport

print("脚本执行完成", 0x00FF00)
stop

// ============================================
// 工具函数（需要根据实际ASSA函数实现）
// ============================================

function GetItemCount(itemName)
    // 实际实现中，这里应该调用ASSA的获取物品数量函数
    // 示例实现，返回固定值
    return 10
endfunction

function GetCurrentTime()
    // 实际实现中，这里应该获取当前时间
    return "2026-03-21 05:40:00"
endfunction

// ============================================
// 使用说明
// ============================================

// 1. 在脚本开头包含此模板文件
// 2. 使用HandleError函数报告错误
// 3. 使用预定义的处理函数进行常见错误处理
// 4. 在脚本关键位置添加错误检查
// 5. 脚本结束时调用GenerateErrorReport生成报告

// 错误级别说明:
// - fatal: 致命错误，脚本必须停止
// - severe: 严重错误，需要用户干预
// - general: 一般错误，功能受限但可继续
// - info: 提示信息，仅记录不影响执行

// 预定义错误代码:
// - COORD_INVALID: 坐标无效
// - NPC_NOT_FOUND: NPC未找到
// - NETWORK_TIMEOUT: 网络超时
// - CONNECTION_LOST: 连接丢失
// - ITEM_INSUFFICIENT: 物品不足
// - RECOVERY_FAILED: 恢复失败

// ============================================
// 结束
// ============================================
"""
        
        with open(template_file, 'w', encoding='utf-8') as f:
            f.write(template)
        
        print(f"ASSA脚本模板已生成: {template_file}")
        return template_file
    
    def interactive_mode(self):
        """交互模式"""
        print("=" * 60)
        print("石器时代错误处理框架")
        print("=" * 60)
        
        while True:
            print("\n请选择操作:")
            print("1. 创建新错误")
            print("2. 查看错误定义")
            print("3. 生成错误报告")
            print("4. 生成ASSA脚本模板")
            print("5. 查看错误历史")
            print("6. 添加错误定义")
            print("7. 退出")
            
            choice = input("\n请输入选项 (1-7): ").strip()
            
            if choice == "1":
                print("\n--- 创建新错误 ---")
                print("错误级别: fatal(致命), severe(严重), general(一般), info(提示)")
                level_input = input("错误级别: ").strip().lower()
                
                # 验证错误级别
                valid_levels = ["fatal", "severe", "general", "info"]
                if level_input not in valid_levels:
                    print(f"❌ 无效错误级别，请使用: {', '.join(valid_levels)}")
                    continue
                
                level = ErrorLevel(level_input)
                code = input("错误代码: ").strip()
                message = input("错误信息: ").strip()
                context = input("错误上下文 (JSON格式，可选): ").strip() or "{}"
                recovery = input("恢复建议 (可选): ").strip() or None
                
                try:
                    context_dict = json.loads(context) if context else {}
                except:
                    print("❌ 上下文必须是有效的JSON格式")
                    context_dict = {}
                
                error = self.create_error(level, code, message, context_dict, recovery)
                print(f"\n✅ 错误已创建: {error}")
                print(f"错误ID: {error.error_id}")
                
                # 显示ASSA脚本代码
                print("\nASSA脚本代码:")
                print(error.to_assascript())
            
            elif choice == "2":
                print("\n--- 错误定义列表 ---")
                print(f"共有 {len(self.error_definitions)} 个错误定义:")
                print()
                
                for i, (code, definition) in enumerate(self.error_definitions.items(), 1):
                    level = definition.get("level", "general")
                    message = definition.get("message", "")
                    recovery = definition.get("recovery", "")
                    
                    level_name = ErrorLevel(level).get_display_name()
                    print(f"{i}. [{level_name}] {code}")
                    print(f"   信息: {message}")
                    print(f"   恢复: {recovery}")
                    print()
            
            elif choice == "3":
                print("\n--- 生成错误报告 ---")
                hours = input("统计小时数 (默认24): ").strip()
                hours = int(hours) if hours.isdigit() else 24
                
                report_file = self.generate_error_report(hours)
                print(f"✅ 错误报告已生成: {report_file}")
            
            elif choice == "4":
                print("\n--- 生成ASSA脚本模板 ---")
                template_file = self.generate_assascript_template()
                print(f"✅ ASSA脚本模板已生成: {template_file}")
            
            elif choice == "5":
                print("\n--- 错误历史 ---")
                recent_errors = self.error_history[-10:] if self.error_history else []
                
                if not recent_errors:
                    print("暂无错误历史")
                else:
                    print(f"最近 {len(recent_errors)} 个错误:")
                    print()
                    
                    for i, error in enumerate(recent_errors, 1):
                        time_str = error["timestamp"][11:19]
                        level_name = error["level_display"]
                        code = error["code"]
                        message = error["message"][:50] + "..." if len(error["message"]) > 50 else error["message"]
                        
                        print(f"{i}. [{time_str}] [{level_name}] {code}")
                        print(f"   信息: {message}")
                        print()
            
            elif choice == "6":
                print("\n--- 添加错误定义 ---")
                code = input("错误代码: ").strip()
                level = input("错误级别 (fatal/severe/general/info): ").strip().lower()
                message = input("错误信息: ").strip()
                recovery = input("恢复建议: ").strip()
                
                if code and level in ["fatal", "severe", "general", "info"] and message:
                    self.error_definitions[code] = {
                        "level": level,
                        "message": message,
                        "recovery": recovery
                    }
                    self.save_data()
                    print(f"✅ 错误定义已添加: {code}")
                else:
                    print("❌ 输入无效，请检查错误级别和必填字段")
            
            elif choice == "7":
                print("\n退出错误处理框架")
                break
            
            else:
                print("❌ 无效选项")

def main():
    """主函数"""
    handler = ErrorHandler()
    
    print("石器时代错误处理框架 v1.0")
    print("=" * 60)
    
    # 显示系统状态
    error_def_count = len(handler.error_definitions)
    error_history_count = len(handler.error_history)
    
    print(f"系统状态:")
    print(f"  • 错误定义: {error_def_count} 个")
    print(f"  • 错误历史: {error_history_count} 条")
    print(f"  • 数据目录: {handler.data_dir}")
    
    # 进入交互模式
    handler.interactive_mode()

if __name__ == "__main__":
    main()