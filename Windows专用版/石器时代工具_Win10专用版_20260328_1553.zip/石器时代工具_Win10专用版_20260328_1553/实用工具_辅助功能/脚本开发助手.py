#!/usr/bin/env python3
"""
石器时代脚本开发助手
集成开发工具链的核心工具
"""

import os
import sys
import json
import re
from datetime import datetime
from pathlib import Path

class ScriptDevelopmentAssistant:
    def __init__(self):
        self.base_dir = Path("/root/.openclaw/workspace/石器时代知识库")
        self.templates_dir = self.base_dir / "开发工具链" / "模板"
        self.examples_dir = self.base_dir / "开发工具链" / "示例"
        self.tools_dir = self.base_dir / "开发工具链" / "工具"
        
        # 创建目录
        self.templates_dir.mkdir(parents=True, exist_ok=True)
        self.examples_dir.mkdir(parents=True, exist_ok=True)
        self.tools_dir.mkdir(parents=True, exist_ok=True)
        
        # 加载脚本数据库
        self.script_db = self.load_script_database()
        
        # 初始化模板系统
        self.init_templates()
        
    def load_script_database(self):
        """加载脚本数据库"""
        db_path = Path("/root/.openclaw/workspace/石器时代脚本数据库/脚本数据库.json")
        if db_path.exists():
            with open(db_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        return []
    
    def init_templates(self):
        """初始化模板系统"""
        templates = {
            "basic": self.create_basic_template(),
            "network_optimized": self.create_network_optimized_template(),
            "ng25_adapted": self.create_ng25_adapted_template(),
            "dungeon": self.create_dungeon_template(),
            "money_making": self.create_money_making_template(),
            "pet_related": self.create_pet_related_template(),
            "task": self.create_task_template(),
            "transport": self.create_transport_template()
        }
        
        for name, content in templates.items():
            template_path = self.templates_dir / f"{name}.asc"
            if not template_path.exists():
                with open(template_path, 'w', encoding='utf-8') as f:
                    f.write(content)
    
    def create_basic_template(self):
        """创建基础模板"""
        return """// ============================================
// 脚本名称: {script_name}
// 创建时间: {create_time}
// 脚本类型: {script_type}
// ============================================

// 脚本说明:
// {description}

// 配置参数
set MAX_RETRY 3
set TIMEOUT 5000

// 状态变量
set step 0
set success 0
set fail 0

// 脚本开始
label start
    log 🚀 脚本开始运行: {script_name}
    
    // 初始化
    set step 0
    set success 0
    set fail 0
    
    // 主逻辑
    call main_logic
    
    // 脚本结束
    goto finish

// 主逻辑
label main_logic
    inc step
    log 步骤{'{step}'}: 执行主逻辑
    
    // 在这里添加你的逻辑
    
    ret

// 错误处理
label error_handle
    inc fail
    log ⚠️ 发生错误，失败次数: {'{fail}'}
    
    if fail > 3
        log ❌ 错误过多，停止脚本
        stop
    
    wait 2000
    ret

// 脚本完成
label finish
    log ✅ 脚本完成!
    log 📊 统计: 步骤{'{step}'}, 成功{'{success}'}, 失败{'{fail}'}
    stop

// ============================================
// 函数定义
// ============================================

// 示例函数
function example_function
    log 执行示例函数
    ret

// ============================================
// 使用说明
// ============================================
//
// 1. 在main_logic中添加具体逻辑
// 2. 根据需要添加更多函数
// 3. 在error_handle中处理错误
// 4. 测试脚本功能
//"""
    
    def create_network_optimized_template(self):
        """创建网络优化模板"""
        return """// ============================================
// 脚本名称: {script_name} (网络优化版)
// 创建时间: {create_time}
// 优化特性: 网络波动处理 + 错误恢复
// ============================================

// 🎯 优化说明:
// 1. 所有等待指令添加超时
// 2. 三级错误重试机制
// 3. 防卡检测和自动恢复
// 4. 详细运行日志

// ⚙️ 配置参数
set MAX_RETRY 3           // 最大重试次数
set NETWORK_TIMEOUT 10000 // 网络超时(毫秒)
set POS_TIMEOUT 5000      // 位置超时(毫秒)
set RETRY_DELAY 2000      // 重试延迟(毫秒)

// 📊 状态变量
set retry_count 0
set error_level 0         // 0=正常,1=轻微,2=严重,3=致命
set stuck_counter 0
set step_counter 0

// ============================================
// 🔧 网络优化核心函数
// ============================================

// 安全等待对话框
function waitdlg_safe(npc_name)
    set local_retry 0
label waitdlg_retry
    waitdlg npc_name, NETWORK_TIMEOUT
    if dlg npc_name ret
    inc local_retry
    if local_retry > 2 goto network_error
    log 对话框等待失败，重试中...
    wait RETRY_DELAY
    goto waitdlg_retry

// 安全等待位置
function waitpos_safe(x, y)
    set local_retry 0
label waitpos_retry
    waitpos x, y, POS_TIMEOUT
    if pos x, y ret
    inc local_retry
    if local_retry > 1 goto network_error
    wait RETRY_DELAY
    goto waitpos_retry

// 安全移动
function walk_safe(x, y)
    walkpos x, y
    call waitpos_safe(x, y)
    ret

// 防卡检测
function check_stuck
    inc stuck_counter
    if stuck_counter > 15
        log ⚠️ 检测到可能卡住，尝试恢复
        useitem 羽毛
        wait 3000
        set stuck_counter 0
    ret

// ============================================
// 🚨 错误处理系统
// ============================================

// 网络错误
label network_error
    inc retry_count
    if retry_count > MAX_RETRY goto fatal_error
    log 网络错误，第{'{retry_count}'}次重试
    wait RETRY_DELAY
    ret

// 致命错误
label fatal_error
    log ⚠️ 严重错误，返回记录点
    useitem 羽毛
    wait 3000
    set retry_count 0
    goto start

// ============================================
// 🚀 脚本开始
// ============================================

label start
    // 初始化
    set retry_count 0
    set error_level 0
    set stuck_counter 0
    set step_counter 0
    
    log 🎮 {script_name} - 网络优化版开始运行
    log 📝 已添加网络优化和错误处理
    
    // 网络状态检查
    if map == "" goto network_error
    
    // 防卡检测启动
    call check_stuck
    
    // 执行主逻辑
    call main_logic

// ============================================
// 🎯 主逻辑 (在这里添加你的逻辑)
// ============================================

label main_logic
    inc step_counter
    log 步骤{'{step_counter}'}: 开始执行主逻辑
    
    // 使用安全函数
    // call walk_safe(100, 100)
    // call waitdlg_safe("NPC名称")
    
    // 定期防卡检测
    call check_stuck
    
    log ✅ 主逻辑执行完成
    ret

// ============================================
// 🏁 脚本结束处理
// ============================================

label finish
    log 🎉 脚本任务完成!
    log 📊 运行统计:
    log   步骤数: {'{step_counter}'}
    log   错误重试: {'{retry_count}'}次
    log   防卡检测: {'{stuck_counter}'}次
    
    log ✅ 脚本安全结束
    stop

// ============================================
// 💡 使用说明
// ============================================
//
// 优化特性:
// ✅ 网络波动自动处理
// ✅ 四级错误恢复系统  
// ✅ 防卡检测和恢复
// ✅ 详细运行日志
//
// 使用方法:
// 1. 在main_logic中添加具体逻辑
// 2. 使用安全函数替换原来的指令
// 3. 定期调用check_stuck()防止卡住
//"""
    
    def create_ng25_adapted_template(self):
        """创建NG25适配模板"""
        template = self.create_network_optimized_template()
        template += """

// ============================================
// 📝 NG25适配检查点
// ============================================

// 注意: 以下名称需要确认在NG25私服中是否正确
// 请根据实际情况修改以下名称:

// 1. 地图名称检查
label check_map_names
    // 常见地图名称，确认NG25是否使用相同名称
    // 渔村、福村、萨村、加加村、卡鲁他那村、达那村
    // 沙姆岛、奇咯咯、多多村、小小村、霍比特村
    // 南卡村、塔姆村、柯奥村、特尔坷村、米兰达
    // 伊甸园、地城、水城、火城、风城、冰城
    ret

// 2. NPC名称检查  
label check_npc_names
    // 常见NPC名称，确认NG25是否使用相同名称
    // 商人、银行职员、宠物店、医院、村长
    // 传送员、任务管理员、魔王、女神、守卫
    ret

// 3. 宠物名称检查
label check_pet_names
    // 常见宠物名称，确认NG25是否使用相同名称
    // 人龙、雷龙、老虎、暴龙、机暴
    // 金虎、红虎、绿虎、蓝虎、黄虎
    ret

// 4. 物品名称检查
label check_item_names
    // 常见物品名称，确认NG25是否使用相同名称
    // 羽毛、石币、药水、武器、防具、饰品
    ret

// ============================================
// 🎯 NG25适配使用说明
// ============================================
//
// 1. 在关键步骤调用检查点:
//    call check_map_names
//    call check_npc_names
//
// 2. 根据NG25实际情况修改检查点中的名称
// 3. 测试脚本在NG25中的兼容性
// 4. 记录名称差异，建立映射表
//"""
        return template
    
    def create_dungeon_template(self):
        """创建副本模板"""
        return self.create_ng25_adapted_template().replace(
            "// 🎯 主逻辑 (在这里添加你的逻辑)",
            """// ============================================
// 🏰 副本逻辑
// ============================================

// 前往副本入口
label go_to_dungeon_entrance
    inc step_counter
    log 步骤{'{step_counter}'}: 前往副本入口
    
    call check_stuck
    call check_map_names
    
    // 使用安全的移动函数
    // call walk_safe(100, 100)
    // call walk_safe(120, 120)
    
    // 与副本管理员对话
    // dlg 副本管理员
    // call waitdlg_safe("副本管理员")
    
    log ✅ 已到达副本入口
    ret

// 副本战斗
label dungeon_battle
    inc step_counter
    log 步骤{'{step_counter}'}: 开始副本战斗
    
    call check_stuck
    call check_pet_names
    
    // 战斗逻辑
    set battle_retry 0
label battle_loop
    // attack 怪物
    // wait 2000
    
    // 检查战斗状态
    // if fight == 1 goto battle_continue
    // if fight == 0 goto battle_complete
    
    inc battle_retry
    if battle_retry > 3 goto network_error
    goto battle_loop

label battle_continue
    // 继续战斗
    wait 1000
    goto battle_loop

label battle_complete
    log ✅ 战斗完成
    ret

// 领取奖励
label get_rewards
    inc step_counter
    log 步骤{'{step_counter}'}: 领取副本奖励
    
    call check_stuck
    call check_npc_names
    
    // 与奖励NPC对话
    // dlg 奖励管理员
    // call waitdlg_safe("奖励管理员")
    
    log 🎁 奖励领取完成
    ret

// 🎯 主逻辑
label main_logic
    // 副本流程
    call go_to_dungeon_entrance
    call dungeon_battle
    call get_rewards
    
    log 🏆 副本完成!
    ret"""
        )
    
    def create_money_making_template(self):
        """创建赚钱脚本模板"""
        # 类似方式创建其他模板
        return self.create_ng25_adapted_template()
    
    def create_pet_related_template(self):
        """创建宠物相关模板"""
        return self.create_ng25_adapted_template()
    
    def create_task_template(self):
        """创建任务脚本模板"""
        return self.create_ng25_adapted_template()
    
    def create_transport_template(self):
        """创建交通脚本模板"""
        return self.create_ng25_adapted_template()
    
    def create_script(self, script_name, script_type="basic", description=""):
        """创建新脚本"""
        now = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        
        # 选择模板
        template_file = self.templates_dir / f"{script_type}.asc"
        if not template_file.exists():
            print(f"❌ 模板不存在: {script_type}")
            return None
        
        with open(template_file, 'r', encoding='utf-8') as f:
            template = f.read()
        
        # 填充模板
        script_content = template.format(
            script_name=script_name,
            create_time=now,
            script_type=script_type,
            description=description
        )
        
        # 保存脚本
        script_path = Path.cwd() / f"{script_name}.asc"
        with open(script_path, 'w', encoding='utf-8') as f:
            f.write(script_content)
        
        print(f"✅ 脚本创建成功: {script_path}")
        return script_path
    
    def analyze_script(self, script_path):
        """分析脚本"""
        if not Path(script_path).exists():
            print(f"❌ 脚本不存在: {script_path}")
            return None
        
        with open(script_path, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read()
        
        analysis = {
            'file': Path(script_path).name,
            'size': len(content),
            'lines': content.count('\n') + 1,
            'has_network_optimization': False,
            'has_ng25_adaptation': False,
            'issues': []
        }
        
        # 检查网络优化
        if 'waitdlg_safe' in content or 'walk_safe' in content:
            analysis['has_network_optimization'] = True
        
        # 检查NG25适配
        if 'check_map_names' in content or 'check_npc_names' in content:
            analysis['has_ng25_adaptation'] = True
        
        # 检查常见问题
        lines = content.split('\n')
        for i, line in enumerate(lines, 1):
            line = line.strip()
            
            # 检查无超时的等待
            if 'waitdlg' in line.lower() and ',' not in line:
                analysis['issues'].append(f"行{i}: waitdlg无超时")
            elif 'waitpos' in line.lower() and ',' not in line:
                analysis['issues'].append(f"行{i}: waitpos无超时")
            elif 'waitmap' in line.lower() and ',' not in line:
                analysis['issues'].append(f"行{i}: waitmap无超时")
        
        return analysis
    
    def optimize_script(self, script_path, optimization_type="network"):
        """优化脚本"""
        if not Path(script_path).exists():
            print(f"❌ 脚本不存在: {script_path}")
            return None
        
        with open(script_path, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read()
        
        # 备份原始脚本
        backup_path = Path(script_path).with_suffix('.asc.backup')
        with open(backup_path, 'w', encoding='utf-8') as f:
            f.write(content)
        
        print(f"📁 原始脚本已备份: {backup_path}")
        
        # 根据优化类型应用优化
        if optimization_type == "network":
            optimized = self.apply_network_optimization(content)
        elif optimization_type == "ng25":
            optimized = self.apply_ng25_optimization(content)
        else:
            print(f"❌ 不支持的优化类型: {optimization_type}")
            return None
        
        # 保存优化后的脚本
        optimized_path = Path(script_path).with_suffix('.asc.optimized')
        with open(optimized_path, 'w', encoding='utf-8') as f:
            f.write(optimized)
        
        print(f"✅ 优化完成: {optimized_path}")
        return optimized_path
    
    def apply_network_