#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
配置管理模块
"""

import os
import json
import logging
from typing import Dict, List, Any, Optional
from pathlib import Path

class ConfigManager:
    """配置管理器"""
    
    def __init__(self, config_dir: Optional[str] = None):
        """
        初始化配置管理器
        
        Args:
            config_dir: 配置目录路径
        """
        self.logger = logging.getLogger(__name__)
        
        # 确定配置目录
        if config_dir is None:
            # 默认配置目录：用户目录下的 StoneCaptcha
            home_dir = os.path.expanduser("~")
            self.config_dir = os.path.join(home_dir, "StoneCaptcha", "config")
        else:
            self.config_dir = config_dir
        
        # 确保配置目录存在
        os.makedirs(self.config_dir, exist_ok=True)
        
        # 配置文件路径
        self.config_file = os.path.join(self.config_dir, "config.json")
        self.users_file = os.path.join(self.config_dir, "users.json")
        
        self.logger.info(f"配置管理器初始化完成，配置目录: {self.config_dir}")
    
    def get_default_config(self) -> Dict[str, Any]:
        """获取默认配置"""
        return {
            "version": "1.0.0",
            "game": {
                "title": "石器时代",
                "exe_path": "",
                "window_class": ""
            },
            "captcha": {
                "area": {"x": 100, "y": 200, "width": 200, "height": 80},
                "input_area": {"x": 150, "y": 300, "width": 100, "height": 30},
                "check_interval": 5,
                "auto_input": True,
                "screenshot_quality": 90
            },
            "ocr": {
                "engine": "tesseract",
                "language": "eng",
                "tesseract_path": "",
                "confidence_threshold": 0.7,
                "character_whitelist": "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
            },
            "system": {
                "log_level": "INFO",
                "max_log_files": 10,
                "auto_update": True,
                "start_with_system": False
            },
            "user_interface": {
                "theme": "dark",
                "language": "zh_CN",
                "font_size": 12,
                "auto_hide": False
            }
        }
    
    def get_default_users(self) -> List[Dict[str, Any]]:
        """获取默认用户列表"""
        return [
            {
                "id": 1,
                "username": "default_user",
                "game_account": "",
                "enabled": True,
                "last_used": "",
                "statistics": {
                    "total_captchas": 0,
                    "successful": 0,
                    "failed": 0,
                    "accuracy": 0.0
                }
            }
        ]
    
    def load_config(self) -> Dict[str, Any]:
        """
        加载配置
        
        Returns:
            配置字典
        """
        try:
            if os.path.exists(self.config_file):
                with open(self.config_file, 'r', encoding='utf-8') as f:
                    config = json.load(f)
                
                # 合并默认配置（确保新版本有所有字段）
                default_config = self.get_default_config()
                config = self._merge_configs(default_config, config)
                
                self.logger.info(f"配置已从文件加载: {self.config_file}")
                return config
            else:
                self.logger.info("配置文件不存在，使用默认配置")
                return self.get_default_config()
                
        except Exception as e:
            self.logger.error(f"加载配置失败: {e}")
            return self.get_default_config()
    
    def save_config(self, config: Dict[str, Any]) -> bool:
        """
        保存配置
        
        Args:
            config: 配置字典
            
        Returns:
            是否成功
        """
        try:
            # 确保配置目录存在
            os.makedirs(os.path.dirname(self.config_file), exist_ok=True)
            
            with open(self.config_file, 'w', encoding='utf-8') as f:
                json.dump(config, f, ensure_ascii=False, indent=2)
            
            self.logger.info(f"配置已保存到文件: {self.config_file}")
            return True
            
        except Exception as e:
            self.logger.error(f"保存配置失败: {e}")
            return False
    
    def load_users(self) -> List[Dict[str, Any]]:
        """
        加载用户列表
        
        Returns:
            用户列表
        """
        try:
            if os.path.exists(self.users_file):
                with open(self.users_file, 'r', encoding='utf-8') as f:
                    users = json.load(f)
                
                self.logger.info(f"用户列表已从文件加载: {self.users_file}")
                return users
            else:
                self.logger.info("用户文件不存在，使用默认用户")
                return self.get_default_users()
                
        except Exception as e:
            self.logger.error(f"加载用户列表失败: {e}")
            return self.get_default_users()
    
    def save_users(self, users: List[Dict[str, Any]]) -> bool:
        """
        保存用户列表
        
        Args:
            users: 用户列表
            
        Returns:
            是否成功
        """
        try:
            # 确保配置目录存在
            os.makedirs(os.path.dirname(self.users_file), exist_ok=True)
            
            with open(self.users_file, 'w', encoding='utf-8') as f:
                json.dump(users, f, ensure_ascii=False, indent=2)
            
            self.logger.info(f"用户列表已保存到文件: {self.users_file}")
            return True
            
        except Exception as e:
            self.logger.error(f"保存用户列表失败: {e}")
            return False
    
    def add_user(self, user_data: Dict[str, Any]) -> bool:
        """
        添加用户
        
        Args:
            user_data: 用户数据
            
        Returns:
            是否成功
        """
        try:
            users = self.load_users()
            
            # 生成新用户ID
            if users:
                max_id = max(user.get('id', 0) for user in users)
                new_id = max_id + 1
            else:
                new_id = 1
            
            # 创建新用户
            new_user = {
                "id": new_id,
                "username": user_data.get("username", f"user_{new_id}"),
                "game_account": user_data.get("game_account", ""),
                "enabled": user_data.get("enabled", True),
                "last_used": "",
                "statistics": {
                    "total_captchas": 0,
                    "successful": 0,
                    "failed": 0,
                    "accuracy": 0.0
                }
            }
            
            users.append(new_user)
            
            return self.save_users(users)
            
        except Exception as e:
            self.logger.error(f"添加用户失败: {e}")
            return False
    
    def remove_user(self, user_id: int) -> bool:
        """
        删除用户
        
        Args:
            user_id: 用户ID
            
        Returns:
            是否成功
        """
        try:
            users = self.load_users()
            
            # 查找并删除用户
            new_users = [user for user in users if user.get('id') != user_id]
            
            if len(new_users) == len(users):
                self.logger.warning(f"未找到用户ID: {user_id}")
                return False
            
            return self.save_users(new_users)
            
        except Exception as e:
            self.logger.error(f"删除用户失败: {e}")
            return False
    
    def update_user(self, user_id: int, user_data: Dict[str, Any]) -> bool:
        """
        更新用户
        
        Args:
            user_id: 用户ID
            user_data: 更新的用户数据
            
        Returns:
            是否成功
        """
        try:
            users = self.load_users()
            
            # 查找用户
            for i, user in enumerate(users):
                if user.get('id') == user_id:
                    # 更新用户数据
                    for key, value in user_data.items():
                        if key in user:
                            user[key] = value
                    
                    users[i] = user
                    return self.save_users(users)
            
            self.logger.warning(f"未找到用户ID: {user_id}")
            return False
            
        except Exception as e:
            self.logger.error(f"更新用户失败: {e}")
            return False
    
    def get_user_statistics(self) -> Dict[str, Any]:
        """
        获取用户统计信息
        
        Returns:
            统计信息字典
        """
        try:
            users = self.load_users()
            
            total_users = len(users)
            enabled_users = sum(1 for user in users if user.get('enabled', False))
            
            total_captchas = 0
            successful_captchas = 0
            
            for user in users:
                stats = user.get('statistics', {})
                total_captchas += stats.get('total_captchas', 0)
                successful_captchas += stats.get('successful', 0)
            
            overall_accuracy = (successful_captchas / total_captchas * 100) if total_captchas > 0 else 0
            
            return {
                "total_users": total_users,
                "enabled_users": enabled_users,
                "total_captchas": total_captchas,
                "successful_captchas": successful_captchas,
                "overall_accuracy": round(overall_accuracy, 2)
            }
            
        except Exception as e:
            self.logger.error(f"获取用户统计失败: {e}")
            return {}
    
    def reset_to_default(self) -> bool:
        """
        重置为默认配置
        
        Returns:
            是否成功
        """
        try:
            # 备份当前配置
            backup_dir = os.path.join(self.config_dir, "backup")
            os.makedirs(backup_dir, exist_ok=True)
            
            import shutil
            import time
            
            timestamp = int(time.time())
            
            if os.path.exists(self.config_file):
                backup_file = os.path.join(backup_dir, f"config_backup_{timestamp}.json")
                shutil.copy2(self.config_file, backup_file)
                self.logger.info(f"配置已备份到: {backup_file}")
            
            if os.path.exists(self.users_file):
                backup_file = os.path.join(backup_dir, f"users_backup_{timestamp}.json")
                shutil.copy2(self.users_file, backup_file)
                self.logger.info(f"用户列表已备份到: {backup_file}")
            
            # 保存默认配置
            default_config = self.get_default_config()
            default_users = self.get_default_users()
            
            config_success = self.save_config(default_config)
            users_success = self.save_users(default_users)
            
            return config_success and users_success
            
        except Exception as e:
            self.logger.error(f"重置配置失败: {e}")
            return False
    
    def _merge_configs(self, default: Dict[str, Any], current: Dict[str, Any]) -> Dict[str, Any]:
        """
        合并配置（递归合并字典）
        
        Args:
            default: 默认配置
            current: 当前配置
            
        Returns:
            合并后的配置
        """
        merged = default.copy()
        
        for key, value in current.items():
            if key in merged:
                if isinstance(merged[key], dict) and isinstance(value, dict):
                    merged[key] = self._merge_configs(merged[key], value)
                else:
                    merged[key] = value
            else:
                merged[key] = value
        
        return merged
    
    def export_config(self, export_path: str) -> bool:
        """
        导出配置
        
        Args:
            export_path: 导出路径
            
        Returns:
            是否成功
        """
        try:
            config = self.load_config()
            users = self.load_users()
            
            export_data = {
                "config": config,
                "users": users,
                "export_time": time.strftime("%Y-%m-%d %H:%M:%S"),
                "version": "1.0.0"
            }
            
            with open(export_path, 'w', encoding='utf-8') as f:
                json.dump(export_data, f, ensure_ascii=False, indent=2)
            
            self.logger.info(f"配置已导出到: {export_path}")
            return True
            
        except Exception as e:
            self.logger.error(f"导出配置失败: {e}")
            return False
    
    def import_config(self, import_path: str) -> bool:
        """
        导入配置
        
        Args:
            import_path: 导入文件路径
            
        Returns:
            是否成功
        """
        try:
            if not os.path.exists(import_path):
                self.logger.error(f"导入文件不存在: {import_path}")
                return False
            
            with open(import_path, 'r', encoding='utf-8') as f:
                import_data = json.load(f)
            
            # 验证导入数据
            if "config" not in import_data or "users" not in import_data:
                self.logger.error("导入文件格式不正确")
                return False
            
            # 备份当前配置
            self.reset_to_default()
            
            # 导入新配置
            config_success = self.save_config(import_data["config"])
            users_success = self.save_users(import_data["users"])
            
            return config_success and users_success
            
        except Exception as e:
            self.logger.error(f"导入配置失败: {e}")
            return False


# 简单测试函数
def test_config_manager():
    """测试配置管理器"""
    print("⚙️  测试配置管理器")
    print("-" * 40)
    
    # 创建配置管理器
    config_mgr = ConfigManager()
    
    # 测试配置加载和保存
    print("📋 测试配置管理...")
    config = config_mgr.load_config()
    print(f"✅ 配置加载成功，版本: {config.get('version', '未知')}")
    
    # 修改配置
    config['game']['title'] = '石器时代测试版'
    if config_mgr.save_config(config):
        print("✅ 配置保存成功")
    
    # 测试用户管理
    print("\n👥 测试用户管理...")
    users = config_mgr.load_users()
    print(f"✅ 用户列表加载成功，用户数: {len(users)}")
    
    # 添加新用户
    new_user = {
        "username": "test_user",
        "game_account": "test_account"
    }
    if config_mgr.add_user(new_user):
        print("✅ 用户添加成功")
    
    # 获取统计信息
    stats = config_mgr.get_user_statistics()
    print(f"📊 用户统计: {stats}")
    
    # 重置配置
    print("\n🔄 测试配置重置...")
    if config_mgr.reset_to_default():
        print("✅ 配置重置成功")
    
    print("\n🎉 配置管理器测试完成")

if __name__ == "__main__":
    test_config_manager()