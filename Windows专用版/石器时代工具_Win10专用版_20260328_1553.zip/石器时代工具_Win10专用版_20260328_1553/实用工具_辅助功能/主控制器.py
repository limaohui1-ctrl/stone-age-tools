#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
石器时代脚本性能监控系统 - 主控制器
核心功能：集成所有模块，提供统一控制接口
"""

import json
import time
import threading
import logging
import os
import sys
from datetime import datetime
from typing import Dict, List, Optional, Any, Tuple
from dataclasses import dataclass, asdict
from enum import Enum
import subprocess
import signal


class SystemStatus(Enum):
    """系统状态"""
    STOPPED = "已停止"
    STARTING = "启动中"
    RUNNING = "运行中"
    STOPPING = "停止中"
    ERROR = "错误"


class ModuleStatus(Enum):
    """模块状态"""
    NOT_LOADED = "未加载"
    LOADING = "加载中"
    RUNNING = "运行中"
    STOPPED = "已停止"
    ERROR = "错误"


@dataclass
class ModuleInfo:
    """模块信息"""
    name: str
    description: str
    status: ModuleStatus
    last_activity: str
    error_message: Optional[str]
    metrics: Dict[str, Any]


@dataclass
class SystemMetrics:
    """系统指标"""
    timestamp: str
    cpu_usage: float
    memory_usage: float
    disk_usage: float
    network_status: str
    active_tasks: int
    completed_tasks: int
    error_count: int


class PerformanceMonitorController:
    """性能监控系统主控制器"""
    
    def __init__(self, config_path: Optional[str] = None):
        """
        初始化主控制器
        
        Args:
            config_path: 配置文件路径
        """
        self.config = self._load_config(config_path)
        self.logger = self._setup_logging()
        
        # 系统状态
        self.system_status = SystemStatus.STOPPED
        self.start_time = None
        self.stop_time = None
        
        # 模块管理
        self.modules: Dict[str, ModuleInfo] = {}
        self.module_threads: Dict[str, threading.Thread] = {}
        
        # 系统指标
        self.system_metrics_history: List[SystemMetrics] = []
        self.max_history_size = 1000
        
        # 任务队列
        self.task_queue = []
        self.task_results = {}
        
        # 信号处理
        self._setup_signal_handlers()
        
        # 初始化模块
        self._initialize_modules()
        
    def _load_config(self, config_path: Optional[str]) -> Dict[str, Any]:
        """加载配置"""
        default_config = {
            "system": {
                "name": "石器时代脚本性能监控系统",
                "version": "1.0.0",
                "description": "实时监控和优化石器时代脚本性能",
                "author": "OpenClaw AI助手",
                "auto_start": True,
                "check_interval": 5.0,
                "max_concurrent_tasks": 3,
            },
            "modules": {
                "monitor_agent": {
                    "enabled": True,
                    "config_path": "config/monitor_agent.json",
                    "auto_start": True,
                },
                "analysis_engine": {
                    "enabled": True,
                    "config_path": "config/analysis_engine.json",
                    "auto_start": True,
                },
                "optimization_executor": {
                    "enabled": True,
                    "config_path": "config/optimization_executor.json",
                    "auto_start": False,  # 需要手动启动
                },
            },
            "logging": {
                "level": "INFO",
                "max_file_size": 10485760,  # 10MB
                "backup_count": 5,
            },
            "monitoring": {
                "metrics_interval": 10.0,
                "health_check_interval": 30.0,
                "alert_thresholds": {
                    "cpu_usage": 90.0,
                    "memory_usage": 95.0,
                    "disk_usage": 90.0,
                    "error_rate": 10.0,
                }
            },
            "web_interface": {
                "enabled": True,
                "host": "127.0.0.1",
                "port": 8080,
                "debug": False,
            }
        }
        
        if config_path and os.path.exists(config_path):
            try:
                with open(config_path, 'r', encoding='utf-8') as f:
                    user_config = json.load(f)
                    # 深度合并配置
                    self._deep_merge(default_config, user_config)
            except Exception as e:
                self.logger.warning(f"加载配置文件失败，使用默认配置: {e}")
        
        return default_config
    
    def _deep_merge(self, base: Dict[str, Any], update: Dict[str, Any]):
        """深度合并字典"""
        for key, value in update.items():
            if key in base and isinstance(base[key], dict) and isinstance(value, dict):
                self._deep_merge(base[key], value)
            else:
                base[key] = value
    
    def _setup_logging(self) -> logging.Logger:
        """设置日志"""
        log_dir = "/root/.openclaw/workspace/石器时代脚本性能监控系统/logs"
        os.makedirs(log_dir, exist_ok=True)
        
        logger = logging.getLogger("PerformanceMonitorController")
        logger.setLevel(getattr(logging, self.config["logging"]["level"]))
        
        if not logger.handlers:
            # 文件处理器
            log_file = os.path.join(log_dir, f"controller_{datetime.now().strftime('%Y%m%d')}.log")
            file_handler = logging.FileHandler(log_file, encoding='utf-8')
            file_handler.setLevel(logger.level)
            
            # 控制台处理器
            console_handler = logging.StreamHandler()
            console_handler.setLevel(logger.level)
            
            # 格式化器
            formatter = logging.Formatter(
                '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
                datefmt='%Y-%m-%d %H:%M:%S'
            )
            file_handler.setFormatter(formatter)
            console_handler.setFormatter(formatter)
            
            logger.addHandler(file_handler)
            logger.addHandler(console_handler)
        
        return logger
    
    def _setup_signal_handlers(self):
        """设置信号处理器"""
        signal.signal(signal.SIGINT, self._handle_shutdown_signal)
        signal.signal(signal.SIGTERM, self._handle_shutdown_signal)
    
    def _handle_shutdown_signal(self, signum, frame):
        """处理关闭信号"""
        self.logger.info(f"收到关闭信号 {signum}, 正在优雅关闭...")
        self.stop()
        sys.exit(0)
    
    def _initialize_modules(self):
        """初始化模块"""
        module_configs = self.config["modules"]
        
        # 监控代理模块
        if module_configs["monitor_agent"]["enabled"]:
            self.modules["monitor_agent"] = ModuleInfo(
                name="监控代理",
                description="实时监控脚本性能，检测网络波动",
                status=ModuleStatus.NOT_LOADED,
                last_activity=datetime.now().isoformat(),
                error_message=None,
                metrics={}
            )
        
        # 分析引擎模块
        if module_configs["analysis_engine"]["enabled"]:
            self.modules["analysis_engine"] = ModuleInfo(
                name="分析引擎",
                description="分析性能数据，识别瓶颈，生成优化建议",
                status=ModuleStatus.NOT_LOADED,
                last_activity=datetime.now().isoformat(),
                error_message=None,
                metrics={}
            )
        
        # 优化实施器模块
        if module_configs["optimization_executor"]["enabled"]:
            self.modules["optimization_executor"] = ModuleInfo(
                name="优化实施器",
                description="自动实施优化，跟踪优化效果",
                status=ModuleStatus.NOT_LOADED,
                last_activity=datetime.now().isoformat(),
                error_message=None,
                metrics={}
            )
        
        self.logger.info(f"初始化了 {len(self.modules)} 个模块")
    
    def start(self):
        """启动系统"""
        if self.system_status != SystemStatus.STOPPED:
            self.logger.warning(f"系统状态不是已停止: {self.system_status}")
            return False
        
        self.logger.info("启动性能监控系统...")
        self.system_status = SystemStatus.STARTING
        self.start_time = datetime.now()
        
        try:
            # 启动模块
            self._start_modules()
            
            # 启动系统监控
            self._start_system_monitoring()
            
            # 启动任务处理器
            self._start_task_processor()
            
            self.system_status = SystemStatus.RUNNING
            self.logger.info(f"性能监控系统启动成功，启动时间: {self.start_time}")
            
            # 如果配置了自动启动Web界面
            if self.config["web_interface"]["enabled"]:
                self._start_web_interface()
            
            return True
            
        except Exception as e:
            self.logger.error(f"启动系统失败: {e}")
            self.system_status = SystemStatus.ERROR
            return False
    
    def _start_modules(self):
        """启动模块"""
        module_configs = self.config["modules"]
        
        for module_name, module_info in self.modules.items():
            if module_configs.get(module_name, {}).get("auto_start", False):
                self.start_module(module_name)
    
    def start_module(self, module_name: str) -> bool:
        """启动模块"""
        if module_name not in self.modules:
            self.logger.error(f"模块不存在: {module_name}")
            return False
        
        module_info = self.modules[module_name]
        
        if module_info.status not in [ModuleStatus.NOT_LOADED, ModuleStatus.STOPPED]:
            self.logger.warning(f"模块状态不允许启动: {module_name} - {module_info.status}")
            return False
        
        self.logger.info(f"启动模块: {module_name}")
        module_info.status = ModuleStatus.LOADING
        module_info.last_activity = datetime.now().isoformat()
        
        try:
            # 在实际环境中，这里应该：
            # 1. 加载模块配置
            # 2. 初始化模块实例
            # 3. 启动模块线程
            
            # 模拟模块启动
            def module_worker():
                module_info.status = ModuleStatus.RUNNING
                module_info.last_activity = datetime.now().isoformat()
                
                # 模拟模块运行
                while module_info.status == ModuleStatus.RUNNING:
                    # 更新模块指标
                    module_info.metrics = {
                        "uptime": (datetime.now() - datetime.fromisoformat(module_info.last_activity)).total_seconds(),
                        "processed_tasks": 0,
                        "active_tasks": 0,
                        "last_error": None,
                    }
                    
                    # 模拟工作
                    time.sleep(1.0)
            
            # 启动模块线程
            thread = threading.Thread(
                target=module_worker,
                name=f"Module-{module_name}",
                daemon=True
            )
            self.module_threads[module_name] = thread
            thread.start()
            
            self.logger.info(f"模块启动成功: {module_name}")
            return True
            
        except Exception as e:
            self.logger.error(f"启动模块失败 {module_name}: {e}")
            module_info.status = ModuleStatus.ERROR
            module_info.error_message = str(e)
            return False
    
    def stop_module(self, module_name: str) -> bool:
        """停止模块"""
        if module_name not in self.modules:
            self.logger.error(f"模块不存在: {module_name}")
            return False
        
        module_info = self.modules[module_name]
        
        if module_info.status != ModuleStatus.RUNNING:
            self.logger.warning(f"模块不在运行状态: {module_name} - {module_info.status}")
            return False
        
        self.logger.info(f"停止模块: {module_name}")
        module_info.status = ModuleStatus.STOPPING
        
        try:
            # 停止模块线程
            if module_name in self.module_threads:
                # 在实际环境中，这里应该有更优雅的停止机制
                pass
            
            module_info.status = ModuleStatus.STOPPED
            module_info.last_activity = datetime.now().isoformat()
            
            self.logger.info(f"模块停止成功: {module_name}")
            return True
            
        except Exception as e:
            self.logger.error(f"停止模块失败 {module_name}: {e}")
            module_info.status = ModuleStatus.ERROR
            module_info.error_message = str(e)
            return False
    
    def _start_system_monitoring(self):
        """启动系统监控"""
        def monitoring_worker():
            while self.system_status == SystemStatus.RUNNING:
                try:
                    # 收集系统指标
                    metrics = self._collect_system_metrics()
                    self.system_metrics_history.append(metrics)
                    
                    # 限制历史记录大小
                    if len(self.system_metrics_history) > self.max_history_size:
                        self.system_metrics_history = self.system_metrics_history[-self.max_history_size:]
                    
                    # 检查健康状态
                    self._check_system_health(metrics)
                    
                    # 等待下一个监控周期
                    time.sleep(self.config["monitoring"]["metrics_interval"])
                    
                except Exception as e:
                    self.logger.error(f"系统监控出错: {e}")
                    time.sleep(5.0)
        
        thread = threading.Thread(
            target=monitoring_worker,
            name="SystemMonitor",
            daemon=True
        )
        thread.start()
    
    def _collect_system_metrics(self) -> SystemMetrics:
        """收集系统指标"""
        # 在实际环境中，这里应该使用psutil等库收集真实指标
        # 这里使用模拟数据
        
        import random
        
        return SystemMetrics(
            timestamp=datetime.now().isoformat(),
            cpu_usage=random.uniform(10.0, 50.0),
            memory_usage=random.uniform(30.0, 70.0),
            disk_usage=68.0,  # 从之前检查获得
            network_status="正常",
            active_tasks=len([t for t in self.task_queue if t.get("status") == "running"]),
            completed_tasks=len(self.task_results),
            error_count=sum(1 for m in self.modules.values() if m.status == ModuleStatus.ERROR),
        )
    
    def _check_system_health(self, metrics: SystemMetrics):
        """检查系统健康状态"""
        thresholds = self.config["monitoring"]["alert_thresholds"]
        
        alerts = []
        
        if metrics.cpu_usage > thresholds["cpu_usage"]:
            alerts.append(f"CPU使用率过高: {metrics.cpu_usage:.1f}%")
        
        if metrics.memory_usage > thresholds["memory_usage"]:
            alerts.append(f"内存使用率过高: {metrics.memory_usage:.1f}%")
        
        if metrics.disk_usage > thresholds["disk_usage"]:
            alerts.append(f"磁盘使用率过高: {metrics.disk_usage:.1f}%")
        
        error_rate = (metrics.error_count / max(1, metrics.completed_tasks)) * 100
        if error_rate > thresholds["error_rate"]:
            alerts.append(f"错误率过高: {error_rate:.1f}%")
        
        if alerts:
            self.logger.warning(f"系统健康警报: {'; '.join(alerts)}")
    
    def _start_task_processor(self):
        """启动任务处理器"""
        def task_processor_worker():
            while self.system_status == SystemStatus.RUNNING:
                try:
                    # 处理任务队列
                    if self.task_queue:
                        task = self.task_queue.pop(0)
                        self._process_task(task)
                    
                    # 等待下一个处理周期
                    time.sleep(1.0)
                    
                except Exception as e:
                    self.logger.error(f"任务处理器出错: {e}")
                    time.sleep(5.0)
        
        thread = threading.Thread(
            target=task_processor_worker,
            name="TaskProcessor",
            daemon=True
        )
        thread.start()
    
    def _process_task(self, task: Dict[str, Any]):
        """处理任务"""
        task_id = task.get("id", "unknown")
        task_type = task.get("type", "unknown")
        
        self.logger.info(f"处理任务: {task_id} - {task_type}")
        
        try:
            # 根据任务类型处理
            if task_type == "performance_monitoring":
                result = self._handle_performance_monitoring(task)
            elif task_type == "data_analysis":
                result = self._handle_data_analysis(task)
            elif task_type == "optimization":
                result = self._handle_optimization(task)
            else:
                result = {"error": f"未知任务类型: {task_type}"}
            
            # 保存任务结果
            self.task_results[task_id] = {
                "task": task,
                "result": result,
                "completed_at": datetime.now().isoformat(),
                "success": "error" not in result,
            }
            
            self.logger.info(f"任务完成: {task_id}")
            
        except Exception as e:
            self.logger.error(f"处理任务失败 {task_id}: {e}")
            self.task_results[task_id] = {
                "task": task,
                "result": {"error": str(e)},
                "completed_at": datetime.now().isoformat(),
                "success": False,
            }
    
    def _handle_performance_monitoring(self, task: Dict[str, Any]) -> Dict[str, Any]:
        """处理性能监控任务"""
        # 在实际环境中，这里应该调用监控代理模块
        return {
            "monitoring_started": True,
            "script_name": task.get("script_name", "unknown"),
            "duration": task.get("duration", 300),
            "metrics_collected": 0,  # 模拟数据
        }
    
    def _handle_data_analysis(self, task: Dict[str, Any]) -> Dict[str, Any]:
        """处理数据分析任务"""
        # 在实际环境中，这里应该调用分析引擎模块
        return {
            "analysis_completed": True,
            "data_points": task.get("data_points", 0),
            "bottlenecks_found": 0,  # 模拟数据
            "recommendations": [],
        }
    
    def _handle_optimization(self, task: Dict[str, Any]) -> Dict[str, Any]:
        """处理优化任务"""
        # 在实际环境中，这里应该调用优化实施器模块
        return {
            "optimization_applied": True,
            "type": task.get("optimization_type", "unknown"),
            "estimated_improvement": task.get("estimated_improvement", 0.0),
            "actual_improvement": 0.0,  # 模拟数据
        }
    
    def _start_web_interface(self):
        """启动Web界面"""
        def web_interface_worker():
            try:
                # 在实际环境中，这里应该启动Flask应用
                # 这里只是模拟
                self.logger.info(f"Web界面将在 http://{self.config['web_interface']['host']}:{self.config['web_interface']['port']} 启动")
                
                # 模拟Web服务器运行
                while self.system_status == SystemStatus.RUNNING:
                    time.sleep(1.0)
                    
            except Exception as e:
                self.logger.error(f"Web界面出错: {e}")
        
        thread = threading.Thread(
            target=web_interface_worker,
            name="WebInterface",
            daemon=True
        )
        thread.start()
    
    def stop(self):
        """停止系统"""
        if self.system_status != SystemStatus.RUNNING:
            self.logger.warning(f"系统不在运行状态: {self.system_status}")
            return False
        
        self.logger.info("停止性能监控系统...")
        self.system_status = SystemStatus.STOPPING
        
        try:
            # 停止所有模块
            for module_name in list(self.modules.keys()):
                if self.modules[module_name].status == ModuleStatus.RUNNING:
                    self.stop_module(module_name)
            
            self.system_status = SystemStatus.STOPPED
            self.stop_time = datetime.now()
            
            runtime = (self.stop_time - self.start_time).total_seconds() if self.start_time else 0
            self.logger.info(f"性能监控系统已停止，运行时间: {runtime:.1f}秒")
            
            return True
            
        except Exception as e:
            self.logger.error(f"停止系统失败: {e}")
            self.system_status = SystemStatus.ERROR
            return False
    
    def get_system_status(self) -> Dict[str, Any]:
        """获取系统状态"""
        return {
            "system": {
                "status": self.system_status.value,
                "start_time": self.start_time.isoformat() if self.start_time else None,
                "stop_time": self.stop_time.isoformat() if self.stop_time else None,
                "uptime": (datetime.now() - self.start_time).total_seconds() if self.start_time else 0,
            },
            "modules": {
                name: {
                    "status": info.status.value,
                    "last_activity": info.last_activity,
                    "error_message": info.error_message,
                    "metrics": info.metrics,
                }
                for name, info in self.modules.items()
            },
            "metrics": {
                "total_tasks": len(self.task_results),
                "pending_tasks": len(self.task_queue),
                "system_metrics": asdict(self.system_metrics_history[-1]) if self.system_metrics_history else {},
            }
        }
    
    def add_task(self, task_type: str, **kwargs) -> str:
        """添加任务"""
        task_id = f"task_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{task_type}"
        
        task = {
            "id": task_id,
            "type": task_type,
            "created_at": datetime.now().isoformat(),
            "status": "pending",
            **kwargs,
        }
        
        self.task_queue.append(task)
        self.logger.info(f"添加任务: {task_id} - {task_type}")
        
        return task_id
    
    def get_task_result(self, task_id: str) -> Optional[Dict[str, Any]]:
        """获取任务结果"""
        return self.task_results.get(task_id)
    
    def generate_system_report(self) -> str:
        """生成系统报告"""
        report = []
        report.append("=" * 60)
        report.append("石器时代脚本性能监控系统 - 系统报告")
        report.append("=" * 60)
        report.append(f"生成时间: {datetime.now().isoformat()}")
        report.append(f"系统版本: {self.config['system']['version']}")
        report.append(f"系统状态: {self.system_status.value}")
        
        if self.start_time:
            uptime = (datetime.now() - self.start_time).total_seconds()
            report.append(f"运行时间: {uptime:.1f}秒 ({uptime/3600:.1f}小时)")
        
        # 模块状态
        report.append("\n模块状态:")
        for name, info in self.modules.items():
            report.append(f"  {name}: {info.status.value}")
            if info.error_message:
                report.append(f"    错误: {info.error_message}")
        
        # 任务统计
        report.append(f"\n任务统计:")
        report.append(f"  总任务数: {len(self.task_results)}")
        report.append(f"  待处理任务: {len(self.task_queue)}")
        report.append(f"  成功任务: {sum(1 for r in self.task_results.values() if r.get('success'))}")
        report.append(f"  失败任务: {sum(1 for r in self.task_results.values() if not r.get('success'))}")
        
        # 系统指标
        if self.system_metrics_history:
            latest_metrics = self.system_metrics_history[-1]
            report.append(f"\n最新系统指标:")
            report.append(f"  CPU使用率: {latest_metrics.cpu_usage:.1f}%")
            report.append(f"  内存使用率: {latest_metrics.memory_usage:.1f}%")
            report.append(f"  磁盘使用率: {latest_metrics.disk_usage:.1f}%")
            report.append(f"  网络状态: {latest_metrics.network_status}")
            report.append(f"  活动任务: {latest_metrics.active_tasks}")
            report.append(f"  错误计数: {latest_metrics.error_count}")
        
        # 配置信息
        report.append(f"\n配置信息:")
        report.append(f"  自动启动: {'是' if self.config['system']['auto_start'] else '否'}")
        report.append(f"  Web界面: {'启用' if self.config['web_interface']['enabled'] else '禁用'}")
        if self.config['web_interface']['enabled']:
            report.append(f"    地址: http://{self.config['web_interface']['host']}:{self.config['web_interface']['port']}")
        
        report.append("\n" + "=" * 60)
        report.append("报告结束")
        report.append("=" * 60)
        
        return "\n".join(report)
    
    def save_configuration(self, config_path: Optional[str] = None):
        """保存配置"""
        if not config_path:
            config_dir = "/root/.openclaw/workspace/石器时代脚本性能监控系统/config"
            os.makedirs(config_dir, exist_ok=True)
            config_path = os.path.join(config_dir, "system_config.json")
        
        try:
            with open(config_path, 'w', encoding='utf-8') as f:
                json.dump(self.config, f, ensure_ascii=False, indent=2)
            self.logger.info(f"配置已保存: {config_path}")
            return config_path
        except Exception as e:
            self.logger.error(f"保存配置失败: {e}")
            return None


# 使用示例
if __name__ == "__main__":
    print("石器时代脚本性能监控系统 - 主控制器演示")
    print("=" * 60)
    
    # 创建控制器实例
    controller = PerformanceMonitorController()
    
    # 启动系统
    print("\n启动系统...")
    if controller.start():
        print("系统启动成功")
        
        # 显示系统状态
        status = controller.get_system_status()
        print(f"\n系统状态: {status['system']['status']}")
        
        # 添加一些任务
        print("\n添加任务...")
        task_ids = [
            controller.add_task("performance_monitoring", script_name="NG25跑环脚本", duration=600),
            controller.add_task("data_analysis", data_points=100),
            controller.add_task("optimization", optimization_type="network_retry"),
        ]
        
        print(f"添加了 {len(task_ids)} 个任务")
        
        # 等待任务处理
        print("\n等待任务处理...")
        time.sleep(3)
        
        # 生成报告
        print("\n生成系统报告...")
        report = controller.generate_system_report()
        print(report)
        
        # 停止系统
        print("\n停止系统...")
        controller.stop()
        
    else:
        print("系统启动失败")
    
    print("\n主控制器演示完成！")