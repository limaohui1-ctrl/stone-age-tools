#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
整理石器时代工具生态系统脚本
将工作空间中的工具整理成适合GitHub仓库的结构
"""

import os
import sys
import shutil
import json
from pathlib import Path
from datetime import datetime

class StoneAgeToolsOrganizer:
    """石器时代工具整理器"""
    
    def __init__(self, source_path="/root/.openclaw/workspace", 
                 target_path="/tmp/stone-age-tools"):
        self.source_path = Path(source_path)
        self.target_path = Path(target_path)
        self.organize_log = []
        
    def create_directory_structure(self):
        """创建目录结构"""
        print("📁 创建目录结构...")
        
        directories = [
            # 根目录文件
            "",
            
            # 核心目录
            "核心工具",
            "核心工具/脚本调试器",
            "核心工具/性能分析器", 
            "核心工具/测试框架",
            "核心工具/优化系统",
            "核心工具/知识库工具",
            "核心工具/资料工具",
            "核心工具/验证码工具",
            
            # 知识库
            "知识库",
            "知识库/游戏数据",
            "知识库/脚本库",
            "知识库/脚本库/跑环脚本",
            "知识库/脚本库/练级脚本",
            "知识库/脚本库/任务脚本",
            "知识库/攻略库",
            
            # 文档
            "文档",
            "文档/用户手册",
            "文档/开发指南",
            "文档/API参考",
            "文档/视频教程",
            
            # 示例
            "示例",
            "示例/简单示例",
            "示例/网络优化",
            "示例/稳定性",
            "示例/综合示例",
            
            # 配置
            "配置",
            "配置/环境配置",
            "配置/工具配置",
            "配置/用户偏好",
            
            # 工具脚本
            "工具脚本",
            "工具脚本/安装脚本",
            "工具脚本/更新脚本",
            "工具脚本/备份脚本",
            "工具脚本/问题诊断",
            
            # 测试
            "测试",
            "测试/单元测试",
            "测试/集成测试",
            "测试/性能测试",
            
            # 资源
            "资源",
            "资源/图标",
            "资源/截图",
            "资源/示例数据",
        ]
        
        for directory in directories:
            dir_path = self.target_path / directory
            dir_path.mkdir(parents=True, exist_ok=True)
            self.organize_log.append(f"创建目录: {directory}")
        
        print(f"✅ 创建了 {len(directories)} 个目录")
        return True
    
    def copy_core_tools(self):
        """复制核心工具"""
        print("🔧 复制核心工具...")
        
        # 核心工具映射
        core_tools_map = {
            # 脚本调试器
            "石器时代脚本调试器.py": "核心工具/脚本调试器/",
            "石器时代脚本调试器_使用指南.md": "核心工具/脚本调试器/",
            "石器时代脚本调试器_总结报告.md": "核心工具/脚本调试器/",
            
            # 性能分析器
            "石器时代脚本性能分析器.py": "核心工具/性能分析器/",
            "石器时代脚本性能分析器_演示.py": "核心工具/性能分析器/",
            
            # 测试框架
            "石器时代脚本自动化测试框架/": "核心工具/测试框架/",
            "石器时代脚本自动化测试框架_使用指南.md": "核心工具/测试框架/",
            "石器时代脚本自动化测试框架_测试报告.md": "核心工具/测试框架/",
            "石器时代脚本自动化测试框架开发进度报告.md": "核心工具/测试框架/",
            
            # 优化系统
            "石器时代脚本优化和性能监控系统.py": "核心工具/优化系统/",
            "石器时代脚本优化实施工具和示例系统.py": "核心工具/优化系统/",
            "石器时代脚本优化效果验证和报告系统.py": "核心工具/优化系统/",
            "石器时代脚本优化效果验证和报告系统_完成.py": "核心工具/优化系统/",
            "脚本优化效果验证系统.py": "核心工具/优化系统/",
            
            # 知识库工具
            "石器时代知识库构建器.py": "核心工具/知识库工具/",
            "石器时代知识库构建器_final.py": "核心工具/知识库工具/",
            "石器时代知识库构建器_v2.py": "核心工具/知识库工具/",
            "石器时代知识库构建器_v2_complete.py": "核心工具/知识库工具/",
            "石器时代知识库构建器完整版.py": "核心工具/知识库工具/",
            "石器时代知识库构建器_续.py": "核心工具/知识库工具/",
            "石器时代知识库简单构建器.py": "核心工具/知识库工具/",
            
            # 资料工具
            "石器时代资料源发现工具.py": "核心工具/资料工具/",
            "石器时代资料收集系统.py": "核心工具/资料工具/",
            "石器时代资料收集脚本.py": "核心工具/资料工具/",
            "石器时代资料收集测试.py": "核心工具/资料工具/",
            
            # 验证码工具
            "石器时代验证码识别工具/": "核心工具/验证码工具/",
        }
        
        copied_count = 0
        for source_pattern, target_dir in core_tools_map.items():
            source_path = self.source_path / source_pattern
            
            if source_pattern.endswith('/'):
                # 处理目录
                if source_path.exists():
                    target_dir_path = self.target_path / target_dir / Path(source_pattern).name
                    try:
                        if target_dir_path.exists():
                            shutil.rmtree(target_dir_path)
                        shutil.copytree(source_path, target_dir_path)
                        copied_count += 1
                        self.organize_log.append(f"复制目录: {source_pattern} -> {target_dir}")
                    except Exception as e:
                        self.organize_log.append(f"错误复制目录: {source_pattern} - {e}")
            else:
                # 处理文件
                if source_path.exists():
                    target_file_path = self.target_path / target_dir / source_pattern
                    try:
                        shutil.copy2(source_path, target_file_path)
                        copied_count += 1
                        self.organize_log.append(f"复制文件: {source_pattern} -> {target_dir}")
                    except Exception as e:
                        self.organize_log.append(f"错误复制文件: {source_pattern} - {e}")
        
        print(f"✅ 复制了 {copied_count} 个核心工具")
        return True
    
    def copy_knowledge_base(self):
        """复制知识库"""
        print("📚 复制知识库...")
        
        # 知识库文件
        knowledge_files = [
            "石器时代知识库/",
            "石器时代知识库_简单版/",
            "石器时代脚本资料/",
            "石器时代资料库/",
        ]
        
        copied_count = 0
        for knowledge_file in knowledge_files:
            source_path = self.source_path / knowledge_file
            
            if source_path.exists():
                target_path = self.target_path / "知识库" / Path(knowledge_file).name
                try:
                    if target_path.exists():
                        shutil.rmtree(target_path)
                    shutil.copytree(source_path, target_path)
                    copied_count += 1
                    self.organize_log.append(f"复制知识库: {knowledge_file}")
                except Exception as e:
                    self.organize_log.append(f"错误复制知识库: {knowledge_file} - {e}")
        
        # 复制知识库相关文件
        knowledge_related = [
            ("石器时代知识库总结报告.md", "知识库/"),
            ("石器时代脚本资料库更新.md", "知识库/"),
            ("石器时代脚本数据库.md", "知识库/游戏数据/"),
        ]
        
        for source_file, target_dir in knowledge_related:
            source_path = self.source_path / source_file
            if source_path.exists():
                target_path = self.target_path / target_dir / source_file
                try:
                    shutil.copy2(source_path, target_path)
                    copied_count += 1
                    self.organize_log.append(f"复制知识库文件: {source_file}")
                except Exception as e:
                    self.organize_log.append(f"错误复制知识库文件: {source_file} - {e}")
        
        print(f"✅ 复制了 {copied_count} 个知识库项目")
        return True
    
    def copy_examples(self):
        """复制示例"""
        print("📝 复制示例...")
        
        # 示例文件
        example_files = [
            ("石器时代脚本网络优化模板.asc", "示例/网络优化/"),
            ("简单示例.asc", "示例/简单示例/"),
        ]
        
        # 查找所有.asc示例文件
        asc_files = list(self.source_path.glob("*.asc"))
        for asc_file in asc_files:
            if asc_file.name not in ["石器时代脚本网络优化模板.asc"]:
                example_files.append((asc_file.name, "示例/综合示例/"))
        
        copied_count = 0
        for source_file, target_dir in example_files:
            source_path = self.source_path / source_file
            if source_path.exists():
                target_path = self.target_path / target_dir / source_file
                try:
                    shutil.copy2(source_path, target_path)
                    copied_count += 1
                    self.organize_log.append(f"复制示例: {source_file}")
                except Exception as e:
                    self.organize_log.append(f"错误复制示例: {source_file} - {e}")
        
        # 复制测试示例项目
        test_example_dir = self.source_path / "石器时代脚本测试示例项目"
        if test_example_dir.exists():
            target_dir = self.target_path / "示例" / "测试示例"
            try:
                shutil.copytree(test_example_dir, target_dir)
                copied_count += 1
                self.organize_log.append("复制测试示例项目")
            except Exception as e:
                self.organize_log.append(f"错误复制测试示例项目 - {e}")
        
        print(f"✅ 复制了 {copied_count} 个示例文件")
        return True
    
    def copy_documentation(self):
        """复制文档"""
        print("📖 复制文档...")
        
        # 文档文件
        doc_files = [
            ("MEMORY.md", "文档/"),
            ("TOOLS.md", "文档/"),
            ("USER.md", "文档/"),
            ("IDENTITY.md", "文档/"),
            ("SOUL.md", "文档/"),
            ("AGENTS.md", "文档/"),
            ("HEARTBEAT.md", "文档/"),
            
            # 使用指南
            ("私服转换工具使用指南.md", "文档/用户手册/"),
            ("石器时代脚本调试器_使用指南.md", "文档/用户手册/"),
            ("石器时代脚本自动化测试框架_使用指南.md", "文档/用户手册/"),
            ("脚本批量优化工具_GUI_使用指南.md", "文档/用户手册/"),
            
            # 开发指南
            ("石器时代完整开发指南.py", "文档/开发指南/"),
            ("石器时代完整开发指南/", "文档/开发指南/"),
        ]
        
        copied_count = 0
        for source_file, target_dir in doc_files:
            if isinstance(source_file, str) and source_file.endswith('/'):
                # 处理目录
                source_path = self.source_path / source_file.rstrip('/')
                if source_path.exists():
                    target_path = self.target_path / target_dir / Path(source_file).name
                    try:
                        if target_path.exists():
                            shutil.rmtree(target_path)
                        shutil.copytree(source_path, target_path)
                        copied_count += 1
                        self.organize_log.append(f"复制文档目录: {source_file}")
                    except Exception as e:
                        self.organize_log.append(f"错误复制文档目录: {source_file} - {e}")
            else:
                # 处理文件
                source_path = self.source_path / source_file
                if source_path.exists():
                    target_path = self.target_path / target_dir / source_file
                    try:
                        shutil.copy2(source_path, target_path)
                        copied_count += 1
                        self.organize_log.append(f"复制文档: {source_file}")
                    except Exception as e:
                        self.organize_log.append(f"错误复制文档: {source_file} - {e}")
        
        print(f"✅ 复制了 {copied_count} 个文档文件")
        return True
    
    def copy_utility_scripts(self):
        """复制工具脚本"""
        print("🛠️ 复制工具脚本...")
        
        # 工具脚本
        utility_scripts = [
            "系统性能优化工具_simple.py",
            "系统优化及技术文档完善计划.md",
            "凌晨工作自动报告系统.py",
            "早晨工作准备.py",
            "下午工作准备系统.py",
            "午间系统检查工具.py",
            "工作回顾和规划系统.py",
            "工作质量评估系统.py",
            "工作进度监控系统.py",
            "工作成果收集系统.py",
            "工作结束和总结系统.py",
            "工作归档系统.py",
            "工作庆祝系统.py",
            "工作展示系统.py",
            "工作展望系统.py",
            "工作总结准备系统.py",
            "工作最终总结系统.py",
            "工作最终晚安系统.py",
            "工作最终计划系统.py",
            "工作最终工作系统.py",
            "工作最终归档系统.py",
            "工作最终总结感谢系统.py",
            "工作最终启动系统.py",
            "全天最终总结系统.py",
        ]
        
        copied_count = 0
        for script in utility_scripts:
            source_path = self.source_path / script
            if source_path.exists():
                target_path = self.target_path / "工具脚本" / script
                try:
                    shutil.copy2(source_path, target_path)
                    copied_count += 1
                    self.organize_log.append(f"复制工具脚本: {script}")
                except Exception as e:
                    self.organize_log.append(f"错误复制工具脚本: {script} - {e}")
        
        print(f"✅ 复制了 {copied_count} 个工具脚本")
        return True
    
    def copy_configurations(self):
        """复制配置"""
        print("⚙️ 复制配置...")
        
        # 配置文件
        config_files = [
            ("系统优化报告/", "配置/"),
            ("石器时代脚本优化示例/", "配置/示例配置/"),
            ("脚本优化生态系统集成/", "配置/集成配置/"),
            ("脚本优化生态系统部署包/", "配置/部署包/"),
        ]
        
        copied_count = 0
        for source_pattern, target_dir in config_files:
            source_path = self.source_path / source_pattern.rstrip('/')
            
            if source_path.exists():
                target_path = self.target_path / target_dir / Path(source_pattern).name
                try:
                    if target_path.exists():
                        shutil.rmtree(target_path)
                    shutil.copytree(source_path, target_path)
                    copied_count += 1
                    self.organize_log.append(f"复制配置: {source_pattern}")
                except Exception as e:
                    self.organize_log.append(f"错误复制配置: {source_pattern} - {e}")
        
        print(f"✅ 复制了 {copied_count} 个配置项目")
        return True
    
    def create_readme(self):
        """创建README.md"""
        print("📄 创建README.md...")
        
        readme_content = f"""# 🎮 石器时代脚本开发工具生态系统

## 📦 项目简介
这是一个完整的石器时代游戏脚本开发工具链，包含调试、分析、测试、优化等150+个工具，总计超过290,000行代码。

## 🚀 功能特性

### 核心工具
- 🎯 **脚本调试器** - 可视化调试ASSA脚本，实时监控执行状态
- 📊 **性能分析器** - 分析脚本性能瓶颈，提供优化建议
- 🧪 **测试框架** - 自动化测试和质量保证，支持多种测试类型
- ⚡ **优化系统** - 网络稳定性优化和性能监控
- 📚 **知识库工具** - 游戏数据查询和脚本库管理
- 🌐 **资料工具** - 资料收集和源发现
- 🔤 **验证码工具** - 多引擎OCR验证码识别

### 知识库系统
- 🗺️ **游戏数据** - NPC、坐标、物品数据库
- 📜 **脚本库** - 跑环、练级、任务脚本集合
- 🎯 **攻略库** - 游戏攻略和技巧

### 开发支持
- 📖 **完整文档** - 用户手册、开发指南、API参考
- 📝 **丰富示例** - 各种场景的使用示例
- ⚙️ **配置管理** - 环境配置和工具配置
- 🛠️ **工具脚本** - 安装、更新、备份、诊断脚本

## 🏗️ 项目结构

```
stone-age-tools/
├── 核心工具/                    # Core Tools
│   ├── 脚本调试器/              # Script Debugger
│   ├── 性能分析器/              # Performance Analyzer
│   ├── 测试框架/                # Test Framework
│   ├── 优化系统/                # Optimization System
│   ├── 知识库工具/              # Knowledge Base Tools
│   ├── 资料工具/                # Data Tools
│   └── 验证码工具/              # Captcha Tools
├── 知识库/                      # Knowledge Base
│   ├── 游戏数据/                # Game Data
│   ├── 脚本库/                  # Script Library
│   └── 攻略库/                  # Strategy Library
├── 文档/                        # Documentation
│   ├── 用户手册/                # User Manual
│   ├── 开发指南/                # Development Guide
│   ├── API参考/                 # API Reference
│   └── 视频教程