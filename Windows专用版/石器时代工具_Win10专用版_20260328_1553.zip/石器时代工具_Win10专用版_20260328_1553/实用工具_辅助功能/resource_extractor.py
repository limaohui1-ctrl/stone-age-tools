#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
资源提取器 - 从原软件提取验证码相关资源
"""

import os
import sys
import json
import shutil
import logging
from pathlib import Path
from typing import Dict, List, Optional, Tuple
import zipfile
import tarfile

class ResourceExtractor:
    """资源提取器"""
    
    def __init__(self, source_dir: str, target_dir: str):
        """
        初始化资源提取器
        
        Args:
            source_dir: 原软件目录
            target_dir: 目标目录
        """
        self.logger = logging.getLogger(__name__)
        self.source_dir = Path(source_dir)
        self.target_dir = Path(target_dir)
        
        # 确保目标目录存在
        self.target_dir.mkdir(parents=True, exist_ok=True)
        
        # 资源类型映射
        self.resource_types = {
            'dll': ['*.dll'],
            'exe': ['*.exe'],
            'config': ['*.ini', '*.json', '*.xml', '*.config'],
            'image': ['*.png', '*.jpg', '*.jpeg', '*.bmp', '*.gif'],
            'log': ['*.log', '*.txt'],
            'model': ['*.model', '*.dat', '*.bin', '*.onnx']
        }
        
        self.logger.info(f"资源提取器初始化完成")
        self.logger.info(f"源目录: {self.source_dir}")
        self.logger.info(f"目标目录: {self.target_dir}")
    
    def analyze_structure(self) -> Dict[str, List[str]]:
        """
        分析原软件结构
        
        Returns:
            文件结构字典
        """
        structure = {
            'directories': [],
            'files_by_type': {},
            'total_size': 0
        }
        
        try:
            # 收集所有目录
            for root, dirs, files in os.walk(self.source_dir):
                rel_root = Path(root).relative_to(self.source_dir)
                structure['directories'].append(str(rel_root))
                
                # 按类型收集文件
                for file in files:
                    file_path = Path(root) / file
                    file_size = file_path.stat().st_size
                    structure['total_size'] += file_size
                    
                    # 按扩展名分类
                    ext = file_path.suffix.lower()[1:] if file_path.suffix else 'other'
                    if ext not in structure['files_by_type']:
                        structure['files_by_type'][ext] = []
                    
                    structure['files_by_type'][ext].append({
                        'name': file,
                        'path': str(file_path.relative_to(self.source_dir)),
                        'size': file_size,
                        'full_path': str(file_path)
                    })
            
            self.logger.info(f"分析完成: {len(structure['directories'])}个目录, "
                           f"{sum(len(files) for files in structure['files_by_type'].values())}个文件, "
                           f"总大小: {structure['total_size'] / 1024 / 1024:.2f}MB")
            
            return structure
            
        except Exception as e:
            self.logger.error(f"分析软件结构失败: {e}")
            return structure
    
    def extract_ocr_resources(self) -> Dict[str, str]:
        """
        提取OCR相关资源
        
        Returns:
            提取的资源路径字典
        """
        extracted = {}
        
        try:
            ocr_dir = self.target_dir / "ocr_resources"
            ocr_dir.mkdir(exist_ok=True)
            
            # 查找OCR相关文件
            ocr_patterns = ['*ocr*', '*captcha*', '*识别*', '*验证*']
            
            for pattern in ocr_patterns:
                for file_path in self.source_dir.rglob(pattern):
                    if file_path.is_file():
                        # 复制文件
                        target_path = ocr_dir / file_path.name
                        shutil.copy2(file_path, target_path)
                        
                        file_type = file_path.suffix.lower()[1:] if file_path.suffix else 'unknown'
                        extracted[file_path.name] = {
                            'source': str(file_path.relative_to(self.source_dir)),
                            'target': str(target_path),
                            'type': file_type,
                            'size': file_path.stat().st_size
                        }
            
            # 特别处理已知的OCR文件
            known_ocr_files = ['Ocr.dll', 'CodeHook.dll', 'EasyHook.dll', 'EasyHook32.dll']
            
            for ocr_file in known_ocr_files:
                for file_path in self.source_dir.rglob(ocr_file):
                    if file_path.is_file():
                        target_path = ocr_dir / file_path.name
                        if not target_path.exists():
                            shutil.copy2(file_path, target_path)
                            
                            if ocr_file not in extracted:
                                extracted[ocr_file] = {
                                    'source': str(file_path.relative_to(self.source_dir)),
                                    'target': str(target_path),
                                    'type': 'dll',
                                    'size': file_path.stat().st_size
                                }
            
            self.logger.info(f"提取了 {len(extracted)} 个OCR相关资源")
            return extracted
            
        except Exception as e:
            self.logger.error(f"提取OCR资源失败: {e}")
            return extracted
    
    def extract_config_files(self) -> Dict[str, Dict]:
        """
        提取配置文件
        
        Returns:
            配置文件字典
        """
        configs = {}
        
        try:
            config_dir = self.target_dir / "configs"
            config_dir.mkdir(exist_ok=True)
            
            # 查找配置文件
            config_patterns = ['*.ini', '*.json', '*.xml', '*.config', '*.txt']
            
            for pattern in config_patterns:
                for file_path in self.source_dir.rglob(pattern):
                    if file_path.is_file():
                        # 读取配置文件内容
                        try:
                            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                                content = f.read()
                            
                            # 复制文件
                            target_path = config_dir / file_path.name
                            shutil.copy2(file_path, target_path)
                            
                            configs[file_path.name] = {
                                'source': str(file_path.relative_to(self.source_dir)),
                                'target': str(target_path),
                                'content_preview': content[:500] + '...' if len(content) > 500 else content,
                                'size': len(content)
                            }
                            
                        except Exception as e:
                            self.logger.warning(f"读取配置文件失败 {file_path}: {e}")
            
            self.logger.info(f"提取了 {len(configs)} 个配置文件")
            return configs
            
        except Exception as e:
            self.logger.error(f"提取配置文件失败: {e}")
            return configs
    
    def extract_image_samples(self) -> Dict[str, Dict]:
        """
        提取验证码样本图片
        
        Returns:
            图片样本字典
        """
        images = {}
        
        try:
            images_dir = self.target_dir / "image_samples"
            images_dir.mkdir(exist_ok=True)
            
            # 查找图片文件
            image_patterns = ['*.png', '*.jpg', '*.jpeg', '*.bmp', '*.gif']
            
            for pattern in image_patterns:
                for file_path in self.source_dir.rglob(pattern):
                    if file_path.is_file():
                        # 检查文件大小（避免提取太大的非验证码图片）
                        file_size = file_path.stat().st_size
                        if file_size < 10 * 1024 * 1024:  # 小于10MB
                            # 复制文件
                            target_path = images_dir / file_path.name
                            shutil.copy2(file_path, target_path)
                            
                            images[file_path.name] = {
                                'source': str(file_path.relative_to(self.source_dir)),
                                'target': str(target_path),
                                'type': file_path.suffix.lower()[1:],
                                'size': file_size
                            }
            
            self.logger.info(f"提取了 {len(images)} 个图片样本")
            return images
            
        except Exception as e:
            self.logger.error(f"提取图片样本失败: {e}")
            return images
    
    def extract_log_files(self) -> Dict[str, Dict]:
        """
        提取日志文件
        
        Returns:
            日志文件字典
        """
        logs = {}
        
        try:
            logs_dir = self.target_dir / "logs"
            logs_dir.mkdir(exist_ok=True)
            
            # 查找日志文件
            log_patterns = ['*.log', '*.txt']
            
            for pattern in log_patterns:
                for file_path in self.source_dir.rglob(pattern):
                    if file_path.is_file() and file_path.stat().st_size > 0:
                        # 读取日志内容（前1000行）
                        try:
                            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                                lines = []
                                for i, line in enumerate(f):
                                    if i >= 1000:
                                        break
                                    lines.append(line.strip())
                            
                            # 复制文件
                            target_path = logs_dir / file_path.name
                            shutil.copy2(file_path, target_path)
                            
                            logs[file_path.name] = {
                                'source': str(file_path.relative_to(self.source_dir)),
                                'target': str(target_path),
                                'line_count': len(lines),
                                'sample_lines': lines[:10],  # 前10行作为样本
                                'size': file_path.stat().st_size
                            }
                            
                        except Exception as e:
                            self.logger.warning(f"读取日志文件失败 {file_path}: {e}")
            
            self.logger.info(f"提取了 {len(logs)} 个日志文件")
            return logs
            
        except Exception as e:
            self.logger.error(f"提取日志文件失败: {e}")
            return logs
    
    def analyze_verification_patterns(self) -> Dict[str, any]:
        """
        分析验证码识别模式
        
        Returns:
            识别模式分析结果
        """
        analysis = {
            'captcha_patterns': [],
            'verification_methods': [],
            'integration_points': [],
            'recommendations': []
        }
        
        try:
            # 分析日志文件中的验证码模式
            logs = self.extract_log_files()
            
            captcha_patterns = set()
            for log_name, log_info in logs.items():
                if 'sample_lines' in log_info:
                    for line in log_info['sample_lines']:
                        # 查找验证码相关模式
                        if '验证码' in line or 'captcha' in line.lower():
                            captcha_patterns.add('中文验证码')
                        if '识别结果' in line:
                            captcha_patterns.add('识别结果记录')
                        if any(char in line for char in ['[', ']', '【', '】']):
                            captcha_patterns.add('括号格式')
            
            analysis['captcha_patterns'] = list(captcha_patterns)
            
            # 分析配置文件
            configs = self.extract_config_files()
            for config_name, config_info in configs.items():
                if 'content_preview' in config_info:
                    content = config_info['content_preview'].lower()
                    if 'interval' in content:
                        analysis['verification_methods'].append('定时检查')
                    if 'hook' in content:
                        analysis['integration_points'].append('进程钩子')
                    if 'ocr' in content:
                        analysis['verification_methods'].append('OCR识别')
            
            # 生成建议
            if 'OCR识别' in analysis['verification_methods']:
                analysis['recommendations'].append('使用开源OCR库替代专有DLL')
            if '进程钩子' in analysis['integration_points']:
                analysis['recommendations'].append('使用合法API替代进程注入')
            if '定时检查' in analysis['verification_methods']:
                analysis['recommendations'].append('实现智能触发机制')
            
            self.logger.info(f"验证码模式分析完成: {len(analysis['captcha_patterns'])}种模式")
            return analysis
            
        except Exception as e:
            self.logger.error(f"分析验证码模式失败: {e}")
            return analysis
    
    def generate_extraction_report(self) -> str:
        """
        生成资源提取报告
        
        Returns:
            报告文件路径
        """
        try:
            report_path = self.target_dir / "extraction_report.md"
            
            # 收集所有分析结果
            structure = self.analyze_structure()
            ocr_resources = self.extract_ocr_resources()
            configs = self.extract_config_files()
            images = self.extract_image_samples()
            logs = self.extract_log_files()
            patterns = self.analyze_verification_patterns()
            
            # 生成报告
            report_content = [
                "# 🔍 原软件资源提取报告",
                "",
                f"## 📅 报告时间: {time.strftime('%Y-%m-%d %H:%M:%S')}",
                "",
                f"## 📁 源目录: {self.source_dir}",
                f"## 📁 目标目录: {self.target_dir}",
                "",
                "## 📊 软件结构分析",
                "",
                f"- **总目录数**: {len(structure['directories'])}",
                f"- **总文件数**: {sum(len(files) for files in structure['files_by_type'].values())}",
                f"- **总大小**: {structure['total_size'] / 1024 / 1024:.2f} MB",
                "",
                "### 文件类型分布:",
            ]
            
            for file_type, files in structure['files_by_type'].items():
                report_content.append(f"- **{file_type}**: {len(files)}个文件")
            
            report_content.extend([
                "",
                "## 🔧 OCR资源提取",
                "",
                f"- **提取的OCR资源**: {len(ocr_resources)}个",
            ])
            
            for resource_name, resource_info in list(ocr_resources.items())[:10]:  # 显示前10个
                report_content.append(f"  - `{resource_name}`: {resource_info['size'] / 1024:.1f} KB")
            
            if len(ocr_resources) > 10:
                report_content.append(f"  - ... 还有{len(ocr_resources) - 10}个资源")
            
            report_content.extend([
                "",
                "## ⚙️ 配置文件提取",
                "",
                f"- **提取的配置文件**: {len(configs)}个",
            ])
            
            for config_name, config_info in list(configs.items())[:5]:  # 显示前5个
                report_content.append(f"  - `{config_name}`: {config_info['size']}字节")
            
            report_content.extend([
                "",
                "## 🖼️ 图片样本提取",
                "",
                f"- **提取的图片样本**: {len(images)}个",
                "",
                "## 📝 日志文件提取",
                "",
                f"- **提取的日志文件**: {len(logs)}个",
                "",
                "## 🎯 验证码模式分析",
                "",
                "### 识别模式:",
            ])
            
            for pattern in patterns.get('captcha_patterns', []):
                report_content.append(f"- {pattern}")
            
            report_content.extend([
                "",
                "### 验证方法:",
            ])
            
            for method in patterns.get('verification_methods', []):
                report_content.append(f"- {method}")
            
            report_content.extend([
                "",
                "### 集成点:",
            ])
            
            for point in patterns.get('integration_points', []):
                report_content.append(f"- {point}")
            
            report_content.extend([
                "",
                "### 开发建议:",
            ])
            
            for recommendation in patterns.get('recommendations', []):
                report_content.append(f"- ✅ {recommendation}")
            
            report_content.extend([
                "",
                "## 🚀 下一步行动",
                "",
                "1. **分析OCR算法** - 研究提取的OCR资源",
                "2. **设计替代方案** - 基于分析结果设计开源方案",
                "3. **实现核心功能** - 开发验证码识别模块",
                "4. **测试和优化** - 确保功能完整和稳定",
                "",
                "---",
                "",
                "*报告生成完成*"
            ])
            
            # 写入报告
            with open(report_path, 'w', encoding='utf-8') as f:
                f.write('\n'.join(report_content))
            
            self.logger.info(f"资源提取报告已生成: {report_path}")
            return str(report_path)
            
        except Exception as e:
            self.logger.error(f"生成提取报告失败: {e}")
            return ""

# 导入time模块
import time

# 简单测试函数
def test_resource_extractor():
    """测试资源提取器"""
    print("🔍 测试资源提取器")
    print("-" * 40)
    
    # 源目录（原软件目录）
    source_dir = "/root/.openclaw/qqbot/downloads/验证码分析/验证码"
    
    if not os.path.exists(source_dir):
        print(f"❌ 源目录不存在: {source_dir}")
        print("💡 请确保原软件已解压")
        return
    
    # 目标目录
    target_dir = "/root/.openclaw/workspace/石器时代验证码识别工具/extracted_resources"
    
    # 创建提取器
    extractor = ResourceExtractor(source_dir, target_dir)
    
    # 分析软件结构
    print("📊 分析软件结构...")
    structure = extractor.analyze_structure()
    print(f"✅ 分析完成: {len(structure['directories'])}个目录")
    
    # 提取OCR资源
    print("\n🔧 提取OCR资源...")
    ocr_resources = extractor.extract_ocr_resources()
    print(f"✅ 提取了 {len(ocr_resources)} 个OCR资源")
    
    # 提取配置文件
    print("\n⚙️ 提取配置文件...")
    configs = extractor.extract_config_files()
    print(f"✅ 提取了 {len(configs)} 个配置文件")
    
    # 生成报告
    print("\n📊 生成提取报告...")
    report_path = extractor.generate_extraction_report()
    if report_path:
        print(f"✅ 报告已生成: {report_path}")
    
    print("\n🎉 资源提取测试完成")
    print(f"📁 提取的资源保存在: {target_dir}")

if __name__ == "__main__":
    test_resource_extractor()