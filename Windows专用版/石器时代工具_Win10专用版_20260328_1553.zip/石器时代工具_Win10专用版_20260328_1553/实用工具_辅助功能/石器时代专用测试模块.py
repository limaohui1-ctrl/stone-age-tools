#!/usr/bin/env python3
"""
石器时代脚本专用测试模块
为石器时代脚本提供专门的测试功能和断言
"""

import os
import re
import json
import logging
from pathlib import Path
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass, field
from enum import Enum

logger = logging.getLogger(__name__)

class ASSACommandType(Enum):
    """ASSA命令类型枚举"""
    MOVE = "移动"  # walkpos, waitpos等
    INTERACT = "交互"  # say, npc, click等
    CONDITION = "条件"  # if, while, for等
    VARIABLE = "变量"  # set, get, inc等
    LOGIC = "逻辑"  # and, or, not等
    FUNCTION = "函数"  # call, return等
    ERROR = "错误处理"  # error, try, catch等
    UI = "界面"  # msg, dialog等
    OTHER = "其他"

@dataclass
class ASSACommand:
    """ASSA命令数据结构"""
    line_number: int
    command: str
    command_type: ASSACommandType
    parameters: List[str] = field(default_factory=list)
    comment: Optional[str] = None
    is_valid: bool = True
    validation_error: Optional[str] = None

@dataclass
class StoneAgeScript:
    """石器时代脚本数据结构"""
    file_path: Path
    script_name: str
    total_lines: int
    commands: List[ASSACommand] = field(default_factory=list)
    variables: Dict[str, Any] = field(default_factory=dict)
    functions: Dict[str, List[ASSACommand]] = field(default_factory=dict)
    errors: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)

class StoneAgeTestAssertion:
    """石器时代脚本专用断言"""
    
    @staticmethod
    def assert_script_completes(script_path: str, timeout: int = 300) -> bool:
        """断言脚本能在指定时间内完成执行"""
        # 这里应该调用实际的脚本执行器
        # 暂时返回模拟结果
        return True
    
    @staticmethod
    def assert_no_errors(script_content: str) -> Tuple[bool, List[str]]:
        """断言脚本没有语法错误"""
        errors = []
        
        # 检查常见错误模式
        error_patterns = [
            (r'error\s+[0-9]+', "错误代码未处理"),
            (r'goto\s+[^:]+:', "goto标签格式错误"),
            (r'if\s*\([^)]*$', "if条件不完整"),
            (r'while\s*\([^)]*$', "while条件不完整"),
            (r'for\s*\([^)]*$', "for循环不完整"),
        ]
        
        lines = script_content.split('\n')
        for i, line in enumerate(lines, 1):
            line = line.strip()
            if not line or line.startswith('//') or line.startswith('#'):
                continue
                
            for pattern, error_msg in error_patterns:
                if re.search(pattern, line, re.IGNORECASE):
                    errors.append(f"第{i}行: {error_msg} - {line}")
        
        return len(errors) == 0, errors
    
    @staticmethod
    def assert_coordinates_valid(coordinates: List[Tuple[int, int]]) -> Tuple[bool, List[str]]:
        """断言坐标有效"""
        errors = []
        
        for x, y in coordinates:
            if not (0 <= x <= 1000 and 0 <= y <= 1000):
                errors.append(f"坐标({x},{y})超出有效范围(0-1000)")
        
        return len(errors) == 0, errors
    
    @staticmethod
    def assert_npc_names_valid(npc_names: List[str]) -> Tuple[bool, List[str]]:
        """断言NPC名称有效"""
        errors = []
        
        # 常见NPC名称模式
        valid_patterns = [
            r'^[+\-]?NPC名称$',
            r'^[+\-]?NPC.*$',
            r'^[+\-]?.*NPC$',
        ]
        
        for npc_name in npc_names:
            npc_name = npc_name.strip()
            if not any(re.match(pattern, npc_name) for pattern in valid_patterns):
                errors.append(f"NPC名称格式可能无效: {npc_name}")
        
        return len(errors) == 0, errors
    
    @staticmethod
    def assert_script_structure(script_content: str) -> Tuple[bool, Dict[str, Any]]:
        """断言脚本结构合理"""
        structure_info = {
            "has_main_loop": False,
            "has_error_handling": False,
            "has_comments": False,
            "function_count": 0,
            "variable_count": 0,
        }
        
        lines = script_content.split('\n')
        total_lines = len(lines)
        comment_lines = 0
        
        for line in lines:
            line = line.strip()
            
            # 检查注释
            if line.startswith('//') or line.startswith('#'):
                comment_lines += 1
            
            # 检查主循环
            if re.search(r'while\s*\(true\)', line, re.IGNORECASE):
                structure_info["has_main_loop"] = True
            
            # 检查错误处理
            if re.search(r'error\s+[0-9]+', line, re.IGNORECASE):
                structure_info["has_error_handling"] = True
            
            # 检查函数定义
            if re.search(r'^\s*function\s+', line, re.IGNORECASE):
                structure_info["function_count"] += 1
            
            # 检查变量定义
            if re.search(r'^\s*set\s+', line, re.IGNORECASE):
                structure_info["variable_count"] += 1
        
        # 计算注释比例
        comment_ratio = comment_lines / total_lines if total_lines > 0 else 0
        structure_info["has_comments"] = comment_ratio > 0.1  # 至少10%的注释
        
        # 评估结构合理性
        is_valid = (
            structure_info["has_main_loop"] and
            structure_info["has_error_handling"] and
            structure_info["has_comments"] and
            structure_info["function_count"] > 0
        )
        
        return is_valid, structure_info

class StoneAgeScriptParser:
    """石器时代脚本解析器"""
    
    @staticmethod
    def parse_script(file_path: str) -> StoneAgeScript:
        """解析石器时代脚本文件"""
        path = Path(file_path)
        if not path.exists():
            raise FileNotFoundError(f"脚本文件不存在: {file_path}")
        
        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read()
        
        script = StoneAgeScript(
            file_path=path,
            script_name=path.stem,
            total_lines=len(content.split('\n'))
        )
        
        lines = content.split('\n')
        for i, line in enumerate(lines, 1):
            command = StoneAgeScriptParser._parse_line(i, line)
            if command:
                script.commands.append(command)
        
        # 提取变量和函数
        script.variables = StoneAgeScriptParser._extract_variables(script.commands)
        script.functions = StoneAgeScriptParser._extract_functions(script.commands)
        
        return script
    
    @staticmethod
    def _parse_line(line_number: int, line: str) -> Optional[ASSACommand]:
        """解析单行命令"""
        line = line.strip()
        if not line or line.startswith('//') or line.startswith('#'):
            return None
        
        # 分离注释
        if '//' in line:
            line, comment = line.split('//', 1)
            line = line.strip()
            comment = comment.strip()
        else:
            comment = None
        
        # 识别命令类型
        command_type = StoneAgeScriptParser._identify_command_type(line)
        
        # 提取参数
        if '(' in line and ')' in line:
            # 函数调用格式: command(param1, param2)
            command_part = line[:line.index('(')].strip()
            params_part = line[line.index('(')+1:line.index(')')].strip()
            params = [p.strip() for p in params_part.split(',')] if params_part else []
        else:
            # 简单命令格式: command param1 param2
            parts = line.split()
            command_part = parts[0] if parts else ""
            params = parts[1:] if len(parts) > 1 else []
        
        return ASSACommand(
            line_number=line_number,
            command=command_part,
            command_type=command_type,
            parameters=params,
            comment=comment,
            is_valid=True
        )
    
    @staticmethod
    def _identify_command_type(command: str) -> ASSACommandType:
        """识别命令类型"""
        command_lower = command.lower()
        
        # 移动命令
        move_commands = ['walkpos', 'waitpos', 'move', 'goto']
        if any(cmd in command_lower for cmd in move_commands):
            return ASSACommandType.MOVE
        
        # 交互命令
        interact_commands = ['say', 'npc', 'click', 'dialog', 'select']
        if any(cmd in command_lower for cmd in interact_commands):
            return ASSACommandType.INTERACT
        
        # 条件命令
        condition_commands = ['if', 'else', 'while', 'for', 'switch']
        if any(cmd in command_lower for cmd in condition_commands):
            return ASSACommandType.CONDITION
        
        # 变量命令
        variable_commands = ['set', 'get', 'inc', 'dec', 'var']
        if any(cmd in command_lower for cmd in variable_commands):
            return ASSACommandType.VARIABLE
        
        # 逻辑命令
        logic_commands = ['and', 'or', 'not', 'xor']
        if any(cmd in command_lower for cmd in logic_commands):
            return ASSACommandType.LOGIC
        
        # 函数命令
        function_commands = ['function', 'call', 'return']
        if any(cmd in command_lower for cmd in function_commands):
            return ASSACommandType.FUNCTION
        
        # 错误处理命令
        error_commands = ['error', 'try', 'catch', 'throw']
        if any(cmd in command_lower for cmd in error_commands):
            return ASSACommandType.ERROR
        
        # 界面命令
        ui_commands = ['msg', 'dialog', 'alert', 'prompt']
        if any(cmd in command_lower for cmd in ui_commands):
            return ASSACommandType.UI
        
        return ASSACommandType.OTHER
    
    @staticmethod
    def _extract_variables(commands: List[ASSACommand]) -> Dict[str, Any]:
        """从命令中提取变量"""
        variables = {}
        
        for cmd in commands:
            if cmd.command_type == ASSACommandType.VARIABLE and cmd.command.lower() == 'set':
                if len(cmd.parameters) >= 2:
                    var_name = cmd.parameters[0]
                    var_value = cmd.parameters[1]
                    variables[var_name] = var_value
        
        return variables
    
    @staticmethod
    def _extract_functions(commands: List[ASSACommand]) -> Dict[str, List[ASSACommand]]:
        """从命令中提取函数"""
        functions = {}
        current_function = None
        function_commands = []
        
        for cmd in commands:
            if cmd.command_type == ASSACommandType.FUNCTION and cmd.command.lower() == 'function':
                # 保存上一个函数
                if current_function and function_commands:
                    functions[current_function] = function_commands.copy()
                
                # 开始新函数
                if cmd.parameters:
                    current_function = cmd.parameters[0]
                    function_commands = []
            elif current_function:
                function_commands.append(cmd)
        
        # 保存最后一个函数
        if current_function and function_commands:
            functions[current_function] = function_commands
        
        return functions

class StoneAgeTestGenerator:
    """石器时代脚本测试用例生成器"""
    
    @staticmethod
    def generate_test_cases(script_path: str, output_dir: str = "tests") -> List[Dict[str, Any]]:
        """为脚本生成测试用例"""
        test_cases = []
        
        try:
            script = StoneAgeScriptParser.parse_script(script_path)
            
            # 生成基本功能测试
            test_cases.append({
                "id": f"{script.script_name}_basic",
                "name": f"{script.script_name} 基本功能测试",
                "description": "测试脚本基本执行功能",
                "script_path": script_path,
                "timeout": 300,
                "assertions": [
                    {
                        "type": "script_completes",
                        "timeout": 300,
                        "message": "脚本应在5分钟内完成执行"
                    },
                    {
                        "type": "no_errors",
                        "message": "脚本应无语法错误"
                    }
                ]
            })
            
            # 生成结构测试
            test_cases.append({
                "id": f"{script.script_name}_structure",
                "name": f"{script.script_name} 结构测试",
                "description": "测试脚本结构合理性",
                "script_path": script_path,
                "timeout": 60,
                "assertions": [
                    {
                        "type": "script_structure",
                        "min_comments": 0.1,
                        "require_main_loop": True,
                        "require_error_handling": True,
                        "message": "脚本结构应合理"
                    }
                ]
            })
            
            # 为每个函数生成测试
            for func_name, func_commands in script.functions.items():
                test_cases.append({
                    "id": f"{script.script_name}_function_{func_name}",
                    "name": f"{script.script_name} 函数测试 - {func_name}",
                    "description": f"测试函数 {func_name}",
                    "script_path": script_path,
                    "function_to_test": func_name,
                    "timeout": 120,
                    "assertions": [
                        {
                            "type": "function_exists",
                            "function_name": func_name,
                            "message": f"函数 {func_name} 应存在"
                        }
                    ]
                })
            
            # 保存测试用例
            output_path = Path(output_dir) / f"{script.script_name}_tests.json"
            output_path.parent.mkdir(exist_ok=True)
            
            with open(output_path, 'w', encoding='utf-8') as f:
                json.dump(test_cases, f, ensure_ascii=False, indent=2)
            
            logger.info(f"为脚本 {script.script_name} 生成了 {len(test_cases)} 个测试用例")
            logger.info(f"测试用例已保存到: {output_path}")
            
        except Exception as e:
            logger.error(f"生成测试用例失败: {e}")
        
        return test_cases

def main():
    """主函数"""
    import argparse
    
    parser = argparse.ArgumentParser(description="石器时代脚本专用测试模块")
    parser.add_argument("script", help="石器时代脚本文件路径")
    parser.add_argument("--output", "-o", default="tests", help="测试用例输出目录")
    parser.add_argument("--verbose", "-v", action="store_true", help="详细输出")
    
    args = parser.parse_args()
    
    # 设置日志
    level = logging.DEBUG if args.verbose else logging.INFO
    logging.basicConfig(level=level, format='%(levelname)s: %(message)s')
    
    # 生成测试用例
    test_cases = StoneAgeTestGenerator.generate_test_cases(args.script, args.output)
    
    print(f"\n🎯 为脚本 {args.script} 生成的测试用例:")
    for i, test_case in enumerate(test_cases, 1):
        print(f"{i}. {test_case['name']}")
        print(f"   {test_case['description']}")
        print(f"   断言: {len(test_case['assertions'])} 个")
        print()

if __name__ == "__main__":
    main()