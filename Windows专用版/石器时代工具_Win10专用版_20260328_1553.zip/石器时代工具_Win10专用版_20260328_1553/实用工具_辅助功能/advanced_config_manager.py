#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
高级配置管理器 - 完整的配置管理系统
支持配置验证、迁移、导入导出等功能
"""

import os
import json
import logging
import shutil
from pathlib import Path
from typing import Dict, Any, Optional, List, Tuple
from datetime import datetime
import hashlib

class AdvancedConfigManager:
    """高级配置管理器"""
    
    # 配置版本
    CONFIG_VERSION = "1.0.0"
    
    # 配置架构定义
    CONFIG_SCHEMA = {
        "type": "object",
        "required": ["version", "game", "ocr", "system"],
        "properties": {
            "version": {"type": "string"},
            "description": {"type": "string"},
            
            "game": {
                "type": "object",
                "required": ["window_title", "check_interval"],
                "properties": {
                    "window_title": {"type": "string"},
                    "window_class": {"type": "string"},
                    "exe_path": {"type": "string"},
                    "captcha_area": {
                        "type": "object",
                        "properties": {
                            "x": {"type": "number", "minimum": 0},
                            "y": {"type": "number", "minimum": 0},
                            "width": {"type": "number", "minimum": 1},
                            "height": {"type": "number", "minimum": 1},
                            "auto_detect": {"type": "boolean"}
                        }
                    },
                    "input_area": {
                        "type": "object",
                        "properties": {
                            "x": {"type": "number", "minimum": 0},
                            "y": {"type": "number", "minimum": 0},
                            "width": {"type": "number", "minimum": 1},
                            "height": {"type": "number", "minimum": 1}
                        }
                    },
                    "check_interval": {"type": "number", "minimum": 1, "maximum": 300},
                    "auto_input": {"type": "boolean"},
                    "retry_count": {"type": "number", "minimum": 0, "maximum": 10}
                }
            },
            
            "ocr": {
                "type": "object",
                "required": ["primary_engine"],
                "properties": {
                    "primary_engine": {"type": "string", "enum": ["tesseract", "easyocr", "paddleocr"]},
                    "fallback_engines": {"type": "array", "items": {"type": "string"}},
                    "language": {"type": "string"},
                    "character_whitelist": {"type": "string"},
                    "confidence_threshold": {"type": "number", "minimum": 0, "maximum": 1},
                    
                    "preprocessing": {
                        "type": "object",
                        "properties": {
                            "enabled": {"type": "boolean"},
                            "grayscale": {"type": "boolean"},
                            "threshold": {"type": "boolean"},
                            "denoise": {"type": "boolean"},
                            "morphology": {"type": "boolean"},
                            "resize": {"type": "array", "items": {"type": "number"}, "minItems": 2, "maxItems": 2}
                        }
                    },
                    
                    "tesseract": {
                        "type": "object",
                        "properties": {
                            "path": {"type": "string"},
                            "data_path": {"type": "string"},
                            "config": {"type": "string"}
                        }
                    },
                    
                    "easyocr": {
                        "type": "object",
                        "properties": {
                            "gpu": {"type": "boolean"},
                            "model_storage_directory": {"type": "string"}
                        }
                    }
                }
            },
            
            "users": {
                "type": "array",
                "items": {
                    "type": "object",
                    "required": ["id", "username", "enabled"],
                    "properties": {
                        "id": {"type": "number", "minimum": 1},
                        "username": {"type": "string"},
                        "game_account": {"type": "string"},
                        "enabled": {"type": "boolean"},
                        "created_at": {"type": "string"},
                        "last_used": {"type": "string"},
                        "statistics": {
                            "type": "object",
                            "properties": {
                                "total_captchas": {"type": "number", "minimum": 0},
                                "successful": {"type": "number", "minimum": 0},
                                "failed": {"type": "number", "minimum": 0},
                                "accuracy": {"type": "number", "minimum": 0, "maximum": 1},
                                "total_time": {"type": "number", "minimum": 0}
                            }
                        }
                    }
                }
            },
            
            "system": {
                "type": "object",
                "required": ["log_level"],
                "properties": {
                    "log_level": {"type": "string", "enum": ["DEBUG", "INFO", "WARNING", "ERROR"]},
                    "log_file": {"type": "string"},
                    "max_log_size": {"type": "number", "minimum": 1024},
                    "max_log_files": {"type": "number", "minimum": 1},
                    
                    "auto_update": {"type": "boolean"},
                    "update_channel": {"type": "string", "enum": ["stable", "beta", "dev"]},
                    "check_update_interval": {"type": "number", "minimum": 3600},
                    
                    "start_minimized": {"type": "boolean"},
                    "minimize_to_tray": {"type": "boolean"},
                    "close_to_tray": {"type": "boolean"},
                    
                    "performance": {
                        "type": "object",
                        "properties": {
                            "max_threads": {"type": "number", "minimum": 1, "maximum": 16},
                            "cache_size": {"type": "number", "minimum": 0, "maximum": 1000},
                            "cleanup_interval": {"type": "number", "minimum": 60}
                        }
                    }
                }
            },
            
            "user_interface": {
                "type": "object",
                "properties": {
                    "theme": {"type": "string", "enum": ["dark", "light", "auto"]},
                    "language": {"type": "string"},
                    "font_family": {"type": "string"},
                    "font_size": {"type": "number", "minimum": 8, "maximum": 24},
                    
                    "window": {
                        "type": "object",
                        "properties": {
                            "width": {"type": "number", "minimum": 400},
                            "height": {"type": "number", "minimum": 300},
                            "maximized": {"type": "boolean"},
                            "position": {"type": "string", "enum": ["center", "remember"]}
                        }
                    },
                    
                    "notifications": {
                        "type": "object",
                        "properties": {
                            "enabled": {"type": "boolean"},
                            "sound": {"type": "boolean"},
                            "duration": {"type": "number", "minimum": 1000, "maximum": 10000}
                        }
                    }
                }
            },
            
            "advanced": {
                "type": "object",
                "properties": {
                    "debug_mode": {"type": "boolean"},
                    "developer_mode": {"type": "boolean"},
                    "experimental_features": {"type": "boolean"},
                    
                    "captcha_database": {
                        "type": "object",
                        "properties": {
                            "enabled": {"type": "boolean"},
                            "auto_collect": {"type": "boolean"},
                            "auto_train": {"type": "boolean"},
                            "storage_path": {"type": "string"}
                        }
                    },
                    
                    "machine_learning": {
                        "type": "object",
                        "properties": {
                            "enabled": {"type": "boolean"},
                            "model_path": {"type": "string"},
                            "training_interval": {"type": "number", "minimum": 3600},
                            "min_samples": {"type": "number", "minimum": 100}
                        }
                    }
                }
            }
        }
    }
    
    def __init__(self, config_dir: Optional[str] = None):
        """
        初始化配置管理器
        
        Args:
            config_dir: 配置目录路径
        """
        self.logger = logging.getLogger(__name__)
        
        # 设置配置目录
        if config_dir:
            self.config_dir = Path(config_dir)
        else:
            self.config_dir = Path(__file__).parent.parent.parent / "configs"
        
        # 确保配置目录存在
        self.config_dir.mkdir(parents=True, exist_ok=True)
        
        # 配置文件路径
        self.config_file = self.config_dir / "config.json"
        self.backup_dir = self.config_dir / "backups"
        self.backup_dir.mkdir(exist_ok=True)
        
        # 当前配置
        self.config = None
        self.config_hash = None
        
        # 配置历史
        self.history_file = self.config_dir / "config_history.json"
        self.history = self._load_history()
        
        self.logger.info(f"配置管理器初始化完成: {self.config_dir}")
    
    def load_config(self, create_default: bool = True) -> Dict[str, Any]:
        """
        加载配置文件
        
        Args:
            create_default: 如果配置文件不存在，是否创建默认配置
            
        Returns:
            配置字典
        """
        try:
            if self.config_file.exists():
                # 读取配置文件
                with open(self.config_file, 'r', encoding='utf-8') as f:
                    self.config = json.load(f)
                
                # 计算配置哈希
                self.config_hash = self._calculate_config_hash(self.config)
                
                # 验证配置
                if not self.validate_config(self.config):
                    self.logger.warning("配置文件验证失败，尝试修复")
                    self.config = self._fix_config(self.config)
                
                # 检查配置版本
                if self.config.get('version') != self.CONFIG_VERSION:
                    self.logger.info(f"配置版本不匹配: {self.config.get('version')} -> {self.CONFIG_VERSION}")
                    self.config = self._migrate_config(self.config)
                
                self.logger.info(f"配置文件加载成功: {self.config_file}")
                
            elif create_default:
                # 创建默认配置
                self.logger.info("配置文件不存在，创建默认配置")
                self.config = self.create_default_config()
                self.save_config()
            else:
                raise FileNotFoundError(f"配置文件不存在: {self.config_file}")
            
            return self.config
            
        except Exception as e:
            self.logger.error(f"加载配置文件失败: {e}")
            if create_default:
                self.config = self.create_default_config()
                return self.config
            else:
                raise
    
    def save_config(self, backup: bool = True) -> bool:
        """
        保存配置文件
        
        Args:
            backup: 是否创建备份
            
        Returns:
            是否保存成功
        """
        try:
            if self.config is None:
                self.logger.error("没有配置数据可保存")
                return False
            
            # 创建备份
            if backup and self.config_file.exists():
                self._create_backup()
            
            # 更新版本
            self.config['version'] = self.CONFIG_VERSION
            self.config['last_modified'] = datetime.now().isoformat()
            
            # 验证配置
            if not self.validate_config(self.config):
                self.logger.error("配置验证失败，无法保存")
                return False
            
            # 保存配置文件
            with open(self.config_file, 'w', encoding='utf-8') as f:
                json.dump(self.config, f, indent=2, ensure_ascii=False)
            
            # 计算新哈希
            new_hash = self._calculate_config_hash(self.config)
            
            # 记录配置历史
            if new_hash != self.config_hash:
                self._record_config_change(self.config_hash, new_hash)
                self.config_hash = new_hash
            
            self.logger.info(f"配置文件保存成功: {self.config_file}")
            return True
            
        except Exception as e:
            self.logger.error(f"保存配置文件失败: {e}")
            return False
    
    def create_default_config(self) -> Dict[str, Any]:
        """创建默认配置"""
        default_config = {
            "version": self.CONFIG_VERSION,
            "description": "石器时代验证码识别工具 - 默认配置",
            
            "game": {
                "window_title": "石器时代",
                "window_class": "",
                "exe_path": "",
                "captcha_area": {
                    "x": 100,
                    "y": 200,
                    "width": 200,
                    "height": 80,
                    "auto_detect": True
                },
                "input_area": {
                    "x": 150,
                    "y": 300,
                    "width": 100,
                    "height": 30
                },
                "check_interval": 5,
                "auto_input": True,
                "retry_count": 3
            },
            
            "ocr": {
                "primary_engine": "tesseract",
                "fallback_engines": ["easyocr", "paddleocr"],
                "language": "eng",
                "character_whitelist": "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789",
                "confidence_threshold": 0.7,
                
                "preprocessing": {
                    "enabled": True,
                    "grayscale": True,
                    "threshold": True,
                    "denoise": True,
                    "morphology": True,
                    "resize": [200, 80]
                },
                
                "tesseract": {
                    "path": "",
                    "data_path": "",
                    "config": "--psm 8 --oem 3"
                },
                
                "easyocr": {
                    "gpu": False,
                    "model_storage_directory": "./data/models/easyocr"
                }
            },
            
            "users": [
                {
                    "id": 1,
                    "username": "default_user",
                    "game_account": "",
                    "enabled": True,
                    "created_at": datetime.now().strftime("%Y-%m-%d"),
                    "last_used": "",
                    "statistics": {
                        "total_captchas": 0,
                        "successful": 0,
                        "failed": 0,
                        "accuracy": 0.0,
                        "total_time": 0.0
                    }
                }
            ],
            
            "system": {
                "log_level": "INFO",
                "log_file": "./data/logs/stonecaptcha.log",
                "max_log_size": 10485760,
                "max_log_files": 10,
                
                "auto_update": True,
                "update_channel": "stable",
                "check_update_interval": 86400,
                
                "start_minimized": False,
                "minimize_to_tray": True,
                "close_to_tray": True,
                
                "performance": {
                    "max_threads": 4,
                    "cache_size": 100,
                    "cleanup_interval": 3600
                }
            },
            
            "user_interface": {
                "theme": "dark",
                "language": "zh_CN",
                "font_family": "Microsoft YaHei",
                "font_size": 12,
                
                "window": {
                    "width": 800,
                    "height": 600,
                    "maximized": False,
                    "position": "center"
                },
                
                "notifications": {
                    "enabled": True,
                    "sound": True,
                    "duration": 3000
                }
            },
            
            "advanced": {
                "debug_mode": False,
                "developer_mode": False,
                "experimental_features": False,
                
                "captcha_database": {
                    "enabled": True,
                    "auto_collect": True,
                    "auto_train": False,
                    "storage_path": "./data/captcha_database"
                },
                
                "machine_learning": {
                    "enabled": False,
                    "model_path": "./data/models/ml",
                    "training_interval": 604800,
                    "min_samples": 1000
                }
            }
        }
        
        return default_config
    
    def validate_config(self, config: Dict[str, Any]) -> bool:
        """
        验证配置是否符合架构
        
        Args:
            config: 配置字典
            
        Returns:
            是否验证通过
        """
        try:
            # 简化验证：检查必需字段
            required_fields = ["version", "game", "ocr", "system"]
            for field in required_fields:
                if field not in config:
                    self.logger.error(f"缺少必需字段: {field}")
                    return False
            
            # 检查游戏配置
            game_fields = ["window_title", "check_interval"]
            for field in game_fields:
                if field not in config["game"]:
                    self.logger.error(f"游戏配置缺少字段: {field}")
                    return False
            
            # 检查OCR配置
            if "primary_engine" not in config["ocr"]:
                self.logger.error("OCR配置缺少primary_engine字段")
                return False
            
            # 检查系统配置
            if "log_level" not in config["system"]:
                self.logger.error("系统配置缺少log_level字段")
                return False
            
            return True
            
        except Exception as e:
            self.logger.error(f"配置验证失败: {e}")
            return False
    
    def _fix_config(self, config: Dict[str, Any]) -> Dict[str, Any]:
        """
        修复配置中的问题
        
        Args:
            config: 需要修复的配置
            
        Returns:
            修复后的配置
        """
        try:
            fixed_config = config.copy()
            
            # 确保版本字段存在
            if "version" not in fixed_config:
                fixed_config["version"] = self.CONFIG_VERSION
            
            # 确保描述字段存在
            if "description" not in fixed_config:
                fixed_config["description"] = "修复后的配置"
            
            # 修复游戏配置
            if "game" not in fixed_config:
                fixed_config["game"] = self.create_default_config()["game"]
            else:
                game_default = self.create_default_config()["game"]
                for key, value in game_default.items():
                    if key not in fixed_config["game"]:
                        fixed_config["game"][key] = value
            
            # 修复OCR配置
            if "ocr" not in fixed_config:
                fixed_config["ocr"] = self.create_default_config()["ocr"]
            else:
                ocr_default = self.create_default_config()["ocr"]
                for key, value in ocr_default.items():
                    if key not in fixed_config["ocr"]:
                        fixed_config["ocr"][key] = value
            
            # 修复系统配置
            if "system" not in fixed_config:
                fixed_config["system"] = self.create_default_config()["system"]
            else:
                system_default = self.create_default_config()["system"]
                for key, value in system_default.items():
                    if key not in fixed_config["system"]:
                        fixed_config["system"][key] = value
            
            self.logger.info("配置修复完成")
            return fixed_config
            
        except Exception as e:
            self.logger.error(f"配置修复失败: {e}")
            return config
    
    def _migrate_config(self, config: Dict[str, Any]) -> Dict[str, Any]:
        """
        迁移旧版本配置到新版本
        
        Args:
            config: 旧版本配置
            
        Returns:
            迁移后的配置
        """
        try:
            migrated_config = config.copy()
            old_version = config.get("version", "0.0.0")
            
            self.logger.info(f"开始配置迁移: {old_version} -> {self.CONFIG_VERSION}")
            
            # 版本迁移逻辑
            if old_version == "0.0.0" or old_version.startswith("0."):
                # 从0.x版本迁移到1.0.0
                migrated_config["version"] = self.CONFIG_VERSION
                
                # 添加缺失的字段
                default_config = self.create_default_config()
                
                # 确保所有必需字段都存在
                for section in ["game", "ocr", "system"]:
                    if section not in migrated_config:
                        migrated_config[section] = default_config[section]
                    else:
                        for key, value in default_config[section].items():
                            if key not in migrated_config[section]:
                                migrated_config[section][key] = value
                
                # 添加用户界面配置（如果不存在）
                if "user_interface" not in migrated_config:
                    migrated_config["user_interface"] = default_config["user_interface"]
                
                # 添加高级配置（如果不存在）
                if "advanced" not in migrated_config:
                    migrated_config["advanced"] = default_config["advanced"]
            
            self.logger.info(f"配置迁移完成: {old_version} -> {migrated_config['version']}")
            return migrated_config
            
        except Exception as e:
            self.logger.error(f"配置迁移失败: {e}")
            return config
    
    def _calculate_config_hash(self, config: Dict[str, Any]) -> str:
        """
        计算配置的哈希值
        
        Args:
            config: 配置字典
            
        Returns:
            配置哈希值
        """
        try:
            # 创建配置的字符串表示（排除时间相关字段）
            config_copy = config.copy()
            
            # 移除可能变化的字段
            for field in ["last_modified", "last_used"]:
                if field in config_copy:
                    del config_copy[field]
            
            # 移除用户统计中的时间字段
            if "users" in config_copy:
                for user in config_copy["users"]:
                    if "last_used" in user:
                        user["last_used"] = ""
            
            # 计算哈希
            config_str = json.dumps(config_copy, sort_keys=True)
            return hashlib.md5(config_str.encode()).hexdigest()
            
        except Exception as e:
            self.logger.error(f"计算配置哈希失败: {e}")
            return ""
    
    def _create_backup(self) -> bool:
        """
        创建配置文件备份
        
        Returns:
            是否备份成功
        """
        try:
            if not self.config_file.exists():
                return False
            
            # 创建备份文件名（带时间戳）
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            backup_file = self.backup_dir / f"config_backup_{timestamp}.json"
            
            # 复制配置文件
            shutil.copy2(self.config_file, backup_file)
            
            # 限制备份文件数量（最多保留10个）
            backup_files = sorted(self.backup_dir.glob("config_backup_*.json"))
            if len(backup_files) > 10:
                for old_backup in backup_files[:-10]:
                    old_backup.unlink()
            
            self.logger.info(f"配置文件备份创建成功: {backup_file}")
            return True
            
        except Exception as e:
            self.logger.error(f"创建备份失败: {e}")
            return False
    
    def _load_history(self) -> List[Dict[str, Any]]:
        """
        加载配置历史
        
        Returns:
            配置历史列表
        """
        try:
            if self.history_file.exists():
                with open(self.history_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            else:
                return []
        except Exception as e:
            self.logger.error(f"加载配置历史失败: {e}")
            return []
    
    def _record_config_change(self, old_hash: str, new_hash: str) -> None:
        """
        记录配置变更
        
        Args:
            old_hash: 旧配置哈希
            new_hash: 新配置哈希
        """
        try:
            change_record = {
                "timestamp": datetime.now().isoformat(),
                "old_hash": old_hash,
                "new_hash": new_hash,
                "description": "配置变更"
            }
            
            self.history.append(change_record)
            
            # 限制历史记录数量（最多保留50条）
            if len(self.history) > 50:
                self.history = self.history[-50:]
            
            # 保存历史记录
            with open(self.history_file, 'w', encoding='utf-8') as f:
                json.dump(self.history, f, indent=2, ensure_ascii=False)
            
            self.logger.info("配置变更已记录")
            
        except Exception as e:
            self.logger.error(f"记录配置变更失败: {e}")
    
    def export_config(self, export_path: str) -> bool:
        """
        导出配置到文件
        
        Args:
            export_path: 导出文件路径
            
        Returns:
            是否导出成功
        """
        try:
            if self.config is None:
                self.logger.error("没有配置数据可导出")
                return False
            
            export_file = Path(export_path)
            export_file.parent.mkdir(parents=True, exist_ok=True)
            
            with open(export_file, 'w', encoding='utf-8') as f:
                json.dump(self.config, f, indent=2, ensure_ascii=False)
            
            self.logger.info(f"配置导出成功: {export_file}")
            return True
            
        except Exception as e:
            self.logger.error(f"配置导出失败: {e}")
            return False
    
    def import_config(self, import_path: str) -> bool:
        """
        从文件导入配置
        
        Args:
            import_path: 导入文件路径
            
        Returns:
            是否导入成功
        """
        try:
            import_file = Path(import_path)
            if not import_file.exists():
                self.logger.error(f"导入文件不存在: {import_file}")
                return False
            
            with open(import_file, 'r', encoding='utf-8') as f:
                imported_config = json.load(f)
            
            # 验证导入的配置
            if not self.validate_config(imported_config):
                self.logger.error("导入的配置验证失败")
                return False
            
            # 更新当前配置
            self.config = imported_config
            
            # 保存配置
            if self.save_config():
                self.logger.info(f"配置导入成功: {import_file}")
                return True
            else:
                self.logger.error("导入的配置保存失败")
                return False
            
        except Exception as e:
            self.logger.error(f"配置导入失败: {e}")
            return False
    
    def reset_to_default(self) -> bool:
        """
        重置为默认配置
        
        Returns:
            是否重置成功
        """
        try:
            self.config = self.create_default_config()
            return self.save_config()
            
        except Exception as e:
            self.logger.error(f"重置配置失败: {e}")
            return False
    
    def get_config_summary(self) -> Dict[str, Any]:
        """
        获取配置摘要
        
        Returns:
            配置摘要信息
        """
        try:
            if self.config is None:
                return {"error": "配置未加载"}
            
            summary = {
                "version": self.config.get("version", "未知"),
                "description": self.config.get("description", ""),
                "game_window": self.config.get("game", {}).get("window_title", "未知"),
                "ocr_engine": self.config.get("ocr", {}).get("primary_engine", "未知"),
                "user_count": len(self.config.get("users", [])),
                "last_modified": self.config.get("last_modified", ""),
                "config_hash": self.config_hash
            }
            
            return summary
            
        except Exception as e:
            self.logger.error(f"获取配置摘要失败: {e}")
            return {"error": str(e)}
    
    def get_config_history(self, limit: int = 10) -> List[Dict[str, Any]]:
        """
        获取配置历史记录
        
        Args:
            limit: 返回的历史记录数量限制
            
        Returns:
            配置历史记录列表
        """
        try:
            return self.history[-limit:] if limit > 0 else self.history
        except Exception as e:
            self.logger.error(f"获取配置历史失败: {e}")
            return []
    
    def restore_backup(self, backup_file: str) -> bool:
        """
        从备份恢复配置
        
        Args:
            backup_file: 备份文件路径
            
        Returns:
            是否恢复成功
        """
        try:
            backup_path = Path(backup_file)
            if not backup_path.exists():
                self.logger.error(f"备份文件不存在: {backup_path}")
                return False
            
            # 读取备份配置
            with open(backup_path, 'r', encoding='utf-8') as f:
                backup_config = json.load(f)
            
            # 验证备份配置
            if not self.validate_config(backup_config):
                self.logger.error("备份配置验证失败")
                return False
            
            # 创建当前配置的备份
            self._create_backup()
            
            # 恢复配置
            self.config = backup_config
            return self.save_config(backup=False)
            
        except Exception as e:
            self.logger.error(f"恢复备份失败: {e}")
            return False
    
    def add_user(self, username: str, game_account: str = "") -> bool:
        """
        添加新用户
        
        Args:
            username: 用户名
            game_account: 游戏账号
            
        Returns:
            是否添加成功
        """
        try:
            if self.config is None:
                self.logger.error("配置未加载")
                return False
            
            # 获取下一个用户ID
            user_ids = [user["id"] for user in self.config.get("users", [])]
            next_id = max(user_ids) + 1 if user_ids else 1
            
            # 创建新用户
            new_user = {
                "id": next_id,
                "username": username,
                "game_account": game_account,
                "enabled": True,
                "created_at": datetime.now().strftime("%Y-%m-%d"),
                "last_used": "",
                "statistics": {
                    "total_captchas": 0,
                    "successful": 0,
                    "failed": 0,
                    "accuracy": 0.0,
                    "total_time": 0.0
                }
            }
            
            # 添加用户
            if "users" not in self.config:
                self.config["users"] = []
            
            self.config["users"].append(new_user)
            
            # 保存配置
            if self.save_config():
                self.logger.info(f"用户添加成功: {username} (ID: {next_id})")
                return True
            else:
                self.logger.error("用户添加失败：配置保存失败")
                return False
            
        except Exception as e:
            self.logger.error(f"添加用户失败: {e}")
            return False
    
    def remove_user(self, user_id: int) -> bool:
        """
        移除用户
        
        Args:
            user_id: 用户ID
            
        Returns:
            是否移除成功
        """
        try:
            if self.config is None:
                self.logger.error("配置未加载")
                return False
            
            # 查找用户
            users = self.config.get("users", [])
            user_index = next((i for i, user in enumerate(users) if user["id"] == user_id), -1)
            
            if user_index == -1:
                self.logger.error(f"用户不存在: ID={user_id}")
                return False
            
            # 移除用户
            removed_user = users.pop(user_index)
            self.config["users"] = users
            
            # 保存配置
            if self.save_config():
                self.logger.info(f"用户移除成功: {removed_user['username']} (ID: {user_id})")
                return True
            else:
                self.logger.error("用户移除失败：配置保存失败")
                return False
            
        except Exception as e:
            self.logger.error(f"移除用户失败: {e}")
            return False
    
    def update_user_statistics(self, user_id: int, successful: bool, processing_time: float) -> bool:
        """
        更新用户统计信息
        
        Args:
            user_id: 用户ID
            successful: 是否成功识别
            processing_time: 处理时间（秒）
            
        Returns:
            是否更新成功
        """
        try:
            if self.config is None:
                self.logger.error("配置未加载")
                return False
            
            # 查找用户
            users = self.config.get("users", [])
            user = next((u for u in users if u["id"] == user_id), None)
            
            if user is None:
                self.logger.error(f"用户不存在: ID={user_id}")
                return False
            
            # 更新统计信息
            stats = user["statistics"]
            stats["total_captchas"] += 1
            stats["total_time"] += processing_time
            
            if successful:
                stats["successful"] += 1
            else:
                stats["failed"] += 1
            
            # 计算准确率
            if stats["total_captchas"] > 0:
                stats["accuracy"] = stats["successful"] / stats["total_captchas"]
            
            # 更新最后使用时间
            user["last_used"] = datetime.now().isoformat()
            
            # 保存配置
            if self.save_config():
                self.logger.debug(f"用户统计更新成功: ID={user_id}")
                return True
            else:
                self.logger.error("用户统计更新失败：配置保存失败")
                return False
            
        except Exception as e:
            self.logger.error(f"更新用户统计失败: {e}")
            return False
    
    def get_user_by_id(self, user_id: int) -> Optional[Dict[str, Any]]:
        """
        根据ID获取用户信息
        
        Args:
            user_id: 用户ID
            
        Returns:
            用户信息字典，如果不存在则返回None
        """
        try:
            if self.config is None:
                return None
            
            users = self.config.get("users", [])
            return next((user for user in users if user["id"] == user_id), None)
            
        except Exception as e:
            self.logger.error(f"获取用户信息失败: {e}")
            return None
    
    def get_enabled_users(self) -> List[Dict[str, Any]]:
        """
        获取所有启用的用户
        
        Returns:
            启用的用户列表
        """
        try:
            if self.config is None:
                return []
            
            users = self.config.get("users", [])
            return [user for user in users if user.get("enabled", False)]
            
        except Exception as e:
            self.logger.error(f"获取启用用户失败: {e}")
            return []


# 测试代码
if __name__ == "__main__":
    import sys
    
    # 设置日志
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    print("=== 高级配置管理器测试 ===")
    
    # 创建配置管理器实例
    config_manager = AdvancedConfigManager()
    
    # 测试1: 加载配置
    print("\n1. 加载配置...")
    config = config_manager.load_config()
    print(f"   配置加载成功，版本: {config.get('version')}")
    
    # 测试2: 获取配置摘要
    print("\n2. 获取配置摘要...")
    summary = config_manager.get_config_summary()
    print(f"   配置摘要: {summary}")
    
    # 测试3: 添加新用户
    print("\n3. 添加新用户...")
    if config_manager.add_user("test_user", "test_account"):
        print("   用户添加成功")
    else:
        print("   用户添加失败")
    
    # 测试4: 获取启用用户
    print("\n4. 获取启用用户...")
    enabled_users = config_manager.get_enabled_users()
    print(f"   启用用户数量: {len(enabled_users)}")
    
    # 测试5: 导出配置
    print("\n5. 导出配置...")
    export_path = "/tmp/test_config_export.json"
    if config_manager.export_config(export_path):
        print(f"   配置导出成功: {export_path}")
    else:
        print("   配置导出失败")
    
    # 测试6: 重置配置
    print("\n6. 重置为默认配置...")
    if config_manager.reset_to_default():
        print("   配置重置成功")
    else:
        print("   配置重置失败")
    
    # 测试7: 获取配置历史
    print("\n7. 获取配置历史...")
    history = config_manager.get_config_history(5)
    print(f"   最近配置变更记录: {len(history)} 条")
    
    print("\n=== 测试完成 ===")
    print("高级配置管理器功能完整，可以正常使用。")
