#!/usr/bin/env python3
"""
石器时代知识库构建器
从已有的脚本文件中提取关键信息，构建结构化知识库
"""

import os
import re
import json
import time
from pathlib import Path

class StoneAgeKnowledgeBuilder:
    def __init__(self):
        self.workspace_dir = "/root/.openclaw/workspace"
        self.knowledge_dir = os.path.join(self.workspace_dir, "石器时代知识库")
        self.ensure_directories()
        
        # 数据存储
        self.knowledge_base = {
            "metadata": {
                "name": "石器时代游戏知识库",
                "version": "1.0.0",
                "created_at": time.strftime("%Y-%m-%d %H:%M:%S"),
                "description": "从脚本文件中提取的石器时代游戏知识"
            },
            "maps": [],      # 地图信息
            "npcs": [],      # NPC信息
            "pets": [],      # 宠物信息
            "coordinates": [], # 坐标信息
            "items": [],     # 物品信息
            "skills": [],    # 技能信息
            "scripts": []    # 脚本信息
        }
    
    def ensure_directories(self):
        """确保目录结构存在"""
        directories = [
            self.knowledge_dir,
            os.path.join(self.knowledge_dir, "原始脚本"),
            os.path.join(self.knowledge_dir, "分析结果"),
            os.path.join(self.knowledge_dir, "知识图谱"),
        ]
        
        for directory in directories:
            os.makedirs(directory, exist_ok=True)
            print(f"✅ 目录已创建: {directory}")
    
    def find_script_files(self):
        """查找所有石器时代脚本文件"""
        script_files = []
        
        # 搜索.asc文件
        for root, dirs, files in os.walk(self.workspace_dir):
            for file in files:
                if file.endswith('.asc'):
                    script_files.append(os.path.join(root, file))
                elif '石器' in file or '脚本' in file:
                    script_files.append(os.path.join(root, file))
        
        print(f"📁 找到 {len(script_files)} 个脚本文件")
        return script_files
    
    def analyze_script_file(self, filepath):
        """分析单个脚本文件"""
        print(f"🔍 分析文件: {os.path.basename(filepath)}")
        
        try:
            with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
            
            # 复制到知识库
            filename = os.path.basename(filepath)
            dest_path = os.path.join(self.knowledge_dir, "原始脚本", filename)
            with open(dest_path, 'w', encoding='utf-8') as f:
                f.write(content)
            
            # 提取信息
            extracted = {
                "file": filename,
                "size": len(content),
                "lines": content.count('\n') + 1,
                "maps": self.extract_maps(content),
                "npcs": self.extract_npcs(content),
                "pets": self.extract_pets(content),
                "coordinates": self.extract_coordinates(content),
                "items": self.extract_items(content),
                "commands": self.extract_commands(content)
            }
            
            return extracted
            
        except Exception as e:
            print(f"❌ 分析文件失败 {filepath}: {e}")
            return None
    
    def extract_maps(self, content):
        """提取地图信息"""
        maps = []
        
        # 地图ID模式
        patterns = [
            r'map\s*[=:]\s*(\d+)',  # map=1001
            r'地图\s*[=:]\s*(\d+)',  # 地图=1001
            r'(\d{3,4})\s*地图',     # 1001地图
            r'地图(\d{3,4})',        # 地图1001
        ]
        
        for pattern in patterns:
            matches = re.findall(pattern, content, re.IGNORECASE)
            for match in matches:
                if match not in maps:
                    maps.append(match)
        
        return maps
    
    def extract_npcs(self, content):
        """提取NPC信息"""
        npcs = []
        
        # NPC名称模式
        patterns = [
            r'NPC\s*[=:]\s*([^\s\n,;]{2,20})',  # NPC=村长
            r'对话\s*[=:]\s*([^\s\n,;]{2,20})',  # 对话=村长
            r'找\s*([^\s\n,;]{2,20})\s*NPC',    # 找村长NPC
            r'([^\s\n,;]{2,20})\s*NPC',         # 村长NPC
        ]
        
        for pattern in patterns:
            matches = re.findall(pattern, content, re.IGNORECASE)
            for match in matches:
                if match not in npcs and len(match) > 1:
                    npcs.append(match)
        
        return npcs
    
    def extract_pets(self, content):
        """提取宠物信息"""
        pets = []
        
        # 宠物名称模式
        patterns = [
            r'宠物\s*[=:]\s*([^\s\n,;]{2,20})',  # 宠物=雷龙
            r'宠\s*[=:]\s*([^\s\n,;]{2,20})',    # 宠=雷龙
            r'([^\s\n,;]{2,20})\s*宠',           # 雷龙宠
            r'培养\s*([^\s\n,;]{2,20})',         # 培养雷龙
        ]
        
        for pattern in patterns:
            matches = re.findall(pattern, content, re.IGNORECASE)
            for match in matches:
                if match not in pets and len(match) > 1:
                    pets.append(match)
        
        return pets
    
    def extract_coordinates(self, content):
        """提取坐标信息"""
        coordinates = []
        
        # 坐标模式
        patterns = [
            r'坐标\s*[=:]\s*(\d+)[,\s]+(\d+)',  # 坐标=100,200
            r'\((\d+)[,\s]+(\d+)\)',           # (100,200)
            r'(\d+)[,\s]+(\d+)\s*坐标',        # 100,200坐标
            r'走到\s*(\d+)[,\s]+(\d+)',        # 走到100,200
            r'移动到\s*(\d+)[,\s]+(\d+)',      # 移动到100,200
        ]
        
        for pattern in patterns:
            matches = re.findall(pattern, content)
            for match in matches:
                if len(match) == 2:
                    coord = f"{match[0]},{match[1]}"
                    if coord not in coordinates:
                        coordinates.append(coord)
        
        return coordinates
    
    def extract_items(self, content):
        """提取物品信息"""
        items = []
        
        # 物品名称模式
        patterns = [
            r'物品\s*[=:]\s*([^\s\n,;]{2,20})',  # 物品=石头
            r'道具\s*[=:]\s*([^\s\n,;]{2,20})',  # 道具=石头
            r'获得\s*([^\s\n,;]{2,20})',         # 获得石头
            r'使用\s*([^\s\n,;]{2,20})',         # 使用石头
        ]
        
        for pattern in patterns:
            matches = re.findall(pattern, content, re.IGNORECASE)
            for match in matches:
                if match not in items and len(match) > 1:
                    items.append(match)
        
        return items
    
    def extract_commands(self, content):
        """提取ASSA命令"""
        commands = []
        
        # ASSA命令模式
        patterns = [
            r'let\s+@[^\s=]+\s*=',          # let @变量=
            r'waitmap\s+[^\s\n]+',          # waitmap 地图
            r'walk\s+[^\s\n]+',             # walk 坐标
            r'say\s+[^\s\n]+',              # say 文本
            r'button\s+[^\s\n]+',           # button 按钮
            r'dlg\s+[^\s\n]+',              # dlg 对话框
        ]
        
        for pattern in patterns:
            matches = re.findall(pattern, content, re.IGNORECASE)
            for match in matches:
                if match not in commands:
                    commands.append(match.strip())
        
        return commands
    
    def build_knowledge_base(self):
        """构建知识库"""
        print("="*60)
        print("🧠 开始构建石器时代知识库")
        print("="*60)
        
        # 查找脚本文件
        script_files = self.find_script_files()
        
        all_analysis = []
        
        for filepath in script_files:
            analysis = self.analyze_script_file(filepath)
            if analysis:
                all_analysis.append(analysis)
                
                # 合并到知识库
                self.knowledge_base["maps"].extend(analysis["maps"])
                self.knowledge_base["npcs"].extend(analysis["npcs"])
                self.knowledge_base["pets"].extend(analysis["pets"])
                self.knowledge_base["coordinates"].extend(analysis["coordinates"])
                self.knowledge_base["items"].extend(analysis["items"])
                
                # 添加脚本信息
                script_info = {
                    "name": analysis["file"],
                    "size": analysis["size"],
                    "lines": analysis["lines"],
                    "commands_count": len(analysis["commands"]),
                    "commands_sample": analysis["commands"][:5] if analysis["commands"] else []
                }
                self.knowledge_base["scripts"].append(script_info)
        
        # 去重
        for key in ["maps", "npcs", "pets", "coordinates", "items"]:
            self.knowledge_base[key] = list(set(self.knowledge_base[key]))
        
        # 保存知识库
        self.save_knowledge_base()
        
        # 生成分析报告
        self.generate_analysis_report(all_analysis)
        
        # 创建知识图谱
        self.create_knowledge_graph()
        
        return self.knowledge_base
    
    def save_knowledge_base(self):
        """保存知识库到文件"""
        # JSON格式
        json_file = os.path.join(self.knowledge_dir, "知识库.json")
        with open(json_file, 'w', encoding='utf-8') as f:
            json.dump(self.knowledge_base, f, ensure_ascii=False, indent=2)
        
        # Markdown格式
        md_file = os.path.join(self.knowledge_dir, "知识库.md")
        with open(md_file, 'w', encoding='utf-8') as f:
            f.write("# 石器时代游戏知识库\n\n")
            f.write(f"**生成时间**: {self.knowledge_base['metadata']['created_at']}\n\n")
            
            f.write("## 数据统计\n\n")
            f.write(f"- **地图数量**: {len(self.knowledge_base['maps'])}\n")
            f.write(f"- **NPC数量**: {len(self.knowledge_base['npcs'])}\n")
            f.write(f"- **宠物数量**: {len(self.knowledge_base['pets'])}\n")
            f.write(f"- **坐标数量**: {len(self.knowledge_base['coordinates'])}\n")
            f.write(f"- **物品数量**: {len(self.knowledge_base['items'])}\n")
            f.write(f"- **脚本数量**: {len(self.knowledge_base['scripts'])}\n\n")
            
            f.write("## 地图列表\n\n")
            for i, map_id in enumerate(sorted(self.knowledge_base['maps']), 1):
                f.write(f"{i}. 地图ID: {map_id}\n")
            
            f.write("\n## NPC列表\n\n")
            for i, npc in enumerate(sorted(self.knowledge_base['npcs']), 1):
                f.write(f"{i}. {npc}\n")
            
            f.write("\n## 宠物列表\n\n")
            for i, pet in enumerate(sorted(self.knowledge_base['pets']), 1):
                f.write(f"{i}. {pet}\n")
            
            f.write("\n## 坐标列表\n\n")
            for i, coord in enumerate(sorted(self.knowledge_base['coordinates']), 1):
                f.write(f"{i}. {coord}\n")
            
            f.write("\n## 物品列表\n\n")
            for i, item in enumerate(sorted(self.knowledge_base['items']), 1):
                f.write(f"{i}. {item}\n")
            
            f.write("\n## 脚本列表\n\n")
            for i, script in enumerate(self.knowledge_base['scripts'], 1):
                f.write(f"{i}. **{script['name']}**\n")
                f.write(f"   - 大小: {script['size']} 字节\n")
                f.write(f"   - 行数: {script['lines']} 行\n")
                f.write(f"   - 命令数: {script['commands_count']} 个\n")
                if script['commands_sample']:
                    f.write(f"   - 命令示例: {', '.join(script['commands_sample'])}\n")
        
        print(f"✅ 知识库已保存:")
        print(f"   📄 JSON格式: {json_file}")
        print(f"   📄 Markdown格式: {md_file}")
    
    def generate_analysis_report(self, all_analysis):
        """生成分析报告"""
        report_file = os.path.join(self.knowledge_dir, "分析结果", "脚本分析报告.md")
        
        with open(report_file, 'w', encoding='utf-8') as f:
            f.write("# 石器时代脚本分析报告\n\n")
            f.write(f"**分析时间**: {time.strftime('%Y-%m-%d %H:%M:%S')}\n")
            f.write(f"**分析文件数**: {len(all_analysis)}\n\n")
            
            f.write("## 文件分析详情\n\n")
            
            total_size = 0
            total_lines = 0
            
            for analysis in all_analysis:
                f.write(f"### {analysis['file']}\n")
                f.write(f"- **大小**: {analysis['size']} 字节\n")
                f.write(f"- **行数**: {analysis['lines']} 行\n")
                
                total_size += analysis['size']
                total_lines += analysis['lines']
                
                # 各类型数据统计
                f.write(f"- **地图ID**: {len(analysis['maps'])} 个\n")
                if analysis['maps']:
                    f.write(f"  - {', '.join(analysis['maps'][:10])}")
                    if len(analysis['maps']) > 10:
                        f.write(f" ... 等 {len(analysis['maps'])} 个")
                    f.write("\n")
                
                f.write(f"- **NPC**: {len(analysis['npcs'])} 个\n")
                if analysis['npcs']:
                    f.write(f"  - {', '.join(analysis['npcs'][:10])}")
                    if len(analysis['npcs']) > 10:
                        f.write(f" ... 等 {len(analysis['npcs'])} 个")
                    f.write("\n")
                
                f.write(f"- **宠物**: {len(analysis['pets'])} 个\n")
                if analysis['pets']:
                    f.write(f"  - {', '.join(analysis['pets'][:10])}")
                    if len(analysis['pets']) > 10:
                        f.write(f" ... 等 {len(analysis['pets'])} 个")
                    f.write("\n")
                
                f.write(f"- **坐标**: {len(analysis['coordinates'])} 个\n")
                if analysis['coordinates']:
                    f.write(f"  - {', '.join(analysis['coordinates'][:10])}")
                    if len(analysis['coordinates']) > 10:
                        f.write(f" ... 等 {len(analysis['coordinates'])} 个")
                    f.write("\n")
                
                f.write(f"- **物品**: {len(analysis['items'])} 个\n")
                if analysis['items']:
                    f.write(f"  - {', '.join(analysis['items'][:10])}")
                    if len(analysis['items']) > 10:
                        f.write(f" ... 等 {len(analysis['items'])} 个")
                    f.write("\n")
                
                f.write(f"- **命令**: {len(analysis['commands'])} 个\n")
                if analysis['commands']:
                    f.write(f"  - 示例: {analysis['commands'][0]}\n")
                
                f.write("\n")
            
            f.write("## 总体统计\n\n")
            f.write(f"- **总文件数**: {len(all_analysis)}\n")
            f.write(f"- **总大小**: {total_size} 字节 ({total_size/1024:.1f} KB)\n")
            f.write(f"- **总行数**: {total_lines} 行\n")
            f.write(f"- **平均文件大小**: {total_size/len(all_analysis):.0f} 字节\n")
            f.write(f"- **平均行数**: {total_lines/len(all_analysis):.0f} 行\n")
        
        print(f"📊 分析报告已生成: {report_file}")
    
    def create_knowledge_graph(self):
        """创建知识图谱"""
        graph_file = os.path.join(self.knowledge_dir,    def create_knowledge_graph(self):
        """创建知识图谱"""
        graph_file = os.path.join(self.knowledge_dir, "知识图谱", "知识图谱.md")
        
        with open(graph_file, 'w', encoding='utf-8') as f:
            f.write("# 石器时代知识图谱\n\n")
            f.write(f"**生成时间**: {time.strftime('%Y-%m-%d %H:%M:%S')}\n\n")
            
            f.write("## 知识图谱结构\n\n")
            f.write("```mermaid\n")
            f.write("graph TD\n")
            
            # 添加节点
            f.write("    A[石器时代游戏]\n")
            
            # 地图节点
            if self.knowledge_base['maps']:
                f.write("    A --> B[地图系统]\n")
                for i, map_id in enumerate(self.knowledge_base['maps'][:5], 1):  # 只显示前5个
                    f.write(f"    B --> B{i}[地图{map_id}]\n")
                if len(self.knowledge_base['maps']) > 5:
                    f.write(f"    B --> B更多[等{len(self.knowledge_base['maps'])-5}个地图]\n")
            
            # NPC节点
            if self.knowledge_base['npcs']:
                f.write("    A --> C[NPC系统]\n")
                for i, npc in enumerate(self.knowledge_base['npcs'][:5], 1):
                    f.write(f"    C --> C{i}[{npc}]\n")
                if len(self.knowledge_base['npcs']) > 5:
                    f.write(f"    C --> C更多[等{len(self.knowledge_base['npcs'])-5}个NPC]\n")
            
            # 宠物节点
            if self.knowledge_base['pets']:
                f.write("    A --> D[宠物系统]\n")
                for i, pet in enumerate(self.knowledge_base['pets'][:5], 1):
                    f.write(f"    D --> D{i}[{pet}]\n")
                if len(self.knowledge_base['pets']) > 5:
                    f.write(f"    D --> D更多[等{len(self.knowledge_base['pets'])-5}个宠物]\n")
            
            # 坐标节点
            if self.knowledge_base['coordinates']:
                f.write("    A --> E[坐标系统]\n")
                for i, coord in enumerate(self.knowledge_base['coordinates'][:5], 1):
                    f.write(f"    E --> E{i}[{coord}]\n")
                if len(self.knowledge_base['coordinates']) > 5:
                    f.write(f"    E --> E更多[等{len(self.knowledge_base['coordinates'])-5}个坐标]\n")
            
            # 脚本节点
            if self.knowledge_base['scripts']:
                f.write("    A --> F[脚本系统]\n")
                for i, script in enumerate(self.knowledge_base['scripts'][:5], 1):
                    f.write(f"    F --> F{i}[{script['name']}]\n")
                if len(self.knowledge_base['scripts']) > 5:
                    f.write(f"    F --> F更多[等{len(self.knowledge_base['scripts'])-5}个脚本]\n")
            
            f.write("```\n\n")
            
            f.write("## 知识关系\n\n")
            f.write("### 地图与坐标关系\n")
            if self.knowledge_base['maps'] and self.knowledge_base['coordinates']:
                f.write("地图系统中的每个地图都包含多个坐标点，用于角色移动和NPC定位。\n\n")
            
            f.write("### NPC与脚本关系\n")
            if self.knowledge_base['npcs'] and self.knowledge_base['scripts']:
                f.write("脚本中频繁引用NPC进行对话、任务交接等操作。\n\n")
            
            f.write("### 宠物与培养关系\n")
            if self.knowledge_base['pets']:
                f.write("宠物系统涉及宠物的培养、战斗和进化，是游戏的核心玩法之一。\n\n")
            
            f.write("## 知识应用\n\n")
            f.write("1. **脚本开发**: 基于知识库开发新的游戏脚本\n")
            f.write("2. **游戏攻略**: 制作详细的地图、NPC、宠物攻略\n")
            f.write("3. **数据分析**: 分析游戏机制和玩家行为\n")
            f.write("4. **教学材料**: 制作石器时代脚本开发教程\n")
        
        print(f"🕸️  知识图谱已创建: {graph_file}")
    
    def create_ng25_adapter(self):
        """创建NG25私服适配器"""
        ng25_dir = os.path.join(self.knowledge_dir, "NG25适配")
        os.makedirs(ng25_dir, exist_ok=True)
        
        # 创建名称映射文件
        mapping_file = os.path.join(ng25_dir, "名称映射.json")
        
        # 基于已有知识创建映射
        mapping = {
            "metadata": {
                "name": "NG25私服名称映射",
                "created_at": time.strftime("%Y-%m-%d %H:%M:%S"),
                "description": "官方名称到NG25私服名称的映射"
            },
            "maps": {},
            "npcs": {},
            "pets": {},
            "items": {}
        }
        
        # 为每个地图创建映射
        for map_id in self.knowledge_base['maps']:
            mapping['maps'][map_id] = f"NG25_{map_id}"
        
        # 为每个NPC创建映射
        for npc in self.knowledge_base['npcs']:
            mapping['npcs'][npc] = f"NG25_{npc}"
        
        # 为每个宠物创建映射
        for pet in self.knowledge_base['pets']:
            mapping['pets'][pet] = f"NG25_{pet}"
        
        # 为每个物品创建映射
        for item in self.knowledge_base['items']:
            mapping['items'][item] = f"NG25_{item}"
        
        # 保存映射文件
        with open(mapping_file, 'w', encoding='utf-8') as f:
            json.dump(mapping, f, ensure_ascii=False, indent=2)
        
        # 创建适配器脚本
        adapter_file = os.path.join(ng25_dir, "NG25适配器.py")
        with open(adapter_file, 'w', encoding='utf-8') as f:
            f.write('''#!/usr/bin/env python3
"""
NG25私服适配器
将官方脚本转换为NG25私服可用的脚本
"""

import json
import re
import os

class NG25Adapter:
    def __init__(self, mapping_file="名称映射.json"):
        """初始化适配器"""
        self.mapping_file = mapping_file
        self.load_mappings()
    
    def load_mappings(self):
        """加载名称映射"""
        try:
            with open(self.mapping_file, 'r', encoding='utf-8') as f:
                self.mappings = json.load(f)
            print(f"✅ 已加载 {len(self.mappings.get('maps', {}))} 个地图映射")
            print(f"✅ 已加载 {len(self.mappings.get('npcs', {}))} 个NPC映射")
            print(f"✅ 已加载 {len(self.mappings.get('pets', {}))} 个宠物映射")
            print(f"✅ 已加载 {len(self.mappings.get('items', {}))} 个物品映射")
        except Exception as e:
            print(f"❌ 加载映射文件失败: {e}")
            self.mappings = {}
    
    def adapt_script(self, script_content):
        """适配脚本内容"""
        adapted = script_content
        
        # 替换地图
        for official, ng25 in self.mappings.get('maps', {}).items():
            pattern = rf'\\b{official}\\b'
            adapted = re.sub(pattern, ng25, adapted)
        
        # 替换NPC
        for official, ng25 in self.mappings.get('npcs', {}).items():
            pattern = rf'\\b{official}\\b'
            adapted = re.sub(pattern, ng25, adapted)
        
        # 替换宠物
        for official, ng25 in self.mappings.get('pets', {}).items():
            pattern = rf'\\b{official}\\b'
            adapted = re.sub(pattern, ng25, adapted)
        
        # 替换物品
        for official, ng25 in self.mappings.get('items', {}).items():
            pattern = rf'\\b{official}\\b'
            adapted = re.sub(pattern, ng25, adapted)
        
        return adapted
    
    def adapt_file(self, input_file, output_file=None):
        """适配整个文件"""
        try:
            with open(input_file, 'r', encoding='utf-8') as f:
                content = f.read()
            
            adapted = self.adapt_script(content)
            
            if output_file is None:
                output_file = input_file.replace('.asc', '_NG25.asc')
            
            with open(output_file, 'w', encoding='utf-8') as f:
                f.write(adapted)
            
            print(f"✅ 文件已适配: {input_file} -> {output_file}")
            return True
            
        except Exception as e:
            print(f"❌ 适配文件失败 {input_file}: {e}")
            return False

def main():
    """主函数"""
    print("🔄 NG25私服适配器启动")
    print("="*50)
    
    adapter = NG25Adapter()
    
    # 示例使用
    print("\\n使用方法:")
    print("1. 将官方脚本放在当前目录")
    print("2. 运行: python NG25适配器.py <输入文件> [输出文件]")
    print("3. 适配后的脚本将保存为 *_NG25.asc")
    
    print("\\n已加载的映射:")
    if adapter.mappings:
        for category, items in adapter.mappings.items():
            if category != 'metadata':
                print(f"  {category}: {len(items)} 个映射")

if __name__ == "__main__":
    main()
''')
        
        print(f"🔄 NG25适配器已创建:")
        print(f"   📄 映射文件: {mapping_file}")
        print(f"   📄 适配器脚本: {adapter_file}")
        
        return mapping_file, adapter_file

def main():
    """主函数"""
    print("🚀 石器时代知识库构建器启动")
    print("="*60)
    
    builder = StoneAgeKnowledgeBuilder()
    
    # 构建知识库
    knowledge_base = builder.build_knowledge_base()
    
    # 创建NG25适配器
    mapping_file, adapter_file = builder.create_ng25_adapter()
    
    print("\n" + "="*60)
    print("🎉 知识库构建完成!")
    print("="*60)
    
    # 显示统计信息
    print("📊 知识库统计:")
    print(f"  📍 地图: {len(knowledge_base['maps'])} 个")
    print(f"  👤 NPC: {len(knowledge_base['npcs'])} 个")
    print(f"  🐾 宠物: {len(knowledge_base['pets'])} 个")
    print(f"  📍 坐标: {len(knowledge_base['coordinates'])} 个")
    print(f"  🎒 物品: {len(knowledge_base['items'])} 个")
    print(f"  📜 脚本: {len(knowledge_base['scripts'])} 个")
    
    print("\n📁 生成的文件:")
    print(f"  📄 知识库JSON: {builder.knowledge_dir}/知识库.json")
    print(f"  📄 知识库MD: {builder.knowledge_dir}/知识库.md")
    print(f"  📄 分析报告: {builder.knowledge_dir}/分析结果/脚本分析报告.md")
    print(f"  📄 知识图谱: {builder.knowledge_dir}/知识图谱/知识图谱.md")
    print(f"  📄 NG25映射: {mapping_file}")
    print(f"  📄 NG25适配器: {adapter_file}")
    
    print("\n💡 下一步建议:")
    print("1. 查看知识库文件，了解游戏结构")
    print("2. 使用NG25适配器转换官方脚本")
    print("3. 基于知识库开发新的游戏脚本")
    print("4. 定期更新知识库内容")
    print("5. 将知识库用于脚本开发和教学")

if __name__ == "__main__":
    main()