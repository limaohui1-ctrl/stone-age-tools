"""
进程监控器模块

提供游戏进程的查找、监控和管理功能。
"""

import time
import psutil
from typing import Optional, Dict, Any, List, Tuple
from dataclasses import dataclass, field
from enum import Enum

from ..core.exceptions import (
    ProcessNotFoundError, ProcessNotAccessibleError, ProcessPermissionError
)
from ..core.logger import log_function_call, log_performance
from ..core.config import get_config


class ProcessState(Enum):
    """进程状态枚举"""
    UNKNOWN = "unknown"
    RUNNING = "running"
    SLEEPING = "sleeping"
    DISK_SLEEP = "disk_sleep"
    STOPPED = "stopped"
    TRACING_STOP = "tracing_stop"
    ZOMBIE = "zombie"
    DEAD = "dead"
    WAKE_KILL = "wake_kill"
    WAKING = "waking"
    IDLE = "idle"
    LOCKED = "locked"
    WAITING = "waiting"


@dataclass
class ProcessInfo:
    """进程信息"""
    pid: int
    name: str
    exe_path: str
    cmdline: List[str]
    status: ProcessState
    create_time: float
    cpu_percent: float
    memory_percent: float
    memory_rss: int  # 驻留集大小 (字节)
    memory_vms: int  # 虚拟内存大小 (字节)
    num_threads: int
    num_handles: int
    username: str
    nice: int
    io_counters: Optional[Any] = None
    connections: Optional[List[Any]] = None
    
    @property
    def memory_rss_mb(self) -> float:
        """内存使用量 (MB)"""
        return self.memory_rss / (1024 * 1024)
    
    @property
    def memory_vms_mb(self) -> float:
        """虚拟内存使用量 (MB)"""
        return self.memory_vms / (1024 * 1024)
    
    @property
    def uptime(self) -> float:
        """运行时间 (秒)"""
        return time.time() - self.create_time
    
    @property
    def uptime_formatted(self) -> str:
        """格式化的运行时间"""
        uptime = self.uptime
        hours = int(uptime // 3600)
        minutes = int((uptime % 3600) // 60)
        seconds = int(uptime % 60)
        return f"{hours:02d}:{minutes:02d}:{seconds:02d}"
    
    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return {
            'pid': self.pid,
            'name': self.name,
            'exe_path': self.exe_path,
            'cmdline': self.cmdline,
            'status': self.status.value,
            'create_time': self.create_time,
            'cpu_percent': self.cpu_percent,
            'memory_percent': self.memory_percent,
            'memory_rss': self.memory_rss,
            'memory_rss_mb': self.memory_rss_mb,
            'memory_vms': self.memory_vms,
            'memory_vms_mb': self.memory_vms_mb,
            'num_threads': self.num_threads,
            'num_handles': self.num_handles,
            'username': self.username,
            'nice': self.nice,
            'uptime': self.uptime,
            'uptime_formatted': self.uptime_formatted
        }


class ProcessMonitor:
    """进程监控器"""
    
    def __init__(self, config_path: Optional[str] = None):
        """
        初始化进程监控器
        
        Args:
            config_path: 配置文件路径
        """
        self.config = get_config(config_path)
        self.game_config = self.config.game
        self.monitor_config = self.config.monitor
        self.logger = self.config.logging
        
        # 进程缓存
        self._process_cache: Dict[int, ProcessInfo] = {}
        self._last_found_pid: Optional[int] = None
        
        # 资源监控历史
        self._cpu_history: Dict[int, List[Tuple[float, float]]] = {}  # pid -> [(timestamp, cpu_percent), ...]
        self._memory_history: Dict[int, List[Tuple[float, float]]] = {}  # pid -> [(timestamp, memory_mb), ...]
        
        # 状态跟踪
        self._last_status: Dict[int, ProcessState] = {}
        self._status_changes: List[Tuple[float, int, ProcessState, ProcessState]] = []  # (timestamp, pid, old, new)
    
    @log_function_call("DEBUG")
    @log_performance(0.5)
    def find_game_process(self, process_name: Optional[str] = None,
                         timeout: Optional[float] = None) -> ProcessInfo:
        """
        查找游戏进程
        
        Args:
            process_name: 进程名称，如果为None则使用配置中的名称
            timeout: 超时时间（秒），如果为None则使用配置中的超时
            
        Returns:
            进程信息
            
        Raises:
            ProcessNotFoundError: 未找到进程
        """
        target_name = process_name or self.game_config.process_name
        search_timeout = timeout or self.game_config.window_search_timeout
        
        start_time = time.time()
        retry_interval = self.game_config.window_retry_interval
        
        while time.time() - start_time < search_timeout:
            try:
                # 尝试查找进程
                process_info = self._find_process_by_name(target_name)
                
                if process_info:
                    self._last_found_pid = process_info.pid
                    self._process_cache[process_info.pid] = process_info
                    
                    # 记录进程找到事件
                    self.logger.process_event("found", process_info.to_dict())
                    return process_info
                
                # 未找到，尝试使用模式匹配
                for pattern_name, pattern in self.game_config.process_patterns.items():
                    process_info = self._find_process_by_name(pattern)
                    if process_info:
                        self.logger.info(f"使用模式 '{pattern_name}' 找到进程: {pattern}")
                        self._last_found_pid = process_info.pid
                        self._process_cache[process_info.pid] = process_info
                        
                        self.logger.process_event("found_by_pattern", process_info.to_dict())
                        return process_info
                
                # 未找到，等待后重试
                time.sleep(retry_interval)
            
            except Exception as e:
                self.logger.error(f"查找进程时出错: {e}")
                time.sleep(retry_interval)
        
        # 超时未找到
        error_details = f"进程名: {target_name}, 超时: {search_timeout}秒"
        raise ProcessNotFoundError(target_name, error_details)
    
    def _find_process_by_name(self, process_name: str) -> Optional[ProcessInfo]:
        """根据进程名查找进程"""
        try:
            for proc in psutil.process_iter(['pid', 'name', 'exe', 'cmdline', 'status']):
                try:
                    # 检查进程名匹配
                    if process_name.lower() in proc.info['name'].lower():
                        return self._get_process_info(proc.pid)
                    
                    # 检查可执行文件路径匹配
                    if proc.info['exe'] and process_name.lower() in proc.info['exe'].lower():
                        return self._get_process_info(proc.pid)
                    
                    # 检查命令行参数匹配
                    if proc.info['cmdline']:
                        cmdline_str = ' '.join(proc.info['cmdline']).lower()
                        if process_name.lower() in cmdline_str:
                            return self._get_process_info(proc.pid)
                
                except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                    continue
            
            return None
        
        except Exception as e:
            self.logger.error(f"查找进程失败: {e}")
            return None
    
    @log_function_call("DEBUG")
    def _get_process_info(self, pid: int) -> Optional[ProcessInfo]:
        """获取进程详细信息"""
        try:
            proc = psutil.Process(pid)
            
            # 基本进程信息
            with proc.oneshot():
                name = proc.name()
                exe_path = proc.exe() or ""
                cmdline = proc.cmdline()
                create_time = proc.create_time()
                
                # 进程状态
                status_str = proc.status()
                status = self._parse_process_status(status_str)
                
                # CPU和内存使用
                cpu_percent = proc.cpu_percent(interval=0.1)
                memory_info = proc.memory_info()
                memory_percent = proc.memory_percent()
                
                # 其他信息
                num_threads = proc.num_threads()
                
                try:
                    num_handles = proc.num_handles()
                except (psutil.AccessDenied, AttributeError):
                    num_handles = 0
                
                username = proc.username()
                nice = proc.nice()
                
                # IO计数器（如果可用）
                try:
                    io_counters = proc.io_counters()
                except (psutil.AccessDenied, AttributeError):
                    io_counters = None
                
                # 网络连接（如果可用）
                try:
                    connections = proc.connections()
                except (psutil.AccessDenied, AttributeError):
                    connections = None
            
            # 创建进程信息对象
            process_info = ProcessInfo(
                pid=pid,
                name=name,
                exe_path=exe_path,
                cmdline=cmdline,
                status=status,
                create_time=create_time,
                cpu_percent=cpu_percent,
                memory_percent=memory_percent,
                memory_rss=memory_info.rss,
                memory_vms=memory_info.vms,
                num_threads=num_threads,
                num_handles=num_handles,
                username=username,
                nice=nice,
                io_counters=io_counters,
                connections=connections
            )
            
            return process_info
        
        except psutil.NoSuchProcess:
            self.logger.warning(f"进程不存在 (PID: {pid})")
            return None
        
        except psutil.AccessDenied as e:
            self.logger.error(f"进程访问被拒绝 (PID: {pid}): {e}")
            return None
        
        except Exception as e:
            self.logger.error(f"获取进程信息失败 (PID: {pid}): {e}")
            return None
    
    def _parse_process_status(self, status_str: str) -> ProcessState:
        """解析进程状态字符串"""
        status_map = {
            'running': ProcessState.RUNNING,
            'sleeping': ProcessState.SLEEPING,
            'disk-sleep': ProcessState.DISK_SLEEP,
            'stopped': ProcessState.STOPPED,
            'tracing-stop': ProcessState.TRACING_STOP,
            'zombie': ProcessState.ZOMBIE,
            'dead': ProcessState.DEAD,
            'wake-kill': ProcessState.WAKE_KILL,
            'waking': ProcessState.WAKING,
            'idle': ProcessState.IDLE,
            'locked': ProcessState.LOCKED,
            'waiting': ProcessState.WAITING,
        }
        
        return status_map.get(status_str.lower(), ProcessState.UNKNOWN)
    
    @log_function_call("INFO")
    @log_performance(0.5)
    def monitor_process(self, pid: Optional[int] = None,
                       interval: Optional[float] = None) -> ProcessInfo:
        """
        监控进程状态
        
        Args:
            pid: 进程ID，如果为None则使用最后找到的进程
            interval: 监控间隔
            
        Returns:
            最新的进程信息
            
        Raises:
            ProcessNotFoundError: 进程未找到
        """
        target_pid = pid or self._last_found_pid
        monitor_interval = interval or self.monitor_config.process_monitor_interval
        
        if not target_pid:
            raise ProcessNotFoundError("未指定进程ID且未找到历史进程")
        
        try:
            # 获取进程信息
            process_info = self.get_process_info(target_pid)
            if not process_info:
                raise ProcessNotFoundError(f"进程未找到 (PID: {target_pid})")
            
            # 跟踪状态变化
            current_status = process_info.status
            last_status = self._last_status.get(target_pid)
            
            if last_status and last_status != current_status:
                timestamp = time.time()
                self._status_changes.append((timestamp, target_pid, last_status, current_status))
                
                # 记录状态变化
                self.logger.info(
                    f"进程状态变化 (PID: {target_pid}): "
                    f"{last_status.value} -> {current_status.value}"
                )
            
            self._last_status[target_pid] = current_status
            
            # 记录资源使用历史
            self._record_resource_history(target_pid, process_info)
            
            # 检查资源阈值
            self._check_resource_thresholds(process_info)
            
            # 清理旧的历史记录
            self._cleanup_old_history()
            
            return process_info
        
        except Exception as e:
            self.logger.error(f"监控进程失败 (PID: {target_pid}): {e}")
            raise
    
    def _record_resource_history(self, pid: int, process_info: ProcessInfo):
        """记录资源使用历史"""
        timestamp = time.time()
        
        # CPU历史
        if pid not in self._cpu_history:
            self._cpu_history[pid] = []
        self._cpu_history[pid].append((timestamp, process_info.cpu_percent))
        
        # 内存历史
        if pid not in self._memory_history:
            self._memory_history[pid] = []
        self._memory_history[pid].append((timestamp, process_info.memory_rss_mb))
        
        # 限制历史记录长度
        max_history = 1000
        for history in [self._cpu_history[pid], self._memory_history[pid]]:
            if len(history) > max_history:
                history.pop(0)
    
    def _check_resource_thresholds(self, process_info: ProcessInfo):
        """检查资源使用阈值"""
        warnings = []
        
        # 检查CPU使用率
        if process_info.cpu_percent > self.monitor_config.cpu_threshold:
            warnings.append(f"CPU使用率过高: {process_info.cpu_percent:.1f}%")
        
        # 检查内存使用量
        if process_info.memory_rss_mb > self.monitor_config.memory_threshold:
            warnings.append(f"内存使用过高: {process_info.memory_rss_mb:.1f}MB")
        
        # 记录警告
        if warnings:
            warning_msg = ", ".join(warnings)
            self.logger.warning(f"资源使用警告 (PID: {process_info.pid}): {warning_msg}")
    
    def _cleanup_old_history(self):
        """清理旧的历史记录"""
        current_time = time.time()
        max_age = 3600  # 保留1小时内的记录
        
        # 清理CPU历史
        for pid in list(self._cpu_history.keys()):
            self._cpu_history[pid] = [
                (ts, value) for ts, value in self._cpu_history[pid]
                if current_time - ts < max_age
            ]
            if not self._cpu_history[pid]:
                del self._cpu_history[pid]
        
        # 清理内存历史
        for pid in list(self._memory_history.keys()):
            self._memory_history[pid] = [
                (ts, value) for ts, value in self._memory_history[pid]
                if current_time - ts < max_age
            ]
            if not self._memory_history[pid]:
                del self._memory_history[pid]
        
        # 清理状态变化记录
        self._status_changes = [
            (ts, pid, old, new) for ts, pid, old, new in self._status_changes
            if current_time - ts < max_age
        ]
    
    @log_function_call("INFO")
    def terminate_process(self, pid: Optional[int] = None, force: bool = False) -> bool:
        """
        终止进程
        
        Args:
            pid: 进程ID
            force: 是否强制终止
            
        Returns:
            是否成功
        """
        target_pid = pid or self._last_found_pid
        
        if not target_pid:
            raise ProcessNotFoundError("未指定进程ID且未找到历史进程")
        
        try:
            proc = psutil.Process(target_pid)
            
            if force:
                # 强制终止
                proc.kill()
                self.logger.info(f"进程强制终止 (PID: {target_pid})")
            else:
                # 正常终止
                proc.terminate()
                self.logger.info(f"进程正常终止 (PID: {target_pid})")
            
            # 等待进程结束
            try:
                proc.wait(timeout=5)
            except psutil.TimeoutExpired:
                self.logger.warning(f"进程终止超时 (PID: {target_pid})")
            
            # 清理缓存
            if target_pid in self._process_cache:
                del self._process_cache[target_pid]
            
            if target_pid == self._last_found_pid:
                self._last_found_pid = None
            
            return True
        
        except psutil.NoSuchProcess:
            self.logger.warning(f"进程已不存在 (PID: {target_pid})")
            return True
        
        except psutil.AccessDenied as e:
            error_msg = f"进程终止权限不足 (PID: {target_pid}): {e}"
            self.logger.error(error_msg)
            raise ProcessPermissionError("terminate", str(e))
        
        except Exception as e:
            self.logger.error(f"终止进程失败 (PID: {target_pid}): {e}")
            return False
    
    @log_function_call("DEBUG")
    def get_process_info(self, pid: Optional[int] = None) -> Optional[ProcessInfo]:
        """
        获取进程信息
        
        Args:
            pid: 进程ID，如果为None则使用最后找到的进程
            
        Returns:
            进程信息，如果进程不存在则返回None
        """
        target_pid = pid or self._last_found_pid
        
        if not target_pid:
            return None
        
        # 检查缓存
        if target_pid in self._process_cache:
            cached_info = self._process_cache[target_pid]
            
            # 验证缓存是否仍然有效
            try:
                psutil.Process(target_pid)
                return cached_info
            except psutil.NoSuchProcess:
                # 进程已不存在，清理缓存
                del self._process_cache[target_pid]
                if target_pid == self._last_found_pid:
                    self._last_found_pid = None
        
        # 获取最新信息
        process_info = self._get_process_info(target_pid)
        if process_info:
            self._process_cache[target_pid] = process_info
        
        return process_info
    
    @log_function_call("DEBUG")
    def get_all_processes(self) -> List[ProcessInfo]:
        """获取所有进程"""
        processes = []
        
        for proc in psutil.process_iter(['pid']):
            try:
                process_info = self._get_process_info(proc.pid)
                if process_info:
                    processes.append(process_info)
            except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                continue
        
        return processes
    
    @log_function_call("DEBUG")
    def find_processes_by_name(self, name_pattern: str) -> List[ProcessInfo]:
        """根据名称模式查找进程"""
        processes = []
        
        for proc in psutil.process_iter(['pid', 'name']):
            try:
                proc_name = proc.info['name']
                if name_pattern.lower() in proc_name.lower():
                    process_info = self._get_process_info(proc.pid)
                    if process_info:
                        processes.append(process_info)
            except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                continue
        
        return processes
    
    @log_function_call("DEBUG")
    def get_resource_history(self, pid: Optional[int] = None, 
                           limit: int = 100) -> Dict[str, List[Tuple[float, float]]]:
        """
        获取资源使用历史
        
        Args:
            pid: 进程ID
            limit: 返回的最大记录数
            
        Returns:
            资源历史字典 {'cpu': [(timestamp, percent), ...], 'memory': [(timestamp, mb), ...]}
        """
        target_pid = pid or self._last_found_pid
        
        if not target_pid:
            return {'cpu': [], 'memory': []}
        
        cpu_history = self._cpu_history.get(target_pid, [])[-limit:]
        memory_history = self._memory_history.get(target_pid, [])[-limit:]
        
        return {
            'cpu': cpu_history,
            'memory': memory_history
        }
    
    @log_function_call("DEBUG")
    def get_resource_stats(self, pid: Optional[int] = None) -> Dict[str, Any]:
        """
        获取资源统计信息
        
        Args:
            pid: 进程ID
            
        Returns:
            资源统计字典
        """
        target_pid = pid or self._last_found_pid
        
        if not target_pid:
            return {}
        
        process_info = self.get_process_info(target_pid)
        if not process_info:
            return {}
        
        # 计算统计信息
        cpu_history = self._cpu_history.get(target_pid, [])
        memory_history = self._memory_history.get(target_pid, [])
        
        if cpu_history:
            cpu_values = [value for _, value in cpu_history]
            cpu_avg = sum(cpu_values) / len(cpu_values)
            cpu_max = max(cpu_values)
            cpu_min = min(cpu_values)
        else:
            cpu_avg = cpu_max = cpu_min = process_info.cpu_percent
        
        if memory_history:
            memory_values = [value for _, value in memory_history]
            memory_avg = sum(memory_values) / len(memory_values)
            memory_max = max(memory_values)
            memory_min = min(memory_values)
        else:
            memory_avg = memory_max = memory_min = process_info.memory_rss_mb
        
        return {
            'pid': target_pid,
            'name': process_info.name,
            'current_cpu': process_info.cpu_percent,
            'avg_cpu': cpu_avg,
            'max_cpu': cpu_max,
            'min_cpu': cpu_min,
            'current_memory_mb': process_info.memory_rss_mb,
            'avg_memory_mb': memory_avg,
            'max_memory_mb': memory_max,
            'min_memory_mb': memory_min,
            'uptime': process_info.uptime,
            'uptime_formatted': process_info.uptime_formatted,
            'status': process_info.status.value,
            'num_threads': process_info.num_threads,
            'username': process_info.username
        }
    
    @log_function_call("DEBUG")
    def get_status_history(self, pid: Optional[int] = None, 
                          limit: int = 10) -> List[Tuple[float, str, str]]:
        """
        获取状态变化历史
        
        Args:
            pid: 进程ID
            limit: 返回的最大记录数
            
        Returns:
            状态变化历史列表 [(timestamp, old_status, new_status), ...]
        """
        target_pid = pid or self._last_found_pid
        
        if not target_pid:
            return []
        
        history = []
        for ts, history_pid, old, new in self._status_changes:
            if history_pid == target_pid:
                history.append((ts, old.value, new.value))
        
        return history[-limit:]
    
    @log_function_call("INFO")
    def suspend_process(self, pid: Optional[int] = None) -> bool:
        """
        挂起进程
        
        Args:
            pid: 进程ID
            
        Returns:
            是否成功
        """
        target_pid = pid or self._last_found_pid
        
        if not target_pid:
            raise ProcessNotFoundError("未指定进程ID且未找到历史进程")
        
        try:
            proc = psutil.Process(target_pid)
            proc.suspend()
            
            self.logger.info(f"进程挂起成功 (PID: {target_pid})")
            return True
        
        except psutil.NoSuchProcess:
            self.logger.warning(f"进程已不存在 (PID: {target_pid})")
            return False
        
        except psutil.AccessDenied as e:
            error_msg = f"进程挂起权限不足 (PID: {target_pid}): {e}"
            self.logger.error(error_msg)
            raise ProcessPermissionError("suspend", str(e))
        
        except AttributeError:
            self.logger.error(f"当前平台不支持进程挂起 (PID: {target_pid})")
            return False
        
        except Exception as e:
            self.logger.error(f"挂起进程失败 (PID: {target_pid}): {e}")
            return False
    
    @log_function_call("INFO")
    def resume_process(self, pid: Optional[int] = None) -> bool:
        """
        恢复进程
        
        Args:
            pid: 进程ID
            
        Returns:
            是否成功
        """
        target_pid = pid or self._last_found_pid
        
        if not target_pid:
            raise ProcessNotFoundError("未指定进程ID且未找到历史进程")
        
        try:
            proc = psutil.Process(target_pid)
            proc.resume()
            
            self.logger.info(f"进程恢复成功 (PID: {target_pid})")
            return True
        
        except psutil.NoSuchProcess:
            self.logger.warning(f"进程已不存在 (PID: {target_pid})")
            return False
        
        except psutil.AccessDenied as e:
            error_msg = f"进程恢复权限不足 (PID: {target_pid}): {e}"
            self.logger.error(error_msg)
            raise ProcessPermissionError("resume", str(e))
        
        except AttributeError:
            self.logger.error(f"当前平台不支持进程恢复 (PID: {target_pid})")
            return False
        
        except Exception as e:
            self.logger.error(f"恢复进程失败 (PID: {target_pid}): {e}")
            return False
    
    @log_function_call("INFO")
    def set_process_priority(self, pid: Optional[int] = None, 
                           priority: str = "normal") -> bool:
        """
        设置进程优先级
        
        Args:
            pid: 进程ID
            priority: 优先级 (idle, below_normal, normal, above_normal, high, realtime)
            
        Returns:
            是否成功
        """
        target_pid = pid or self._last_found_pid
        
        if not target_pid:
            raise ProcessNotFoundError("未指定进程ID且未找到历史进程")
        
        priority_map = {
            'idle': psutil.IDLE_PRIORITY_CLASS,
            'below_normal': psutil.BELOW_NORMAL_PRIORITY_CLASS,
            'normal': psutil.NORMAL_PRIORITY_CLASS,
            'above_normal': psutil.ABOVE_NORMAL_PRIORITY_CLASS,
            'high': psutil.HIGH_PRIORITY_CLASS,
            'realtime': psutil.REALTIME_PRIORITY_CLASS,
        }
        
        if priority not in priority_map:
            self.logger.error(f"无效的优先级: {priority}")
            return False
        
        try:
            proc = psutil.Process(target_pid)
            proc.nice(priority_map[priority])
            
            self.logger.info(f"进程优先级设置成功 (PID: {target_pid}, 优先级: {priority})")
            return True
        
        except psutil.NoSuchProcess:
            self.logger.warning(f"进程已不存在 (PID: {target_pid})")
            return False
        
        except psutil.AccessDenied as e:
            error_msg = f"进程优先级设置权限不足 (PID: {target_pid}): {e}"
            self.logger.error(error_msg)
            raise ProcessPermissionError("set_priority", str(e))
        
        except Exception as e:
            self.logger.error(f"设置进程优先级失败 (PID: {target_pid}): {e}")
            return False
    
    @log_function_call("INFO")
    def clear_cache(self):
        """清理缓存"""
        cache_size = len(self._process_cache)
        self._process_cache.clear()
        self._last_found_pid = None
        self._last_status.clear()
        self._status_changes.clear()
        self._cpu_history.clear()
        self._memory_history.clear()
        
        self.logger.info(f"进程缓存已清理，清理了 {cache_size} 个缓存项")
    
    def __del__(self):
        """析构函数，清理资源"""
        try:
            self.clear_cache()
        except Exception:
            pass


# 简化使用
def create_process_monitor(config_path: Optional[str] = None) -> ProcessMonitor:
    """创建进程监控器实例"""
    return ProcessMonitor(config_path)