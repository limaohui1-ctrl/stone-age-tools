            # 创建目录
            os.makedirs("实际应用案例", exist_ok=True)
            
            # 构建Markdown内容
            md_content = f"""# {case_study['case_id']}

## 案例信息
- **分类**: {case_study['category']['name']}
- **描述**: {case_study['category']['description']}
- **模板**: {case_study['template']['name']}
- **创建时间**: {case_study['created_time']}

## 案例内容
"""
            
            for section in case_study["sections"]:
                md_content += f"\n### {section['name']}\n"
                md_content += f"*预计长度: {section['estimated_length']}*\n\n"
                md_content += f"{section['content']}\n"
            
            md_content += "\n## 效果指标\n"
            for metric in case_study["effect_metrics"]:
                md_content += f"\n### {metric['name']}\n"
                md_content += f"**测量**: {metric['measurement']}\n"
                md_content += f"**示例**: {', '.join(metric['examples'][:2])}\n"
            
            md_content += "\n## 使用推荐\n"
            for recommendation in case_study["recommendations"]:
                md_content += f"- {recommendation}\n"
            
            # 保存文件
            with open(filepath, 'w', encoding='utf-8') as f:
                f.write(md_content)
            
            print(f"\n💾 案例文件已保存到: {filepath}")
            print(f"📏 文件大小: {len(md_content)} 字节")
            
        except Exception as e:
            print(f"⚠️ 保存案例文件失败: {str(e)}")
    
    def show_case_categories(self):
        """显示案例分类"""
        print("\n" + "=" * 70)
        print("📋 实际应用案例分类")
        print("=" * 70)
        
        for category_key, category in self.case_categories.items():
            print(f"\n🎯 {category['name']}:")
            print(f"   描述: {category['description']}")
            print(f"   常见场景:")
            for scenario in category["common_scenarios"][:2]:
                print(f"     • {scenario}")
            print(f"   关键收益:")
            for benefit in category["key_benefits"][:2]:
                print(f"     • {benefit}")
        
        print(f"\n📊 效果指标分类:")
        print(f"\n  📈 定量指标:")
        for metric_key, metric in self.effect_metrics["quantitative_metrics"].items():
            print(f"     • {metric['name']}: {metric['measurement']}")
        
        print(f"\n  🎭 定性指标:")
        for metric_key, metric in self.effect_metrics["qualitative_metrics"].items():
            print(f"     • {metric['name']}: {metric['measurement']}")

# ==================== 效果验证系统 ====================

class EffectValidationSystem:
    """效果验证系统"""
    
    def __init__(self):
        self.validation_methods = self._create_validation_methods()
        self.data_collection_tools = self._initialize_data_collection_tools()
        self.analysis_frameworks = self._create_analysis_frameworks()
        
    def _create_validation_methods(self) -> Dict:
        """创建验证方法"""
        return {
            "quantitative_analysis": {
                "name": "定量分析",
                "description": "使用数值数据验证效果",
                "methods": [
                    "前后对比测试",
                    "A/B测试",
                    "时间序列分析",
                    "统计显著性检验"
                ],
                "data_sources": ["性能指标", "使用日志", "监控数据", "用户行为"],
                "output_format": "数据报告和图表"
            },
            "qualitative_assessment": {
                "name": "定性评估",
                "description": "使用非数值数据评估效果",
                "methods": [
                    "用户访谈",
                    "问卷调查",
                    "观察研究",
                    "案例研究"
                ],
                "data_sources": ["用户反馈", "使用体验", "问题报告", "改进建议"],
                "output_format": "评估报告和建议"
            },
            "mixed_methods": {
                "name": "混合方法",
                "description": "结合定量和定性方法",
                "methods": [
                    "三角验证",
                    "多源数据整合",
                    "综合评估",
                    "迭代验证"
                ],
                "data_sources": ["所有可用数据源"],
                "output_format": "综合验证报告"
            }
        }
    
    def _initialize_data_collection_tools(self) -> Dict:
        """初始化数据收集工具"""
        return {
            "automated_monitoring": {
                "name": "自动化监控",
                "tools": ["性能监控器", "使用追踪器", "错误记录器", "日志分析器"],
                "data_types": ["实时指标", "历史数据", "异常事件", "趋势分析"],
                "advantages": "实时、准确、全面、自动化"
            },
            "user_feedback": {
                "name": "用户反馈收集",
                "tools": ["调查问卷", "用户访谈", "反馈表单", "社区讨论"],
                "data_types": ["满意度评分", "使用体验", "改进建议", "问题报告"],
                "advantages": "直接、详细、有深度、用户中心"
            },
            "expert_evaluation": {
                "name": "专家评估",
                "tools": ["技术评审", "质量检查", "安全审计", "性能测试"],
                "data_types": ["技术评估", "质量评分", "安全评级", "性能基准"],
                "advantages": "专业、权威、全面、标准"
            }
        }
    
    def _create_analysis_frameworks(self) -> Dict:
        """创建分析框架"""
        return {
            "roi_analysis": {
                "name": "投资回报率分析",
                "metrics": ["时间节省", "成本降低", "效率提升", "质量改善"],
                "calculation": "(收益 - 成本) / 成本 × 100%",
                "interpretation": "正ROI表示投资有价值"
            },
            "effectiveness_analysis": {
                "name": "效果分析",
                "metrics": ["目标达成度", "问题解决率", "用户满意度", "质量提升度"],
                "calculation": "实际效果 / 预期效果 × 100%",
                "interpretation": "高百分比表示效果好"
            },
            "efficiency_analysis": {
                "name": "效率分析",
                "metrics": ["时间效率", "资源效率", "人力效率", "流程效率"],
                "calculation": "产出 / 投入",
                "interpretation": "高比率表示效率高"
            },
            "sustainability_analysis": {
                "name": "可持续性分析",
                "metrics": ["长期效果", "维护成本", "扩展能力", "用户持续使用"],
                "calculation": "长期价值 / 长期成本",
                "interpretation": "高比率表示可持续"
            }
        }
    
    def create_validation_plan(self, validation_type: str = "mixed_methods") -> Dict:
        """创建验证计划"""
        print(f"\n📊 创建验证计划: {validation_type}")
        
        if validation_type not in self.validation_methods:
            print(f"⚠️ 未找到验证类型: {validation_type}")
            return {}
        
        validation_method = self.validation_methods[validation_type]
        
        validation_plan = {
            "plan_id": f"validation_{validation_type}_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
            "validation_method": validation_method,
            "created_time": datetime.now().isoformat(),
            "data_collection": self._plan_data_collection(validation_type),
            "analysis_framework": self._select_analysis_framework(validation_type),
            "timeline": self._create_validation_timeline(validation_type),
            "success_criteria": self._define_success_criteria(validation_type)
        }
        
        # 显示验证计划
        self._show_validation_plan(validation_plan)
        
        return validation_plan
    
    def _plan_data_collection(self, validation_type: str) -> Dict:
        """计划数据收集"""
        collection_plans = {
            "quantitative_analysis": {
                "primary_tools": ["自动化监控"],
                "data_sources": ["性能指标", "使用日志", "监控数据"],
                "collection_frequency": "实时或定期",
                "data_quality": "高精度、可量化"
            },
            "qualitative_assessment": {
                "primary_tools": ["用户反馈"],
                "data_sources": ["用户反馈", "使用体验", "改进建议"],
                "collection_frequency": "定期或事件驱动",
                "data_quality": "详细、有深度、主观"
            },
            "mixed_methods": {
                "primary_tools": ["自动化监控", "用户反馈", "专家评估"],
                "data_sources": ["所有可用数据源"],
                "collection_frequency": "综合频率",
                "data_quality": "全面、平衡、可靠"
            }
        }
        
        return collection_plans.get(validation_type, {})
    
    def _select_analysis_framework(self, validation_type: str) -> List[Dict]:
        """选择分析框架"""
        framework_mapping = {
            "quantitative_analysis": ["roi_analysis", "efficiency_analysis"],
            "qualitative_assessment": ["effectiveness_analysis", "sustainability_analysis"],
            "mixed_methods": ["roi_analysis", "effectiveness_analysis", "efficiency_analysis", "sustainability_analysis"]
        }
        
        selected_frameworks = []
        framework_keys = framework_mapping.get(validation_type, [])
        
        for framework_key in framework_keys:
            if framework_key in self.analysis_frameworks:
                selected_frameworks.append(self.analysis_frameworks[framework_key])
        
        return selected_frameworks
    
    def _create_validation_timeline(self, validation_type: str) -> Dict:
        """创建验证时间线"""
        timelines = {
            "quantitative_analysis": {
                "data_collection": "1-2周",
                "data_analysis": "3-5天",
                "report_generation": "2-3天",
                "total": "2-3周"
            },
            "qualitative_assessment": {
                "data_collection": "2-3周",
                "data_analysis": "1-2周",
                "report_generation": "3-5天",
                "total": "4-6周"
            },
            "mixed_methods": {
                "data_collection": "3-4周",
                "data_analysis": "2-3周",
                "report_generation": "1-2周",
                "total": "6-9周"
            }
        }
        
        return timelines.get(validation_type, {})
    
    def _define_success_criteria(self, validation_type: str) -> List[str]:
        """定义成功标准"""
        criteria = {
            "quantitative_analysis": [
                "数据收集完整准确",
                "分析方法科学合理",
                "结果具有统计显著性",
                "结论有数据支持"
            ],
            "qualitative_assessment": [
                "用户反馈真实可靠",
                "评估方法系统全面",
                "洞察深入有价值",
                "建议具体可行"
            ],
            "mixed_methods": [
                "数据来源多样全面",
                "分析方法综合平衡",
                "结论可靠有深度",
                "建议具体可操作"
            ]
        }
        
        return criteria.get(validation_type, [])
    
    def _show_validation_plan(self, validation_plan: Dict):
        """显示验证计划"""
        print("\n" + "=" * 70)
        print(f"📊 验证计划: {validation_plan['plan_id']}")
        print("=" * 70)
        
        method = validation_plan["validation_method"]
        print(f"\n📋 验证方法:")
        print(f"  名称: {method['name']}")
        print(f"  描述: {method['description']}")
        print(f"  方法: {', '.join(method['methods'][:2])}")
        print(f"  数据源: {', '.join(method['data_sources'][:2])}")
        print(f"  输出格式: {method['output_format']}")
        
        print(f"\n📈 数据收集:")
        collection = validation_plan["data_collection"]
        print(f"  主要工具: {', '.join(collection.get('primary_tools', []))}")
        print(f"  数据源: {', '.join(collection.get('data_sources', []))}")
        print(f"  收集频率: {collection.get('collection_frequency', 'N/A')}")
        print(f"  数据质量: {collection.get('data_quality', 'N/A')}")
        
        print(f"\n🔍 分析框架:")
        for framework in validation_plan["analysis_framework"]:
            print(f"\n  📊 {framework['name']}:")
            print(f"     指标: {', '.join(framework['metrics'][:2])}")
            print(f"     计算: {framework['calculation']}")
            print(f"     解释: {framework['interpretation']}")
        
        print(f"\n⏰ 时间线:")
        for phase, time in validation_plan["timeline"].items():
            print(f"  • {phase}: {time}")
        
        print(f"\n✅ 成功标准:")
        for criterion in validation_plan["success_criteria"]:
            print(f"  • {criterion}")

# ==================== 用户反馈收集 ====================

class UserFeedbackCollector:
    """用户反馈收集"""
    
    def __init__(self):
        self.feedback_channels = self._create_feedback_channels()
        self.feedback_templates = self._create_feedback_templates()
        self.analysis_methods = self._initialize_analysis_methods()
        
    def _create_feedback_channels(self) -> Dict:
        """创建反馈渠道"""
        return {
            "direct_interaction": {
                "name": "直接交互",
                "channels": ["用户访谈", "焦点小组", "现场观察", "技术支持"],
                "advantages": "深入、详细、实时、互动",
                "limitations": "耗时、样本有限、主观"
            },
            "indirect_collection": {
                "name": "间接收集",
                "channels": ["调查问卷", "反馈表单", "使用日志", "错误报告"],
                "advantages": "高效、可扩展、客观、可量化",
                "limitations": "缺乏深度、可能不完整、响应率低"
            },
            "community_engagement": {
                "name": "社区参与",
                "channels": ["社区论坛", "社交媒体", "开源贡献", "用户会议"],
                "advantages": "广泛、多样、持续、社区建设",
                "limitations": "噪声多、管理复杂、代表性可能偏差"
            }
        }
    
    def _create_feedback_templates(self) -> Dict:
        """创建反馈模板"""
        return {
            "satisfaction_survey": {
                "name": "满意度调查",
                "purpose": "评估用户满意度和使用体验",
                "questions": [
                    "总体满意度评分 (1-5)",
                    "易用性评价",
                    "功能完整性评价",
                    "性能满意度",
                    "推荐意愿"
                ],
                "scale": "李克特量表 (1-5)",
                "analysis": "平均分、分布、趋势"
            },
            "feature_feedback": {
                "name": "功能反馈",
                "purpose": "收集对具体功能的反馈",
                "questions": [
                    "功能使用频率",
                    "功能有用性评价",
                    "功能易用性评价",
                    "改进建议",
                    "问题报告"
                ],
                "scale": "混合 (评分+开放)",
                "analysis": "功能评分、问题分类、建议汇总"
            },
            "improvement_suggestions": {
                "name": "改进建议",
                "purpose": "收集改进和优化建议",
                "questions": [
                    "最需要改进的方面",
                    "新功能需求",
                    "性能优化建议",
                    "用户体验改进",
                    "其他建议"
                ],
                "scale": "开放性问题",
                "analysis": "主题分析、优先级排序、实施建议"
            }
        }
    
    def _initialize_analysis_methods(self) -> Dict:
        """初始化分析方法"""
        return {
            "quantitative_analysis": {
                "name": "定量分析",
                "methods": ["统计分析", "趋势分析", "相关性分析", "聚类分析"],
                "tools": ["Excel", "R", "Python", "统计分析软件"],
                "output": "数据报告、图表、统计结论"
            },
            "qualitative_analysis": {
                "name": "定性分析",
                "methods": ["主题分析", "内容分析", "话语分析", "案例研究"],
                "tools": ["NVivo", "Atlas.ti", "手工编码", "文本分析"],
                "output": "主题报告、洞察分析、建议汇总"
            },
            "sentiment_analysis": {
                "name": "情感分析",
                "methods": ["情感评分", "情感分类", "情感趋势", "情感原因"],
                "tools": ["自然语言处理", "机器学习", "情感词典", "深度学习"],
                "output": "情感报告、情感趋势、情感原因"
            }
        }
    
    def create_feedback_plan(self, channel: str = "direct_interaction", template: str = "satisfaction_survey") -> Dict:
        """创建反馈计划"""
        print(f"\n💬 创建反馈计划: {channel} - {template}")
        
        if channel not in self.feedback_channels:
            print(f"⚠️ 未找到反馈渠道: {channel}")
            return {}
        
        if template not in self.feedback_templates:
            print(f"⚠️ 未找到反馈模板: {template}")
            return {}
        
        channel_info = self.feedback_channels[channel]
        template_info = self.feedback_templates[template]
        
        feedback_plan = {
            "plan_id": f"feedback_{channel}_{template}_{datetime.now().strftime('%Y%m%d_