#!/usr/bin/env python3
"""
石器时代脚本测试框架 - GUI启动器
简化启动和依赖检查
"""

import os
import sys
import subprocess
from pathlib import Path

def check_dependencies():
    """检查依赖"""
    print("🔍 检查依赖...")
    
    # 检查Python版本
    python_version = sys.version_info
    if python_version.major < 3 or (python_version.major == 3 and python_version.minor < 8):
        print(f"❌ Python版本过低: {sys.version}")
        print("   需要 Python 3.8 或更高版本")
        return False
    
    print(f"✅ Python版本: {sys.version}")
    
    # 检查PyQt6
    try:
        import PyQt6
        print(f"✅ PyQt6已安装: {PyQt6.__version__}")
    except ImportError:
        print("❌ PyQt6未安装")
        print("   安装命令: pip install PyQt6")
        
        # 询问是否安装
        response = input("是否自动安装PyQt6? (y/n): ").strip().lower()
        if response == 'y':
            print("正在安装PyQt6...")
            try:
                subprocess.check_call([sys.executable, "-m", "pip", "install", "PyQt6"])
                print("✅ PyQt6安装成功")
            except Exception as e:
                print(f"❌ 安装失败: {e}")
                return False
        else:
            return False
    
    # 检查其他依赖
    required_modules = ['json', 'logging', 'datetime', 'pathlib']
    for module in required_modules:
        try:
            __import__(module)
            print(f"✅ {module} 可用")
        except ImportError:
            print(f"❌ {module} 不可用")
            return False
    
    return True

def setup_environment():
    """设置环境"""
    print("🔧 设置环境...")
    
    # 添加当前目录到Python路径
    current_dir = Path(__file__).parent
    sys.path.insert(0, str(current_dir))
    
    # 创建必要目录
    directories = ['test_results', 'gui_test_results', 'generated_tests']
    for directory in directories:
        dir_path = current_dir / directory
        dir_path.mkdir(exist_ok=True)
        print(f"✅ 创建目录: {directory}")
    
    # 检查必要文件
    required_files = [
        "示例石器时代脚本.asc",
        "石器时代脚本测试配置.json",
        "石器时代专用测试模块.py",
        "石器时代测试运行器.py"
    ]
    
    for file in required_files:
        file_path = current_dir / file
        if file_path.exists():
            print(f"✅ 文件存在: {file}")
        else:
            print(f"⚠️  文件缺失: {file}")
    
    return True

def start_gui():
    """启动GUI"""
    print("🚀 启动GUI界面...")
    
    try:
        # 导入GUI模块
        from gui.石器时代测试GUI_完整最终 import main as gui_main
        
        print("✅ GUI模块加载成功")
        print("\n" + "="*50)
        print("🎮 石器时代脚本测试框架 GUI")
        print("="*50)
        
        # 启动GUI
        gui_main()
        
    except Exception as e:
        print(f"❌ 启动GUI失败: {e}")
        import traceback
        traceback.print_exc()
        
        # 尝试备用启动方式
        print("\n尝试备用启动方式...")
        try:
            gui_path = Path(__file__).parent / "gui" / "石器时代测试GUI_完整最终.py"
            if gui_path.exists():
                subprocess.run([sys.executable, str(gui_path)])
            else:
                print("❌ GUI文件不存在")
        except Exception as e2:
            print(f"❌ 备用启动也失败: {e2}")

def show_welcome():
    """显示欢迎信息"""
    welcome_text = """
    ====================================================
    🎮 石器时代脚本测试框架 - GUI版本
    ====================================================
    
    功能特性:
    ✅ 图形化界面，易于使用
    ✅ 完整的ASSA脚本解析器
    ✅ 自动化测试框架
    ✅ 详细的测试报告
    ✅ 代码覆盖率分析
    ✅ 石器时代专用测试功能
    
    使用步骤:
    1. 打开石器时代脚本文件 (.asc)
    2. 创建或加载测试配置
    3. 运行测试并查看结果
    4. 根据结果优化脚本
    
    支持的功能:
    - 脚本语法检查
    - 结构完整性验证
    - 坐标系统测试
    - 错误处理测试
    - 性能基准测试
    
    ====================================================
    """
    print(welcome_text)

def main():
    """主函数"""
    show_welcome()
    
    # 检查依赖
    if not check_dependencies():
        print("\n❌ 依赖检查失败，请安装缺失的依赖")
        sys.exit(1)
    
    # 设置环境
    if not setup_environment():
        print("\n❌ 环境设置失败")
        sys.exit(1)
    
    print("\n✅ 所有检查通过，准备启动GUI...")
    
    # 启动GUI
    start_gui()

if __name__ == "__main__":
    main()