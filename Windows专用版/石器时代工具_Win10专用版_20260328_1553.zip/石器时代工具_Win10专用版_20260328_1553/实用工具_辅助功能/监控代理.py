#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
石器时代脚本性能监控代理
核心功能：实时监控脚本执行性能，检测网络波动，提供优化建议
"""

import time
import threading
import json
import logging
import psutil
import socket
import statistics
from dataclasses import dataclass, asdict
from typing import Dict, List, Optional, Any
from datetime import datetime
from enum import Enum
import queue


class PerformanceLevel(Enum):
    """性能等级"""
    EXCELLENT = "优秀"      # 性能优秀，无问题
    GOOD = "良好"          # 性能良好，轻微波动
    FAIR = "一般"          # 性能一般，需要关注
    POOR = "较差"          # 性能较差，需要优化
    CRITICAL = "严重"      # 性能严重问题，需要立即处理


class NetworkStatus(Enum):
    """网络状态"""
    STABLE = "稳定"        # 网络稳定
    SLIGHT_FLUCTUATION = "轻微波动"  # 轻微波动
    MODERATE_FLUCTUATION = "中度波动"  # 中度波动
    SEVERE_FLUCTUATION = "严重波动"  # 严重波动
    DISCONNECTED = "断开"  # 网络断开


@dataclass
class PerformanceMetrics:
    """性能指标"""
    timestamp: str
    script_name: str
    execution_time: float  # 执行时间（秒）
    cpu_usage: float       # CPU使用率（%）
    memory_usage: float    # 内存使用率（%）
    network_latency: float # 网络延迟（毫秒）
    network_jitter: float  # 网络抖动（毫秒）
    packet_loss: float     # 丢包率（%）
    success_rate: float    # 成功率（%）
    error_count: int       # 错误次数
    retry_count: int       # 重试次数
    
    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return asdict(self)


@dataclass
class PerformanceAnalysis:
    """性能分析结果"""
    performance_level: PerformanceLevel
    network_status: NetworkStatus
    bottleneck: str
    recommendations: List[str]
    estimated_improvement: float  # 预计改进百分比
    priority: int  # 优化优先级（1-5，1最高）


class PerformanceMonitor:
    """性能监控器"""
    
    def __init__(self, script_name: str, config_path: Optional[str] = None):
        """
        初始化性能监控器
        
        Args:
            script_name: 脚本名称
            config_path: 配置文件路径
        """
        self.script_name = script_name
        self.config = self._load_config(config_path)
        
        # 性能指标队列
        self.metrics_queue = queue.Queue(maxsize=1000)
        
        # 监控线程
        self.monitoring = False
        self.monitor_thread = None
        
        # 历史数据
        self.history: List[PerformanceMetrics] = []
        self.max_history_size = 1000
        
        # 设置日志
        self._setup_logging()
        
        # 网络测试目标
        self.network_test_targets = [
            "8.8.8.8",  # Google DNS
            "1.1.1.1",  # Cloudflare DNS
            "223.5.5.5",  # 阿里云DNS
        ]
        
    def _load_config(self, config_path: Optional[str]) -> Dict[str, Any]:
        """加载配置"""
        default_config = {
            "monitoring_interval": 1.0,  # 监控间隔（秒）
            "network_test_interval": 5.0,  # 网络测试间隔（秒）
            "performance_thresholds": {
                "execution_time": {
                    "excellent": 1.0,
                    "good": 3.0,
                    "fair": 5.0,
                    "poor": 10.0,
                },
                "network_latency": {
                    "excellent": 50,
                    "good": 100,
                    "fair": 200,
                    "poor": 500,
                },
                "packet_loss": {
                    "excellent": 0.1,
                    "good": 1.0,
                    "fair": 5.0,
                    "poor": 10.0,
                }
            },
            "optimization_rules": {
                "network_retry": {
                    "enabled": True,
                    "max_retries": 3,
                    "retry_delay": 2.0,
                },
                "timeout_adjustment": {
                    "enabled": True,
                    "base_timeout": 10.0,
                    "adjustment_factor": 1.5,
                }
            }
        }
        
        if config_path:
            try:
                with open(config_path, 'r', encoding='utf-8') as f:
                    user_config = json.load(f)
                    default_config.update(user_config)
            except Exception as e:
                logging.warning(f"加载配置文件失败，使用默认配置: {e}")
        
        return default_config
    
    def _setup_logging(self):
        """设置日志"""
        log_dir = "/root/.openclaw/workspace/石器时代脚本性能监控系统/logs"
        os.makedirs(log_dir, exist_ok=True)
        
        log_file = os.path.join(log_dir, f"{self.script_name}_{datetime.now().strftime('%Y%m%d')}.log")
        
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler(log_file, encoding='utf-8'),
                logging.StreamHandler()
            ]
        )
        self.logger = logging.getLogger(f"PerformanceMonitor-{self.script_name}")
    
    def start_monitoring(self):
        """开始监控"""
        if self.monitoring:
            self.logger.warning("监控已经在运行")
            return
        
        self.monitoring = True
        self.monitor_thread = threading.Thread(target=self._monitoring_loop, daemon=True)
        self.monitor_thread.start()
        self.logger.info(f"开始监控脚本: {self.script_name}")
    
    def stop_monitoring(self):
        """停止监控"""
        self.monitoring = False
        if self.monitor_thread:
            self.monitor_thread.join(timeout=5.0)
        self.logger.info(f"停止监控脚本: {self.script_name}")
    
    def _monitoring_loop(self):
        """监控循环"""
        last_network_test = 0
        
        while self.monitoring:
            try:
                # 收集性能指标
                metrics = self._collect_metrics()
                
                # 添加到队列和历史记录
                self.metrics_queue.put(metrics)
                self.history.append(metrics)
                
                # 限制历史记录大小
                if len(self.history) > self.max_history_size:
                    self.history = self.history[-self.max_history_size:]
                
                # 定期网络测试
                current_time = time.time()
                if current_time - last_network_test >= self.config["network_test_interval"]:
                    network_metrics = self._test_network()
                    if network_metrics:
                        self.metrics_queue.put(network_metrics)
                        self.history.append(network_metrics)
                    last_network_test = current_time
                
                # 分析性能
                if len(self.history) >= 10:  # 至少有10个数据点才开始分析
                    analysis = self._analyze_performance()
                    if analysis.performance_level in [PerformanceLevel.POOR, PerformanceLevel.CRITICAL]:
                        self._handle_performance_issue(analysis)
                
                # 等待下一个监控周期
                time.sleep(self.config["monitoring_interval"])
                
            except Exception as e:
                self.logger.error(f"监控循环出错: {e}")
                time.sleep(1.0)
    
    def _collect_metrics(self) -> PerformanceMetrics:
        """收集性能指标"""
        timestamp = datetime.now().isoformat()
        
        # 获取系统资源使用情况
        cpu_percent = psutil.cpu_percent(interval=0.1)
        memory_info = psutil.virtual_memory()
        memory_percent = memory_info.percent
        
        # 测试网络延迟（简化版本）
        network_latency = self._ping_test(self.network_test_targets[0])
        
        return PerformanceMetrics(
            timestamp=timestamp,
            script_name=self.script_name,
            execution_time=0.0,  # 由脚本执行时设置
            cpu_usage=cpu_percent,
            memory_usage=memory_percent,
            network_latency=network_latency,
            network_jitter=0.0,  # 需要历史数据计算
            packet_loss=0.0,     # 需要专门测试
            success_rate=100.0,  # 由脚本执行统计
            error_count=0,       # 由脚本执行统计
            retry_count=0,       # 由脚本执行统计
        )
    
    def _ping_test(self, host: str, timeout: float = 2.0) -> float:
        """Ping测试（简化版本）"""
        try:
            start_time = time.time()
            socket.create_connection((host, 80), timeout=timeout)
            latency = (time.time() - start_time) * 1000  # 转换为毫秒
            return latency
        except Exception as e:
            self.logger.debug(f"Ping测试失败 {host}: {e}")
            return 9999.0  # 返回一个很大的值表示失败
    
    def _test_network(self) -> Optional[PerformanceMetrics]:
        """网络测试"""
        latencies = []
        for target in self.network_test_targets:
            latency = self._ping_test(target)
            if latency < 9999.0:  # 排除失败的情况
                latencies.append(latency)
        
        if not latencies:
            return None
        
        avg_latency = statistics.mean(latencies)
        
        return PerformanceMetrics(
            timestamp=datetime.now().isoformat(),
            script_name=f"{self.script_name}_network_test",
            execution_time=0.0,
            cpu_usage=0.0,
            memory_usage=0.0,
            network_latency=avg_latency,
            network_jitter=statistics.stdev(latencies) if len(latencies) > 1 else 0.0,
            packet_loss=0.0,
            success_rate=100.0,
            error_count=0,
            retry_count=0,
        )
    
    def _analyze_performance(self) -> PerformanceAnalysis:
        """分析性能"""
        if len(self.history) < 10:
            return PerformanceAnalysis(
                performance_level=PerformanceLevel.GOOD,
                network_status=NetworkStatus.STABLE,
                bottleneck="数据不足，无法分析",
                recommendations=["继续收集性能数据"],
                estimated_improvement=0.0,
                priority=5
            )
        
        # 获取最近的数据
        recent_data = self.history[-10:]
        
        # 分析执行时间
        exec_times = [m.execution_time for m in recent_data if m.execution_time > 0]
        avg_exec_time = statistics.mean(exec_times) if exec_times else 0.0
        
        # 分析网络延迟
        network_latencies = [m.network_latency for m in recent_data]
        avg_latency = statistics.mean(network_latencies)
        
        # 分析网络抖动
        if len(network_latencies) > 1:
            network_jitter = statistics.stdev(network_latencies)
        else:
            network_jitter = 0.0
        
        # 确定性能等级
        perf_level = self._determine_performance_level(avg_exec_time, avg_latency, network_jitter)
        
        # 确定网络状态
        network_status = self._determine_network_status(avg_latency, network_jitter)
        
        # 识别瓶颈
        bottleneck = self._identify_bottleneck(avg_exec_time, avg_latency, network_jitter)
        
        # 生成优化建议
        recommendations = self._generate_recommendations(perf_level, network_status, bottleneck)
        
        # 计算预计改进
        estimated_improvement = self._estimate_improvement(perf_level, bottleneck)
        
        # 确定优先级
        priority = self._determine_priority(perf_level, network_status)
        
        return PerformanceAnalysis(
            performance_level=perf_level,
            network_status=network_status,
            bottleneck=bottleneck,
            recommendations=recommendations,
            estimated_improvement=estimated_improvement,
            priority=priority
        )
    
    def _determine_performance_level(self, exec_time: float, latency: float, jitter: float) -> PerformanceLevel:
        """确定性能等级"""
        thresholds = self.config["performance_thresholds"]
        
        # 检查执行时间
        if exec_time <= thresholds["execution_time"]["excellent"]:
            exec_score = 4
        elif exec_time <= thresholds["execution_time"]["good"]:
            exec_score = 3
        elif exec_time <= thresholds["execution_time"]["fair"]:
            exec_score = 2
        elif exec_time <= thresholds["execution_time"]["poor"]:
            exec_score = 1
        else:
            exec_score = 0
        
        # 检查网络延迟
        if latency <= thresholds["network_latency"]["excellent"]:
            latency_score = 4
        elif latency <= thresholds["network_latency"]["good"]:
            latency_score = 3
        elif latency <= thresholds["network_latency"]["fair"]:
            latency_score = 2
        elif latency <= thresholds["network_latency"]["poor"]:
            latency_score = 1
        else:
            latency_score = 0
        
        # 综合评分
        total_score = exec_score + latency_score
        
        if total_score >= 7:
            return PerformanceLevel.EXCELLENT
        elif total_score >= 5:
            return PerformanceLevel.GOOD
        elif total_score >= 3:
            return PerformanceLevel.FAIR
        elif total_score >= 1:
            return PerformanceLevel.POOR
        else:
            return PerformanceLevel.CRITICAL
    
    def _determine_network_status(self, latency: float, jitter: float) -> NetworkStatus:
        """确定网络状态"""
        if latency > 500 or jitter > 100:
            return NetworkStatus.SEVERE_FLUCTUATION
        elif latency > 200 or jitter > 50:
            return NetworkStatus.MODERATE_FLUCTUATION
        elif latency > 100 or jitter > 20:
            return NetworkStatus.SLIGHT_FLUCTUATION
        else:
            return NetworkStatus.STABLE
    
    def _identify_bottleneck(self, exec_time: float, latency: float, jitter: float) -> str:
        """识别性能瓶颈"""
        bottlenecks = []
        
        if exec_time > 5.0:
            bottlenecks.append("脚本执行时间过长")
        
        if latency > 200:
            bottlenecks.append("网络延迟过高")
        
        if jitter > 50:
            bottlenecks.append("网络抖动严重")
        
        if not bottlenecks:
            return "无明显瓶颈"
        
        return "，".join(bottlenecks)
    
    def _generate_recommendations(self, perf_level: PerformanceLevel, 
                                 network_status: NetworkStatus, 
                                 bottleneck: str) -> List[str]:
        """生成优化建议"""
        recommendations = []
        
        if perf_level in [PerformanceLevel.POOR, PerformanceLevel.CRITICAL]:
            recommendations.append("立即检查脚本和网络状态")
        
        if "网络延迟过高" in bottleneck or "网络抖动严重" in bottleneck:
            recommendations.extend([
                "增加网络重试机制",
                "优化网络请求超时时间",
                "使用更稳定的网络连接"
            ])
        
        if "脚本执行时间过长" in bottleneck:
            recommendations.extend([
                "优化脚本逻辑，减少不必要的操作",
                "增加执行超时和恢复机制",
                "分批处理大型任务"
            ])
        
        if network_status in [NetworkStatus.MODERATE_FLUCTUATION, NetworkStatus.SEVERE_FLUCTUATION]:
            recommendations.append("启用智能网络波动处理")
        
        if not recommendations:
            recommendations.append("保持当前配置，定期监控")
        
        return recommendations
    
    def _estimate_improvement(self, perf_level: PerformanceLevel, bottleneck: str) -> float:
        """估计改进百分比"""
        if perf_level == PerformanceLevel.EXCELLENT:
            return 0.0
        
        improvement = 0.0
        
        if "网络延迟过高" in bottleneck:
            improvement += 30.0
        
        if "网络抖动严重" in bottleneck:
            improvement += 25.0
        
        if "脚本执行时间过长" in bottleneck:
            improvement += 40.0
        
        # 根据性能等级调整
        if perf_level == PerformanceLevel.CRITICAL:
            improvement *= 1.5
        elif perf_level == PerformanceLevel.POOR:
            improvement *= 1.2
        
        return min(improvement, 80.0)  # 最多估计80%改进
    
    def _determine_priority(self, perf_level: PerformanceLevel, network_status: NetworkStatus) -> int:
        """确定优化优先级"""
        priority_map = {
            PerformanceLevel.CRITICAL: 1,
            PerformanceLevel.POOR: 2,
            PerformanceLevel.FAIR: 3,
            PerformanceLevel.GOOD: 4,
            PerformanceLevel.EXCELLENT: 5,
        }
        
        network_priority_map = {
            NetworkStatus.DISCONNECTED: 1,
            NetworkStatus.SEVERE_FLUCTUATION: 2,
            NetworkStatus.MODERATE_FLUCTUATION: 3,
            NetworkStatus.SLIGHT_FLUCTUATION: 4,
            NetworkStatus.STABLE: 5,
        }
        
        # 取较低（更紧急）的优先级
        perf_priority = priority_map.get(perf_level, 3)
        net_priority = network_priority_map.get(network_status, 3)
        
        return min(perf_priority, net_priority)
    
    def _handle_performance_issue(self, analysis: PerformanceAnalysis):
        """处理性能问题"""
        self.logger.warning(f"检测到性能问题: {analysis.bottleneck}")
        self.logger.warning(f"性能等级: {analysis.performance_level.value}")
        self.logger.warning(f"网络状态: {analysis.network_status.value}")
        self.logger.warning(f"优化建议: {analysis.recommendations}")
        
        # 根据优先级采取不同措施
        if analysis.priority <= 2:  # 高优先级问题
            self._apply_emergency_optimizations(analysis)
        elif analysis.priority <= 3:  # 中等优先级问题
            self._apply_standard_optimizations(analysis)
    
    def _apply_emergency_optimizations(self, analysis: PerformanceAnalysis):
        """应用紧急优化"""
        self.logger.info("应用紧急优化措施")
        
        # 增加网络重试
        if self.config["optimization_rules"]["network_retry"]["enabled"]:
            max_retries = self.config["optimization_rules"]["network_retry"]["max_retries"]
            retry_delay = self.config["optimization_rules"]["network_retry"]["retry_delay"]
            self.logger.info(f"启用网络重试: 最大重试次数={max_retries}, 重试延迟={retry_delay}秒")
        
        # 调整超时时间
        if self.config["optimization_rules"]["timeout_adjustment"]["enabled"]:
            base_timeout = self.config["optimization_rules"]["timeout_adjustment"]["base_timeout"]
            adjustment_factor = self.config["optimization_rules"]["timeout_adjustment"]["adjustment_factor"]
            new_timeout = base_timeout * adjustment_factor
            self.logger.info(f"调整超时时间: {base_timeout}秒 -> {new_timeout}秒")
    
    def _apply_standard_optimizations(self, analysis: PerformanceAnalysis):
        """应用标准优化"""
        self.logger.info("应用标准优化措施")
        
        for recommendation in analysis.recommendations:
            self.logger.info(f"执行优化建议: {recommendation}")
    
    def get_recent_metrics(self, count: int = 10) -> List[PerformanceMetrics]:
        """获取最近的性能指标"""
        return self.history[-count:] if self.history else []
    
    def get_performance_summary(self) -> Dict[str, Any]:
        """获取性能摘要"""
        if not self.history:
            return {"status": "无数据"}
        
        recent_data = self.history[-10:] if len(self.history) >= 10 else self.history
        
        # 计算统计数据
        exec_times = [m.execution_time for m in recent_data if m.execution_time > 0]
        latencies = [m.network_latency for m in recent_data]
        
        summary = {
            "script_name": self.script_name,
            "monitoring_duration": len(self.history),
            "avg_execution_time": statistics.mean(exec_times) if exec_times else 0.0,
            "avg_network_latency": statistics.mean(latencies) if latencies else 0.0,
            "current_cpu_usage": recent_data[-1].cpu_usage if recent_data else 0.0,
            "current_memory_usage": recent_data[-1].memory_usage if recent_data else 0.0,
            "performance_level": self._analyze_performance().performance_level.value,
            "network_status": self._analyze_performance().network_status.value,
        }
        
        return summary
    
    def save_report(self, report_path: Optional[str] = None):
        """保存性能报告"""
        if not report_path:
            report_dir = "/root/.openclaw/workspace/石器时代脚本性能监控系统/reports"
            os.makedirs(report_dir, exist_ok=True)
            report_path = os.path.join(report_dir, f"{self.script_name}_performance_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json")
        
        report = {
            "script_name": self.script_name,
            "report_time": datetime.now().isoformat(),
            "monitoring_duration": len(self.history),
            "performance_summary": self.get_performance_summary(),
            "recent_metrics": [m.to_dict() for m in self.get_recent_metrics(20)],
            "performance_analysis": {
                "level": self._analyze_performance().performance_level.value,
                "network_status": self._analyze_performance().network_status.value,
                "bottleneck": self._analyze_performance().bottleneck,
                "recommendations": self._analyze_performance().recommendations,
                "estimated_improvement": self._analyze_performance().estimated_improvement,
                "priority": self._analyze_performance().priority,
            },
            "optimization_history": []
        }
        
        try:
            with open(report_path, 'w', encoding='utf-8') as f:
                json.dump(report, f, ensure_ascii=False, indent=2)
            self.logger.info(f"性能报告已保存: {report_path}")
            return report_path
        except Exception as e:
            self.logger.error(f"保存性能报告失败: {e}")
            return None


# 使用示例
if __name__ == "__main__":
    import os
    
    # 创建监控器实例
    monitor = PerformanceMonitor("NG25跑环脚本")
    
    # 开始监控
    monitor.start_monitoring()
    
    try:
        # 模拟脚本执行
        print("性能监控已启动，按Ctrl+C停止...")
        
        # 模拟执行一些任务
        for i in range(30):
            # 模拟执行时间
            execution_time = 2.0 + (i % 10) * 0.5  # 2.0-6.5秒
            
            # 更新执行时间指标
            if monitor.history:
                monitor.history[-1].execution_time = execution_time
            
            # 获取性能摘要
            if i % 5 == 0:
                summary = monitor.get_performance_summary()
                print(f"\n[{i+1}/30] 性能摘要:")
                for key, value in summary.items():
                    print(f"  {key}: {value}")
            
            time.sleep(1.0)
        
        # 保存报告
        report_path = monitor.save_report()
        if report_path:
            print(f"\n性能报告已保存: {report_path}")
        
    except KeyboardInterrupt:
        print("\n用户中断监控")
    finally:
        # 停止监控
        monitor.stop_monitoring()
        print("性能监控已停止")