#!/usr/bin/env python3
"""
窗口管理测试脚本

在Windows环境中测试游戏窗口管理功能。
需要实际的石器时代游戏客户端运行。
"""

import sys
import os
import time

# 添加src目录到Python路径
current_dir = os.path.dirname(os.path.abspath(__file__))
src_dir = os.path.join(current_dir, '..', 'src')
sys.path.insert(0, src_dir)

def print_header(title):
    """打印标题"""
    print("\n" + "=" * 60)
    print(f"🎮 {title}")
    print("=" * 60)

def test_window_finding():
    """测试窗口查找功能"""
    print_header("窗口查找测试")
    
    try:
        from monitor.window_manager import WindowManager
        
        print("初始化窗口管理器...")
        wm = WindowManager()
        print("✅ 窗口管理器初始化成功")
        
        print(f"\n查找游戏窗口 (标题包含: '{wm.game_config.window_title}')...")
        print("请确保石器时代游戏客户端已启动...")
        
        try:
            # 查找游戏窗口
            window_info = wm.find_game_window(timeout=10)
            
            if window_info:
                print("✅ 找到游戏窗口！")
                print(f"\n窗口详细信息:")
                print(f"  标题: {window_info.title}")
                print(f"  句柄 (HWND): {window_info.hwnd}")
                print(f"  类名: {window_info.class_name}")
                print(f"  状态: {window_info.state.value}")
                print(f"  位置: ({window_info.rect[0]}, {window_info.rect[1]})")
                print(f"  大小: {window_info.width} x {window_info.height}")
                print(f"  进程ID: {window_info.process_id}")
                print(f"  线程ID: {window_info.thread_id}")
                print(f"  可见: {window_info.is_visible}")
                print(f"  启用: {window_info.is_enabled}")
                print(f"  激活: {window_info.is_active}")
                
                return window_info
            else:
                print("❌ 未找到游戏窗口")
                print("可能原因:")
                print("1. 游戏未启动")
                print("2. 窗口标题不匹配")
                print("3. 游戏以管理员权限运行，而测试脚本没有")
                return None
                
        except Exception as e:
            print(f"❌ 查找窗口时出错: {e}")
            return None
            
    except Exception as e:
        print(f"❌ 初始化窗口管理器失败: {e}")
        import traceback
        traceback.print_exc()
        return None

def test_window_control(window_info):
    """测试窗口控制功能"""
    if not window_info:
        print("⚠️  没有窗口信息，跳过窗口控制测试")
        return False
    
    print_header("窗口控制测试")
    
    try:
        from monitor.window_manager import WindowManager
        
        wm = WindowManager()
        hwnd = window_info.hwnd
        
        print(f"测试窗口控制 (HWND: {hwnd})")
        
        # 测试1: 激活窗口
        print("\n1. 测试激活窗口...")
        success = wm.activate_window(hwnd)
        if success:
            print("✅ 窗口激活成功")
            time.sleep(1)  # 等待窗口激活
        else:
            print("⚠️  窗口激活失败")
        
        # 测试2: 获取窗口信息
        print("\n2. 测试获取窗口信息...")
        info = wm.get_window_info(hwnd)
        if info:
            print("✅ 获取窗口信息成功")
            print(f"   当前状态: {info.state.value}")
            print(f"   是否激活: {info.is_active}")
        else:
            print("❌ 获取窗口信息失败")
        
        # 测试3: 最小化/恢复窗口
        print("\n3. 测试窗口最小化/恢复...")
        
        # 最小化
        print("   正在最小化窗口...")
        if wm.minimize_window(hwnd):
            print("   ✅ 窗口最小化成功")
            time.sleep(2)
        else:
            print("   ⚠️  窗口最小化失败")
        
        # 恢复
        print("   正在恢复窗口...")
        if wm.restore_window(hwnd):
            print("   ✅ 窗口恢复成功")
            time.sleep(2)
        else:
            print("   ⚠️  窗口恢复失败")
        
        # 测试4: 移动窗口
        print("\n4. 测试移动窗口...")
        current_x, current_y = window_info.position
        new_x = current_x + 100
        new_y = current_y + 100
        
        print(f"   从 ({current_x}, {current_y}) 移动到 ({new_x}, {new_y})")
        if wm.move_window(hwnd, x=new_x, y=new_y):
            print("   ✅ 窗口移动成功")
            time.sleep(1)
            
            # 移回原位置
            wm.move_window(hwnd, x=current_x, y=current_y)
            print("   ✅ 窗口移回原位置")
        else:
            print("   ⚠️  窗口移动失败")
        
        # 测试5: 窗口状态监控
        print("\n5. 测试窗口状态监控...")
        print("   监控窗口状态变化 (5秒)...")
        
        states = []
        for i in range(5):
            state = wm.monitor_window_state(hwnd, interval=1)
            states.append(state.value)
            print(f"   第{i+1}秒: {state.value}")
        
        print(f"   状态变化: {', '.join(states)}")
        
        print("\n🎉 窗口控制测试完成！")
        return True
        
    except Exception as e:
        print(f"❌ 窗口控制测试失败: {e}")
        import traceback
        traceback.print_exc()
        return False

def test_window_screenshot(window_info):
    """测试窗口截图功能"""
    if not window_info:
        print("⚠️  没有窗口信息，跳过截图测试")
        return False
    
    print_header("窗口截图测试")
    
    try:
        from monitor.window_manager import WindowManager
        
        wm = WindowManager()
        hwnd = window_info.hwnd
        
        print("测试窗口截图功能...")
        
        # 测试全窗口截图
        print("\n1. 测试全窗口截图...")
        screenshot = wm.get_window_screenshot(hwnd)
        
        if screenshot:
            print("✅ 截图成功！")
            print(f"   截图大小: {screenshot.size}")
            print(f"   截图模式: {screenshot.mode}")
            
            # 保存截图
            screenshot_path = os.path.join(current_dir, "window_screenshot.png")
            screenshot.save(screenshot_path)
            print(f"   截图已保存: {screenshot_path}")
        else:
            print("❌ 截图失败")
        
        # 测试区域截图
        print("\n2. 测试区域截图...")
        if screenshot:
            # 截取窗口左上角 200x200 区域
            region = (
                window_info.rect[0],
                window_info.rect[1],
                window_info.rect[0] + 200,
                window_info.rect[1] + 200
            )
            
            region_screenshot = wm.get_window_screenshot(hwnd, region=region)
            if region_screenshot:
                print("✅ 区域截图成功！")
                print(f"   区域大小: {region_screenshot.size}")
                
                # 保存区域截图
                region_path = os.path.join(current_dir, "window_region_screenshot.png")
                region_screenshot.save(region_path)
                print(f"   区域截图已保存: {region_path}")
            else:
                print("❌ 区域截图失败")
        
        print("\n🎉 窗口截图测试完成！")
        return True
        
    except Exception as e:
        print(f"❌ 窗口截图测试失败: {e}")
        print("注意: 截图功能需要PIL库，请确保已安装: pip install pillow")
        import traceback
        traceback.print_exc()
        return False

def test_multiple_windows():
    """测试多窗口管理"""
    print_header("多窗口管理测试")
    
    try:
        from monitor.window_manager import WindowManager
        
        wm = WindowManager()
        
        print("查找所有包含'石器时代'的窗口...")
        windows = wm.find_windows_by_title("石器时代")
        
        if windows:
            print(f"✅ 找到 {len(windows)} 个石器时代窗口")
            
            for i, window in enumerate(windows):
                print(f"\n窗口 {i+1}:")
                print(f"  标题: {window.title}")
                print(f"  句柄: {window.hwnd}")
                print(f"  大小: {window.width} x {window.height}")
                print(f"  进程ID: {window.process_id}")
                
                # 尝试激活每个窗口
                print(f"  正在激活...")
                if wm.activate_window(window.hwnd):
                    print(f"  ✅ 激活成功")
                    time.sleep(1)
                else:
                    print(f"  ⚠️  激活失败")
        else:
            print("⚠️  未找到石器时代窗口")
            print("尝试查找所有窗口...")
            
            all_windows = wm.get_all_windows()
            print(f"系统中共有 {len(all_windows)} 个窗口")
            
            # 显示前10个窗口
            for i, window in enumerate(all_windows[:10]):
                print(f"{i+1}. {window.title[:50]}... (HWND: {window.hwnd})")
        
        print("\n🎉 多窗口管理测试完成！")
        return True
        
    except Exception as e:
        print(f"❌ 多窗口管理测试失败: {e}")
        import traceback
        traceback.print_exc()
        return False

def test_error_handling():
    """测试错误处理"""
    print_header("错误处理测试")
    
    try:
        from monitor.window_manager import WindowManager
        from core.exceptions import WindowNotFoundError
        
        wm = WindowManager()
        
        print("测试错误情况处理...")
        
        # 测试1: 查找不存在的窗口
        print("\n1. 测试查找不存在的窗口...")
        try:
            wm.find_game_window(title="这个窗口肯定不存在", timeout=3)
            print("❌ 应该抛出异常但未抛出")
        except WindowNotFoundError as e:
            print(f"✅ 正确抛出异常: {e}")
        except Exception as e:
            print(f"⚠️  抛出异常但类型不对: {type(e).__name__}: {e}")
        
        # 测试2: 操作无效窗口句柄
        print("\n2. 测试操作无效窗口句柄...")
        try:
            wm.activate_window(999999)  # 无效句柄
            print("❌ 应该抛出异常但未抛出")
        except Exception as e:
            print(f"✅ 正确抛出异常: {type(e).__name__}: {e}")
        
        # 测试3: 获取无效窗口信息
        print("\n3. 测试获取无效窗口信息...")
        info = wm.get_window_info(999999)
        if info is None:
            print("✅ 正确处理无效窗口，返回None")
        else:
            print("❌ 应该返回None但返回了信息")
        
        print("\n🎉 错误处理测试完成！")
        return True
        
    except Exception as e:
        print(f"❌ 错误处理测试失败: {e}")
        import traceback
        traceback.print_exc()
        return False

def main():
    """主测试函数"""
    print("🦖 石器时代游戏客户端集成工具 - 窗口管理测试")
    print("=" * 60)
    print("测试环境: Windows 10/11 + 石器时代客户端")
    print("=" * 60)
    print("重要提示:")
    print("1. 请先启动石器时代游戏客户端")
    print("2. 建议以管理员身份运行此测试脚本")
    print("3. 测试过程中请不要操作游戏窗口")
    print("=" * 60)
    
    test_results = {}
    
    try:
        # 运行各个测试
        window_info = test_window_finding()
        test_results["窗口查找"] = "通过" if window_info else "失败"
        
        if window_info:
            control_result = test_window_control(window_info)
            test_results["窗口控制"] = "通过" if control_result else "失败"
            
            screenshot_result = test_window_screenshot(window_info)
            test_results["窗口截图"] = "通过" if screenshot_result else "失败"
        else:
            test_results["窗口控制"] = "跳过"
            test_results["窗口截图"] = "跳过"
        
        multi_result = test_multiple_windows()
        test_results["多窗口管理"] = "通过" if multi_result else "失败"
        
        error_result = test_error_handling()
        test_results["错误处理"] = "通过" if error_result else "失败"
        
        # 生成测试报告
        print_header("测试报告")
        
        passed = sum(1 for result in test_results.values() if result == "通过")
        total = len(test_results)
        
        print("测试结果汇总:")
        for test_name, result in test_results.items():
            status = "✅" if result == "通过" else "❌" if result == "失败" else "⚠️"
            print(f"  {status} {test_name}: {result}")
        
        print(f"\n🏁 总体结果: {passed}/{total} 项测试通过")
        
        if passed == total:
            print("\n🎉 恭喜！所有窗口管理测试通过！")
        else:
            print("\n⚠️  部分测试失败，请检查错误信息。")
        
        print("\n" + "=" * 60)
        print("📝 测试完成")
        print("=" * 60)
        print("窗口管理功能测试完成。")
        print("如果测试中发现问题，请记录错误信息并反馈。")
        
        return 0 if passed == total else 1
        
    except KeyboardInterrupt:
        print("\n\n⏹️  测试被用户中断")
        return 1
    except Exception as e:
        print(f"\n❌ 测试过程发生未预期错误: {e}")
        import traceback
        traceback.print_exc()
        return 1

if __name__ == "__main__":
    sys.exit(main())