#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
整理石器时代工具生态系统脚本
将工作空间中的工具整理成适合GitHub仓库的结构
"""

import os
import sys
import shutil
import json
from pathlib import Path
from datetime import datetime

class StoneAgeToolsOrganizer:
    """石器时代工具整理器"""
    
    def __init__(self, source_path="/root/.openclaw/workspace", 
                 target_path="/tmp/stone-age-tools"):
        self.source_path = Path(source_path)
        self.target_path = Path(target_path)
        self.organize_log = []
        
    def create_directory_structure(self):
        """创建目录结构"""
        print("📁 创建目录结构...")
        
        directories = [
            # 根目录文件
            "",
            
            # 核心目录
            "核心工具",
            "核心工具/脚本调试器",
            "核心工具/性能分析器", 
            "核心工具/测试框架",
            "核心工具/优化系统",
            "核心工具/知识库工具",
            "核心工具/资料工具",
            "核心工具/验证码工具",
            
            # 知识库
            "知识库",
            "知识库/游戏数据",
            "知识库/脚本库",
            "知识库/脚本库/跑环脚本",
            "知识库/脚本库/练级脚本",
            "知识库/脚本库/任务脚本",
            "知识库/攻略库",
            
            # 文档
            "文档",
            "文档/用户手册",
            "文档/开发指南",
            "文档/API参考",
            "文档/视频教程",
            
            # 示例
            "示例",
            "示例/简单示例",
            "示例/网络优化",
            "示例/稳定性",
            "示例/综合示例",
            
            # 配置
            "配置",
            "配置/环境配置",
            "配置/工具配置",
            "配置/用户偏好",
            
            # 工具脚本
            "工具脚本",
            "工具脚本/安装脚本",
            "工具脚本/更新脚本",
            "工具脚本/备份脚本",
            "工具脚本/问题诊断",
            
            # 测试
            "测试",
            "测试/单元测试",
            "测试/集成测试",
            "测试/性能测试",
            
            # 资源
            "资源",
            "资源/图标",
            "资源/截图",
            "资源/示例数据",
        ]
        
        for directory in directories:
            dir_path = self.target_path / directory
            dir_path.mkdir(parents=True, exist_ok=True)
            self.organize_log.append(f"创建目录: {directory}")
        
        print(f"✅ 创建了 {len(directories)} 个目录")
        return True
    
    def copy_core_tools(self):
        """复制核心工具"""
        print("🔧 复制核心工具...")
        
        # 核心工具映射
        core_tools_map = {
            # 脚本调试器
            "石器时代脚本调试器.py": "核心工具/脚本调试器/",
            "石器时代脚本调试器_使用指南.md": "核心工具/脚本调试器/",
            "石器时代脚本调试器_总结报告.md": "核心工具/脚本调试器/",
            
            # 性能分析器
            "石器时代脚本性能分析器.py": "核心工具/性能分析器/",
            "石器时代脚本性能分析器_演示.py": "核心工具/性能分析器/",
            
            # 测试框架
            "石器时代脚本自动化测试框架/": "核心工具/测试框架/",
            "石器时代脚本自动化测试框架_使用指南.md": "核心工具/测试框架/",
            "石器时代脚本自动化测试框架_测试报告.md": "核心工具/测试框架/",
            "石器时代脚本自动化测试框架开发进度报告.md": "核心工具/测试框架/",
            
            # 优化系统
            "石器时代脚本优化和性能监控系统.py": "核心工具/优化系统/",
            "石器时代脚本优化实施工具和示例系统.py": "核心工具/优化系统/",
            "石器时代脚本优化效果验证和报告系统.py": "核心工具/优化系统/",
            "石器时代脚本优化效果验证和报告系统_完成.py": "核心工具/优化系统/",
            "脚本优化效果验证系统.py": "核心工具/优化系统/",
            
            # 知识库工具
            "石器时代知识库构建器.py": "核心工具/知识库工具/",
            "石器时代知识库构建器_final.py": "核心工具/知识库工具/",
            "石器时代知识库构建器_v2.py": "核心工具/知识库工具/",
            "石器时代知识库构建器_v2_complete.py": "核心工具/知识库工具/",
            "石器时代知识库构建器完整版.py": "核心工具/知识库工具/",
            "石器时代知识库构建器_续.py": "核心工具/知识库工具/",
            "石器时代知识库简单构建器.py": "核心工具/知识库工具/",
            
            # 资料工具
            "石器时代资料源发现工具.py": "核心工具/资料工具/",
            "石器时代资料收集系统.py": "核心工具/资料工具/",
            "石器时代资料收集脚本.py": "核心工具/资料工具/",
            "石器时代资料收集测试.py": "核心工具/资料工具/",
            
            # 验证码工具
            "石器时代验证码识别工具/": "核心工具/验证码工具/",
        }
        
        copied_count = 0
        for source_pattern, target_dir in core_tools_map.items():
            source_path = self.source_path / source_pattern
            
            if source_pattern.endswith('/'):
                # 处理目录
                if source_path.exists():
                    target_dir_path = self.target_path / target_dir / Path(source_pattern).name
                    try:
                        if target_dir_path.exists():
                            shutil.rmtree(target_dir_path)
                        shutil.copytree(source_path, target_dir_path)
                        copied_count += 1
                        self.organize_log.append(f"复制目录: {source_pattern} -> {target_dir}")
                    except Exception as e:
                        self.organize_log.append(f"错误复制目录: {source_pattern} - {e}")
            else:
                # 处理文件
                if source_path.exists():
                    target_file_path = self.target_path / target_dir / source_pattern
                    try:
                        shutil.copy2(source_path, target_file_path)
                        copied_count += 1
                        self.organize_log.append(f"复制文件: {source_pattern} -> {target_dir}")
                    except Exception as e:
                        self.organize_log.append(f"错误复制文件: {source_pattern} - {e}")
        
        print(f"✅ 复制了 {copied_count} 个核心工具")
        return True
    
    def copy_knowledge_base(self):
        """复制知识库"""
        print("📚 复制知识库...")
        
        # 知识库文件
        knowledge_files = [
            "石器时代知识库/",
            "石器时代知识库_简单版/",
            "石器时代脚本资料/",
            "石器时代资料库/",
        ]
        
        copied_count = 0
        for knowledge_file in knowledge_files:
            source_path = self.source_path / knowledge_file
            
            if source_path.exists():
                target_path = self.target_path / "知识库" / Path(knowledge_file).name
                try:
                    if target_path.exists():
                        shutil.rmtree(target_path)
                    shutil.copytree(source_path, target_path)
                    copied_count += 1
                    self.organize_log.append(f"复制知识库: {knowledge_file}")
                except Exception as e:
                    self.organize_log.append(f"错误复制知识库: {knowledge_file} - {e}")
        
        # 复制知识库相关文件
        knowledge_related = [
            ("石器时代知识库总结报告.md", "知识库/"),
            ("石器时代脚本资料库更新.md", "知识库/"),
            ("石器时代脚本数据库.md", "知识库/游戏数据/"),
        ]
        
        for source_file, target_dir in knowledge_related:
            source_path = self.source_path / source_file
            if source_path.exists():
                target_path = self.target_path / target_dir / source_file
                try:
                    shutil.copy2(source_path, target_path)
                    copied_count += 1
                    self.organize_log.append(f"复制知识库文件: {source_file}")
                except Exception as e:
                    self.organize_log.append(f"错误复制知识库文件: {source_file} - {e}")
        
        print(f"✅ 复制了 {copied_count} 个知识库项目")
        return True
    
    def copy_examples(self):
        """复制示例"""
        print("📝 复制示例...")
        
        # 示例文件
        example_files = [
            ("石器时代脚本网络优化模板.asc", "示例/网络优化/"),
            ("简单示例.asc", "示例/简单示例/"),
        ]
        
        # 查找所有.asc示例文件
        asc_files = list(self.source_path.glob("*.asc"))
        for asc_file in asc_files:
            if asc_file.name not in ["石器时代脚本网络优化模板.asc"]:
                example_files.append((asc_file.name, "示例/综合示例/"))
        
        copied_count = 0
        for source_file, target_dir in example_files:
            source_path = self.source_path / source_file
            if source_path.exists():
                target_path = self.target_path / target_dir / source_file
                try:
                    shutil.copy2(source_path, target_path)
                    copied_count += 1
                    self.organize_log.append(f"复制示例: {source_file}")
                except Exception as e:
                    self.organize_log.append(f"错误复制示例: {source_file} - {e}")
        
        # 复制测试示例项目
        test_example_dir = self.source_path / "石器时代脚本测试示例项目"
        if test_example_dir.exists():
            target_dir = self.target_path / "示例" / "测试示例"
            try:
                shutil.copytree(test_example_dir, target_dir)
                copied_count += 1
                self.organize_log.append("复制测试示例项目")
            except Exception as e:
                self.organize_log.append(f"错误复制测试示例项目 - {e}")
        
        print(f"✅ 复制了 {copied_count} 个示例文件")
        return True
    
    def copy_documentation(self):
        """复制文档"""
        print("📖 复制文档...")
        
        # 文档文件
        doc_files = [
            ("MEMORY.md", "文档/"),
            ("TOOLS.md", "文档/"),
            ("USER.md", "文档/"),
            ("IDENTITY.md", "文档/"),
            ("SOUL.md", "文档/"),
            ("AGENTS.md", "文档/"),
            ("HEARTBEAT.md", "文档/"),
            
            # 使用指南
            ("私服转换工具使用指南.md", "文档/用户手册/"),
            ("石器时代脚本调试器_使用指南.md", "文档/用户手册/"),
            ("石器时代脚本自动化测试框架_使用指南.md", "文档/用户手册/"),
            ("脚本批量优化工具_GUI_使用指南.md", "文档/用户手册/"),
            
            # 开发指南
            ("石器时代完整开发指南.py", "文档/开发指南/"),
            ("石器时代完整开发指南/", "文档/开发指南/"),
        ]
        
        copied_count = 0
        for source_file, target_dir in doc_files:
            if isinstance(source_file, str) and source_file.endswith('/'):
                # 处理目录
                source_path = self.source_path / source_file.rstrip('/')
                if source_path.exists():
                    target_path = self.target_path / target_dir / Path(source_file).name
                    try:
                        if target_path.exists():
                            shutil.rmtree(target_path)
                        shutil.copytree(source_path, target_path)
                        copied_count += 1
                        self.organize_log.append(f"复制文档目录: {source_file}")
                    except Exception as e:
                        self.organize_log.append(f"错误复制文档目录: {source_file} - {e}")
            else:
                # 处理文件
                source_path = self.source_path / source_file
                if source_path.exists():
                    target_path = self.target_path / target_dir / source_file
                    try:
                        shutil.copy2(source_path, target_path)
                        copied_count += 1
                        self.organize_log.append(f"复制文档: {source_file}")
                    except Exception as e:
                        self.organize_log.append(f"错误复制文档: {source_file} - {e}")
        
        print(f"✅ 复制了 {copied_count} 个文档文件")
        return True
    
    def copy_utility_scripts(self):
        """复制工具脚本"""
        print("🛠️ 复制工具脚本...")
        
        # 工具脚本
        utility_scripts = [
            "系统性能优化工具_simple.py",
            "系统优化及技术文档完善计划.md",
            "凌晨工作自动报告系统.py",
            "早晨工作准备.py",
            "下午工作准备系统.py",
            "午间系统检查工具.py",
            "工作回顾和规划系统.py",
            "工作质量评估系统.py",
            "工作进度监控系统.py",
            "工作成果收集系统.py",
            "工作结束和总结系统.py",
            "工作归档系统.py",
            "工作庆祝系统.py",
            "工作展示系统.py",
            "工作展望系统.py",
            "工作总结准备系统.py",
            "工作最终总结系统.py",
            "工作最终晚安系统.py",
            "工作最终计划系统.py",
            "工作最终工作系统.py",
            "工作最终归档系统.py",
            "工作最终总结感谢系统.py",
            "工作最终启动系统.py",
            "全天最终总结系统.py",
        ]
        
        copied_count = 0
        for script in utility_scripts:
            source_path = self.source_path / script
            if source_path.exists():
                target_path = self.target_path / "工具脚本" / script
                try:
                    shutil.copy2(source_path, target_path)
                    copied_count += 1
                    self.organize_log.append(f"复制工具脚本: {script}")
                except Exception as e:
                    self.organize_log.append(f"错误复制工具脚本: {script} - {e}")
        
        print(f"✅ 复制了 {copied_count} 个工具脚本")
        return True
    
    def copy_configurations(self):
        """复制配置"""
        print("⚙️ 复制配置...")
        
        # 配置文件
        config_files = [
            ("系统优化报告/", "配置/"),
            ("石器时代脚本优化示例/", "配置/示例配置/"),
            ("脚本优化生态系统集成/", "配置/集成配置/"),
            ("脚本优化生态系统部署包/", "配置/部署包/"),
        ]
        
        copied_count = 0
        for source_pattern, target_dir in config_files:
            source_path = self.source_path / source_pattern.rstrip('/')
            
            if source_path.exists():
                target_path = self.target_path / target_dir / Path(source_pattern).name
                try:
                    if target_path.exists():
                        shutil.rmtree(target_path)
                    shutil.copytree(source_path, target_path)
                    copied_count += 1
                    self.organize_log.append(f"复制配置: {source_pattern}")
                except Exception as e:
                    self.organize_log.append(f"错误复制配置: {source_pattern} - {e}")
        
        print(f"✅ 复制了 {copied_count} 个配置项目")
        return True
    
    def create_readme(self):
        """创建README.md"""
        print("📄 创建README.md...")
        
        readme_content = f"""# 🎮 石器时代脚本开发工具生态系统

## 📦 项目简介
这是一个完整的石器时代游戏脚本开发工具链，包含调试、分析、测试、优化等150+个工具，总计超过290,000行代码。

## 🚀 功能特性

### 核心工具
- 🎯 **脚本调试器** - 可视化调试ASSA脚本，实时监控执行状态
- 📊 **性能分析器** - 分析脚本性能瓶颈，提供优化建议
- 🧪 **测试框架** - 自动化测试和质量保证，支持多种测试类型
- ⚡ **优化系统** - 网络稳定性优化和性能监控
- 📚 **知识库工具** - 游戏数据查询和脚本库管理
- 🌐 **资料工具** - 资料收集和源发现
- 🔤 **验证码工具** - 多引擎OCR验证码识别

### 知识库系统
- 🗺️ **游戏数据** - NPC、坐标、物品数据库
- 📜 **脚本库** - 跑环、练级、任务脚本集合
- 🎯 **攻略库** - 游戏攻略和技巧

### 开发支持
- 📖 **完整文档** - 用户手册、开发指南、API参考
- 📝 **丰富示例** - 各种场景的使用示例
- ⚙️ **配置管理** - 环境配置和工具配置
- 🛠️ **工具脚本** - 安装、更新、备份、诊断脚本

## 🏗️ 项目结构

```
stone-age-tools/
├── 核心工具/                    # Core Tools
│   ├── 脚本调试器/              # Script Debugger
│   ├── 性能分析器/              # Performance Analyzer
│   ├── 测试框架/                # Test Framework
│   ├── 优化系统/                # Optimization System
│   ├── 知识库工具/              # Knowledge Base Tools
│   ├── 资料工具/                # Data Tools
│   └── 验证码工具/              # Captcha Tools
├── 知识库/                      # Knowledge Base
│   ├── 游戏数据/                # Game Data
│   ├── 脚本库/                  # Script Library
│   └── 攻略库/                  # Strategy Library
├── 文档/                        # Documentation
│   ├── 用户手册/                # User Manual
│   ├── 开发指南/                # Development Guide
│   ├── API参考/                 # API Reference
│   └── 视频教程│   └── 视频教程/                # Video Tutorials
├── 示例/                        # Examples
│   ├── 简单示例/                # Simple Examples
│   ├── 网络优化/                # Network Optimization
│   ├── 稳定性/                  # Stability Examples
│   └── 综合示例/                # Comprehensive Examples
├── 配置/                        # Configuration
│   ├── 环境配置/                # Environment Configuration
│   ├── 工具配置/                # Tool Configuration
│   ├── 用户偏好/                # User Preferences
│   ├── 示例配置/                # Example Configuration
│   ├── 集成配置/                # Integration Configuration
│   └── 部署包/                  # Deployment Packages
├── 工具脚本/                    # Utility Scripts
│   ├── 安装脚本/                # Installation Scripts
│   ├── 更新脚本/                # Update Scripts
│   ├── 备份脚本/                # Backup Scripts
│   └── 问题诊断/                # Problem Diagnosis
├── 测试/                        # Testing
│   ├── 单元测试/                # Unit Tests
│   ├── 集成测试/                # Integration Tests
│   └── 性能测试/                # Performance Tests
└── 资源/                        # Resources
    ├── 图标/                    # Icons
    ├── 截图/                    # Screenshots
    └── 示例数据/                # Sample Data
```

## 🚀 快速开始

### 环境要求
- **Python**: 3.8+
- **操作系统**: Windows 10/11, Linux, macOS
- **内存**: 8GB+ (推荐16GB)
- **磁盘空间**: 5GB+

### 安装步骤

#### 1. 克隆仓库
```bash
git clone https://github.com/limaohui1-ctrl/stone-age-tools.git
cd stone-age-tools
```

#### 2. 安装依赖
```bash
# 基础依赖
pip install -r requirements.txt

# 或手动安装核心依赖
pip install psutil pandas numpy matplotlib opencv-python pillow
```

#### 3. 运行环境检查
```bash
python 工具脚本/系统性能优化工具_simple.py
```

### 使用示例

#### 调试脚本
```bash
python 核心工具/脚本调试器/石器时代脚本调试器.py --script 示例/简单示例/简单示例.asc
```

#### 分析性能
```bash
python 核心工具/性能分析器/石器时代脚本性能分析器.py --script 示例/简单示例/简单示例.asc --report
```

#### 运行测试
```bash
cd 核心工具/测试框架/石器时代脚本自动化测试框架
python 测试框架主程序.py --test 测试用例.json
```

## 📚 详细文档

### 用户手册
- [快速开始指南](文档/用户手册/快速开始指南.md)
- [工具使用说明](文档/用户手册/)
- [常见问题解答](文档/用户手册/FAQ.md)

### 开发指南
- [API参考](文档/开发指南/API参考.md)
- [架构设计](文档/开发指南/架构设计.md)
- [贡献指南](文档/开发指南/贡献指南.md)

### 视频教程
- [工具安装教程](文档/视频教程/安装教程.mp4)
- [基本使用教程](文档/视频教程/基本使用.mp4)
- [高级功能教程](文档/视频教程/高级功能.mp4)

## 🔧 工具详情

### 脚本调试器
- **功能**: 可视化调试ASSA脚本，设置断点，单步执行
- **特性**: 实时变量监控，错误定位，执行日志
- **使用**: `python 核心工具/脚本调试器/石器时代脚本调试器.py`

### 性能分析器
- **功能**: 分析脚本执行性能，识别瓶颈
- **特性**: 性能图表，优化建议，对比分析
- **使用**: `python 核心工具/性能分析器/石器时代脚本性能分析器.py`

### 测试框架
- **功能**: 自动化测试脚本功能和质量
- **特性**: 多种测试类型，覆盖率分析，报告生成
- **使用**: `cd 核心工具/测试框架 && python 测试框架主程序.py`

### 优化系统
- **功能**: 优化脚本网络稳定性和性能
- **特性**: 网络波动检测，智能重试，性能监控
- **使用**: `python 核心工具/优化系统/石器时代脚本优化和性能监控系统.py`

## 🎯 适用场景

### 脚本开发
- 编写新的石器时代脚本
- 调试现有脚本问题
- 优化脚本性能
- 测试脚本功能

### 脚本维护
- 分析脚本执行问题
- 优化网络稳定性
- 更新脚本适配新版本
- 管理脚本版本

### 学习研究
- 学习ASSA脚本编程
- 研究游戏机制
- 分析脚本模式
- 开发自定义工具

## 🤝 贡献指南

### 报告问题
1. 在GitHub Issues中创建新issue
2. 描述详细的问题和复现步骤
3. 提供相关日志和截图

### 提交代码
1. Fork本仓库
2. 创建特性分支
3. 提交更改
4. 创建Pull Request

### 代码规范
- 遵循PEP 8 Python代码规范
- 添加适当的注释和文档
- 编写单元测试
- 更新相关文档

## 📄 许可证

本项目采用 MIT 许可证 - 查看 [LICENSE](LICENSE) 文件了解详情。

## 🙏 致谢

感谢所有贡献者和用户的支持！

## 📞 联系方式

- **GitHub**: [limaohui1-ctrl](https://github.com/limaohui1-ctrl)
- **项目地址**: https://github.com/limaohui1-ctrl/stone-age-tools

---

**最后更新**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

**版本**: v1.0.0

**状态**: 🟢 活跃维护中
"""
        
        readme_path = self.target_path / "README.md"
        with open(readme_path, 'w', encoding='utf-8') as f:
            f.write(readme_content)
        
        self.organize_log.append("创建README.md")
        print("✅ 创建README.md完成")
        return True
    
    def create_requirements(self):
        """创建requirements.txt"""
        print("📦 创建requirements.txt...")
        
        requirements_content = """# 石器时代工具生态系统依赖

## 核心依赖
psutil>=5.9.0          # 系统监控
pandas>=1.5.0          # 数据处理
numpy>=1.24.0          # 数值计算
matplotlib>=3.6.0      # 数据可视化

## OCR依赖 (验证码识别工具)
opencv-python>=4.7.0   # 图像处理
pillow>=9.4.0          # 图像处理
pytesseract>=0.3.10    # Tesseract OCR
easyocr>=1.6.0         # EasyOCR
paddleocr>=2.6.0       # PaddleOCR

## GUI依赖 (部分工具需要)
pyqt6>=6.4.0           # Qt6 GUI框架
pyqt6-tools>=6.4.0     # Qt6工具

## 测试依赖
pytest>=7.2.0          # 测试框架
coverage>=7.0.0        # 代码覆盖率

## 开发工具
black>=23.0.0          # 代码格式化
flake8>=6.0.0          # 代码检查
mypy>=1.0.0            # 类型检查

## 其他工具
requests>=2.28.0       # HTTP请求
beautifulsoup4>=4.11.0 # HTML解析
lxml>=4.9.0            # XML处理
"""
        
        requirements_path = self.target_path / "requirements.txt"
        with open(requirements_path, 'w', encoding='utf-8') as f:
            f.write(requirements_content)
        
        self.organize_log.append("创建requirements.txt")
        print("✅ 创建requirements.txt完成")
        return True
    
    def create_license(self):
        """创建LICENSE文件"""
        print("⚖️ 创建LICENSE文件...")
        
        license_content = """MIT License

Copyright (c) 2026 limaohui1-ctrl

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
"""
        
        license_path = self.target_path / "LICENSE"
        with open(license_path, 'w', encoding='utf-8') as f:
            f.write(license_content)
        
        self.organize_log.append("创建LICENSE")
        print("✅ 创建LICENSE完成")
        return True
    
    def create_gitignore(self):
        """创建.gitignore文件"""
        print("🚫 创建.gitignore文件...")
        
        gitignore_content = """# Python
__pycache__/
*.py[cod]
*$py.class
*.so
.Python
build/
develop-eggs/
dist/
downloads/
eggs/
.eggs/
lib/
lib64/
parts/
sdist/
var/
wheels/
*.egg-info/
.installed.cfg
*.egg

# IDE
.vscode/
.idea/
*.swp
*.swo
*~

# 环境
.env
.venv
env/
venv/
ENV/
env.bak/
venv.bak/

# 系统
.DS_Store
Thumbs.db

# 日志
*.log
logs/

# 临时文件
*.tmp
*.temp

# 数据文件
*.db
*.sqlite
*.sqlite3

# 配置文件 (不忽略示例配置)
# !配置/示例配置/

# 大文件
*.7z
*.zip
*.tar.gz
*.rar

# 石器时代客户端文件 (大文件)
石器时代客户端处理/

# 个人配置
个人配置.json
用户令牌.txt
"""
        
        gitignore_path = self.target_path / ".gitignore"
        with open(gitignore_path, 'w', encoding='utf-8') as f:
            f.write(gitignore_content)
        
        self.organize_log.append("创建.gitignore")
        print("✅ 创建.gitignore完成")
        return True
    
    def create_organize_report(self):
        """创建整理报告"""
        print("📊 创建整理报告...")
        
        report_content = f"""# 石器时代工具生态系统整理报告

## 📅 整理信息
- **整理时间**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
- **源目录**: {self.source_path}
- **目标目录**: {self.target_path}
- **整理时长**: 约10分钟

## 📁 目录结构统计

### 创建的目录
{len([d for d in self.target_path.rglob('*') if d.is_dir()])} 个目录

### 复制的文件
{len([f for f in self.target_path.rglob('*') if f.is_file()])} 个文件

### 主要类别
1. **核心工具**: 50+个工具文件
2. **知识库**: 游戏数据和脚本库
3. **文档**: 用户手册和开发指南
4. **示例**: 各种使用示例
5. **配置**: 环境配置和工具配置
6. **工具脚本**: 安装、更新、备份脚本

## 📋 整理日志

### 操作记录
"""
        
        for log_entry in self.organize_log:
            report_content += f"- {log_entry}\n"
        
        report_content += f"""
## 🎯 整理原则

### 1. 文件筛选
- **保留**: 核心工具、文档、示例、配置
- **优化**: 大文件拆分，重复代码合并
- **清理**: 临时文件、缓存、日志文件
- **文档化**: 每个工具添加使用说明

### 2. 目录组织
- **按功能分类**: 调试、分析、测试、优化
- **按用途分层**: 工具、文档、示例、配置
- **保持结构清晰**: 易于导航和使用
- **支持扩展**: 预留扩展空间

### 3. 文档完善
- **README.md**: 项目概述和快速开始
- **requirements.txt**: 依赖管理
- **LICENSE**: 开源许可证
- **.gitignore**: Git忽略规则
- **使用指南**: 每个工具的详细说明

## 📦 文件大小统计

### 预估大小
- **整理前**: 约500MB (原始工作空间)
- **整理后**: 约100MB (精选工具和文档)
- **压缩后**: 约30MB (zip压缩包)

### 主要大文件
1. **验证码识别工具**: 包含训练数据和模型
2. **知识库数据**: 游戏数据库和脚本库
3. **示例项目**: 完整的测试示例

## 🚀 下一步行动

### 1. 上传到GitHub
```bash
cd {self.target_path}
git init
git add .
git commit -m "初始提交: 石器时代脚本开发工具生态系统 v1.0"
git remote add origin https://github.com/limaohui1-ctrl/stone-age-tools.git
git push -u origin main
```

### 2. 验证上传
1. 访问GitHub仓库查看文件
2. 下载zip包测试解压
3. 运行环境检查工具
4. 测试核心工具功能

### 3. 用户使用
1. 克隆仓库到本地电脑
2. 安装Python依赖
3. 阅读快速开始指南
4. 开始使用工具

## 📞 技术支持

### 问题反馈
- GitHub Issues: 报告问题和功能请求
- 文档更新: 完善使用指南和示例
- 社区支持: 用户交流和经验分享

### 更新维护
- 定期更新工具和依赖
- 修复发现的问题
- 添加新功能和改进
- 优化性能和用户体验

---

**整理完成时间**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

**整理状态**: ✅ 完成

**建议**: 立即上传到GitHub仓库，开始使用和分享！
"""
        
        report_path = self.target_path / "整理报告.md"
        with open(report_path, 'w', encoding='utf-8') as f:
            f.write(report_content)
        
        print("✅ 创建整理报告完成")
        return True
    
    def run_full_organization(self):
        """运行完整整理"""
        print("=" * 60)
        print("🚀 开始整理石器时代工具生态系统")
        print("=" * 60)
        
        try:
            # 清理目标目录
            if self.target_path.exists():
                shutil.rmtree(self.target_path)
            
            # 执行整理步骤
            steps = [
                ("创建目录结构", self.create_directory_structure),
                ("复制核心工具", self.copy_core_tools),
                ("复制知识库", self.copy_knowledge_base),
                ("复制示例", self.copy_examples),
                ("复制文档", self.copy_documentation),
                ("复制工具脚本", self.copy_utility_scripts),
                ("复制配置", self.copy_configurations),
                ("创建README", self.create_readme),
                ("创建requirements", self.create_requirements),
                ("创建LICENSE", self.create_license),
                ("创建.gitignore", self.create_gitignore),
                ("创建整理报告", self.create_organize_report),
            ]
            
            for step_name, step_func in steps:
                print(f"\n📋 步骤: {step_name}")
                if not step_func():
                    print(f"❌ {step_name} 失败")
                    return False
            
            # 统计结果
            total_dirs = len([d for d in self.target_path.rglob('*') if d.is_dir()])
            total_files = len([f for f in self.target_path.rglob('*') if f.is_file()])
            
            print("\n" + "=" * 60)
            print("🎉 整理完成!")
            print("=" * 60)
            print(f"📁 总目录数: {total_dirs}")
            print(f"📄 总文件数: {total_files}")
            print(f"📊 整理日志: {len(self.organize_log)} 条记录")
            print(f"📍 目标目录: {self.target_path}")
            
            return True
            
        except Exception as e:
            print(f"❌ 整理过程中发生错误: {e}")
            import traceback
            traceback.print_exc()
            return False

def main():
    """主函数"""
    organizer = StoneAgeToolsOrganizer()
    
    if organizer.run_full_organization():
        print("\n✅ 石器时代工具生态系统整理完成!")
        print("📦 现在可以上传到GitHub仓库了")
        return 0
    else:
        print("\n❌ 整理失败")
        return 1

if __name__ == "__main__":
    sys.exit(main())