#!/usr/bin/env python3
"""
石器时代资料收集测试
简单测试web-content-fetcher功能
"""

import os
import subprocess
import json
from datetime import datetime

def test_web_content_fetcher():
    """测试web-content-fetcher功能"""
    print("🔧 测试web-content-fetcher功能")
    
    # 测试网站列表
    test_urls = [
        "https://www.baidu.com/s?wd=石器时代",
        "https://tieba.baidu.com/f?kw=石器时代",
        "https://www.baidu.com/s?wd=ASSA脚本",
    ]
    
    results = []
    
    for url in test_urls:
        print(f"\n🌐 测试URL: {url}")
        
        try:
            # 使用web-content-fetcher
            fetch_script = "/root/.openclaw/workspace/skills/web-content-fetcher/fetch.sh"
            
            cmd = [fetch_script, url, "jina"]
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=20)
            
            if result.returncode == 0:
                content = result.stdout
                print(f"✅ 获取成功: {len(content)} 字符")
                
                # 简单分析内容
                stone_age_keywords = ["石器时代", "石器", "ASSA", "脚本", "宠物", "地图", "NPC"]
                found_keywords = []
                
                for keyword in stone_age_keywords:
                    if keyword in content:
                        found_keywords.append(keyword)
                
                results.append({
                    "url": url,
                    "success": True,
                    "content_length": len(content),
                    "keywords_found": found_keywords,
                    "keyword_count": len(found_keywords)
                })
                
                print(f"   发现关键词: {found_keywords}")
                
                # 保存内容
                save_test_content(url, content)
                
            else:
                print(f"❌ 获取失败: {result.stderr[:100]}")
                results.append({
                    "url": url,
                    "success": False,
                    "error": result.stderr[:200]
                })
                
        except subprocess.TimeoutExpired:
            print(f"⏰ 获取超时")
            results.append({
                "url": url,
                "success": False,
                "error": "Timeout"
            })
        except Exception as e:
            print(f"❌ 异常: {e}")
            results.append({
                "url": url,
                "success": False,
                "error": str(e)
            })
    
    return results

def save_test_content(url, content):
    """保存测试内容"""
    test_dir = "/root/.openclaw/workspace/石器时代资料收集测试"
    os.makedirs(test_dir, exist_ok=True)
    
    # 生成文件名
    import re
    filename = re.sub(r'[^a-zA-Z0-9]', '_', url)[:50] + ".md"
    filepath = os.path.join(test_dir, filename)
    
    with open(filepath, 'w', encoding='utf-8') as f:
        f.write(f"# 测试URL: {url}\n\n")
        f.write(f"**测试时间**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        f.write(f"**内容长度**: {len(content)} 字符\n\n")
        f.write("---\n\n")
        f.write(content)
    
    print(f"   已保存到: {filepath}")

def generate_test_report(results):
    """生成测试报告"""
    report_dir = "/root/.openclaw/workspace/石器时代资料收集测试"
    os.makedirs(report_dir, exist_ok=True)
    
    report_file = os.path.join(report_dir, "测试报告.md")
    
    total_tests = len(results)
    successful_tests = sum(1 for r in results if r.get('success', False))
    success_rate = (successful_tests / total_tests * 100) if total_tests > 0 else 0
    
    total_keywords = sum(r.get('keyword_count', 0) for r in results if r.get('success', False))
    
    with open(report_file, 'w', encoding='utf-8') as f:
        f.write("# 石器时代资料收集功能测试报告\n\n")
        f.write(f"**测试时间**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        f.write(f"**测试工具**: web-content-fetcher技能\n\n")
        
        f.write("## 测试统计\n\n")
        f.write(f"- **总测试URL**: {total_tests}\n")
        f.write(f"- **成功获取**: {successful_tests}\n")
        f.write(f"- **成功率**: {success_rate:.1f}%\n")
        f.write(f"- **总关键词数**: {total_keywords}\n\n")
        
        f.write("## 详细结果\n\n")
        
        for i, result in enumerate(results, 1):
            f.write(f"### 测试 {i}: {result['url']}\n")
            
            if result.get('success', False):
                f.write(f"- **状态**: ✅ 成功\n")
                f.write(f"- **内容长度**: {result['content_length']} 字符\n")
                f.write(f"- **关键词数**: {result['keyword_count']}\n")
                
                if result['keywords_found']:
                    f.write(f"- **发现的关键词**: {', '.join(result['keywords_found'])}\n")
            else:
                f.write(f"- **状态**: ❌ 失败\n")
                f.write(f"- **错误**: {result.get('error', '未知错误')}\n")
            
            f.write("\n")
        
        f.write("## 结论\n\n")
        
        if success_rate >= 50:
            f.write("✅ **测试通过**: web-content-fetcher功能正常，可以用于石器时代资料收集\n")
            f.write("\n**建议**:\n")
            f.write("1. 可以开始正式的石器时代资料收集工作\n")
            f.write("2. 针对重要网站进行深度抓取\n")
            f.write("3. 建立定期收集机制\n")
        else:
            f.write("⚠️ **测试部分通过**: 需要进一步调试web-content-fetcher功能\n")
            f.write("\n**建议**:\n")
            f.write("1. 检查网络连接和代理设置\n")
            f.write("2. 尝试不同的获取方法（markdown, defuddle）\n")
            f.write("3. 测试更多石器时代相关网站\n")
    
    print(f"\n📊 测试报告已生成: {report_file}")
    
    return report_file

def main():
    """主函数"""
    print("🚀 石器时代资料收集功能测试")
    print("="*60)
    
    # 测试web-content-fetcher
    results = test_web_content_fetcher()
    
    # 生成测试报告
    report_file = generate_test_report(results)
    
    print("\n" + "="*60)
    print("🎉 测试完成!")
    print("="*60)
    
    # 统计结果
    total = len(results)
    success = sum(1 for r in results if r.get('success', False))
    keywords = sum(r.get('keyword_count', 0) for r in results if r.get('success', False))
    
    print(f"📊 测试结果:")
    print(f"  ✅ 成功: {success}/{total}")
    print(f"  🔑 关键词: {keywords} 个")
    print(f"  📄 报告: {report_file}")
    
    print("\n💡 下一步:")
    print("1. 查看测试报告了解详细结果")
    print("2. 如果测试通过，可以开始正式资料收集")
    print("3. 如果测试失败，需要调试web-content-fetcher")

if __name__ == "__main__":
    main()