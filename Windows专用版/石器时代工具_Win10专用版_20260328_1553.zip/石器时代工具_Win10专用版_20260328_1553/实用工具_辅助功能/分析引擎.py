#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
石器时代脚本性能分析引擎
核心功能：分析性能数据，识别瓶颈，生成优化建议
"""

import json
import statistics
import numpy as np
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Tuple
from dataclasses import dataclass
import logging
from enum import Enum


class BottleneckType(Enum):
    """瓶颈类型"""
    NETWORK_LATENCY = "网络延迟"
    NETWORK_JITTER = "网络抖动"
    NETWORK_PACKET_LOSS = "网络丢包"
    CPU_USAGE = "CPU使用率"
    MEMORY_USAGE = "内存使用率"
    EXECUTION_TIME = "执行时间"
    SCRIPT_LOGIC = "脚本逻辑"
    EXTERNAL_DEPENDENCY = "外部依赖"
    UNKNOWN = "未知"


class OptimizationStrategy(Enum):
    """优化策略"""
    NETWORK_RETRY = "网络重试"
    TIMEOUT_ADJUSTMENT = "超时调整"
    BATCH_PROCESSING = "批量处理"
    CACHE_OPTIMIZATION = "缓存优化"
    CONNECTION_POOLING = "连接池优化"
    ASYNC_PROCESSING = "异步处理"
    RESOURCE_LIMITATION = "资源限制"
    LOGIC_OPTIMIZATION = "逻辑优化"
    DEPENDENCY_OPTIMIZATION = "依赖优化"


@dataclass
class BottleneckAnalysis:
    """瓶颈分析结果"""
    bottleneck_type: BottleneckType
    severity: float  # 严重程度 0-1
    impact: float    # 影响程度 0-1
    confidence: float  # 置信度 0-1
    evidence: List[str]  # 证据
    root_cause: str  # 根本原因


@dataclass
class OptimizationPlan:
    """优化计划"""
    strategy: OptimizationStrategy
    description: str
    estimated_effort: float  # 预计工作量 1-5
    estimated_improvement: float  # 预计改进百分比
    priority: int  # 优先级 1-5
    implementation_steps: List[str]
    risks: List[str]
    prerequisites: List[str]


class PerformanceAnalyzer:
    """性能分析器"""
    
    def __init__(self, config_path: Optional[str] = None):
        """
        初始化性能分析器
        
        Args:
            config_path: 配置文件路径
        """
        self.config = self._load_config(config_path)
        self.logger = self._setup_logging()
        
        # 分析规则
        self.analysis_rules = self._load_analysis_rules()
        
        # 历史分析结果
        self.analysis_history: List[Dict[str, Any]] = []
        
    def _load_config(self, config_path: Optional[str]) -> Dict[str, Any]:
        """加载配置"""
        default_config = {
            "analysis_window": 30,  # 分析窗口大小（数据点）
            "trend_window": 10,     # 趋势分析窗口
            "thresholds": {
                "network_latency": {
                    "warning": 100,   # 警告阈值（毫秒）
                    "critical": 300,  # 严重阈值（毫秒）
                },
                "network_jitter": {
                    "warning": 20,    # 警告阈值（毫秒）
                    "critical": 50,   # 严重阈值（毫秒）
                },
                "packet_loss": {
                    "warning": 1.0,   # 警告阈值（%）
                    "critical": 5.0,  # 严重阈值（%）
                },
                "cpu_usage": {
                    "warning": 70.0,  # 警告阈值（%）
                    "critical": 90.0, # 严重阈值（%）
                },
                "memory_usage": {
                    "warning": 80.0,  # 警告阈值（%）
                    "critical": 95.0, # 严重阈值（%）
                },
                "execution_time": {
                    "warning": 5.0,   # 警告阈值（秒）
                    "critical": 10.0, # 严重阈值（秒）
                }
            },
            "correlation_rules": {
                "network_and_execution": {
                    "enabled": True,
                    "threshold": 0.7,  # 相关性阈值
                },
                "cpu_and_memory": {
                    "enabled": True,
                    "threshold": 0.6,
                }
            }
        }
        
        if config_path:
            try:
                with open(config_path, 'r', encoding='utf-8') as f:
                    user_config = json.load(f)
                    default_config.update(user_config)
            except Exception as e:
                logging.warning(f"加载配置文件失败，使用默认配置: {e}")
        
        return default_config
    
    def _setup_logging(self) -> logging.Logger:
        """设置日志"""
        log_dir = "/root/.openclaw/workspace/石器时代脚本性能监控系统/logs"
        import os
        os.makedirs(log_dir, exist_ok=True)
        
        logger = logging.getLogger("PerformanceAnalyzer")
        logger.setLevel(logging.INFO)
        
        if not logger.handlers:
            log_file = os.path.join(log_dir, f"analyzer_{datetime.now().strftime('%Y%m%d')}.log")
            file_handler = logging.FileHandler(log_file, encoding='utf-8')
            file_handler.setLevel(logging.INFO)
            
            console_handler = logging.StreamHandler()
            console_handler.setLevel(logging.INFO)
            
            formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
            file_handler.setFormatter(formatter)
            console_handler.setFormatter(formatter)
            
            logger.addHandler(file_handler)
            logger.addHandler(console_handler)
        
        return logger
    
    def _load_analysis_rules(self) -> Dict[str, Any]:
        """加载分析规则"""
        return {
            "network_analysis": {
                "latency_trend": {
                    "description": "分析网络延迟趋势",
                    "method": self._analyze_latency_trend,
                },
                "jitter_analysis": {
                    "description": "分析网络抖动",
                    "method": self._analyze_jitter,
                },
                "packet_loss_pattern": {
                    "description": "分析丢包模式",
                    "method": self._analyze_packet_loss_pattern,
                }
            },
            "resource_analysis": {
                "cpu_trend": {
                    "description": "分析CPU使用趋势",
                    "method": self._analyze_cpu_trend,
                },
                "memory_trend": {
                    "description": "分析内存使用趋势",
                    "method": self._analyze_memory_trend,
                },
                "resource_correlation": {
                    "description": "分析资源相关性",
                    "method": self._analyze_resource_correlation,
                }
            },
            "execution_analysis": {
                "execution_time_trend": {
                    "description": "分析执行时间趋势",
                    "method": self._analyze_execution_time_trend,
                },
                "error_pattern": {
                    "description": "分析错误模式",
                    "method": self._analyze_error_pattern,
                },
                "success_rate_trend": {
                    "description": "分析成功率趋势",
                    "method": self._analyze_success_rate_trend,
                }
            },
            "correlation_analysis": {
                "network_execution_correlation": {
                    "description": "分析网络与执行时间的相关性",
                    "method": self._analyze_network_execution_correlation,
                },
                "resource_execution_correlation": {
                    "description": "分析资源与执行时间的相关性",
                    "method": self._analyze_resource_execution_correlation,
                }
            }
        }
    
    def analyze_performance_data(self, metrics_data: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        分析性能数据
        
        Args:
            metrics_data: 性能指标数据列表
            
        Returns:
            分析结果
        """
        if not metrics_data:
            return {"error": "无性能数据"}
        
        self.logger.info(f"开始分析性能数据，共{len(metrics_data)}个数据点")
        
        # 提取数据字段
        data = self._extract_data_fields(metrics_data)
        
        # 执行各项分析
        analysis_results = {}
        
        # 网络分析
        network_analysis = self._perform_network_analysis(data)
        if network_analysis:
            analysis_results["network"] = network_analysis
        
        # 资源分析
        resource_analysis = self._perform_resource_analysis(data)
        if resource_analysis:
            analysis_results["resource"] = resource_analysis
        
        # 执行分析
        execution_analysis = self._perform_execution_analysis(data)
        if execution_analysis:
            analysis_results["execution"] = execution_analysis
        
        # 相关性分析
        correlation_analysis = self._perform_correlation_analysis(data)
        if correlation_analysis:
            analysis_results["correlation"] = correlation_analysis
        
        # 识别瓶颈
        bottlenecks = self._identify_bottlenecks(analysis_results)
        
        # 生成优化计划
        optimization_plans = self._generate_optimization_plans(bottlenecks, analysis_results)
        
        # 生成总体评估
        overall_assessment = self._generate_overall_assessment(analysis_results, bottlenecks)
        
        # 保存分析结果
        result = {
            "analysis_time": datetime.now().isoformat(),
            "data_points": len(metrics_data),
            "time_range": {
                "start": metrics_data[0].get("timestamp", ""),
                "end": metrics_data[-1].get("timestamp", ""),
            },
            "overall_assessment": overall_assessment,
            "detailed_analysis": analysis_results,
            "bottlenecks": [b.__dict__ for b in bottlenecks],
            "optimization_plans": [p.__dict__ for p in optimization_plans],
            "recommendations": self._generate_recommendations(bottlenecks, optimization_plans),
        }
        
        # 添加到历史记录
        self.analysis_history.append(result)
        
        self.logger.info("性能数据分析完成")
        return result
    
    def _extract_data_fields(self, metrics_data: List[Dict[str, Any]]) -> Dict[str, List[float]]:
        """提取数据字段"""
        data = {
            "execution_time": [],
            "cpu_usage": [],
            "memory_usage": [],
            "network_latency": [],
            "network_jitter": [],
            "packet_loss": [],
            "success_rate": [],
            "error_count": [],
            "retry_count": [],
            "timestamps": [],
        }
        
        for metric in metrics_data:
            data["execution_time"].append(metric.get("execution_time", 0.0))
            data["cpu_usage"].append(metric.get("cpu_usage", 0.0))
            data["memory_usage"].append(metric.get("memory_usage", 0.0))
            data["network_latency"].append(metric.get("network_latency", 0.0))
            data["network_jitter"].append(metric.get("network_jitter", 0.0))
            data["packet_loss"].append(metric.get("packet_loss", 0.0))
            data["success_rate"].append(metric.get("success_rate", 100.0))
            data["error_count"].append(metric.get("error_count", 0))
            data["retry_count"].append(metric.get("retry_count", 0))
            data["timestamps"].append(metric.get("timestamp", ""))
        
        return data
    
    def _perform_network_analysis(self, data: Dict[str, List[float]]) -> Dict[str, Any]:
        """执行网络分析"""
        results = {}
        
        # 网络延迟分析
        if data["network_latency"]:
            latency_results = self.analysis_rules["network_analysis"]["latency_trend"]["method"](data["network_latency"])
            results["latency"] = latency_results
        
        # 网络抖动分析
        if data["network_jitter"]:
            jitter_results = self.analysis_rules["network_analysis"]["jitter_analysis"]["method"](data["network_jitter"])
            results["jitter"] = jitter_results
        
        # 丢包分析
        if data["packet_loss"]:
            packet_loss_results = self.analysis_rules["network_analysis"]["packet_loss_pattern"]["method"](data["packet_loss"])
            results["packet_loss"] = packet_loss_results
        
        return results if results else None
    
    def _perform_resource_analysis(self, data: Dict[str, List[float]]) -> Dict[str, Any]:
        """执行资源分析"""
        results = {}
        
        # CPU分析
        if data["cpu_usage"]:
            cpu_results = self.analysis_rules["resource_analysis"]["cpu_trend"]["method"](data["cpu_usage"])
            results["cpu"] = cpu_results
        
        # 内存分析
        if data["memory_usage"]:
            memory_results = self.analysis_rules["resource_analysis"]["memory_trend"]["method"](data["memory_usage"])
            results["memory"] = memory_results
        
        # 资源相关性分析
        if data["cpu_usage"] and data["memory_usage"]:
            correlation_results = self.analysis_rules["resource_analysis"]["resource_correlation"]["method"](
                data["cpu_usage"], data["memory_usage"]
            )
            results["resource_correlation"] = correlation_results
        
        return results if results else None
    
    def _perform_execution_analysis(self, data: Dict[str, List[float]]) -> Dict[str, Any]:
        """执行执行分析"""
        results = {}
        
        # 执行时间分析
        if data["execution_time"]:
            execution_results = self.analysis_rules["execution_analysis"]["execution_time_trend"]["method"](data["execution_time"])
            results["execution_time"] = execution_results
        
        # 错误模式分析
        if data["error_count"]:
            error_results = self.analysis_rules["execution_analysis"]["error_pattern"]["method"](data["error_count"])
            results["error_pattern"] = error_results
        
        # 成功率分析
        if data["success_rate"]:
            success_results = self.analysis_rules["execution_analysis"]["success_rate_trend"]["method"](data["success_rate"])
            results["success_rate"] = success_results
        
        return results if results else None
    
    def _perform_correlation_analysis(self, data: Dict[str, List[float]]) -> Dict[str, Any]:
        """执行相关性分析"""
        results = {}
        
        # 网络与执行时间相关性
        if data["network_latency"] and data["execution_time"]:
            network_exec_corr = self.analysis_rules["correlation_analysis"]["network_execution_correlation"]["method"](
                data["network_latency"], data["execution_time"]
            )
            results["network_execution_correlation"] = network_exec_corr
        
        # 资源与执行时间相关性
        if data["cpu_usage"] and data["execution_time"]:
            resource_exec_corr = self.analysis_rules["correlation_analysis"]["resource_execution_correlation"]["method"](
                data["cpu_usage"], data["execution_time"]
            )
            results["resource_execution_correlation"] = resource_exec_corr
        
        return results if results else None
    
    def _analyze_latency_trend(self, latencies: List[float]) -> Dict[str, Any]:
        """分析网络延迟趋势"""
        if not latencies:
            return {"error": "无延迟数据"}
        
        avg_latency = statistics.mean(latencies)
        max_latency = max(latencies)
        min_latency = min(latencies)
        
        # 计算趋势
        if len(latencies) >= 2:
            trend = self._calculate_trend(latencies)
        else:
            trend = "数据不足"
        
        # 检查阈值
        thresholds = self.config["thresholds"]["network_latency"]
        status = "正常"
        if avg_latency > thresholds["critical"]:
            status = "严重"
        elif avg_latency > thresholds["warning"]:
            status = "警告"
        
        return {
            "average": avg_latency,
            "maximum": max_latency,
            "minimum": min_latency,
            "trend": trend,
            "status": status,
            "threshold_exceeded": avg_latency > thresholds["warning"],
        }
    
    def _analyze_jitter(self, jitters: List[float]) -> Dict[str, Any]:
        """分析网络抖动"""
        if not jitters:
            return {"error": "无抖动数据"}
        
        avg_jitter = statistics.mean(jitters)
        max_jitter = max(jitters)
        
        # 检查阈值
        thresholds = self.config["thresholds"]["network_jitter"]
        status = "正常"
        if avg_jitter > thresholds["critical"]:
            status = "严重"
        elif avg_jitter > thresholds["warning"]:
            status = "警告"
        
        return {
            "average": avg_jitter,
            "maximum": max_jitter,
            "status": status,
            "threshold_exceeded": avg_jitter > thresholds["warning"],
        }
    
    def _analyze_packet_loss_pattern(self, packet_losses: List[float]) -> Dict[str, Any]:
        """分析丢包模式"""
        if not packet_losses:
            return {"error": "无丢包数据"}
        
        avg_loss = statistics.mean(packet_losses)
        max_loss = max(packet_losses)
        
        # 检查连续丢包
        consecutive_loss = 0
        max_consecutive = 0
        for loss in packet_losses:
            if loss > 0:
                consecutive_loss += 1
                max_consecutive = max(max_consecutive, consecutive_loss)
            else:
                consecutive_loss = 0
        
        # 检查阈值
        thresholds = self.config["thresholds"]["packet_loss"]
        status = "正常"
        if avg_loss > thresholds["critical"]:
            status = "严重"
        elif avg_loss > thresholds["warning"]:
            status = "警告"
        
        return {
            "average": avg_loss,
            "maximum": max_loss,
            "max_consecutive": max_consecutive,
            "status": status,
            "threshold_exceeded": avg_loss > thresholds["warning"],
            "pattern": "连续丢包" if max_consecutive >= 3 else "随机丢包",
        }
    
    def _analyze_cpu_trend(self, cpu_usages: List[float]) -> Dict[str, Any]:
        """分析CPU使用趋势"""
        if not cpu_usages:
            return {"error": "无CPU数据"}
        
        avg_cpu = statistics.mean(cpu_usages)
        max_cpu = max(cpu_usages)
        
        # 检查峰值持续时间
        high_cpu_count = sum(1 for cpu in cpu_usages if cpu > 80)
        high_cpu_percentage = (high_cpu_count / len(cpu_usages)) * 100
        
        # 检查阈值
        thresholds = self.config["thresholds"]["cpu_usage"]
        status = "正常"
        if avg_cpu > thresholds["critical"]:
            status = "严重"
        elif avg_cpu > thresholds["warning"]:
            status = "警告"
        
        return {
            "average": avg_cpu,
            "maximum": max_cpu,
            "high_usage_percentage": high_cpu_percentage,
            "status": status,
            "threshold_exceeded": avg_cpu > thresholds["warning"],
        }
    
    def _analyze_memory_trend(self, memory_usages: List[float]) -> Dict[str, Any]:
        """分析内存使用趋势"""
        if not memory_usages:
            return {"error": "无内存数据"}
        
        avg_memory = statistics.mean(memory_usages)
        max_memory = max(memory_usages)
        
        # 检查内存泄漏模式
        if len(memory_usages) >= 10:
            # 计算最后10个点的趋势
            recent_trend = self._calculate_trend(memory_usages[-10:])
            memory_leak_suspected = recent_trend == "上升" and avg_memory > 70
        else:
            memory_leak_suspected = False
        
        # 检查阈值
        thresholds = self.config["thresholds"]["memory_usage"]
        status = "正常"
        if avg_memory > thresholds["critical"]:
            status = "严重"
        elif avg_memory > thresholds["warning"]:
            status = "警告"
        
        return {
            "average": avg_memory,
            "maximum": max_memory,
            "memory_leak_suspected": memory_leak_suspected,
            "status": status,
            "threshold_exceeded": avg_memory > thresholds["warning"],
        }
    
    def _analyze_resource_correlation(self, cpu_usages: List[float], memory_usages: List[float]) -> Dict[str, Any]:
        """分析资源相关性"""
        if len(cpu_usages) != len(memory_usages) or len(cpu_usages) < 2:
            return {"error": "数据不足"}
        
        # 计算相关性
        try:
            correlation = np.corrcoef(cpu_usages, memory_usages)[0, 1]
        except:
            correlation = 0.0
        
        # 解释相关性
        if abs(correlation) > 0.7:
            correlation_strength = "强"
        elif abs(correlation) > 0.3:
            correlation_strength = "中等"
        else:
            correlation_strength = "弱"
        
        correlation_direction = "正相关" if correlation > 0 else "负相关"
        
        return {
            "correlation_coefficient": correlation,
            "strength": correlation_strength,
            "direction": correlation_direction,
            "interpretation": f"CPU和内存使用率{correlation_direction}，相关性{correlation_strength}",
        }
    
    def _analyze_execution_time_trend(self, execution_times: List[float]) -> Dict[str, Any]:
        """分析执行时间趋势"""
        if not execution_times:
            return {"error": "无执行时间数据"}
        
        avg_time = statistics.mean(execution_times)
        max_time = max(execution_times)
        min_time = min(execution_times)
        
        # 计算趋势
        if len(execution_times) >= 2:
            trend = self._calculate_trend(execution_times)
        else:
            trend = "数据不足"
        
        # 检查异常值
        if len(execution_times) >= 5:
            q1 = np.percentile(execution_times, 25)
            q3 = np.percentile(execution_times, 75)
            iqr = q3 - q1
            outliers = [t for t in execution_times if t < q1 - 1.5*iqr or t > q3 + 1.5*iqr]
            outlier_percentage = (len(outliers) / len(execution_times)) * 100
        else:
            outliers = []
            outlier_percentage = 0.0
        
        # 检查阈值
        thresholds = self.config["thresholds"]["execution_time"]
        status = "正常"
        if avg_time > thresholds["critical"]:
            status = "严重"
        elif avg_time > thresholds["warning"]:
            status = "警告"
        
        return {
            "average": avg_time,
            "maximum": max_time,
            "minimum": min_time,
            "trend": trend,
            "outlier_percentage": outlier_percentage,
            "status": status,
            "threshold_exceeded": avg_time > thresholds["warning"],
        }
    
    def _analyze_error_pattern(self, error_counts: List[int]) -> Dict[str, Any]:
        """分析错误模式"""
        if not error_counts:
            return {"error": "无错误数据"}
        
        total_errors = sum(error_counts)
        avg_errors = statistics.mean(error_counts)
        max_errors = max(error_counts)
        
        # 检查错误模式
        error_pattern = "随机错误"
        if len(error_counts) >= 5:
            # 检查是否错误集中在特定时间段
            error_indices = [i for i, count in enumerate(error_counts) if count > 0]
            if error_indices:
                error_cluster_size = max(error_indices) - min(error_indices) + 1
                if error_cluster_size <= len(error_counts) * 0.3:  # 错误集中在30%的时间内
                    error_pattern = "集中错误"
        
        return {
            "total_errors": total_errors,
            "average_errors": avg_errors,
            "maximum_errors": max_errors,
            "error_pattern": error_pattern,
            "error_rate": (total_errors / len(error_counts)) * 100 if len(error_counts) > 0 else 0,
        }
    
    def _analyze_success_rate_trend(self, success_rates: List[float]) -> Dict[str, Any]:
        """分析成功率趋势"""
        if not success_rates:
            return {"error": "无成功率数据"}
        
        avg_success = statistics.mean(success_rates)
        min_success = min(success_rates)
        
        # 计算趋势
        if len(success_rates) >= 2:
            trend = self._calculate_trend(success_rates)
        else:
            trend = "数据不足"
        
        # 检查低成功率时段
        low_success_periods = sum(1 for rate in success_rates if rate < 90)
        low_success_percentage = (low_success_periods / len(success_rates)) * 100
        
        return {
            "average": avg_success,
            "minimum": min_success,
            "trend": trend,
            "low_success_percentage": low_success_percentage,
            "stability": "稳定" if avg_success > 95 else "不稳定",
        }
    
    def _analyze_network_execution_correlation(self, latencies: List[float], execution_times: List[float]) -> Dict[str, Any]:
        """分析网络与执行时间的相关性"""
        if len(latencies) != len(execution_times) or len(latencies) < 2:
            return {"error": "数据不足"}
        
        # 计算相关性
        try:
            correlation = np.corrcoef(latencies, execution_times)[0, 1]
        except:
            correlation = 0.0
        
        # 检查配置阈值
        threshold = self.config["correlation_rules"]["network_and_execution"]["threshold"]
        
        return {
            "correlation_coefficient": correlation,
            "significant": abs(correlation) > threshold,
            "interpretation": self._interpret_correlation(correlation, "网络延迟", "执行时间"),
            "recommendation": "优化网络连接" if correlation > 0.5 else "无需特别优化",
        }
    
    def _analyze_resource_execution_correlation(self, cpu_usages: List[float], execution_times: List[float]) -> Dict[str, Any]:
        """分析资源与执行时间的相关性"""
        if len(cpu_usages) != len(execution_times) or len(cpu_usages) < 2:
            return {"error": "数据不足"}
        
        # 计算相关性
        try:
            correlation = np.corrcoef(cpu_usages, execution_times)[0, 1]
        except:
            correlation = 0.0
        
        return {
            "correlation_coefficient": correlation,
            "interpretation": self._interpret_correlation(correlation, "CPU使用率", "执行时间"),
            "recommendation": "优化资源使用" if correlation > 0.6 else "资源使用正常",
        }
    
    def _calculate_trend(self, values: List[float]) -> str:
        """计算趋势"""
        if len(values) < 2:
            return "数据不足"
        
        # 使用线性回归计算趋势
        try:
            x = list(range(len(values)))
            slope = np.polyfit(x, values, 1)[0]
            
            if slope > 0.1:
                return "上升"
            elif slope < -0.1:
                return "下降"
            else:
                return "平稳"
        except:
            return "无法计算"
    
    def _interpret_correlation(self, correlation: float, var1: str, var2: str) -> str:
        """解释相关性"""
        abs_corr = abs(correlation)
        
        if abs_corr > 0.7:
            strength = "强"
        elif abs_corr > 0.3:
            strength = "中等"
        else:
            strength = "弱"
        
        direction = "正相关" if correlation > 0 else "负相关"
        
        return f"{var1}与{var2}{direction}，相关性{strength}"
    
    def _identify_bottlenecks(self, analysis_results: Dict[str, Any]) -> List[BottleneckAnalysis]:
        """识别瓶颈"""
        bottlenecks = []
        
        # 检查网络瓶颈
        if "network" in analysis_results:
            network_analysis = analysis_results["network"]
            
            # 网络延迟瓶颈
            if "latency" in network_analysis and network_analysis["latency"].get("threshold_exceeded"):
                bottlenecks.append(BottleneckAnalysis(
                    bottleneck_type=BottleneckType.NETWORK_LATENCY,
                    severity=0.8 if network_analysis["latency"]["status"] == "严重" else 0.5,
                    impact=0.7,
                    confidence=0.9,
                    evidence=[f"平均延迟: {network_analysis['latency']['average']:.1f}ms"],
                    root_cause="网络连接质量差或服务器响应慢"
                ))
            
            # 网络抖动瓶颈
            if "jitter" in network_analysis and network_analysis["jitter"].get("threshold_exceeded"):
                bottlenecks.append(BottleneckAnalysis(
                    bottleneck_type=BottleneckType.NETWORK_JITTER,
                    severity=0.6,
                    impact=0.5,
                    confidence=0.8,
                    evidence=[f"平均抖动: {network_analysis['jitter']['average']:.1f}ms"],
                    root_cause="网络不稳定或带宽不足"
                ))
        
        # 检查资源瓶颈
        if "resource" in analysis_results:
            resource_analysis = analysis_results["resource"]
            
            # CPU瓶颈
            if "cpu" in resource_analysis and resource_analysis["cpu"].get("threshold_exceeded"):
                bottlenecks.append(BottleneckAnalysis(
                    bottleneck_type=BottleneckType.CPU_USAGE,
                    severity=0.7 if resource_analysis["cpu"]["status"] == "严重" else 0.4,
                    impact=0.6,
                    confidence=0.85,
                    evidence=[f"平均CPU使用率: {resource_analysis['cpu']['average']:.1f}%"],
                    root_cause="脚本计算密集或系统负载高"
                ))
            
            # 内存瓶颈
            if "memory" in resource_analysis and resource_analysis["memory"].get("threshold_exceeded"):
                bottlenecks.append(BottleneckAnalysis(
                    bottleneck_type=BottleneckType.MEMORY_USAGE,
                    severity=0.8 if resource_analysis["memory"]["status"] == "严重" else 0.5,
                    impact=0.7,
                    confidence=0.9,
                    evidence=[f"平均内存使用率: {resource_analysis['memory']['average']:.1f}%"],
                    root_cause="内存泄漏或内存不足"
                ))
        
        # 检查执行瓶颈
        if "execution" in analysis_results:
            execution_analysis = analysis_results["execution"]
            
            # 执行时间瓶颈
            if "execution_time" in execution_analysis and execution_analysis["execution_time"].get("threshold_exceeded"):
                bottlenecks.append(BottleneckAnalysis(
                    bottleneck_type=BottleneckType.EXECUTION_TIME,
                    severity=0.9 if execution_analysis["execution_time"]["status"] == "严重" else 0.6,
                    impact=0.8,
                    confidence=0.95,
                    evidence=[f"平均执行时间: {execution_analysis['execution_time']['average']:.1f}秒"],
                    root_cause="脚本逻辑复杂或外部依赖慢"
                ))
        
        # 如果没有找到具体瓶颈，但性能不佳
        if not bottlenecks and "overall_assessment" in analysis_results:
            if analysis_results["overall_assessment"].get("performance_level") in ["较差", "严重"]:
                bottlenecks.append(BottleneckAnalysis(
                    bottleneck_type=BottleneckType.UNKNOWN,
                    severity=0.5,
                    impact=0.5,
                    confidence=0.3,
                    evidence=["总体性能不佳但具体原因不明"],
                    root_cause="需要进一步分析"
                ))
        
        return bottlenecks
    
    def _generate_optimization_plans(self, bottlenecks: List[BottleneckAnalysis], 
                                   analysis_results: Dict[str, Any]) -> List[OptimizationPlan]:
        """生成优化计划"""
        plans = []
        
        for bottleneck in bottlenecks:
            if bottleneck.bottleneck_type == BottleneckType.NETWORK_LATENCY:
                plans.append(OptimizationPlan(
                    strategy=OptimizationStrategy.NETWORK_RETRY,
                    description="增加网络重试机制，处理网络延迟问题",
                    estimated_effort=2.0,
                    estimated_improvement=30.0,
                    priority=1,
                    implementation_steps=[
                        "在网络请求失败时自动重试",
                        "实现指数退避重试策略",
                        "添加网络状态监控",
                        "优化重试超时时间",
                    ],
                    risks=["可能增加总体执行时间"],
                    prerequisites=["需要修改网络请求代码"],
                ))
                
                plans.append(OptimizationPlan(
                    strategy=OptimizationStrategy.TIMEOUT_ADJUSTMENT,
                    description="调整网络超时时间，适应网络波动",
                    estimated_effort=1.5,
                    estimated_improvement=20.0,
                    priority=2,
                    implementation_steps=[
                        "根据网络延迟动态调整超时时间",
                        "实现自适应超时算法",
                        "添加超时日志记录",
                    ],
                    risks=["超时时间过长可能导致响应慢"],
                    prerequisites=["需要访问网络配置"],
                ))
            
            elif bottleneck.bottleneck_type == BottleneckType.EXECUTION_TIME:
                plans.append(OptimizationPlan(
                    strategy=OptimizationStrategy.BATCH_PROCESSING,
                    description="使用批量处理减少执行时间",
                    estimated_effort=3.0,
                    estimated_improvement=40.0,
                    priority=1,
                    implementation_steps=[
                        "分析可批量处理的操作",
                        "实现批量处理逻辑",
                        "优化批量大小",
                        "添加批量处理监控",
                    ],
                    risks=["批量处理可能增加内存使用"],
                    prerequisites=["需要重构部分脚本逻辑"],
                ))
                
                plans.append(OptimizationPlan(
                    strategy=OptimizationStrategy.ASYNC_PROCESSING,
                    description="使用异步处理提高并发性能",
                    estimated_effort=4.0,
                    estimated_improvement=50.0,
                    priority=2,
                    implementation_steps=[
                        "识别可异步执行的操作",
                        "实现异步处理框架",
                        "优化线程/协程池大小",
                        "添加异步错误处理",
                    ],
                    risks=["异步编程复杂度高"],
                    prerequisites=["需要Python 3.7+支持异步"],
                ))
        
        # 如果没有具体瓶颈，提供通用优化建议
        if not plans:
            plans.append(OptimizationPlan(
                strategy=OptimizationStrategy.LOGIC_OPTIMIZATION,
                description="优化脚本逻辑，提高整体性能",
                estimated_effort=2.5,
                estimated_improvement=25.0,
                priority=3,
                implementation_steps=[
                    "分析脚本执行流程",
                    "识别性能热点",
                    "优化循环和条件判断",
                    "减少不必要的计算",
                ],
                risks=["可能引入新的错误"],
                prerequisites=["需要完整的脚本代码"],
            ))
        
        # 根据优先级排序
        plans.sort(key=lambda x: x.priority)
        
        return plans
    
    def _generate_overall_assessment(self, analysis_results: Dict[str, Any], 
                                   bottlenecks: List[BottleneckAnalysis]) -> Dict[str, Any]:
        """生成总体评估"""
        assessment = {
            "performance_level": "优秀",
            "stability": "稳定",
            "recommendation": "保持当前配置",
            "risk_level": "低",
        }
        
        # 根据瓶颈严重程度调整评估
        if bottlenecks:
            max_severity = max(b.impact * b.severity for b in bottlenecks)
            
            if max_severity > 0.6:
                assessment["performance_level"] = "严重"
                assessment["stability"] = "不稳定"
                assessment["recommendation"] = "立即优化"
                assessment["risk_level"] = "高"
            elif max_severity > 0.3:
                assessment["performance_level"] = "一般"
                assessment["stability"] = "基本稳定"
                assessment["recommendation"] = "建议优化"
                assessment["risk_level"] = "中"
            elif max_severity > 0.1:
                assessment["performance_level"] = "良好"
                assessment["stability"] = "稳定"
                assessment["recommendation"] = "可优化"
                assessment["risk_level"] = "低"
        
        # 添加瓶颈数量信息
        assessment["bottleneck_count"] = len(bottlenecks)
        assessment["critical_bottlenecks"] = [b.bottleneck_type.value for b in bottlenecks if b.severity > 0.5]
        
        return assessment
    
    def _generate_recommendations(self, bottlenecks: List[BottleneckAnalysis], 
                                optimization_plans: List[OptimizationPlan]) -> List[str]:
        """生成推荐建议"""
        recommendations = []
        
        if not bottlenecks:
            recommendations.append("性能良好，保持当前配置")
            return recommendations
        
        # 根据瓶颈类型生成建议
        for bottleneck in bottlenecks:
            if bottleneck.bottleneck_type == BottleneckType.NETWORK_LATENCY:
                recommendations.append("优化网络连接，减少延迟")
            elif bottleneck.bottleneck_type == BottleneckType.NETWORK_JITTER:
                recommendations.append("稳定网络连接，减少抖动")
            elif bottleneck.bottleneck_type == BottleneckType.CPU_USAGE:
                recommendations.append("优化CPU使用，减少计算负载")
            elif bottleneck.bottleneck_type == BottleneckType.MEMORY_USAGE:
                recommendations.append("优化内存使用，防止内存泄漏")
            elif bottleneck.bottleneck_type == BottleneckType.EXECUTION_TIME:
                recommendations.append("优化脚本逻辑，减少执行时间")
        
        # 添加优化计划建议
        for plan in optimization_plans[:3]:  # 只取前3个最重要的
            recommendations.append(f"实施{plan.strategy.value}: {plan.description}")
        
        return recommendations
    
    def save_analysis_report(self, analysis_result: Dict[str, Any], 
                           report_path: Optional[str] = None) -> str:
        """保存分析报告"""
        if not report_path:
            report_dir = "/root/.openclaw/workspace/石器时代脚本性能监控系统/reports"
            import os
            os.makedirs(report_dir, exist_ok=True)
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            report_path = os.path.join(report_dir, f"performance_analysis_{timestamp}.json")
        
        try:
            with open(report_path, 'w', encoding='utf-8') as f:
                json.dump(analysis_result, f, ensure_ascii=False, indent=2)
            self.logger.info(f"分析报告已保存: {report_path}")
            return report_path
        except Exception as e:
            self.logger.error(f"保存分析报告失败: {e}")
            return ""
    
    def generate_summary_report(self, analysis_result: Dict[str, Any]) -> str:
        """生成摘要报告"""
        summary = []
        summary.append("=" * 60)
        summary.append("石器时代脚本性能分析报告")
        summary.append("=" * 60)
        summary.append(f"分析时间: {analysis_result.get('analysis_time', '未知')}")
        summary.append(f"数据点数: {analysis_result.get('data_points', 0)}")
        
        # 总体评估
        overall = analysis_result.get('overall_assessment', {})
        summary.append(f"\n总体评估:")
        summary.append(f"  性能等级: {overall.get('performance_level', '未知')}")
        summary.append(f"  稳定性: {overall.get('stability', '未知')}")
        summary.append(f"  风险等级: {overall.get('risk_level', '未知')}")
        summary.append(f"  瓶颈数量: {overall.get('bottleneck_count', 0)}")
        
        # 瓶颈信息
        bottlenecks = analysis_result.get('bottlenecks', [])
        if bottlenecks:
            summary.append(f"\n检测到的瓶颈:")
            for i, bottleneck in enumerate(bottlenecks, 1):
                summary.append(f"  {i}. {bottleneck.get('bottleneck_type', '未知')}")
                summary.append(f"     严重程度: {bottleneck.get('severity', 0):.1%}")
                summary.append(f"     影响程度: {bottleneck.get('impact', 0):.1%}")
                summary.append(f"     根本原因: {bottleneck.get('root_cause', '未知')}")
        
        # 优化建议
        recommendations = analysis_result.get('recommendations', [])
        if recommendations:
            summary.append(f"\n优化建议:")
            for i, rec in enumerate(recommendations, 1):
                summary.append(f"  {i}. {rec}")
        
        # 优化计划
        optimization_plans = analysis_result.get('optimization_plans', [])
        if optimization_plans:
            summary.append(f"\n优化计划 (前3个):")
            for i, plan in enumerate(optimization_plans[:3], 1):
                summary.append(f"  {i}. {plan.get('strategy', '未知')}")
                summary.append(f"     描述: {plan.get('description', '')}")
                summary.append(f"     预计改进: {plan.get('estimated_improvement', 0):.1f}%")
                summary.append(f"     优先级: {plan.get('priority', 5)}")
        
        summary.append("\n" + "=" * 60)
        summary.append("报告结束")
        summary.append("=" * 60)
        
        return "\n".join(summary)


# 使用示例
if __name__ == "__main__":
    import os
    import random
    
    # 创建分析器实例
    analyzer = PerformanceAnalyzer()
    
    # 生成模拟性能数据
    print("生成模拟性能数据...")
    metrics_data = []
    for i in range(50):
        metric = {
            "timestamp": (datetime.now() - timedelta(minutes=i)).isoformat(),
            "execution_time": random.uniform(1.0, 8.0),
            "cpu_usage": random.uniform(20.0, 85.0),
            "memory_usage": random.uniform(30.0, 90.0),
            "network_latency": random.uniform(50.0, 350.0),
            "network_jitter": random.uniform(5.0, 60.0),
            "packet_loss": random.uniform(0.0, 8.0),
            "success_rate": random.uniform(85.0, 100.0),
            "error_count": random.randint(0, 3),
            "retry_count": random.randint(0, 2),
        }
        metrics_data.append(metric)
    
    print(f"生成{len(metrics_data)}个模拟数据点")
    
    # 分析性能数据
    print("\n开始分析性能数据...")
    analysis_result = analyzer.analyze_performance_data(metrics_data)
    
    # 保存详细报告
    report_path = analyzer.save_analysis_report(analysis_result)
    if report_path:
        print(f"详细报告已保存: {report_path}")
    
    # 生成并显示摘要报告
    summary = analyzer.generate_summary_report(analysis_result)
    print("\n" + summary)
    
    print("\n性能分析完成！")