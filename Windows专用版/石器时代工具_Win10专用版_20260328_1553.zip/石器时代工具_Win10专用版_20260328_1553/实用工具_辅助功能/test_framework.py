#!/usr/bin/env python3
"""
石器时代脚本自动化测试框架 - 核心框架
版本: 1.0.0
创建时间: 2026-03-25 04:15
"""

import os
import sys
import json
import time
import logging
import subprocess
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any, Callable
from enum import Enum
from pathlib import Path
import threading
from datetime import datetime

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class TestStatus(Enum):
    """测试状态枚举"""
    PENDING = "pending"
    RUNNING = "running"
    PASSED = "passed"
    FAILED = "failed"
    ERROR = "error"
    SKIPPED = "skipped"

class AssertionType(Enum):
    """断言类型枚举"""
    EQUAL = "equal"
    NOT_EQUAL = "not_equal"
    CONTAINS = "contains"
    NOT_CONTAINS = "not_contains"
    REGEX_MATCH = "regex_match"
    GREATER_THAN = "greater_than"
    LESS_THAN = "less_than"
    IS_TRUE = "is_true"
    IS_FALSE = "is_false"
    IS_NONE = "is_none"
    IS_NOT_NONE = "is_not_none"

@dataclass
class TestResult:
    """测试结果数据类"""
    test_id: str
    test_name: str
    status: TestStatus
    execution_time: float
    start_time: datetime
    end_time: datetime
    assertions: List[Dict[str, Any]] = field(default_factory=list)
    error_message: Optional[str] = None
    stack_trace: Optional[str] = None
    logs: List[str] = field(default_factory=list)
    
    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return {
            "test_id": self.test_id,
            "test_name": self.test_name,
            "status": self.status.value,
            "execution_time": self.execution_time,
            "start_time": self.start_time.isoformat(),
            "end_time": self.end_time.isoformat(),
            "assertions": self.assertions,
            "error_message": self.error_message,
            "stack_trace": self.stack_trace,
            "logs": self.logs
        }

@dataclass
class TestCase:
    """测试用例数据类"""
    test_id: str
    name: str
    description: str
    script_path: str
    setup_script: Optional[str] = None
    teardown_script: Optional[str] = None
    timeout: int = 30
    expected_output: Optional[str] = None
    assertions: List[Dict[str, Any]] = field(default_factory=list)
    tags: List[str] = field(default_factory=list)
    dependencies: List[str] = field(default_factory=list)
    
    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return {
            "test_id": self.test_id,
            "name": self.name,
            "description": self.description,
            "script_path": self.script_path,
            "setup_script": self.setup_script,
            "teardown_script": self.teardown_script,
            "timeout": self.timeout,
            "expected_output": self.expected_output,
            "assertions": self.assertions,
            "tags": self.tags,
            "dependencies": self.dependencies
        }

class ScriptExecutor:
    """脚本执行器"""
    
    def __init__(self, timeout: int = 30):
        self.timeout = timeout
        self.process = None
        self.output = ""
        self.error = ""
        
    def execute(self, script_path: str, args: List[str] = None) -> Dict[str, Any]:
        """执行脚本"""
        if args is None:
            args = []
            
        cmd = ["python3", script_path] + args
        
        try:
            logger.info(f"执行脚本: {script_path}")
            logger.info(f"命令: {' '.join(cmd)}")
            
            self.process = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                cwd=os.path.dirname(script_path) if os.path.dirname(script_path) else "."
            )
            
            # 等待执行完成或超时
            start_time = time.time()
            while True:
                if self.process.poll() is not None:
                    break
                    
                if time.time() - start_time > self.timeout:
                    logger.warning(f"脚本执行超时: {script_path}")
                    self.process.terminate()
                    time.sleep(1)
                    if self.process.poll() is None:
                        self.process.kill()
                    break
                    
                time.sleep(0.1)
            
            # 获取输出
            stdout, stderr = self.process.communicate()
            self.output = stdout
            self.error = stderr
            
            return {
                "success": self.process.returncode == 0,
                "return_code": self.process.returncode,
                "stdout": stdout,
                "stderr": stderr,
                "execution_time": time.time() - start_time
            }
            
        except Exception as e:
            logger.error(f"执行脚本时发生错误: {e}")
            return {
                "success": False,
                "return_code": -1,
                "stdout": "",
                "stderr": str(e),
                "execution_time": 0
            }

class AssertionEngine:
    """断言引擎"""
    
    @staticmethod
    def assert_equal(actual, expected, message: str = "") -> Dict[str, Any]:
        """断言相等"""
        result = {
            "type": AssertionType.EQUAL.value,
            "actual": actual,
            "expected": expected,
            "message": message,
            "passed": actual == expected
        }
        return result
    
    @staticmethod
    def assert_contains(actual, expected, message: str = "") -> Dict[str, Any]:
        """断言包含"""
        result = {
            "type": AssertionType.CONTAINS.value,
            "actual": actual,
            "expected": expected,
            "message": message,
            "passed": expected in actual
        }
        return result
    
    @staticmethod
    def assert_regex(actual, pattern, message: str = "") -> Dict[str, Any]:
        """断言正则匹配"""
        import re
        result = {
            "type": AssertionType.REGEX_MATCH.value,
            "actual": actual,
            "expected": pattern,
            "message": message,
            "passed": bool(re.search(pattern, actual))
        }
        return result
    
    @staticmethod
    def assert_true(actual, message: str = "") -> Dict[str, Any]:
        """断言为真"""
        result = {
            "type": AssertionType.IS_TRUE.value,
            "actual": actual,
            "expected": True,
            "message": message,
            "passed": bool(actual)
        }
        return result
    
    @staticmethod
    def run_assertions(assertions: List[Dict[str, Any]], context: Dict[str, Any]) -> List[Dict[str, Any]]:
        """运行断言列表"""
        results = []
        
        for assertion in assertions:
            assertion_type = assertion.get("type", AssertionType.EQUAL.value)
            actual = assertion.get("actual", "")
            expected = assertion.get("expected", "")
            message = assertion.get("message", "")
            
            # 替换上下文变量
            if isinstance(actual, str):
                for key, value in context.items():
                    actual = actual.replace(f"${{{key}}}", str(value))
            if isinstance(expected, str):
                for key, value in context.items():
                    expected = expected.replace(f"${{{key}}}", str(value))
            
            if assertion_type == AssertionType.EQUAL.value:
                result = AssertionEngine.assert_equal(actual, expected, message)
            elif assertion_type == AssertionType.CONTAINS.value:
                result = AssertionEngine.assert_contains(actual, expected, message)
            elif assertion_type == AssertionType.REGEX_MATCH.value:
                result = AssertionEngine.assert_regex(actual, expected, message)
            elif assertion_type == AssertionType.IS_TRUE.value:
                result = AssertionEngine.assert_true(actual, message)
            else:
                result = {
                    "type": assertion_type,
                    "actual": actual,
                    "expected": expected,
                    "message": f"不支持的断言类型: {assertion_type}",
                    "passed": False
                }
            
            results.append(result)
        
        return results

class TestRunner:
    """测试运行器"""
    
    def __init__(self):
        self.executor = ScriptExecutor()
        self.assertion_engine = AssertionEngine()
        self.results: List[TestResult] = []
        self.current_test: Optional[TestCase] = None
        
    def run_test(self, test_case: TestCase) -> TestResult:
        """运行单个测试用例"""
        self.current_test = test_case
        start_time = datetime.now()
        
        logger.info(f"开始测试: {test_case.name}")
        
        # 执行前置脚本
        setup_result = None
        if test_case.setup_script:
            logger.info(f"执行前置脚本: {test_case.setup_script}")
            setup_result = self.executor.execute(test_case.setup_script)
        
        # 执行主脚本
        script_result = self.executor.execute(test_case.script_path)
        
        # 执行后置脚本
        teardown_result = None
        if test_case.teardown_script:
            logger.info(f"执行后置脚本: {test_case.teardown_script}")
            teardown_result = self.executor.execute(test_case.teardown_script)
        
        # 运行断言
        context = {
            "script_result": script_result,
            "setup_result": setup_result,
            "teardown_result": teardown_result,
            "test_case": test_case.to_dict()
        }
        
        assertion_results = self.assertion_engine.run_assertions(
            test_case.assertions, context
        )
        
        # 确定测试状态
        status = TestStatus.PASSED
        error_message = None
        
        # 检查脚本执行是否成功
        if not script_result["success"]:
            status = TestStatus.FAILED
            error_message = f"脚本执行失败: {script_result['stderr']}"
        
        # 检查断言结果
        failed_assertions = [a for a in assertion_results if not a["passed"]]
        if failed_assertions:
            status = TestStatus.FAILED
            error_message = f"{len(failed_assertions)}个断言失败"
        
        # 创建测试结果
        end_time = datetime.now()
        execution_time = (end_time - start_time).total_seconds()
        
        result = TestResult(
            test_id=test_case.test_id,
            test_name=test_case.name,
            status=status,
            execution_time=execution_time,
            start_time=start_time,
            end_time=end_time,
            assertions=assertion_results,
            error_message=error_message,
            logs=[f"脚本输出: {script_result['stdout'][:500]}..."]
        )
        
        self.results.append(result)
        logger.info(f"测试完成: {test_case.name} - 状态: {status.value}")
        
        return result
    
    def run_tests(self, test_cases: List[TestCase]) -> List[TestResult]:
        """运行多个测试用例"""
        results = []
        
        for test_case in test_cases:
            # 检查依赖
            dependencies_met = True
            for dep in test_case.dependencies:
                dep_result = next((r for r in results if r.test_id == dep), None)
                if not dep_result or dep_result.status != TestStatus.PASSED:
                    dependencies_met = False
                    break
            
            if not dependencies_met:
                logger.warning(f"跳过测试 {test_case.name}: 依赖未满足")
                result = TestResult(
                    test_id=test_case.test_id,
                    test_name=test_case.name,
                    status=TestStatus.SKIPPED,
                    execution_time=0,
                    start_time=datetime.now(),
                    end_time=datetime.now(),
                    error_message="依赖未满足"
                )
                results.append(result)
                continue
            
            result = self.run_test(test_case)
            results.append(result)
        
        return results

class TestReportGenerator:
    """测试报告生成器"""
    
    @staticmethod
    def generate_html_report(results: List[TestResult], output_path: str) -> str:
        """生成HTML报告"""
        html = """
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <title>石器时代脚本测试报告</title>
            <style>
                body { font-family: Arial, sans-serif; margin: 20px; }
                .header { background: #f0f0f0; padding: 20px; border-radius: 5px; }
                .summary { margin: 20px 0; padding: 15px; background: #f9f9f9; border-radius: 5px; }
                .test-result { margin: 10px 0; padding: 10px; border-left: 5px solid #ccc; }
                .passed { border-color: #4CAF50; background: #e8f5e9; }
                .failed { border-color: #f44336; background: #ffebee; }
                .error { border-color: #ff9800; background: #fff3e0; }
                .skipped { border-color: #9e9e9e; background: #f5f5f5; }
                .assertion { margin: 5px 0; padding: 5px; font-size: 0.9em; }
                .assertion-passed { color: #4CAF50; }
                .assertion-failed { color: #f44336; }
                .stats { display: flex; gap: 20px; margin: 20px 0; }
                .stat-box { padding: 15px; background: white; border-radius: 5px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
            </style>
        </head>
        <body>
            <div class="header">
                <h1>石器时代脚本测试报告</h1>
                <p>生成时间: """ + datetime.now().strftime("%Y-%m-%d %H:%M:%S") + """</p>
            </div>
        """
        
        # 统计信息
        total = len(results)
        passed = len([r for r in results if r.status == TestStatus.PASSED])
        failed = len([r for r in results if r.status == TestStatus.FAILED])
        error = len([r for r in results if r.status == TestStatus.ERROR])
        skipped = len([r for r in results if r.status == TestStatus.SKIPPED])
        
        html += f"""
            <div class="summary">
                <h2>测试摘要</h2>
                <div class="stats">
                    <div class="stat-box">
                        <h3>总计</h3>
                        <p style="font-size: 24px; font-weight: bold;">{total}</p>
                    </div>
                    <div class="stat-box">
                        <h3>通过</h3>
                        <p style="font-size: 24px; font-weight: bold; color: #4CAF50;">{passed}</p>
                    </div>
                    <div class="stat-box">
                        <h3>失败</h3>
                        <p style="font-size: 24px; font-weight: bold; color: #f44336;">{failed}</p>
                    </div>
                    <div class="stat-box">
                        <h3>错误</h3>
                        <p style="font-size: 24px; font-weight: bold; color: #ff9800;">{error}</p>
                    </div>
                    <div class="stat-box">
                        <h3>跳过</h3>
                        <p style="font-size: 24px; font-weight: bold; color: #9e9e9e;">{skipped}</p>
                    </div>
                </div>
                <p>通过率: {(passed/total*100 if total > 0 else 0):.1f}%</p>
            </div>
            
            <h2>详细结果</h2>
        """
        
        # 详细结果
        for result in results:
            status_class = ""
            if result.status == TestStatus.PASSED:
                status_class = "passed"
            elif result.status == TestStatus.FAILED:
                status_class = "failed"
            elif result.status == TestStatus.ERROR:
                status_class = "error"
            elif result.status == TestStatus.SKIPPED:
                status_class = "skipped"
            
            html += f"""
            <div class="test-result {status_class}">
                <h3>{result.test_name} ({result.test_id})</h3>
                <p>状态: <strong>{result.status.value}</strong></p>
                <p>执行时间: {result.execution_time:.2f}秒</p>
                <p>开始时间: {result.start_time.strftime('%H:%M:%S')}</p>
                <p>结束时间: {result.end_time.strftime('%H:%M:%S')}</p>
            """
            
            if result.error_message:
                html += f'<p>错误信息: <strong style="color: #f44336;">{result.error_message}</strong></p>'
            
            if result.assertions:
                html += "<h4>断言结果:</h4>"
                for assertion in result.assertions:
                    assertion_class = "assertion-passed" if assertion["passed"] else "assertion-failed"
                    html += f"""
                    <div class="assertion {assertion_class}">
                        <p>{assertion['type']}: {assertion['message']}</p>
                    </div>"""
            
            html += "</div>"
        
        html += """
        </body>
        </html>
        """
        
        # 保存HTML文件
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(html)
        
        logger.info(f"HTML测试报告已生成: {output_path}")
        return html