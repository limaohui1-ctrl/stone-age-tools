#!/usr/bin/env python3
"""
示例脚本 - 用于测试框架演示
"""

import time
import random

def main():
    """主函数"""
    print("=" * 40)
    print("石器时代脚本示例")
    print("=" * 40)
    
    # 模拟脚本执行
    print("1. 初始化脚本...")
    time.sleep(0.5)
    
    print("2. 检查游戏状态...")
    game_running = random.choice([True, True, True, False])  # 75%概率运行中
    if not game_running:
        print("错误: 游戏未运行!")
        return 1
    
    print("3. 执行任务...")
    for i in range(3):
        print(f"  任务 {i+1}: 执行中...")
        time.sleep(0.3)
    
    print("4. 完成任务!")
    print("=" * 40)
    
    # 返回成功
    return 0

if __name__ == "__main__":
    exit_code = main()
    exit(exit_code)