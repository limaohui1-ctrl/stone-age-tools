#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
石器时代脚本性能监控系统 - 主启动脚本
一键启动完整的性能监控系统
"""

import os
import sys
import time
import json
import logging
from datetime import datetime
import argparse


def setup_logging():
    """设置日志"""
    log_dir = "/root/.openclaw/workspace/石器时代脚本性能监控系统/logs"
    os.makedirs(log_dir, exist_ok=True)
    
    logger = logging.getLogger("PerformanceMonitorStarter")
    logger.setLevel(logging.INFO)
    
    if not logger.handlers:
        log_file = os.path.join(log_dir, f"starter_{datetime.now().strftime('%Y%m%d')}.log")
        file_handler = logging.FileHandler(log_file, encoding='utf-8')
        file_handler.setLevel(logging.INFO)
        
        console_handler = logging.StreamHandler()
        console_handler.setLevel(logging.INFO)
        
        formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
        file_handler.setFormatter(formatter)
        console_handler.setFormatter(formatter)
        
        logger.addHandler(file_handler)
        logger.addHandler(console_handler)
    
    return logger


def check_dependencies():
    """检查依赖"""
    logger = logging.getLogger("PerformanceMonitorStarter")
    
    dependencies = [
        ("flask", "Flask"),
        ("psutil", "psutil"),
        ("numpy", "numpy"),
    ]
    
    missing_deps = []
    
    for module_name, display_name in dependencies:
        try:
            __import__(module_name)
            logger.info(f"依赖检查: {display_name} ✓")
        except ImportError:
            missing_deps.append(display_name)
            logger.warning(f"依赖检查: {display_name} ✗")
    
    if missing_deps:
        logger.error(f"缺少依赖: {', '.join(missing_deps)}")
        logger.info("安装命令: pip install " + " ".join([dep.lower() for dep in missing_deps]))
        return False
    
    return True


def create_default_config():
    """创建默认配置"""
    config_dir = "/root/.openclaw/workspace/石器时代脚本性能监控系统/config"
    os.makedirs(config_dir, exist_ok=True)
    
    # 系统配置
    system_config = {
        "system": {
            "name": "石器时代脚本性能监控系统",
            "version": "1.0.0",
            "description": "实时监控和优化石器时代脚本性能",
            "author": "OpenClaw AI助手",
            "auto_start": True,
            "check_interval": 5.0,
            "max_concurrent_tasks": 3,
        },
        "modules": {
            "monitor_agent": {
                "enabled": True,
                "config_path": "config/monitor_agent.json",
                "auto_start": True,
            },
            "analysis_engine": {
                "enabled": True,
                "config_path": "config/analysis_engine.json",
                "auto_start": True,
            },
            "optimization_executor": {
                "enabled": True,
                "config_path": "config/optimization_executor.json",
                "auto_start": False,
            },
        },
        "logging": {
            "level": "INFO",
            "max_file_size": 10485760,
            "backup_count": 5,
        },
        "monitoring": {
            "metrics_interval": 10.0,
            "health_check_interval": 30.0,
            "alert_thresholds": {
                "cpu_usage": 90.0,
                "memory_usage": 95.0,
                "disk_usage": 90.0,
                "error_rate": 10.0,
            }
        },
        "web_interface": {
            "enabled": True,
            "host": "127.0.0.1",
            "port": 8080,
            "debug": False,
        }
    }
    
    # 监控代理配置
    monitor_agent_config = {
        "monitoring_interval": 1.0,
        "network_test_interval": 5.0,
        "performance_thresholds": {
            "execution_time": {
                "excellent": 1.0,
                "good": 3.0,
                "fair": 5.0,
                "poor": 10.0,
            },
            "network_latency": {
                "excellent": 50,
                "good": 100,
                "fair": 200,
                "poor": 500,
            },
            "packet_loss": {
                "excellent": 0.1,
                "good": 1.0,
                "fair": 5.0,
                "poor": 10.0,
            }
        },
        "optimization_rules": {
            "network_retry": {
                "enabled": True,
                "max_retries": 3,
                "retry_delay": 2.0,
            },
            "timeout_adjustment": {
                "enabled": True,
                "base_timeout": 10.0,
                "adjustment_factor": 1.5,
            }
        }
    }
    
    # 分析引擎配置
    analysis_engine_config = {
        "analysis_window": 30,
        "trend_window": 10,
        "thresholds": {
            "network_latency": {
                "warning": 100,
                "critical": 300,
            },
            "network_jitter": {
                "warning": 20,
                "critical": 50,
            },
            "packet_loss": {
                "warning": 1.0,
                "critical": 5.0,
            },
            "cpu_usage": {
                "warning": 70.0,
                "critical": 90.0,
            },
            "memory_usage": {
                "warning": 80.0,
                "critical": 95.0,
            },
            "execution_time": {
                "warning": 5.0,
                "critical": 10.0,
            }
        },
        "correlation_rules": {
            "network_and_execution": {
                "enabled": True,
                "threshold": 0.7,
            },
            "cpu_and_memory": {
                "enabled": True,
                "threshold": 0.6,
            }
        }
    }
    
    # 优化实施器配置
    optimization_executor_config = {
        "auto_execution": {
            "enabled": True,
            "check_interval": 300,
            "max_concurrent_tasks": 2,
            "min_improvement_threshold": 10.0,
        },
        "optimization_parameters": {
            "network_retry": {
                "max_retries": 3,
                "retry_delay_base": 2.0,
                "retry_delay_max": 10.0,
                "backoff_factor": 2.0,
            },
            "timeout_adjustment": {
                "base_timeout": 10.0,
                "adjustment_factor": 1.5,
                "max_timeout": 30.0,
                "min_timeout": 2.0,
            },
            "batch_processing": {
                "batch_size": 10,
                "max_batch_size": 50,
                "batch_timeout": 5.0,
            }
        },
        "monitoring": {
            "effect_measurement_duration": 300,
            "min_measurement_points": 10,
            "rollback_threshold": -20.0,
        }
    }
    
    # 保存配置
    configs = [
        ("system_config.json", system_config),
        ("monitor_agent.json", monitor_agent_config),
        ("analysis_engine.json", analysis_engine_config),
        ("optimization_executor.json", optimization_executor_config),
    ]
    
    for filename, config in configs:
        config_path = os.path.join(config_dir, filename)
        try:
            with open(config_path, 'w', encoding='utf-8') as f:
                json.dump(config, f, ensure_ascii=False, indent=2)
            logging.getLogger("PerformanceMonitorStarter").info(f"创建配置: {filename}")
        except Exception as e:
            logging.getLogger("PerformanceMonitorStarter").error(f"创建配置失败 {filename}: {e}")
    
    return True


def start_system(web_only=False):
    """启动系统"""
    logger = logging.getLogger("PerformanceMonitorStarter")
    
    try:
        # 导入模块
        sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
        
        if not web_only:
            # 启动主控制器
            from src.主控制器 import PerformanceMonitorController
            
            logger.info("启动主控制器...")
            controller = PerformanceMonitorController("config/system_config.json")
            
            if controller.start():
                logger.info("主控制器启动成功")
            else:
                logger.error("主控制器启动失败")
                return None
            
            # 启动Web界面
            from src.web_界面 import PerformanceMonitorWebUI
            
            logger.info("启动Web界面...")
            webui = PerformanceMonitorWebUI(
                controller,
                host=controller.config["web_interface"]["host"],
                port=controller.config["web_interface"]["port"],
                debug=controller.config["web_interface"]["debug"]
            )
            
            if webui.start():
                logger.info(f"Web界面启动成功: {webui.get_url()}")
            else:
                logger.error("Web界面启动失败")
            
            return controller, webui
            
        else:
            # 仅启动Web界面（演示模式）
            logger.info("启动Web界面（演示模式）...")
            
            # 创建模拟控制器
            class MockController:
                def __init__(self):
                    self.config = {
                        "web_interface": {
                            "host": "127.0.0.1",
                            "port": 8080,
                            "debug": False,
                        }
                    }
                    self.task_queue = []
                    self.task_results = {}
                    self.system_metrics_history = []
                    self.modules = {}
                
                def get_system_status(self):
                    return {
                        "system": {
                            "status": "运行中",
                            "start_time": datetime.now().isoformat(),
                            "uptime": 3600,
                        },
                        "modules": {
                            "monitor_agent": {
                                "status": "运行中",
                                "last_activity": datetime.now().isoformat(),
                                "error_message": None,
                                "metrics": {},
                            },
                            "analysis_engine": {
                                "status": "运行中",
                                "last_activity": datetime.now().isoformat(),
                                "error_message": None,
                                "metrics": {},
                            },
                        },
                        "metrics": {
                            "total_tasks": 10,
                            "pending_tasks": 2,
                            "system_metrics": {},
                        }
                    }
                
                def start_module(self, module_name):
                    return True
                
                def stop_module(self, module_name):
                    return True
                
                def add_task(self, task_type, **kwargs):
                    task_id = f"task_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{task_type}"
                    self.task_queue.append({
                        "id": task_id,
                        "type": task_type,
                        "created_at": datetime.now().isoformat(),
                        "status": "pending",
                        **kwargs,
                    })
                    return task_id
                
                def generate_system_report(self):
                    return "演示模式 - 系统报告"
            
            from src.web_界面 import PerformanceMonitorWebUI
            
            controller = MockController()
            webui = PerformanceMonitorWebUI(controller, host="127.0.0.1", port=8080)
            
            if webui.start():
                logger.info(f"Web界面启动成功: {webui.get_url()}")
                return controller, webui
            else:
                logger.error("Web界面启动失败")
                return None
            
    except Exception as e:
        logger.error(f"启动系统失败: {e}")
        import traceback
        logger.error(traceback.format_exc())
        return None


def generate_readme():
    """生成README文件"""
    readme_content = """# 石器时代脚本性能监控系统

## 系统概述

石器时代脚本性能监控系统是一个专门为石器时代游戏脚本开发设计的性能监控和优化工具。系统提供实时性能监控、智能分析、自动优化等功能，帮助开发者解决脚本运行中的网络波动、卡顿等问题。

## 核心功能

### 1. 实时性能监控
- 监控脚本执行时间、CPU使用率、内存使用率
- 检测网络延迟、抖动、丢包
- 实时性能等级评估

### 2. 智能分析引擎
- 分析性能数据，识别瓶颈
- 生成优化建议和计划
- 相关性分析和趋势预测

### 3. 自动优化实施
- 自动执行优化任务
- 跟踪优化效果
- 支持回滚机制

### 4. Web控制界面
- 实时系统状态显示
- 性能图表可视化
- 模块控制和任务管理

## 系统架构

```
石器时代脚本性能监控系统/
├── src/                    # 源代码目录
│   ├── 主控制器.py        # 系统主控制器
│   ├── 监控代理.py        # 性能监控代理
│   ├── 分析引擎.py        # 性能分析引擎
│   ├── 优化实施器.py      # 优化执行器
│   └── web_界面.py        # Web界面
├── config/                 # 配置文件目录
├── data/                   # 数据存储目录
├── logs/                   # 日志文件目录
├── reports/                # 报告文件目录
├── templates/              # Web模板目录
├── static/                 # 静态文件目录
├── 启动系统.py            # 主启动脚本
└── README.md              # 本文档
```

## 快速开始

### 1. 安装依赖
```bash
pip install flask psutil numpy
```

### 2. 启动系统
```bash
# 完整启动
python3 启动系统.py

# 仅启动Web界面（演示模式）
python3 启动系统.py --web-only
```

### 3. 访问Web界面
打开浏览器访问：http://127.0.0.1:8080

## 使用指南

### 系统控制
1. 在Web界面点击"启动"按钮启动系统
2. 系统状态将显示在顶部状态栏
3. 可以随时点击"停止"按钮停止系统

### 模块管理
1. 在"模块控制"区域查看模块状态
2. 点击模块对应的"启动"/"停止"按钮控制模块
3. 模块状态会实时更新

### 性能监控
1. 点击"监控脚本性能"按钮开始监控
2. 在图表区域查看性能趋势
3. 实时指标区域显示当前系统状态

### 数据分析
1. 点击"分析性能数据"按钮开始分析
2. 系统会自动识别性能瓶颈
3. 查看分析结果和优化建议

### 优化实施
1. 点击"优化脚本配置"按钮开始优化
2. 系统会自动执行优化任务
3. 跟踪优化效果和改进百分比

## 配置说明

### 系统配置 (config/system_config.json)
- `system`: 系统基本信息
- `modules`: 模块配置
- `logging`: 日志配置
- `monitoring`: 监控配置
- `web_interface`: Web界面配置

### 监控代理配置 (config/monitor_agent.json)
- 性能阈值设置
- 网络测试参数
- 优化规则配置

### 分析引擎配置 (config/analysis_engine.json)
- 分析窗口大小
- 阈值设置
- 相关性规则

### 优化实施器配置 (config/optimization_executor.json)
- 自动执行配置
- 优化参数
- 效果监控配置

## 故障排除

### 常见问题

1. **系统启动失败**
   - 检查依赖是否安装：`pip install flask psutil numpy`
   - 检查端口是否被占用：`netstat -tlnp | grep 8080`
   - 检查日志文件：`logs/starter_*.log`

2. **Web界面无法访问**
   - 检查防火墙设置
   - 确认服务已启动：`ps aux | grep python`
   - 检查浏览器控制台错误

3. **性能数据不更新**
   - 检查模块状态是否正常
   - 查看监控代理日志
   - 确认脚本执行环境

### 日志文件
- 系统启动日志：`logs/starter_*.log`
- 主控制器日志：`logs/controller_*.log`
- Web界面日志：`logs/webui_*.log`
- 模块日志：`logs/` 目录下各模块日志

## 开发指南

### 添加新模块
1. 在 `src/` 目录下创建新模块文件
2. 实现模块接口
3. 在主控制器中注册模块
4. 更新配置文件

### 扩展功能
1. 修改现有模块代码
2. 添加新的API端点
3. 更新Web界面
4. 测试功能完整性

## 许可证

本项目基于MIT许可证开源。

## 技术支持

如有问题或建议，请联系：
- 邮箱：support@example.com
- GitHub：https://github.com/your-repo

---

**祝您使用愉快！** 🎮🔧
"""
    
    readme_path = "/root/.openclaw/workspace/石器时代脚本性能监控系统/README.md"
    with open(readme_path, 'w', encoding='utf-8') as f:
        f.write(readme_content)
    
    logging.getLogger("PerformanceMonitorStarter").info(f"创建README: {readme_path}")
    return readme_path


def main():
    """主函数"""
    parser = argparse.ArgumentParser(description='石器时代脚本性能监控系统')
    parser.add_argument('--web-only', action='store_true', help='仅启动Web界面（演示模式）')
    parser.add_argument('--create-config', action='store_true', help='仅创建配置文件')
    parser.add_argument('--check-deps', action='store_true', help='仅检查依赖')
    parser.add_argument('--generate-readme', action='store_true', help='生成README文件')
    
    args = parser.parse_args()
    
    # 设置日志
    logger = setup_logging()
    
    print("=" * 60)
    print("石器时代脚本性能监控系统")
    print("=" * 60)
    
    # 检查依赖
    if args.check_deps:
        print("\n检查依赖...")
        if check_dependencies():
            print("所有依赖已安装 ✓")
        else:
            print("缺少依赖，请安装缺失的包")
        return
    
    # 创建配置
    if args.create_config:
        print("\n创建配置文件...")
        create_default_config()
        print("配置文件创建完成 ✓")
        return
    
    # 生成README
    if args.generate_readme:
        print("\n生成README文件...")
        readme_path = generate_readme()
        print(f"README文件已生成: {readme_path} ✓")
        return
    
    # 完整启动
    print("\n启动性能监控系统...")
    
    # 检查依赖
    if not check_dependencies():
        print("缺少依赖，请先安装缺失的包")
        print("安装命令: pip install flask psutil numpy")
        return
    
    # 创建配置
    print("创建配置文件...")
    create_default_config()
    
    # 生成README
    print("生成README文件...")
    generate_readme()
    
    # 启动系统
    print("启动系统组件...")
    result = start_system(web_only=args.web_only)
    
    if result:
        if args.web_only:
            controller, webui = result
            print(f"\nWeb界面已启动: {webui.get_url()}")
            print("模式: 演示模式 (使用模拟数据)")
        else:
            controller, webui = result
            print(f"\n系统启动成功!")
            print(f"Web界面: {webui.get_url()}")
            print("模式: 完整模式")
        
        print("\n系统信息:")
        print(f"  系统名称: {controller.config['system']['name']}")
        print(f"  系统版本: {controller.config['system']['version']}")
        print(f"  Web地址: http://{controller.config['web_interface']['host']}:{controller.config['web_interface']['port']}")
        
        print("\n使用说明:")
        print("  1. 打开浏览器访问Web界面")
        print("  2. 点击'启动'按钮启动系统")
        print("  3. 在'模块控制'区域管理模块")
        print("  4. 使用'快速任务'按钮执行任务")
        print("  5. 在图表区域查看性能数据")
        
        print("\n按 Ctrl+C 停止系统")
        
        try:
            # 保持主线程运行
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            print("\n\n正在停止系统...")
            if not args.web_only:
                controller.stop()
            webui.stop()
            print("系统已停止")
    
    else:
        print("系统启动失败")
        print("请检查日志文件: logs/starter_*.log")


if __name__ == "__main__":
    main()