#!/usr/bin/env python3
"""
测试用例管理器
负责加载、解析和管理测试用例
"""

import os
import json
import yaml
from pathlib import Path
from typing import List, Dict, Any, Optional
from dataclasses import dataclass, field
import logging

from .test_framework import TestCase, TestStatus

logger = logging.getLogger(__name__)

@dataclass
class TestSuite:
    """测试套件"""
    name: str
    description: str
    test_cases: List[TestCase]
    tags: List[str] = field(default_factory=list)
    
    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return {
            "name": self.name,
            "description": self.description,
            "test_cases": [tc.to_dict() for tc in self.test_cases],
            "tags": self.tags
        }

class TestManager:
    """测试管理器"""
    
    def __init__(self, test_dir: str = "tests"):
        self.test_dir = Path(test_dir)
        self.test_suites: List[TestSuite] = []
        self.test_cases: List[TestCase] = []
        
    def load_test_cases(self, config_path: Optional[str] = None) -> List[TestCase]:
        """加载测试用例"""
        if config_path:
            return self._load_from_config(config_path)
        else:
            return self._discover_tests()
    
    def _load_from_config(self, config_path: str) -> List[TestCase]:
        """从配置文件加载测试用例"""
        config_path = Path(config_path)
        
        if not config_path.exists():
            logger.error(f"配置文件不存在: {config_path}")
            return []
        
        try:
            if config_path.suffix == '.json':
                with open(config_path, 'r', encoding='utf-8') as f:
                    config = json.load(f)
            elif config_path.suffix in ['.yaml', '.yml']:
                with open(config_path, 'r', encoding='utf-8') as f:
                    config = yaml.safe_load(f)
            else:
                logger.error(f"不支持的配置文件格式: {config_path.suffix}")
                return []
            
            return self._parse_config(config)
            
        except Exception as e:
            logger.error(f"加载配置文件时发生错误: {e}")
            return []
    
    def _parse_config(self, config: Dict[str, Any]) -> List[TestCase]:
        """解析配置"""
        test_cases = []
        
        # 支持多种配置格式
        if "test_suites" in config:
            # 套件格式
            for suite_config in config["test_suites"]:
                suite_name = suite_config.get("name", "未命名套件")
                suite_description = suite_config.get("description", "")
                
                for case_config in suite_config.get("test_cases", []):
                    test_case = self._create_test_case(case_config)
                    if test_case:
                        test_cases.append(test_case)
                        
                # 创建测试套件
                test_suite = TestSuite(
                    name=suite_name,
                    description=suite_description,
                    test_cases=test_cases[-len(suite_config.get("test_cases", [])):]  # 获取刚添加的测试用例
                )
                self.test_suites.append(test_suite)
                
        elif "test_cases" in config:
            # 直接测试用例格式
            for case_config in config["test_cases"]:
                test_case = self._create_test_case(case_config)
                if test_case:
                    test_cases.append(test_case)
        else:
            # 尝试解析为单个测试用例
            test_case = self._create_test_case(config)
            if test_case:
                test_cases.append(test_case)
        
        self.test_cases = test_cases
        return test_cases
    
    def _create_test_case(self, config: Dict[str, Any]) -> Optional[TestCase]:
        """创建测试用例对象"""
        try:
            test_id = config.get("id", f"test_{len(self.test_cases) + 1}")
            name = config.get("name", f"测试用例 {test_id}")
            description = config.get("description", "")
            script_path = config.get("script_path", "")
            
            # 验证脚本路径
            if not script_path:
                logger.warning(f"测试用例 {name} 缺少脚本路径")
                return None
            
            script_path = Path(script_path)
            if not script_path.exists():
                logger.warning(f"脚本文件不存在: {script_path}")
                return None
            
            # 创建测试用例
            test_case = TestCase(
                test_id=test_id,
                name=name,
                description=description,
                script_path=str(script_path),
                setup_script=config.get("setup_script"),
                teardown_script=config.get("teardown_script"),
                timeout=config.get("timeout", 30),
                expected_output=config.get("expected_output"),
                assertions=config.get("assertions", []),
                tags=config.get("tags", []),
                dependencies=config.get("dependencies", [])
            )
            
            return test_case
            
        except Exception as e:
            logger.error(f"创建测试用例时发生错误: {e}")
            return None
    
    def _discover_tests(self) -> List[TestCase]:
        """自动发现测试用例"""
        test_cases = []
        
        if not self.test_dir.exists():
            logger.warning(f"测试目录不存在: {self.test_dir}")
            return test_cases
        
        # 查找测试配置文件
        config_files = list(self.test_dir.glob("*.json")) + list(self.test_dir.glob("*.yaml")) + list(self.test_dir.glob("*.yml"))
        
        for config_file in config_files:
            logger.info(f"发现测试配置文件: {config_file}")
            cases = self._load_from_config(str(config_file))
            test_cases.extend(cases)
        
        # 查找测试脚本文件
        script_files = list(self.test_dir.glob("**/*.py")) + list(self.test_dir.glob("**/*.asc"))
        
        for script_file in script_files:
            # 跳过以test_开头的文件（可能是测试框架文件）
            if script_file.name.startswith("test_"):
                continue
                
            test_id = f"auto_{len(test_cases) + 1}"
            name = f"自动测试: {script_file.stem}"
            description = f"自动发现的测试脚本: {script_file.name}"
            
            test_case = TestCase(
                test_id=test_id,
                name=name,
                description=description,
                script_path=str(script_file),
                timeout=30,
                tags=["auto_discovered"]
            )
            
            test_cases.append(test_case)
        
        self.test_cases = test_cases
        return test_cases
    
    def get_test_case_by_id(self, test_id: str) -> Optional[TestCase]:
        """根据ID获取测试用例"""
        for test_case in self.test_cases:
            if test_case.test_id == test_id:
                return test_case
        return None
    
    def get_test_cases_by_tag(self, tag: str) -> List[TestCase]:
        """根据标签获取测试用例"""
        return [tc for tc in self.test_cases if tag in tc.tags]
    
    def save_test_results(self, results: List[Any], output_path: str) -> None:
        """保存测试结果"""
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        
        # 转换为可序列化的字典
        serializable_results = []
        for result in results:
            if hasattr(result, 'to_dict'):
                serializable_results.append(result.to_dict())
            elif isinstance(result, dict):
                serializable_results.append(result)
            else:
                # 尝试转换
                try:
                    serializable_results.append(vars(result))
                except:
                    serializable_results.append(str(result))
        
        # 保存为JSON
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump({
                "timestamp": datetime.now().isoformat(),
                "total_tests": len(results),
                "results": serializable_results
            }, f, indent=2, ensure_ascii=False)
        
        logger.info(f"测试结果已保存到: {output_path}")

# 导入datetime
from datetime import datetime