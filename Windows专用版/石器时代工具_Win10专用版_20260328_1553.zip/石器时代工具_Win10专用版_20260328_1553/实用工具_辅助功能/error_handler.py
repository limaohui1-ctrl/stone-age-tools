#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
错误处理系统 - 统一的错误处理、日志记录和恢复机制
"""

import os
import sys
import time
import json
import logging
import traceback
from pathlib import Path
from typing import Dict, List, Any, Optional, Callable, Type
from enum import Enum
from dataclasses import dataclass, asdict
import inspect

# 错误严重级别
class ErrorSeverity(Enum):
    """错误严重级别"""
    DEBUG = 0      # 调试信息
    INFO = 1       # 一般信息
    WARNING = 2    # 警告，不影响功能
    ERROR = 3      # 错误，功能可能受影响
    CRITICAL = 4   # 严重错误，功能不可用
    FATAL = 5      # 致命错误，程序需要退出

# 错误类型
class ErrorType(Enum):
    """错误类型"""
    CONFIG_ERROR = "config_error"          # 配置错误
    OCR_ERROR = "ocr_error"                # OCR识别错误
    GAME_ERROR = "game_error"              # 游戏集成错误
    NETWORK_ERROR = "network_error"        # 网络错误
    FILE_ERROR = "file_error"              # 文件操作错误
    PERMISSION_ERROR = "permission_error"  # 权限错误
    TIMEOUT_ERROR = "timeout_error"        # 超时错误
    VALIDATION_ERROR = "validation_error"  # 验证错误
    UNKNOWN_ERROR = "unknown_error"        # 未知错误

@dataclass
class ErrorInfo:
    """错误信息"""
    timestamp: float
    severity: ErrorSeverity
    error_type: ErrorType
    message: str
    module: str
    function: str
    line_number: int
    traceback: Optional[str] = None
    context: Optional[Dict[str, Any]] = None
    recovery_action: Optional[str] = None
    error_code: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        result = asdict(self)
        result['severity'] = self.severity.value
        result['error_type'] = self.error_type.value
        return result
    
    def to_json(self) -> str:
        """转换为JSON字符串"""
        return json.dumps(self.to_dict(), ensure_ascii=False, indent=2)

class RecoveryAction:
    """恢复动作"""
    
    @staticmethod
    def retry(max_attempts: int = 3, delay: float = 1.0) -> Callable:
        """重试动作装饰器"""
        def decorator(func: Callable) -> Callable:
            def wrapper(*args, **kwargs):
                last_error = None
                for attempt in range(1, max_attempts + 1):
                    try:
                        return func(*args, **kwargs)
                    except Exception as e:
                        last_error = e
                        if attempt < max_attempts:
                            time.sleep(delay)
                        else:
                            raise last_error
                return None
            return wrapper
        return decorator
    
    @staticmethod
    def fallback(fallback_func: Callable) -> Callable:
        """回退动作装饰器"""
        def decorator(func: Callable) -> Callable:
            def wrapper(*args, **kwargs):
                try:
                    return func(*args, **kwargs)
                except Exception as e:
                    # 记录错误
                    frame = inspect.currentframe()
                    caller_info = inspect.getframeinfo(frame.f_back)
                    
                    error_info = ErrorInfo(
                        timestamp=time.time(),
                        severity=ErrorSeverity.WARNING,
                        error_type=ErrorType.UNKNOWN_ERROR,
                        message=f"主函数失败，尝试回退: {str(e)}",
                        module=caller_info.filename,
                        function=caller_info.function,
                        line_number=caller_info.lineno,
                        traceback=traceback.format_exc(),
                        context={'args': args, 'kwargs': kwargs},
                        recovery_action='fallback'
                    )
                    
                    # 执行回退函数
                    try:
                        return fallback_func(*args, **kwargs)
                    except Exception as fallback_error:
                        # 回退也失败，抛出原始错误
                        raise e
            return wrapper
        return decorator

class ErrorHandler:
    """错误处理器"""
    
    def __init__(self, config_path: Optional[str] = None):
        """
        初始化错误处理器
        
        Args:
            config_path: 配置文件路径
        """
        self.config = self._load_config(config_path)
        self.error_history: List[ErrorInfo] = []
        self.max_history_size = self.config.get('max_history_size', 1000)
        
        # 初始化日志
        self._init_logging()
        
        # 错误统计
        self.stats = {
            'total_errors': 0,
            'by_severity': {level.value: 0 for level in ErrorSeverity},
            'by_type': {etype.value: 0 for etype in ErrorType},
            'recovery_attempts': 0,
            'recovery_success': 0,
            'last_error_time': None
        }
    
    def _load_config(self, config_path: Optional[str]) -> Dict[str, Any]:
        """加载配置"""
        default_config = {
            'log_level': 'INFO',
            'log_file': None,  # 如果为None，则只输出到控制台
            'max_history_size': 1000,
            'auto_recovery': True,
            'notify_on_critical': False,
            'email_notifications': False,
            'email_settings': {},
            'error_reporting': {
                'enabled': True,
                'max_reports_per_day': 10
            }
        }
        
        if config_path and os.path.exists(config_path):
            try:
                with open(config_path, 'r', encoding='utf-8') as f:
                    loaded_config = json.load(f)
                default_config.update(loaded_config)
            except Exception as e:
                print(f"加载错误处理配置失败: {e}")
        
        return default_config
    
    def _init_logging(self):
        """初始化日志系统"""
        # 创建日志格式
        log_format = '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        
        # 设置根日志
        logging.basicConfig(
            level=getattr(logging, self.config['log_level']),
            format=log_format,
            handlers=[]
        )
        
        # 创建错误处理器自己的日志器
        self.logger = logging.getLogger('error_handler')
        
        # 添加控制台处理器
        console_handler = logging.StreamHandler()
        console_handler.setFormatter(logging.Formatter(log_format))
        self.logger.addHandler(console_handler)
        
        # 添加文件处理器（如果配置了日志文件）
        if self.config['log_file']:
            log_dir = os.path.dirname(self.config['log_file'])
            if log_dir:
                os.makedirs(log_dir, exist_ok=True)
            
            file_handler = logging.FileHandler(
                self.config['log_file'],
                encoding='utf-8'
            )
            file_handler.setFormatter(logging.Formatter(log_format))
            self.logger.addHandler(file_handler)
    
    def record_error(
        self,
        error: Exception,
        severity: ErrorSeverity = ErrorSeverity.ERROR,
        error_type: ErrorType = ErrorType.UNKNOWN_ERROR,
        context: Optional[Dict[str, Any]] = None,
        recovery_action: Optional[str] = None,
        error_code: Optional[str] = None
    ) -> ErrorInfo:
        """
        记录错误
        
        Args:
            error: 异常对象
            severity: 错误严重级别
            error_type: 错误类型
            context: 错误上下文信息
            recovery_action: 恢复动作描述
            error_code: 错误代码
            
        Returns:
            错误信息对象
        """
        # 获取调用者信息
        frame = inspect.currentframe()
        caller_frame = frame.f_back
        caller_info = inspect.getframeinfo(caller_frame)
        
        # 创建错误信息
        error_info = ErrorInfo(
            timestamp=time.time(),
            severity=severity,
            error_type=error_type,
            message=str(error),
            module=caller_info.filename,
            function=caller_info.function,
            line_number=caller_info.lineno,
            traceback=traceback.format_exc(),
            context=context,
            recovery_action=recovery_action,
            error_code=error_code
        )
        
        # 记录到历史
        self.error_history.append(error_info)
        
        # 限制历史大小
        if len(self.error_history) > self.max_history_size:
            self.error_history = self.error_history[-self.max_history_size:]
        
        # 更新统计
        self.stats['total_errors'] += 1
        self.stats['by_severity'][severity.value] += 1
        self.stats['by_type'][error_type.value] += 1
        self.stats['last_error_time'] = error_info.timestamp
        
        # 记录日志
        log_method = getattr(self.logger, severity.name.lower())
        log_message = f"[{error_type.value}] {error_info.message}"
        
        if context:
            log_message += f" | Context: {json.dumps(context, ensure_ascii=False)}"
        
        log_method(log_message)
        
        # 如果是严重错误，输出详细跟踪
        if severity in [ErrorSeverity.CRITICAL, ErrorSeverity.FATAL]:
            self.logger.error(f"详细跟踪:\n{error_info.traceback}")
        
        # 发送通知（如果配置了）
        if severity in [ErrorSeverity.CRITICAL, ErrorSeverity.FATAL] and self.config['notify_on_critical']:
            self._send_notification(error_info)
        
        return error_info
    
    def handle_error(
        self,
        error: Exception,
        severity: ErrorSeverity = ErrorSeverity.ERROR,
        error_type: ErrorType = ErrorType.UNKNOWN_ERROR,
        context: Optional[Dict[str, Any]] = None,
        recovery_func: Optional[Callable] = None,
        max_retries: int = 0,
        retry_delay: float = 1.0
    ) -> Any:
        """
        处理错误（带恢复机制）
        
        Args:
            error: 异常对象
            severity: 错误严重级别
            error_type: 错误类型
            context: 错误上下文信息
            recovery_func: 恢复函数
            max_retries: 最大重试次数
            retry_delay: 重试延迟（秒）
            
        Returns:
            恢复函数的结果，或None
        """
        # 记录错误
        error_info = self.record_error(
            error, severity, error_type, context,
            recovery_action='automatic' if recovery_func else 'none'
        )
        
        # 尝试恢复
        if recovery_func and self.config['auto_recovery']:
            self.stats['recovery_attempts'] += 1
            
            # 重试逻辑
            for attempt in range(max_retries + 1):
                try:
                    result = recovery_func()
                    self.stats['recovery_success'] += 1
                    
                    self.logger.info(
                        f"恢复成功 (尝试 {attempt + 1}/{max_retries + 1})"
                    )
                    
                    # 更新错误信息的恢复动作
                    error_info.recovery_action = f'recovered_attempt_{attempt + 1}'
                    
                    return result
                    
                except Exception as recovery_error:
                    if attempt < max_retries:
                        self.logger.warning(
                            f"恢复尝试 {attempt + 1} 失败，{retry_delay}秒后重试: {recovery_error}"
                        )
                        time.sleep(retry_delay)
                    else:
                        self.logger.error(
                            f"所有恢复尝试失败 ({max_retries + 1} 次)"
                        )
                        
                        # 记录恢复失败的错误
                        self.record_error(
                            recovery_error,
                            ErrorSeverity.WARNING,
                            error_type,
                            {'recovery_attempt': attempt + 1, 'original_error': str(error)},
                            'recovery_failed'
                        )
        
        return None
    
    def wrap_function(
        self,
        func: Callable,
        severity: ErrorSeverity = ErrorSeverity.ERROR,
        error_type: ErrorType = ErrorType.UNKNOWN_ERROR,
        recovery_func: Optional[Callable] = None,
        max_retries: int = 0
    ) -> Callable:
        """
        包装函数，自动添加错误处理
        
        Args:
            func: 要包装的函数
            severity: 错误严重级别
            error_type: 错误类型
            recovery_func: 恢复函数
            max_retries: 最大重试次数
            
        Returns:
            包装后的函数
        """
        def wrapper(*args, **kwargs):
            try:
                return func(*args, **kwargs)
            except Exception as e:
                # 创建上下文信息
                context = {
                    'function': func.__name__,
                    'args': str(args),
                    'kwargs': str(kwargs)
                }
                
                # 处理错误
                result = self.handle_error(
                    e, severity, error_type, context,
                    recovery_func, max_retries
                )
                
                # 如果恢复失败，重新抛出异常
                if result is None:
                    raise e
                
                return result
        
        # 保留原函数的名称和文档
        wrapper.__name__ = func.__name__
        wrapper.__doc__ = func.__doc__
        
        return wrapper
    
    def _send_notification(self, error_info: ErrorInfo):
        """发送错误通知"""
        # 这里可以实现邮件、短信、Webhook等通知方式
        # 目前只记录日志
        self.logger.warning(
            f"严重错误需要通知: {error_info.message} "
            f"(类型: {error_info.error_type.value}, 级别: {error_info.severity.name})"
        )
        
        # 在实际版本中，这里可以添加：
        # 1. 邮件通知
        # 2. 短信通知
        # 3. Slack/钉钉/微信通知
        # 4. 系统通知
    
    def get_error_summary(self) -> Dict[str, Any]:
        """获取错误摘要"""
        # 最近24小时的错误
        now = time.time()
        day_ago = now - 24 * 3600
        
        recent_errors = [
            error for error in self.error_history
            if error.timestamp >= day_ago
        ]
        
        # 按严重级别分组
        by_severity = {}
        for severity in ErrorSeverity:
            count = len([e for e in recent_errors if e.severity == severity])
            if count > 0:
                by_severity[severity.name] = count
        
        # 按类型分组
        by_type = {}
        for etype in ErrorType:
            count = len([e for e in recent_errors if e.error_type == etype])
            if count > 0:
                by_type[etype.value] = count
        
        # 最常见的错误消息
        error_messages = {}
        for error in recent_errors:
            msg = error.message[:100]  # 截断长消息
            error_messages[msg] = error_messages.get(msg, 0) + 1
        
        top_errors = sorted(
            error_messages.items(),
            key=lambda x: x[1],
            reverse=True
        )[:5]
        
        return {
            'timestamp': now,
            'total_errors': self.stats['total_errors'],
            'recent_24h': len(recent_errors),
            'by_severity': by_severity,
            'by_type': by_type,
            'top_errors': top_errors,
            'recovery_stats': {
                'attempts': self.stats['recovery_attempts'],
                'success': self.stats['recovery_success'],
                'success_rate': (
                    self.stats['recovery_success'] / self.stats['recovery_attempts']
                    if self.stats['recovery_attempts'] > 0 else 0
                )
            },
            'last_error_time': self.stats['last_error_time']
        }
    
    def save_error_report(self, filepath: str) -> bool:
        """保存错误报告"""
        try:
            report_dir = os.path.dirname(filepath)
            if report_dir:
                os.makedirs(report_dir, exist_ok=True)
            
            report_data = {
                'summary': self.get_error_summary(),
                'recent_errors': [
                    error.to_dict() for error in self.error_history[-100:]  # 最近100个错误
                ],
                'system_info': {
                    'platform': sys.platform,
                    'python_version': sys.version,
                    'timestamp': time.time()
                }
            }
            
            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(report_data, f, indent=2, ensure_ascii=False)
            
            self.logger.info(f"错误报告已保存: {filepath}")
            return True
            
        except Exception as e:
            self.logger.error(f"保存错误报告失败: {e}")
            return False
    
    def clear_history(self):
        """清空错误历史"""
        self.error_history.clear()
        self.logger.info("错误历史已清空")
    
    def create_error_monitor(self, interval: float = 60.0) -> 'ErrorMonitor':
        """创建错误监控器"""
        return ErrorMonitor(self, interval)

class ErrorMonitor:
    """错误监控器（定期检查错误状态）"""
    
    def __init__(self, error_handler: ErrorHandler, interval: float = 60.0):
        """
        初始化错误监控器
        
        Args:
            error_handler: 错误处理器
            interval: 检查间隔（秒）
        """
        self.error_handler = error_handler
        self.interval = interval
        self.running = False
        self.thread = None
        
        # 监控配置
        self.thresholds = {
            ErrorSeverity.ERROR: 10,      # 每小时最多10个ERROR
            ErrorSeverity.CRITICAL: 3,    # 每小时最多3个CRITICAL
            ErrorSeverity.FATAL: 1        # 每小时最多1个FATAL
        }
        
        # 监控统计
        self.monitor_stats = {
            'checks_performed': 0,
            'alerts_triggered': 0,
            'last_check_time': None
        }
    
    def start(self):
        """启动监控器"""
        import threading
        
        if self.running:
            self.error_handler.logger.warning("监控器已在运行")
            return
        
        self.running = True
        self.thread = threading.Thread(target=self._monitor_loop, daemon=True)
        self.thread.start()
        
        self.error_handler.logger.info(f"错误监控器已启动，检查间隔: {self.interval}秒")
    
    def stop(self):
        """停止监控器"""
        self.running = False
        if self.thread:
            self.thread.join(timeout=5.0)
        
        self.error_handler.logger.info("错误监控器已停止")
    
    def _monitor_loop(self):
        """监控循环"""
        while self.running:
            try:
                self._check_errors()
                time.sleep(self.interval)
            except Exception as e:
                self.error_handler.logger.error(f"监控循环出错: {e}")
                time.sleep(self.interval)
    
    def _check_errors(self):
        """检查错误状态"""
        self.monitor_stats['checks_performed'] += 1
        self.monitor_stats['last_check_time'] = time.time()
        
        # 获取最近1小时的错误
        now = time.time()
        hour_ago = now - 3600
        
        recent_errors = [
            error for error in self.error_handler.error_history
            if error.timestamp >= hour_ago
        ]
        
        # 检查阈值
        alerts = []
        
        for severity, threshold in self.thresholds.items():
            count = len([e for e in recent_errors if e.severity == severity])
            
            if count > threshold:
                alert_msg = (
                    f"错误阈值警报: {severity.name} "
                    f"({count} > {threshold} 每小时)"
                )
                alerts.append(alert_msg)
                
                self.error_handler.logger.warning(alert_msg)
        
        # 检查错误率趋势
        if len(recent_errors) >= 5:  # 至少有5个错误才检查趋势
            # 将最近1小时分成4个15分钟段
            segments = []
            for i in range(4):
                segment_start = hour_ago + i * 900
                segment_end = segment_start + 900
                
                segment_errors = [
                    e for e in recent_errors
                    if segment_start <= e.timestamp < segment_end
                ]
                segments.append(len(segment_errors))
            
            # 检查是否递增趋势
            if (segments[0] < segments[1] < segments[2] < segments[3]):
                trend_alert = "错误率呈上升趋势（连续4个15分钟段递增）"
                alerts.append(trend_alert)
                self.error_handler.logger.warning(trend_alert)
        
        # 如果有警报，更新统计
        if alerts:
            self.monitor_stats['alerts_triggered'] += 1
            
            # 在实际版本中，这里可以触发通知
            # self._trigger_alerts(alerts)
    
    def get_monitor_stats(self) -> Dict[str, Any]:
        """获取监控统计"""
        return {
            **self.monitor_stats,
            'running': self.running,
            'interval': self.interval,
            'thresholds': {k.name: v for k, v in self.thresholds.items()}
        }

# 全局错误处理器实例
_global_error_handler = None

def get_global_error_handler(config_path: Optional[str] = None) -> ErrorHandler:
    """获取全局错误处理器"""
    global _global_error_handler
    
    if _global_error_handler is None:
        _global_error_handler = ErrorHandler(config_path)
    
    return _global_error_handler

def handle_global_error(
    error: Exception,
    severity: ErrorSeverity = ErrorSeverity.ERROR,
    error_type: ErrorType = ErrorType.UNKNOWN_ERROR,
    context: Optional[Dict[str, Any]] = None
) -> ErrorInfo:
    """使用全局错误处理器处理错误"""
    handler = get_global_error_handler()
    return handler.record_error(error, severity, error_type, context)

def wrap_global_function(
    func: Callable,
    severity: ErrorSeverity = ErrorSeverity.ERROR,
    error_type: ErrorType = ErrorType.UNKNOWN_ERROR,
    recovery_func: Optional[Callable] = None,
    max_retries: int = 0
) -> Callable:
    """使用全局错误处理器包装函数"""
    handler = get_global_error_handler()
    return handler.wrap_function(func, severity, error_type, recovery_func, max_retries)

# 装饰器版本
def error_handler_decorator(
    severity: ErrorSeverity = ErrorSeverity.ERROR,
    error_type: ErrorType = ErrorType.UNKNOWN_ERROR,
    recovery_func: Optional[Callable] = None,
    max_retries: int = 0
):
    """错误处理装饰器"""
    def decorator(func: Callable) -> Callable:
        return wrap_global_function(func, severity, error_type, recovery_func, max_retries)
    return decorator

# 测试函数
def test_error_handler():
    """测试错误处理器"""
    print("🧪 测试错误处理系统")
    print("=" * 50)
    
    # 创建错误处理器
    handler = ErrorHandler()
    
    # 测试记录错误
    print("1. 测试记录错误...")
    try:
        raise ValueError("测试错误")
    except ValueError as e:
        error_info = handler.record_error(
            e,
            ErrorSeverity.ERROR,
            ErrorType.VALIDATION_ERROR,
            {'test': True, 'value': 123}
        )
        print(f"   ✅ 错误已记录: {error_info.message}")
    
    # 测试错误处理（带恢复）
    print("\n2. 测试错误处理（带恢复）...")
    
    def failing_function():
        raise RuntimeError("函数执行失败")
    
    def recovery_function():
        return "恢复成功"
    
    wrapped_func = handler.wrap_function(
        failing_function,
        ErrorSeverity.ERROR,
        ErrorType.UNKNOWN_ERROR,
        recovery_function,
        max_retries=2
    )
    
    try:
        result = wrapped_func()
        print(f"   ✅ 恢复成功: {result}")
    except Exception as e:
        print(f"   ❌ 恢复失败: {e}")
    
    # 测试错误摘要
    print("\n3. 测试错误摘要...")
    summary = handler.get_error_summary()
    print(f"   ✅ 总错误数: {summary['total_errors']}")
    print(f"   ✅ 最近24小时: {summary['recent_24h']}")
    
    # 测试装饰器版本
    print("\n4. 测试装饰器版本...")
    
    @error_handler_decorator(
        severity=ErrorSeverity.WARNING,
        error_type=ErrorType.CONFIG_ERROR,
        max_retries=1
    )
    def decorated_function(x, y):
        if x < 0:
            raise ValueError("x不能为负数")
        return x + y
    
    try:
        result = decorated_function(-1, 5)
        print(f"   ❌ 不应该成功: {result}")
    except ValueError as e:
        print(f"   ✅ 装饰器捕获错误: {e}")
    
    result = decorated_function(2, 3)
    print(f"   ✅ 正常执行: {result}")
    
    # 测试恢复动作装饰器
    print("\n5. 测试恢复动作装饰器...")
    
    @RecoveryAction.retry(max_attempts=3, delay=0.1)
    def retry_function():
        import random
        if random.random() < 0.7:
            raise ValueError("随机失败")
        return "成功"
    
    try:
        result = retry_function()
        print(f"   ✅ 重试成功: {result}")
    except Exception as e:
        print(f"   ❌ 重试失败: {e}")
    
    # 测试错误报告
    print("\n6. 测试错误报告...")
    report_file = Path.home() / "StoneCaptcha" / "test_error_report.json"
    success = handler.save_error_report(str(report_file))
    
    if success:
        print(f"   ✅ 错误报告已保存: {report_file}")
    else:
        print("   ❌ 保存错误报告失败")
    
    print("\n" + "=" * 50)
    print("错误处理系统测试完成")

if __name__ == "__main__":
    test_error_handler()