"""
窗口管理器模块

提供游戏窗口的查找、控制和管理功能。
"""

import time
import ctypes
from typing import Optional, Dict, Any, List, Tuple
from dataclasses import dataclass, field
from enum import Enum

# Windows API常量
import win32gui
import win32con
import win32api

from ..core.exceptions import (
    WindowNotFoundError, WindowNotAccessibleError, WindowStateError
)
from ..core.logger import log_function_call, log_performance
from ..core.config import get_config


class WindowState(Enum):
    """窗口状态枚举"""
    UNKNOWN = "unknown"
    EXISTS = "exists"
    VISIBLE = "visible"
    ACTIVE = "active"
    MINIMIZED = "minimized"
    MAXIMIZED = "maximized"
    NORMAL = "normal"
    HIDDEN = "hidden"


@dataclass
class WindowInfo:
    """窗口信息"""
    hwnd: int
    title: str
    class_name: str
    rect: Tuple[int, int, int, int]  # left, top, right, bottom
    state: WindowState
    process_id: int
    thread_id: int
    is_visible: bool
    is_enabled: bool
    is_active: bool
    
    @property
    def width(self) -> int:
        """窗口宽度"""
        return self.rect[2] - self.rect[0]
    
    @property
    def height(self) -> int:
        """窗口高度"""
        return self.rect[3] - self.rect[1]
    
    @property
    def position(self) -> Tuple[int, int]:
        """窗口位置 (x, y)"""
        return (self.rect[0], self.rect[1])
    
    @property
    def size(self) -> Tuple[int, int]:
        """窗口大小 (width, height)"""
        return (self.width, self.height)
    
    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return {
            'hwnd': self.hwnd,
            'title': self.title,
            'class_name': self.class_name,
            'rect': self.rect,
            'state': self.state.value,
            'process_id': self.process_id,
            'thread_id': self.thread_id,
            'is_visible': self.is_visible,
            'is_enabled': self.is_enabled,
            'is_active': self.is_active,
            'width': self.width,
            'height': self.height,
            'position': self.position,
            'size': self.size
        }


class WindowManager:
    """窗口管理器"""
    
    def __init__(self, config_path: Optional[str] = None):
        """
        初始化窗口管理器
        
        Args:
            config_path: 配置文件路径
        """
        self.config = get_config(config_path)
        self.game_config = self.config.game
        self.logger = self.config.logging
        
        # 窗口缓存
        self._window_cache: Dict[int, WindowInfo] = {}
        self._last_found_hwnd: Optional[int] = None
        
        # 状态跟踪
        self._last_state: Optional[WindowState] = None
        self._state_changes: List[Tuple[float, WindowState, WindowState]] = []  # (timestamp, old, new)
    
    @log_function_call("DEBUG")
    @log_performance(0.5)
    def find_game_window(self, title: Optional[str] = None, 
                        class_name: Optional[str] = None,
                        timeout: Optional[float] = None) -> WindowInfo:
        """
        查找游戏窗口
        
        Args:
            title: 窗口标题，如果为None则使用配置中的标题
            class_name: 窗口类名，如果为None则使用配置中的类名
            timeout: 超时时间（秒），如果为None则使用配置中的超时
            
        Returns:
            窗口信息
            
        Raises:
            WindowNotFoundError: 未找到窗口
        """
        target_title = title or self.game_config.window_title
        target_class = class_name or self.game_config.window_class
        search_timeout = timeout or self.game_config.window_search_timeout
        
        start_time = time.time()
        retry_interval = self.game_config.window_retry_interval
        
        while time.time() - start_time < search_timeout:
            try:
                # 尝试查找窗口
                window_info = self._find_window_by_criteria(target_title, target_class)
                
                if window_info:
                    self._last_found_hwnd = window_info.hwnd
                    self._window_cache[window_info.hwnd] = window_info
                    
                    # 记录窗口找到事件
                    self.logger.window_event("found", window_info.to_dict())
                    return window_info
                
                # 未找到，等待后重试
                time.sleep(retry_interval)
            
            except Exception as e:
                self.logger.error(f"查找窗口时出错: {e}")
                time.sleep(retry_interval)
        
        # 超时未找到
        error_details = f"标题: {target_title}, 类名: {target_class}, 超时: {search_timeout}秒"
        raise WindowNotFoundError(target_title, error_details)
    
    def _find_window_by_criteria(self, title: str, class_name: str) -> Optional[WindowInfo]:
        """根据条件查找窗口"""
        def enum_windows_callback(hwnd, results):
            try:
                # 获取窗口标题
                window_title = win32gui.GetWindowText(hwnd)
                
                # 检查标题匹配
                title_match = not title or title in window_title
                
                # 获取窗口类名
                window_class = win32gui.GetClassName(hwnd)
                class_match = not class_name or class_name == window_class
                
                if title_match and class_match:
                    # 获取窗口信息
                    window_info = self._get_window_info(hwnd)
                    if window_info:
                        results.append(window_info)
                        return False  # 停止枚举
                
                return True  # 继续枚举
            
            except Exception:
                return True  # 继续枚举
        
        results = []
        try:
            win32gui.EnumWindows(enum_windows_callback, results)
            return results[0] if results else None
        except Exception:
            return None
    
    @log_function_call("DEBUG")
    def _get_window_info(self, hwnd: int) -> Optional[WindowInfo]:
        """获取窗口详细信息"""
        try:
            # 基本窗口信息
            title = win32gui.GetWindowText(hwnd)
            class_name = win32gui.GetClassName(hwnd)
            
            # 窗口矩形
            rect = win32gui.GetWindowRect(hwnd)
            
            # 窗口状态
            is_visible = win32gui.IsWindowVisible(hwnd)
            is_enabled = win32gui.IsWindowEnabled(hwnd)
            is_active = win32gui.GetForegroundWindow() == hwnd
            
            # 进程和线程ID
            _, process_id = win32gui.GetWindowThreadProcessId(hwnd)
            thread_id = win32api.GetCurrentThreadId()
            
            # 确定窗口状态
            state = self._determine_window_state(hwnd, is_visible, is_active)
            
            # 创建窗口信息对象
            window_info = WindowInfo(
                hwnd=hwnd,
                title=title,
                class_name=class_name,
                rect=rect,
                state=state,
                process_id=process_id,
                thread_id=thread_id,
                is_visible=is_visible,
                is_enabled=is_enabled,
                is_active=is_active
            )
            
            return window_info
        
        except Exception as e:
            self.logger.error(f"获取窗口信息失败 (HWND: {hwnd}): {e}")
            return None
    
    def _determine_window_state(self, hwnd: int, is_visible: bool, is_active: bool) -> WindowState:
        """确定窗口状态"""
        try:
            # 检查窗口是否存在
            if not win32gui.IsWindow(hwnd):
                return WindowState.UNKNOWN
            
            # 检查是否最小化
            placement = win32gui.GetWindowPlacement(hwnd)
            if placement[1] == win32con.SW_SHOWMINIMIZED:
                return WindowState.MINIMIZED
            
            # 检查是否最大化
            if placement[1] == win32con.SW_SHOWMAXIMIZED:
                return WindowState.MAXIMIZED
            
            # 检查是否可见
            if not is_visible:
                return WindowState.HIDDEN
            
            # 检查是否激活
            if is_active:
                return WindowState.ACTIVE
            
            # 正常状态
            return WindowState.NORMAL
        
        except Exception:
            return WindowState.UNKNOWN
    
    @log_function_call("INFO")
    @log_performance(0.5)
    def activate_window(self, hwnd: Optional[int] = None) -> bool:
        """
        激活窗口
        
        Args:
            hwnd: 窗口句柄，如果为None则使用最后找到的窗口
            
        Returns:
            是否成功激活
            
        Raises:
            WindowNotFoundError: 窗口未找到
            WindowNotAccessibleError: 窗口不可访问
        """
        target_hwnd = hwnd or self._last_found_hwnd
        
        if not target_hwnd:
            raise WindowNotFoundError("未指定窗口句柄且未找到历史窗口")
        
        try:
            # 检查窗口是否存在
            if not win32gui.IsWindow(target_hwnd):
                raise WindowNotFoundError(f"窗口不存在 (HWND: {target_hwnd})")
            
            # 检查窗口是否可见和启用
            if not win32gui.IsWindowVisible(target_hwnd):
                self.logger.warning(f"窗口不可见 (HWND: {target_hwnd})")
            
            if not win32gui.IsWindowEnabled(target_hwnd):
                self.logger.warning(f"窗口未启用 (HWND: {target_hwnd})")
            
            # 尝试不同的激活方法
            
            # 方法1: 使用SetForegroundWindow
            try:
                win32gui.SetForegroundWindow(target_hwnd)
                time.sleep(0.1)
                
                if win32gui.GetForegroundWindow() == target_hwnd:
                    self.logger.info(f"窗口激活成功 (HWND: {target_hwnd})")
                    return True
            except Exception as e:
                self.logger.debug(f"SetForegroundWindow失败: {e}")
            
            # 方法2: 使用ShowWindow和SetForegroundWindow组合
            try:
                # 先恢复窗口（如果最小化）
                placement = win32gui.GetWindowPlacement(target_hwnd)
                if placement[1] == win32con.SW_SHOWMINIMIZED:
                    win32gui.ShowWindow(target_hwnd, win32con.SW_RESTORE)
                    time.sleep(0.1)
                
                # 再激活
                win32gui.SetForegroundWindow(target_hwnd)
                time.sleep(0.1)
                
                if win32gui.GetForegroundWindow() == target_hwnd:
                    self.logger.info(f"窗口激活成功 (HWND: {target_hwnd})")
                    return True
            except Exception as e:
                self.logger.debug(f"组合激活方法失败: {e}")
            
            # 方法3: 使用AttachThreadInput
            try:
                # 获取窗口线程ID
                window_thread_id, _ = win32gui.GetWindowThreadProcessId(target_hwnd)
                
                # 获取当前线程ID
                current_thread_id = win32api.GetCurrentThreadId()
                
                # 附加线程输入
                win32process.AttachThreadInput(current_thread_id, window_thread_id, True)
                
                # 激活窗口
                win32gui.SetForegroundWindow(target_hwnd)
                win32gui.SetActiveWindow(target_hwnd)
                
                # 分离线程输入
                win32process.AttachThreadInput(current_thread_id, window_thread_id, False)
                
                time.sleep(0.1)
                
                if win32gui.GetForegroundWindow() == target_hwnd:
                    self.logger.info(f"窗口激活成功 (HWND: {target_hwnd})")
                    return True
            except Exception as e:
                self.logger.debug(f"AttachThreadInput方法失败: {e}")
            
            # 所有方法都失败
            self.logger.error(f"窗口激活失败 (HWND: {target_hwnd})")
            return False
        
        except Exception as e:
            error_msg = f"激活窗口时出错 (HWND: {target_hwnd}): {e}"
            self.logger.error(error_msg)
            raise WindowNotAccessibleError(f"HWND: {target_hwnd}", str(e))
    
    @log_function_call("INFO")
    def move_window(self, hwnd: Optional[int] = None, 
                   x: Optional[int] = None, y: Optional[int] = None,
                   width: Optional[int] = None, height: Optional[int] = None) -> bool:
        """
        移动和调整窗口大小
        
        Args:
            hwnd: 窗口句柄
            x: 新X坐标
            y: 新Y坐标
            width: 新宽度
            height: 新高度
            
        Returns:
            是否成功
        """
        target_hwnd = hwnd or self._last_found_hwnd
        
        if not target_hwnd:
            raise WindowNotFoundError("未指定窗口句柄且未找到历史窗口")
        
        try:
            # 获取当前窗口信息
            window_info = self.get_window_info(target_hwnd)
            if not window_info:
                raise WindowNotFoundError(f"窗口未找到 (HWND: {target_hwnd})")
            
            # 使用当前值作为默认值
            current_x, current_y = window_info.position
            current_width, current_height = window_info.size
            
            new_x = x if x is not None else current_x
            new_y = y if y is not None else current_y
            new_width = width if width is not None else current_width
            new_height = height if height is not None else current_height
            
            # 移动和调整大小
            result = win32gui.MoveWindow(
                target_hwnd,
                new_x, new_y,
                new_width, new_height,
                True  # 重绘
            )
            
            if result:
                self.logger.info(
                    f"窗口移动调整成功 (HWND: {target_hwnd}): "
                    f"位置({new_x}, {new_y}), 大小({new_width}x{new_height})"
                )
            
            return result
        
        except Exception as e:
            self.logger.error(f"移动窗口失败 (HWND: {target_hwnd}): {e}")
            return False
    
    @log_function_call("INFO")
    def minimize_window(self, hwnd: Optional[int] = None) -> bool:
        """最小化窗口"""
        return self._set_window_show_state(hwnd, win32con.SW_MINIMIZE, "minimize")
    
    @log_function_call("INFO")
    def maximize_window(self, hwnd: Optional[int] = None) -> bool:
        """最大化窗口"""
        return self._set_window_show_state(hwnd, win32con.SW_MAXIMIZE, "maximize")
    
    @log_function_call("INFO")
    def restore_window(self, hwnd: Optional[int] = None) -> bool:
        """恢复窗口"""
        return self._set_window_show_state(hwnd, win32con.SW_RESTORE, "restore")
    
    def _set_window_show_state(self, hwnd: Optional[int], show_cmd: int, operation: str) -> bool:
        """设置窗口显示状态"""
        target_hwnd = hwnd or self._last_found_hwnd
        
        if not target_hwnd:
            raise WindowNotFoundError("未指定窗口句柄且未找到历史窗口")
        
        try:
            result = win32gui.ShowWindow(target_hwnd, show_cmd)
            
            if result:
                self.logger.info(f"窗口{operation}成功 (HWND: {target_hwnd})")
            else:
                self.logger.warning(f"窗口{operation}失败 (HWND: {target_hwnd})")
            
            return bool(result)
        
        except Exception as e:
            self.logger.error(f"窗口{operation}失败 (HWND: {target_hwnd}): {e}")
            return False
    
    @log_function_call("DEBUG")
    def get_window_info(self, hwnd: Optional[int] = None) -> Optional[WindowInfo]:
        """
        获取窗口信息
        
        Args:
            hwnd: 窗口句柄，如果为None则使用最后找到的窗口
            
        Returns:
            窗口信息，如果窗口不存在则返回None
        """
        target_hwnd = hwnd or self._last_found_hwnd
        
        if not target_hwnd:
            return None
        
        # 检查缓存
        if target_hwnd in self._window_cache:
            cached_info = self._window_cache[target_hwnd]
            
            # 验证缓存是否仍然有效
            try:
                if win32gui.IsWindow(target_hwnd):
                    return cached_info
            except Exception:
                pass
        
        # 获取最新信息
        window_info = self._get_window_info(target_hwnd)
        if window_info:
            self._window_cache[target_hwnd] = window_info
        
        return window_info
    
    @log_function_call("DEBUG")
    def monitor_window_state(self, hwnd: Optional[int] = None, 
                           interval: Optional[float] = None) -> WindowState:
        """
        监控窗口状态
        
        Args:
            hwnd: 窗口句柄
            interval: 监控间隔
            
        Returns:
            当前窗口状态
        """
        target_hwnd = hwnd or self._last_found_hwnd
        monitor_interval = interval or self.config.monitor.window_monitor_interval
        
        if not target_hwnd:
            return WindowState.UNKNOWN
        
        try:
            window_info = self.get_window_info(target_hwnd)
            if not window_info:
                return WindowState.UNKNOWN
            
            # 跟踪状态变化
            current_state = window_info.state
            if self._last_state and self._last_state != current_state:
                timestamp = time.time()
                self._state_changes.append((timestamp, self._last_state, current_state))
                
                # 记录状态变化
                self.logger.info(
                    f"窗口状态变化 (HWND: {target_hwnd}): "
                    f"{self._last_state.value} -> {current_state.value}"
                )
            
            self._last_state = current_state
            
            # 清理旧的状态变化记录
            current_time = time.time()
            self._state_changes = [
                (ts, old, new) for ts, old, new in self._state_changes
                if current_time - ts < 3600  # 保留1小时内的记录
            ]
            
            return current_state
        
        except Exception as e:
            self.logger.error(f"监控窗口状态失败 (HWND: {target_hwnd}): {e}")
            return WindowState.UNKNOWN
    
    @log_function_call("DEBUG")
    def get_all_windows(self) -> List[WindowInfo]:
        """获取所有窗口"""
        windows = []
        
        def enum_callback(hwnd, results):
            try:
                window_info = self._get_window_info(hwnd)
                if window_info:
                    results.append(window_info)
            except Exception:
                pass
            return True
        
        win32gui.EnumWindows(enum_callback, windows)
        return windows
    
    @log_function_call("DEBUG")
    def find_windows_by_title(self, title_pattern: str) -> List[WindowInfo]:
        """根据标题模式查找窗口"""
        windows = []
        
        def enum_callback(hwnd, results):
            try:
                window_title = win32gui.GetWindowText(hwnd)
                if title_pattern in window_title:
                    window_info = self._get_window_info(hwnd)
                    if window_info:
                        results.append(window_info)
            except Exception:
                pass
            return True
        
        win32gui.EnumWindows(enum_callback, windows)
        return windows
    
    @log_function_call("DEBUG")
    def find_windows_by_class(self, class_name: str) -> List[WindowInfo]:
        """根据类名查找窗口"""
        windows = []
        
        def enum_callback(hwnd, results):
            try:
                window_class = win32gui.GetClassName(hwnd)
                if class_name == window_class:
                    window_info = self._get_window_info(hwnd)
                    if window_info:
                        results.append(window_info)
            except Exception:
                pass
            return True
        
        win32gui.EnumWindows(enum_callback, windows)
        return windows
    
    @log_function_call("INFO")
    def close_window(self, hwnd: Optional[int] = None, force: bool = False) -> bool:
        """
        关闭窗口
        
        Args:
            hwnd: 窗口句柄
            force: 是否强制关闭
            
        Returns:
            是否成功
        """
        target_hwnd = hwnd or self._last_found_hwnd
        
        if not target_hwnd:
            raise WindowNotFoundError("未指定窗口句柄且未找到历史窗口")
        
        try:
            if force:
                # 强制关闭
                result = win32gui.DestroyWindow(target_hwnd)
            else:
                # 正常关闭（发送关闭消息）
                result = win32gui.PostMessage(target_hwnd, win32con.WM_CLOSE, 0, 0)
            
            if result:
                self.logger.info(f"窗口关闭成功 (HWND: {target_hwnd}, 强制: {force})")
                
                # 清理缓存
                if target_hwnd in self._window_cache:
                    del self._window_cache[target_hwnd]
                
                if target_hwnd == self._last_found_hwnd:
                    self._last_found_hwnd = None
            
            return bool(result)
        
        except Exception as e:
            self.logger.error(f"关闭窗口失败 (HWND: {target_hwnd}): {e}")
            return False
    
    @log_function_call("DEBUG")
    def get_window_screenshot(self, hwnd: Optional[int] = None, 
                            region: Optional[Tuple[int, int, int, int]] = None):
        """
        获取窗口截图
        
        Args:
            hwnd: 窗口句柄
            region: 截图区域 (left, top, right, bottom)，如果为None则截取整个窗口
            
        Returns:
            PIL Image对象或None
        """
        try:
            from PIL import ImageGrab
            
            target_hwnd = hwnd or self._last_found_hwnd
            if not target_hwnd:
                return None
            
            # 获取窗口矩形
            if region:
                left, top, right, bottom = region
            else:
                left, top, right, bottom = win32gui.GetWindowRect(target_hwnd)
            
            # 截取屏幕区域
            screenshot = ImageGrab.grab(bbox=(left, top, right, bottom))
            
            self.logger.debug(
                f"窗口截图成功 (HWND: {target_hwnd}): "
                f"区域({left}, {top}, {right}, {bottom}), 大小{screenshot.size}"
            )
            
            return screenshot
        
        except Exception as e:
            self.logger.error(f"获取窗口截图失败: {e}")
            return None
    
    @log_function_call("DEBUG")
    def get_state_history(self, limit: int = 10) -> List[Tuple[float, str, str]]:
        """
        获取状态变化历史
        
        Args:
            limit: 返回的最大记录数
            
        Returns:
            状态变化历史列表 [(timestamp, old_state, new_state), ...]
        """
        history = []
        for ts, old, new in self._state_changes[-limit:]:
            history.append((ts, old.value, new.value))
        return history
    
    @log_function_call("INFO")
    def clear_cache(self):
        """清理缓存"""
        cache_size = len(self._window_cache)
        self._window_cache.clear()
        self._last_found_hwnd = None
        self._last_state = None
        self._state_changes.clear()
        
        self.logger.info(f"窗口缓存已清理，清理了 {cache_size} 个缓存项")
    
    def __del__(self):
        """析构函数，清理资源"""
        try:
            self.clear_cache()
        except Exception:
            pass


# 简化使用
def create_window_manager(config_path: Optional[str] = None) -> WindowManager:
    """创建窗口管理器实例"""
    return WindowManager(config_path)