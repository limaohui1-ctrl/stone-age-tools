"""
自定义异常类定义

定义游戏客户端集成工具的所有自定义异常。
"""

from typing import Optional


class StoneAgeClientError(Exception):
    """石器时代客户端工具的基础异常类"""
    
    def __init__(self, message: str, details: Optional[str] = None):
        self.message = message
        self.details = details
        super().__init__(self._format_message())
    
    def _format_message(self) -> str:
        if self.details:
            return f"{self.message} (详情: {self.details})"
        return self.message


# ==================== 窗口相关异常 ====================

class WindowNotFoundError(StoneAgeClientError):
    """游戏窗口未找到异常"""
    
    def __init__(self, window_title: Optional[str] = None, details: Optional[str] = None):
        if window_title:
            message = f"未找到游戏窗口: {window_title}"
        else:
            message = "未找到游戏窗口"
        super().__init__(message, details)


class WindowNotAccessibleError(StoneAgeClientError):
    """游戏窗口不可访问异常"""
    
    def __init__(self, window_title: str, details: Optional[str] = None):
        message = f"游戏窗口不可访问: {window_title}"
        super().__init__(message, details)


class WindowStateError(StoneAgeClientError):
    """窗口状态异常"""
    
    def __init__(self, state: str, details: Optional[str] = None):
        message = f"窗口状态异常: {state}"
        super().__init__(message, details)


# ==================== 进程相关异常 ====================

class ProcessNotFoundError(StoneAgeClientError):
    """游戏进程未找到异常"""
    
    def __init__(self, process_name: Optional[str] = None, details: Optional[str] = None):
        if process_name:
            message = f"未找到游戏进程: {process_name}"
        else:
            message = "未找到游戏进程"
        super().__init__(message, details)


class ProcessNotAccessibleError(StoneAgeClientError):
    """游戏进程不可访问异常"""
    
    def __init__(self, process_name: str, details: Optional[str] = None):
        message = f"游戏进程不可访问: {process_name}"
        super().__init__(message, details)


class ProcessPermissionError(StoneAgeClientError):
    """进程权限不足异常"""
    
    def __init__(self, operation: str, details: Optional[str] = None):
        message = f"进程操作权限不足: {operation}"
        super().__init__(message, details)


# ==================== 内存相关异常 ====================

class MemoryReadError(StoneAgeClientError):
    """内存读取异常"""
    
    def __init__(self, address: str, details: Optional[str] = None):
        message = f"内存读取失败: 地址 {address}"
        super().__init__(message, details)


class MemoryPatternNotFoundError(StoneAgeClientError):
    """内存模式未找到异常"""
    
    def __init__(self, pattern_name: str, details: Optional[str] = None):
        message = f"内存模式未找到: {pattern_name}"
        super().__init__(message, details)


class MemoryAccessViolationError(StoneAgeClientError):
    """内存访问违规异常"""
    
    def __init__(self, address: str, details: Optional[str] = None):
        message = f"内存访问违规: 地址 {address}"
        super().__init__(message, details)


# ==================== 图像识别相关异常 ====================

class ImageNotFoundError(StoneAgeClientError):
    """图像未找到异常"""
    
    def __init__(self, image_name: str, details: Optional[str] = None):
        message = f"图像未找到: {image_name}"
        super().__init__(message, details)


class ImageRecognitionError(StoneAgeClientError):
    """图像识别异常"""
    
    def __init__(self, operation: str, details: Optional[str] = None):
        message = f"图像识别失败: {operation}"
        super().__init__(message, details)


class ScreenCaptureError(StoneAgeClientError):
    """屏幕捕获异常"""
    
    def __init__(self, details: Optional[str] = None):
        message = "屏幕捕获失败"
        super().__init__(message, details)


# ==================== 自动化相关异常 ====================

class InputSimulationError(StoneAgeClientError):
    """输入模拟异常"""
    
    def __init__(self, input_type: str, details: Optional[str] = None):
        message = f"输入模拟失败: {input_type}"
        super().__init__(message, details)


class HotkeyConflictError(StoneAgeClientError):
    """热键冲突异常"""
    
    def __init__(self, hotkey: str, details: Optional[str] = None):
        message = f"热键冲突: {hotkey}"
        super().__init__(message, details)


class StateMachineError(StoneAgeClientError):
    """状态机异常"""
    
    def __init__(self, state: str, details: Optional[str] = None):
        message = f"状态机错误: 状态 {state}"
        super().__init__(message, details)


# ==================== 配置相关异常 ====================

class ConfigError(StoneAgeClientError):
    """配置异常"""
    
    def __init__(self, config_key: str, details: Optional[str] = None):
        message = f"配置错误: {config_key}"
        super().__init__(message, details)


class ConfigNotFoundError(StoneAgeClientError):
    """配置文件未找到异常"""
    
    def __init__(self, config_path: str, details: Optional[str] = None):
        message = f"配置文件未找到: {config_path}"
        super().__init__(message, details)


# ==================== 集成相关异常 ====================

class IntegrationError(StoneAgeClientError):
    """集成异常"""
    
    def __init__(self, component: str, details: Optional[str] = None):
        message = f"集成错误: {component}"
        super().__init__(message, details)


class ASSAIntegrationError(StoneAgeClientError):
    """ASSA集成异常"""
    
    def __init__(self, operation: str, details: Optional[str] = None):
        message = f"ASSA集成错误: {operation}"
        super().__init__(message, details)


# ==================== 工具函数 ====================

def handle_exception(exc: Exception, context: str = "") -> str:
    """
    处理异常并返回友好的错误消息
    
    Args:
        exc: 异常对象
        context: 上下文信息
        
    Returns:
        格式化的错误消息
    """
    if isinstance(exc, StoneAgeClientError):
        error_msg = str(exc)
    else:
        error_msg = f"未预期的错误: {type(exc).__name__}: {str(exc)}"
    
    if context:
        return f"[{context}] {error_msg}"
    return error_msg


def safe_execute(func, *args, default=None, context: str = "", **kwargs):
    """
    安全执行函数，捕获异常并返回默认值
    
    Args:
        func: 要执行的函数
        default: 异常时返回的默认值
        context: 上下文信息
        *args, **kwargs: 函数参数
        
    Returns:
        函数结果或默认值
    """
    try:
        return func(*args, **kwargs)
    except Exception as exc:
        error_msg = handle_exception(exc, context)
        print(f"警告: {error_msg}")
        return default