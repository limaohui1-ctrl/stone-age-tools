#!/usr/bin/env python3
"""
石器时代脚本自动化测试框架 - 主入口
"""

import os
import sys
import argparse
import logging
from pathlib import Path

# 添加src目录到Python路径
src_dir = Path(__file__).parent / "src"
sys.path.insert(0, str(src_dir))

# 直接导入模块
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# 现在可以导入
try:
    from src.test_framework import TestRunner, TestCase, TestStatus
    from src.test_manager import TestManager
    from src.coverage_analyzer import CodeCoverageAnalyzer
except ImportError:
    # 备用导入方式
    from test_framework import TestRunner, TestCase, TestStatus
    from test_manager import TestManager
    from coverage_analyzer import CodeCoverageAnalyzer

logger = logging.getLogger(__name__)

def setup_logging(verbose: bool = False):
    """设置日志"""
    level = logging.DEBUG if verbose else logging.INFO
    logging.basicConfig(
        level=level,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.StreamHandler(),
            logging.FileHandler('test_framework.log', encoding='utf-8')
        ]
    )

def create_example_test_case() -> TestCase:
    """创建示例测试用例"""
    return TestCase(
        test_id="example_001",
        name="示例测试用例",
        description="这是一个示例测试用例，用于演示测试框架功能",
        script_path=str(Path(__file__).parent / "examples" / "example_script.py"),
        timeout=10,
        assertions=[
            {
                "type": "contains",
                "actual": "${script_result.stdout}",
                "expected": "Hello",
                "message": "输出应包含'Hello'"
            },
            {
                "type": "equal",
                "actual": "${script_result.return_code}",
                "expected": "0",
                "message": "返回码应为0"
            }
        ],
        tags=["example", "demo"]
    )

def run_demo():
    """运行演示"""
    print("=" * 60)
    print("石器时代脚本自动化测试框架 - 演示")
    print("=" * 60)
    
    # 创建测试运行器
    runner = TestRunner()
    
    # 创建示例测试用例
    test_case = create_example_test_case()
    
    print(f"\n运行测试用例: {test_case.name}")
    print(f"描述: {test_case.description}")
    
    # 运行测试
    result = runner.run_test(test_case)
    
    print(f"\n测试结果:")
    print(f"  状态: {result.status.value}")
    print(f"  执行时间: {result.execution_time:.2f}秒")
    print(f"  断言数量: {len(result.assertions)}")
    
    # 显示断言结果
    print(f"\n断言结果:")
    for i, assertion in enumerate(result.assertions, 1):
        status = "✓" if assertion["passed"] else "✗"
        print(f"  {i}. {status} {assertion['message']}")
    
    print(f"\n演示完成!")
    return result

def main():
    """主函数"""
    parser = argparse.ArgumentParser(
        description="石器时代脚本自动化测试框架",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  %(prog)s run tests/test_config.json       # 运行指定配置的测试
  %(prog)s discover                         # 自动发现测试用例
  %(prog)s demo                             # 运行演示
  %(prog)s --help                           # 显示帮助信息
        """
    )
    
    subparsers = parser.add_subparsers(dest="command", help="命令")
    
    # run命令
    run_parser = subparsers.add_parser("run", help="运行测试")
    run_parser.add_argument("config", help="测试配置文件路径")
    run_parser.add_argument("--output", "-o", default="test_results.json", help="测试结果输出路径")
    run_parser.add_argument("--verbose", "-v", action="store_true", help="详细输出")
    
    # discover命令
    discover_parser = subparsers.add_parser("discover", help="自动发现测试用例")
    discover_parser.add_argument("--dir", "-d", default="tests", help="测试目录")
    discover_parser.add_argument("--output", "-o", default="discovered_tests.json", help="输出文件路径")
    discover_parser.add_argument("--verbose", "-v", action="store_true", help="详细输出")
    
    # demo命令
    demo_parser = subparsers.add_parser("demo", help="运行演示")
    demo_parser.add_argument("--verbose", "-v", action="store_true", help="详细输出")
    
    # coverage命令
    coverage_parser = subparsers.add_parser("coverage", help="分析覆盖率")
    coverage_parser.add_argument("script", help="脚本文件路径")
    coverage_parser.add_argument("--output", "-o", default="coverage_report.html", help="覆盖率报告输出路径")
    coverage_parser.add_argument("--verbose", "-v", action="store_true", help="详细输出")
    
    args = parser.parse_args()
    
    # 设置日志
    setup_logging(args.verbose if hasattr(args, 'verbose') else False)
    
    if args.command == "run":
        # 运行测试
        logger.info(f"加载测试配置: {args.config}")
        
        manager = TestManager()
        test_cases = manager.load_test_cases(args.config)
        
        if not test_cases:
            logger.error("未找到测试用例")
            return 1
        
        logger.info(f"找到 {len(test_cases)} 个测试用例")
        
        runner = TestRunner()
        results = runner.run_tests(test_cases)
        
        # 保存结果
        manager.save_test_results(results, args.output)
        
        # 统计结果
        passed = len([r for r in results if r.status.value == "passed"])
        failed = len([r for r in results if r.status.value == "failed"])
        
        print(f"\n测试完成!")
        print(f"  总计: {len(results)}")
        print(f"  通过: {passed}")
        print(f"  失败: {failed}")
        print(f"  结果已保存到: {args.output}")
        
        return 0 if failed == 0 else 1
        
    elif args.command == "discover":
        # 自动发现测试用例
        logger.info(f"在目录中发现测试用例: {args.dir}")
        
        manager = TestManager(args.dir)
        test_cases = manager.load_test_cases()
        
        if not test_cases:
            logger.warning("未发现测试用例")
            return 0
        
        logger.info(f"发现 {len(test_cases)} 个测试用例")
        
        # 保存发现的测试用例
        manager.save_test_results(
            [tc.to_dict() for tc in test_cases],
            args.output
        )
        
        print(f"\n发现完成!")
        print(f"  发现测试用例: {len(test_cases)}")
        print(f"  结果已保存到: {args.output}")
        
        return 0
        
    elif args.command == "demo":
        # 运行演示
        return 0 if run_demo().status.value == "passed" else 1
        
    elif args.command == "coverage":
        # 分析覆盖率
        logger.info(f"分析覆盖率: {args.script}")
        
        analyzer = CodeCoverageAnalyzer()
        analysis = analyzer.analyze_script(args.script)
        
        if not analysis:
            logger.error("覆盖率分析失败")
            return 1
        
        # 生成报告
        html = analyzer.generate_html_coverage_report(args.output)
        
        print(f"\n覆盖率分析完成!")
        print(f"  脚本: {analysis['script_path']}")
        print(f"  总行数: {analysis['total_lines']}")
        print(f"  可执行行数: {analysis['executable_lines']}")
        print(f"  函数数量: {len(analysis['functions'])}")
        print(f"  类数量: {len(analysis['classes'])}")
        print(f"  报告已生成: {args.output}")
        
        return 0
        
    else:
        # 显示帮助
        parser.print_help()
        return 0

if __name__ == "__main__":
    sys.exit(main())