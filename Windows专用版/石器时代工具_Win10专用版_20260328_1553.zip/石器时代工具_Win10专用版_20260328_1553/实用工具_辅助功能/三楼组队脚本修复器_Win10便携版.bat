@echo off
echo ========================================
echo [Windows] 三楼组队脚本修复器 - Windows 10便携版
echo ========================================
echo.
echo 正在启动石器时代工具...
echo 工具: 三楼组队脚本修复器
echo 时间: %date% %time%
echo.

REM 检查Python
python --version >nul 2>&1
if errorlevel 1 (
    echo [错误] 未找到Python，请先安装Python 3.8+
    echo 下载: https://www.python.org/downloads/
    pause
    exit /b 1
)

REM 运行工具
echo [开始] 启动工具...
python "三楼组队脚本修复器.py" %*

if errorlevel 1 (
    echo.
    echo [警告] 工具运行异常
    echo 请检查错误信息
) else (
    echo.
    echo [完成] 工具运行完成
)

echo.
pause
