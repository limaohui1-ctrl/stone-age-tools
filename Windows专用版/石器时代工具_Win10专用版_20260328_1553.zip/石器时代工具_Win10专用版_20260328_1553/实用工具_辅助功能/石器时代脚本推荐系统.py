#!/usr/bin/env python3
"""
石器时代脚本推荐系统
根据用户需求推荐最适合的脚本
"""

import json
import os
from datetime import datetime

DB_FILE = "/root/.openclaw/workspace/石器时代脚本数据库/脚本数据库.json"
OUTPUT_DIR = "/root/.openclaw/workspace/石器时代脚本推荐"

class ScriptRecommender:
    def __init__(self):
        with open(DB_FILE, 'r', encoding='utf-8') as f:
            self.database = json.load(f)
        print(f"✅ 加载数据库: {len(self.database)} 个脚本")
        
        # 创建输出目录
        os.makedirs(OUTPUT_DIR, exist_ok=True)
    
    def recommend_by_scenario(self, scenario):
        """根据使用场景推荐脚本"""
        recommendations = []
        
        scenario_lower = scenario.lower()
        
        # 场景匹配规则
        scenario_rules = {
            '新手': ['新人', '新手', '入门', '基础'],
            '赚钱': ['赚钱', '石币', '贩卖', '卖钱'],
            '练级': ['练级', '练功', '挂机', '经验'],
            '任务': ['任务', '解任', '活动', '转生'],
            '宠物': ['宠物', '抓宠', '练宠', 'MM'],
            '交通': ['交通', '传送', '移动', '飞行'],
            '料理': ['料理', '合成', '精炼', '制作'],
            '副本': ['副本', '挑战', '活动', '团队'],
        }
        
        for script in self.database:
            score = 0
            
            # 文件名匹配
            filename_lower = script['file_name'].lower()
            for keyword in scenario_rules.get(scenario, []):
                if keyword in filename_lower:
                    score += 3
            
            # 标题匹配
            if 'title' in script:
                title_lower = script['title'].lower()
                for keyword in scenario_rules.get(scenario, []):
                    if keyword in title_lower:
                        score += 2
            
            # 功能匹配
            if 'functions' in script:
                for func in script['functions']:
                    func_lower = func.lower()
                    for keyword in scenario_rules.get(scenario, []):
                        if keyword in func_lower:
                            score += 1
            
            if score > 0:
                recommendations.append((score, script))
        
        # 按分数排序
        recommendations.sort(key=lambda x: x[0], reverse=True)
        return [script for _, script in recommendations[:10]]  # 返回前10个
    
    def recommend_for_ng25(self):
        """推荐NG25适配脚本"""
        ng25_keywords = ['NG25', '私服', '适配', '专用']
        recommendations = []
        
        for script in self.database:
            score = 0
            
            # 检查文件名
            filename_lower = script['file_name'].lower()
            for keyword in ng25_keywords:
                if keyword in filename_lower:
                    score += 2
            
            # 检查标题
            if 'title' in script:
                title_lower = script['title'].lower()
                for keyword in ng25_keywords:
                    if keyword in title_lower:
                        score += 1
            
            # 检查脚本内容特征（简单版本）
            # NG25脚本通常有特定的错误处理
            if 'error_handlers' in script and script['error_handlers']:
                score += 1
            
            if score > 0:
                recommendations.append((score, script))
        
        recommendations.sort(key=lambda x: x[0], reverse=True)
        return [script for _, script in recommendations[:15]]
    
    def recommend_by_complexity(self, level='中等'):
        """根据复杂度推荐脚本"""
        complexity_levels = {
            '简单': {'max_lines': 200, 'max_size': 5000},
            '中等': {'max_lines': 500, 'max_size': 10000},
            '复杂': {'min_lines': 500, 'min_size': 10000},
        }
        
        if level not in complexity_levels:
            level = '中等'
        
        criteria = complexity_levels[level]
        recommendations = []
        
        for script in self.database:
            match = True
            
            if 'max_lines' in criteria and script['line_count'] > criteria['max_lines']:
                match = False
            if 'max_size' in criteria and script['file_size'] > criteria['max_size']:
                match = False
            if 'min_lines' in criteria and script['line_count'] < criteria['min_lines']:
                match = False
            if 'min_size' in criteria and script['file_size'] < criteria['min_size']:
                match = False
            
            if match:
                # 计算复杂度分数
                complexity_score = 0
                comp = script.get('complexity', {})
                if comp.get('has_conditions', False):
                    complexity_score += 1
                if comp.get('has_gotos', False):
                    complexity_score += 1
                if comp.get('has_labels', False):
                    complexity_score += 1
                
                recommendations.append((complexity_score, script))
        
        recommendations.sort(key=lambda x: x[0], reverse=True)
        return [script for _, script in recommendations[:10]]
    
    def generate_recommendation_report(self, recommendations, title, description):
        """生成推荐报告"""
        report = f"# 🎯 {title}\n\n"
        report += f"**生成时间**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n"
        report += f"**推荐数量**: {len(recommendations)} 个脚本\n"
        report += f"**推荐说明**: {description}\n\n"
        
        report += "## 📋 推荐脚本列表\n\n"
        
        for i, script in enumerate(recommendations, 1):
            report += f"### {i}. {script.get('title', script['file_name'])}\n"
            report += f"- **文件**: `{script['file_name']}`\n"
            report += f"- **路径**: `{script['file_path']}`\n"
            report += f"- **大小**: {script['file_size']} 字节\n"
            report += f"- **行数**: {script['line_count']} 行\n"
            
            if 'author' in script:
                report += f"- **作者**: {script['author']}\n"
            
            if 'version' in script:
                report += f"- **版本**: {script['version']}\n"
            
            if 'functions' in script:
                report += f"- **功能**: {', '.join(script['functions'])}\n"
            
            # 显示复杂度信息
            comp = script.get('complexity', {})
            comp_features = []
            if comp.get('has_conditions', False):
                comp_features.append('条件判断')
            if comp.get('has_gotos', False):
                comp_features.append('跳转')
            if comp.get('has_labels', False):
                comp_features.append('标签')
            if comp.get('has_comments', False):
                comp_features.append('注释')
            
            if comp_features:
                report += f"- **复杂度**: {', '.join(comp_features)}\n"
            
            report += "\n"
        
        report += "## 🚀 使用建议\n\n"
        report += "1. **直接使用**: 复制脚本到ASSA脚本目录\n"
        report += "2. **学习参考**: 分析脚本逻辑和实现\n"
        report += "3. **修改适配**: 根据需求调整脚本\n"
        report += "4. **组合使用**: 多个脚本配合完成复杂任务\n\n"
        
        report += "## 📊 统计信息\n\n"
        
        # 计算统计信息
        total_size = sum(s['file_size'] for s in recommendations)
        total_lines = sum(s['line_count'] for s in recommendations)
        avg_size = total_size // len(recommendations) if recommendations else 0
        avg_lines = total_lines // len(recommendations) if recommendations else 0
        
        report += f"- **平均大小**: {avg_size} 字节\n"
        report += f"- **平均行数**: {avg_lines} 行\n"
        report += f"- **总大小**: {total_size} 字节\n"
        report += f"- **总行数**: {total_lines} 行\n\n"
        
        report += "---\n"
        report += "*本报告由石器时代脚本推荐系统自动生成*\n"
        
        return report
    
    def save_report(self, report, filename):
        """保存报告到文件"""
        filepath = os.path.join(OUTPUT_DIR, filename)
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(report)
        return filepath
    
    def interactive_recommendation(self):
        """交互式推荐界面"""
        print("🎯 石器时代脚本推荐系统")
        print("=" * 60)
        print("可用的推荐类型:")
        print("1. 按使用场景推荐")
        print("2. NG25适配脚本推荐")
        print("3. 按复杂度推荐")
        print("=" * 60)
        
        while True:
            print("\n请选择推荐类型 (1-3, 输入q退出):")
            choice = input("> ").strip()
            
            if choice.lower() == 'q':
                print("👋 再见！")
                break
            
            if choice == '1':
                print("\n可用场景:")
                print("- 新手")
                print("- 赚钱")
                print("- 练级")
                print("- 任务")
                print("- 宠物")
                print("- 交通")
                print("- 料理")
                print("- 副本")
                
                scenario = input("\n请输入场景名称: ").strip()
                if scenario:
                    recommendations = self.recommend_by_scenario(scenario)
                    title = f"{scenario}场景脚本推荐"
                    description = f"针对{scenario}使用场景推荐的脚本"
                    report = self.generate_recommendation_report(recommendations, title, description)
                    filename = f"{scenario}场景推荐_{datetime.now().strftime('%Y%m%d_%H%M%S')}.md"
                    filepath = self.save_report(report, filename)
                    print(f"✅ 推荐 {len(recommendations)} 个脚本")
                    print(f"📄 报告已保存: {filepath}")
            
            elif choice == '2':
                recommendations = self.recommend_for_ng25()
                title = "NG25适配脚本推荐"
                description = "针对NG25私服适配的脚本推荐"
                report = self.generate_recommendation_report(recommendations, title, description)
                filename = f"NG25适配推荐_{datetime.now().strftime('%Y%m%d_%H%M%S')}.md"
                filepath = self.save_report(report, filename)
                print(f"✅ 推荐 {len(recommendations)} 个NG25适配脚本")
                print(f"📄 报告已保存: {filepath}")
            
            elif choice == '3':
                print("\n复杂度级别:")
                print("- 简单 (≤200行, ≤5KB)")
                print("- 中等 (≤500行, ≤10KB)")
                print("- 复杂 (≥500行, ≥10KB)")
                
                level = input("\n请输入复杂度级别: ").strip()
                if level in ['简单', '中等', '复杂']:
                    recommendations = self.recommend_by_complexity(level)
                    title = f"{level}复杂度脚本推荐"
                    description = f"{level}复杂度的脚本推荐，适合相应水平的开发者"
                    report = self.generate_recommendation_report(recommendations, title, description)
                    filename = f"{level}复杂度推荐_{datetime.now().strftime('%Y%m%d_%H%M%S')}.md"
                    filepath = self.save_report(report, filename)
                    print(f"✅ 推荐 {len(recommendations)} 个{level}复杂度脚本")
                    print(f"📄 报告已保存: {filepath}")
                else:
                    print("❌ 无效的复杂度级别")
            
            else:
                print("❌ 无效选择，请重新输入")

def main():
    recommender = ScriptRecommender()
    recommender.interactive_recommendation()

if __name__ == "__main__":
    main()