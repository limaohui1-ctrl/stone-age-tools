#!/usr/bin/env python3
import sys
import os
from docx import Document

def extract_docx_content(docx_path, output_path):
    try:
        # 读取DOCX文件
        doc = Document(docx_path)
        
        # 提取所有段落文本
        content = []
        for para in doc.paragraphs:
            if para.text.strip():  # 只提取非空段落
                content.append(para.text)
        
        # 提取表格内容
        for table in doc.tables:
            for row in table.rows:
                row_text = []
                for cell in row.cells:
                    if cell.text.strip():
                        row_text.append(cell.text)
                if row_text:
                    content.append(" | ".join(row_text))
        
        # 写入输出文件
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write('\n'.join(content))
        
        print(f"成功提取内容到: {output_path}")
        print(f"提取了 {len(content)} 行内容")
        
        # 显示前100行内容预览
        print("\n=== 内容预览（前100行）===")
        for i, line in enumerate(content[:100]):
            print(f"{i+1}: {line}")
            
    except Exception as e:
        print(f"提取DOCX文件时出错: {e}")
        sys.exit(1)

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("用法: python3 extract_docx.py <输入文件.docx> <输出文件.txt>")
        sys.exit(1)
    
    input_file = sys.argv[1]
    output_file = sys.argv[2]
    
    if not os.path.exists(input_file):
        print(f"输入文件不存在: {input_file}")
        sys.exit(1)
    
    extract_docx_content(input_file, output_file)