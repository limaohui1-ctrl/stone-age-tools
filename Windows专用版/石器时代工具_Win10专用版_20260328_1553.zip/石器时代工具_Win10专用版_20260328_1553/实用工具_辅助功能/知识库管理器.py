#!/usr/bin/env python3
"""
石器时代知识库管理器
统一管理知识库的所有资源
"""

import os
import json
import shutil
from datetime import datetime
from pathlib import Path

class KnowledgeBaseManager:
    def __init__(self):
        self.base_dir = Path("/root/.openclaw/workspace/石器时代知识库")
        self.setup_directories()
        
        # 加载配置
        self.config = self.load_config()
        
    def setup_directories(self):
        """设置目录结构"""
        directories = [
            "脚本分类",
            "开发工具链",
            "优化框架", 
            "学习资料",
            "数据库",
            "社区资源",
            "文档",
            "备份"
        ]
        
        for directory in directories:
            (self.base_dir / directory).mkdir(parents=True, exist_ok=True)
        
        # 开发工具链子目录
        toolchain_dirs = [
            "模板",
            "示例", 
            "工具",
            "测试",
            "文档"
        ]
        
        for directory in toolchain_dirs:
            (self.base_dir / "开发工具链" / directory).mkdir(parents=True, exist_ok=True)
    
    def load_config(self):
        """加载配置"""
        config_path = self.base_dir / "config.json"
        if config_path.exists():
            with open(config_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        
        # 默认配置
        default_config = {
            "knowledge_base": {
                "name": "石器时代脚本知识库",
                "version": "1.0.0",
                "description": "石器时代脚本开发、优化和分享的知识库",
                "author": "OpenClaw AI Assistant",
                "created": datetime.now().isoformat(),
                "updated": datetime.now().isoformat()
            },
            "categories": {
                "scripts": [
                    "自动挂机", "转生必解", "六转之路", "任务脚本",
                    "1d2dmm", "交通脚本", "素材脚本", "宠物相关",
                    "精练合料", "职业相关", "赚钱脚本", "副本活动",
                    "其它脚本", "公用脚本"
                ],
                "tools": [
                    "开发工具", "测试工具", "优化工具", "分析工具",
                    "管理工具", "学习工具"
                ],
                "resources": [
                    "教程", "示例", "模板", "文档",
                    "问题解答", "最佳实践", "更新日志"
                ]
            },
            "settings": {
                "auto_backup": True,
                "backup_interval": 24,  # 小时
                "max_backups": 30,
                "auto_update": True,
                "notifications": True
            }
        }
        
        # 保存默认配置
        with open(config_path, 'w', encoding='utf-8') as f:
            json.dump(default_config, f, ensure_ascii=False, indent=2)
        
        return default_config
    
    def save_config(self):
        """保存配置"""
        self.config["knowledge_base"]["updated"] = datetime.now().isoformat()
        
        config_path = self.base_dir / "config.json"
        with open(config_path, 'w', encoding='utf-8') as f:
            json.dump(self.config, f, ensure_ascii=False, indent=2)
    
    def import_existing_resources(self):
        """导入现有资源"""
        print("📦 导入现有资源到知识库...")
        
        # 导入脚本数据库
        self.import_script_database()
        
        # 导入优化工具
        self.import_optimization_tools()
        
        # 导入学习资料
        self.import_learning_materials()
        
        # 导入开发工具
        self.import_development_tools()
        
        print("✅ 资源导入完成")
    
    def import_script_database(self):
        """导入脚本数据库"""
        source_db = Path("/root/.openclaw/workspace/石器时代脚本数据库")
        target_db = self.base_dir / "数据库" / "脚本数据库"
        
        if source_db.exists():
            target_db.mkdir(parents=True, exist_ok=True)
            
            # 复制数据库文件
            for file in source_db.glob("*"):
                if file.is_file():
                    shutil.copy2(file, target_db / file.name)
            
            print(f"  ✅ 导入脚本数据库: {source_db.name}")
            
            # 创建索引
            self.create_database_index()
        else:
            print(f"  ⚠️ 脚本数据库不存在: {source_db}")
    
    def create_database_index(self):
        """创建数据库索引"""
        db_path = self.base_dir / "数据库" / "脚本数据库" / "脚本数据库.json"
        if not db_path.exists():
            return
        
        with open(db_path, 'r', encoding='utf-8') as f:
            database = json.load(f)
        
        # 创建分类索引
        categories = {}
        for script in database:
            category = script.get('category', '未分类')
            if category not in categories:
                categories[category] = []
            categories[category].append(script['file_name'])
        
        # 保存索引
        index_path = self.base_dir / "数据库" / "脚本索引.json"
        with open(index_path, 'w', encoding='utf-8') as f:
            json.dump({
                "total_scripts": len(database),
                "categories": categories,
                "last_updated": datetime.now().isoformat()
            }, f, ensure_ascii=False, indent=2)
        
        print(f"  ✅ 创建数据库索引: {len(database)} 个脚本")
    
    def import_optimization_tools(self):
        """导入优化工具"""
        source_dir = Path("/root/.openclaw/workspace")
        target_dir = self.base_dir / "优化框架" / "工具"
        
        optimization_tools = [
            "简单副本优化器.py",
            "NG25名称验证工具.py", 
            "快速NG25验证.py",
            "副本脚本NG25优化器.py",
            "实用副本优化器.py"
        ]
        
        for tool in optimization_tools:
            source_path = source_dir / tool
            if source_path.exists():
                target_dir.mkdir(parents=True, exist_ok=True)
                shutil.copy2(source_path, target_dir / tool)
                print(f"  ✅ 导入优化工具: {tool}")
    
    def import_learning_materials(self):
        """导入学习资料"""
        source_dir = Path("/root/.openclaw/workspace")
        target_dir = self.base_dir / "学习资料"
        
        learning_files = [
            "NG25副本优化完整指南.md",
            "脚本优化原则检查清单.md",
            "石器时代资料库总结报告.md",
            "石器时代脚本资料库更新.md"
        ]
        
        for file in learning_files:
            source_path = source_dir / file
            if source_path.exists():
                target_dir.mkdir(parents=True, exist_ok=True)
                shutil.copy2(source_path, target_dir / file)
                print(f"  ✅ 导入学习资料: {file}")
    
    def import_development_tools(self):
        """导入开发工具"""
        source_dir = Path("/root/.openclaw/workspace")
        target_dir = self.base_dir / "开发工具链" / "工具"
        
        development_tools = [
            "脚本分析工具.py",
            "石器时代知识库构建器.py",
            "石器时代脚本优化分析器.py",
            "石器时代脚本查询工具.py",
            "石器时代脚本推荐系统.py"
        ]
        
        for tool in development_tools:
            source_path = source_dir / tool
            if source_path.exists():
                target_dir.mkdir(parents=True, exist_ok=True)
                shutil.copy2(source_path, target_dir / tool)
                print(f"  ✅ 导入开发工具: {tool}")
    
    def organize_scripts_by_category(self):
        """按分类组织脚本"""
        print("📁 按分类组织脚本...")
        
        # 从客户端导入脚本
        client_scripts_dir = Path("/root/.openclaw/workspace/石器时代客户端处理/解压内容/sqng25/scripts")
        target_base = self.base_dir / "脚本分类"
        
        if client_scripts_dir.exists():
            for category_dir in client_scripts_dir.iterdir():
                if category_dir.is_dir():
                    category_name = category_dir.name
                    target_dir = target_base / category_name
                    
                    # 复制脚本文件
                    script_count = 0
                    for script_file in category_dir.rglob("*.asc"):
                        if script_file.is_file():
                            # 保持目录结构
                            rel_path = script_file.relative_to(category_dir)
                            target_path = target_dir / rel_path
                            target_path.parent.mkdir(parents=True, exist_ok=True)
                            
                            shutil.copy2(script_file, target_path)
                            script_count += 1
                    
                    if script_count > 0:
                        print(f"  ✅ 导入分类 [{category_name}]: {script_count} 个脚本")
        
        print("✅ 脚本组织完成")
    
    def create_knowledge_base_summary(self):
        """创建知识库总结"""
        print("📊 创建知识库总结...")
        
        summary = {
            "knowledge_base": self.config["knowledge_base"],
            "statistics": self.calculate_statistics(),
            "structure": self.get_structure_info(),
            "last_updated": datetime.now().isoformat()
        }
        
        # 保存总结
        summary_path = self.base_dir / "知识库总结.json"
        with open(summary_path, 'w', encoding='utf-8') as f:
            json.dump(summary, f, ensure_ascii=False, indent=2)
        
        # 创建Markdown报告
        self.create_summary_report(summary)
        
        print(f"✅ 知识库总结已创建: {summary_path}")
    
    def calculate_statistics(self):
        """计算统计信息"""
        stats = {
            "total_scripts": 0,
            "total_tools": 0,
            "total_documents": 0,
            "categories": {},
            "last_calculated": datetime.now().isoformat()
        }
        
        # 统计脚本
        scripts_dir = self.base_dir / "脚本分类"
        if scripts_dir.exists():
            for category_dir in scripts_dir.iterdir():
                if category_dir.is_dir():
                    script_count = len(list(category_dir.rglob("*.asc")))
                    stats["total_scripts"] += script_count
                    stats["categories"][category_dir.name] = {
                        "scripts": script_count,
                        "size_mb": self.get_directory_size(category_dir) / (1024 * 1024)
                    }
        
        # 统计工具
        tools_dir = self.base_dir / "开发工具链" / "工具"
        if tools_dir.exists():
            stats["total_tools"] = len(list(tools_dir.glob("*.py")))
        
        # 统计文档
        docs_dir = self.base_dir / "学习资料"
        if docs_dir.exists():
            stats["total_documents"] = len(list(docs_dir.glob("*.md")))
        
        return stats
    
    def get_directory_size(self, directory):
        """获取目录大小"""
        total_size = 0
        for path in directory.rglob('*'):
            if path.is_file():
                total_size += path.stat().st_size
        return total_size
    
    def get_structure_info(self):
        """获取结构信息"""
        structure = {
            "directories": [],
            "main_files": []
        }
        
        # 目录结构
        for item in self.base_dir.iterdir():
            if item.is_dir():
                structure["directories"].append({
                    "name": item.name,
                    "item_count": len(list(item.iterdir()))
                })
        
        # 主要文件
        main_files = ["README.md", "config.json", "知识库总结.json"]
        for file in main_files:
            file_path = self.base_dir / file
            if file_path.exists():
                structure["main_files"].append(file)
        
        return structure
    
    def create_summary_report(self, summary):
        """创建总结报告"""
        report = f"""# 📚 石器时代脚本知识库总结报告

## 🎯 知识库信息
- **名称**: {summary['knowledge_base']['name']}
- **版本**: {summary['knowledge_base']['version']}
- **描述**: {summary['knowledge_base']['description']}
- **作者**: {summary['knowledge_base']['author']}
- **创建时间**: {summary['knowledge_base']['created']}
- **更新时间**: {summary['last_updated']}

## 📊 资源统计

### 脚本资源
- **总脚本数**: {summary['statistics']['total_scripts']} 个
- **分类数量**: {len(summary['statistics']['categories'])} 个

### 开发工具
- **工具数量**: {summary['statistics']['total_tools']} 个
- **文档数量**: {summary['statistics']['total_documents']} 个

### 脚本分类详情
"""
        
        for category, info in summary['statistics']['categories'].items():
            report += f"- **{category}**: {info['scripts']} 个脚本 ({info['size_mb']:.2f} MB)\n"
        
        report += """
## 🏗️ 目录结构

### 主要目录
"""
        
        for directory in summary['structure']['directories']:
            report += f"- **{directory['name']}**: {directory['item_count']} 个项目\n"
        
        report += """
### 主要文件
"""
        
        for file in summary['structure']['main_files']:
            report += f"- `{file}`\n"
        
        report += """
## 🚀 使用指南

### 快速开始
1. **查找脚本**: 浏览脚本分类目录
2. **使用工具**: 使用开发工具链中的工具
3. **学习开发**: 参考学习资料中的教程
4. **优化脚本**: 应用优化框架提升脚本质量

### 开发流程
1. 使用模板创建新脚本
2. 使用测试框架验证脚本
3. 应用优化框架提升稳定性
4. 将脚本添加到知识库

### 贡献指南
1. 按照规范提交新脚本
2. 分享开发经验和技巧
3. 报告问题和改进建议
4. 参与工具和文档的完善

## 📞 支持与帮助

### 获取帮助
- 查看文档和教程
- 使用开发工具链
- 参与社区交流
- 提交问题和反馈

### 更新维护
- 定期备份重要数据
- 及时更新工具和文档
- 参与社区协作和分享

---

*本知识库将持续更新和完善，欢迎贡献和反馈！*
"""
        
        report_path = self.base_dir / "知识库总结报告.md"
        with open(report_path, 'w', encoding='utf-8') as f:
            f.write(report)
        
        print(f"📄 总结报告已创建: {report_path}")
    
    def backup_knowledge_base(self):
        """备份知识库"""
        if not self.config["settings"]["auto_backup"]:
            return
        
        backup_dir = self.base_dir / "备份"
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_path = backup_dir / f"知识库备份_{timestamp}.zip"
        
        # 创建备份
        backup_dir.mkdir(parents=True, exist_ok=True)
        
        # 这里可以添加实际的备份逻辑
        # 例如使用shutil.make_archive
        
        print(f"💾 知识库备份已创建: {backup_path}")
        
        # 清理旧备份
        self.cleanup_old_backups()
    
    def cleanup_old_backups(self):
        """清理旧备份"""
        backup_dir = self.base_dir / "备份"
        if not backup_dir.exists():
            return
        
        max_backups = self.config["settings"]["max_backups"]
        backups = sorted(backup_dir.glob("知识库备份_*.zip"), key=os.path.getmtime)
        
        if len(backups) > max_backups:
            for old_backup in backups[:-max_backups]:
                old_backup.unlink()
                print(f"🗑️ 清理旧备份: {old_backup.name}")
    
    def run_setup(self):
        """运行知识库设置"""
        print("=" * 60)
        print("🏗️  石器时代脚本知识库设置")
        print("=" * 60)
        
        # 导入现有资源
        self.import_existing_resources()
        
        # 组织脚本
        self.organize_scripts_by_category()
        
        # 创建总结
        self.create_knowledge_base_summary()
        
        # 备份
        self.backup_knowledge_base()
        
        print("=" * 60)
        print("🎉 知识库设置完成!")
        print(f"📁 知识库位置: {self.base_dir}")
        print("=" * 60)

def main():
    """主函数"""
    manager = KnowledgeBaseManager()
    manager.run_setup()

if __name__ == "__main__":
    main()