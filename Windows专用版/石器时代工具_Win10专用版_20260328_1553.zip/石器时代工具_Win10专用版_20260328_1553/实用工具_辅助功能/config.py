"""
配置管理模块

提供统一的配置管理功能，支持YAML、JSON、TOML格式。
"""

import os
import json
import yaml
import toml
from pathlib import Path
from typing import Any, Dict, Optional, Union
from dataclasses import dataclass, field, asdict

from .exceptions import ConfigError, ConfigNotFoundError


@dataclass
class GameConfig:
    """游戏配置"""
    window_title: str = "石器时代"
    window_class: str = ""
    process_name: str = "stoneage.exe"
    process_patterns: Dict[str, str] = field(default_factory=lambda: {
        "ng25": "ng25.exe",
        "official": "stoneage.exe",
        "private": "private_server.exe"
    })
    
    # 窗口查找配置
    window_search_timeout: int = 10  # 秒
    window_retry_interval: float = 0.5  # 秒
    
    # 进程监控配置
    process_check_interval: float = 1.0  # 秒
    process_restart_attempts: int = 3


@dataclass
class MonitorConfig:
    """监控配置"""
    # 监控频率
    window_monitor_interval: float = 0.5  # 秒
    process_monitor_interval: float = 1.0  # 秒
    status_monitor_interval: float = 2.0  # 秒
    
    # 状态检测
    check_window_active: bool = True
    check_window_visible: bool = True
    check_window_size: bool = True
    check_process_running: bool = True
    check_process_resources: bool = False
    
    # 资源阈值
    cpu_threshold: float = 90.0  # %
    memory_threshold: float = 1024  # MB
    gpu_threshold: float = 90.0  # %


@dataclass
class ReaderConfig:
    """数据读取配置"""
    # 内存读取配置
    memory_scan_interval: float = 0.1  # 秒
    memory_cache_size: int = 100
    memory_pattern_file: str = "memory_patterns.json"
    
    # 图像识别配置
    pixel_check_interval: float = 0.2  # 秒
    image_match_threshold: float = 0.8  # 匹配阈值
    screenshot_quality: int = 85  # 截图质量
    
    # 坐标读取配置
    coordinate_update_interval: float = 0.1  # 秒
    coordinate_smoothing: bool = True
    coordinate_history_size: int = 10


@dataclass
class AutomationConfig:
    """自动化配置"""
    # 输入模拟配置
    input_delay_min: float = 0.05  # 秒
    input_delay_max: float = 0.2   # 秒
    mouse_move_speed: float = 0.5  # 移动速度系数
    
    # 热键配置
    hotkey_enabled: bool = True
    hotkey_config_file: str = "hotkeys.yaml"
    
    # 状态机配置
    state_machine_enabled: bool = True
    state_transition_delay: float = 0.1  # 秒
    state_timeout: float = 30.0  # 秒


@dataclass
class LoggingConfig:
    """日志配置"""
    # 日志级别
    log_level: str = "INFO"
    console_level: str = "INFO"
    file_level: str = "DEBUG"
    
    # 日志文件
    log_file: str = "logs/stoneage_client.log"
    max_file_size: int = 10 * 1024 * 1024  # 10MB
    backup_count: int = 5
    
    # 日志格式
    log_format: str = "[{time:YYYY-MM-DD HH:mm:ss}] [{level}] {message}"
    console_format: str = "<level>{level: <8}</level> <cyan>{name}</cyan>: <level>{message}</level>"


@dataclass
class IntegrationConfig:
    """集成配置"""
    # ASSA集成
    assa_enabled: bool = True
    assa_script_dir: str = "scripts"
    assa_command_delay: float = 0.1  # 秒
    
    # 工具链集成
    toolchain_enabled: bool = True
    debugger_integration: bool = True
    analyzer_integration: bool = True
    test_framework_integration: bool = True


@dataclass
class Config:
    """主配置类"""
    game: GameConfig = field(default_factory=GameConfig)
    monitor: MonitorConfig = field(default_factory=MonitorConfig)
    reader: ReaderConfig = field(default_factory=ReaderConfig)
    automation: AutomationConfig = field(default_factory=AutomationConfig)
    logging: LoggingConfig = field(default_factory=LoggingConfig)
    integration: IntegrationConfig = field(default_factory=IntegrationConfig)
    
    # 运行时配置
    debug_mode: bool = False
    safe_mode: bool = True
    performance_mode: bool = False
    
    def __post_init__(self):
        """初始化后处理"""
        # 确保目录存在
        self._ensure_directories()
    
    def _ensure_directories(self):
        """确保必要的目录存在"""
        dirs = [
            "logs",
            "data/templates",
            "data/patterns",
            "data/cache",
            "config",
            "scripts"
        ]
        
        for dir_path in dirs:
            Path(dir_path).mkdir(parents=True, exist_ok=True)
    
    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return asdict(self)
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Config':
        """从字典创建配置"""
        # 提取各部分的配置
        game_data = data.get('game', {})
        monitor_data = data.get('monitor', {})
        reader_data = data.get('reader', {})
        automation_data = data.get('automation', {})
        logging_data = data.get('logging', {})
        integration_data = data.get('integration', {})
        
        # 创建配置对象
        config = cls(
            game=GameConfig(**game_data),
            monitor=MonitorConfig(**monitor_data),
            reader=ReaderConfig(**reader_data),
            automation=AutomationConfig(**automation_data),
            logging=LoggingConfig(**logging_data),
            integration=IntegrationConfig(**integration_data),
            debug_mode=data.get('debug_mode', False),
            safe_mode=data.get('safe_mode', True),
            performance_mode=data.get('performance_mode', False)
        )
        
        return config
    
    def save(self, filepath: Union[str, Path], format: str = 'yaml'):
        """
        保存配置到文件
        
        Args:
            filepath: 文件路径
            format: 格式 (yaml, json, toml)
        """
        filepath = Path(filepath)
        data = self.to_dict()
        
        try:
            filepath.parent.mkdir(parents=True, exist_ok=True)
            
            if format.lower() == 'yaml':
                with open(filepath, 'w', encoding='utf-8') as f:
                    yaml.dump(data, f, default_flow_style=False, allow_unicode=True)
            
            elif format.lower() == 'json':
                with open(filepath, 'w', encoding='utf-8') as f:
                    json.dump(data, f, indent=2, ensure_ascii=False)
            
            elif format.lower() == 'toml':
                with open(filepath, 'w', encoding='utf-8') as f:
                    toml.dump(data, f)
            
            else:
                raise ConfigError(f"不支持的格式: {format}")
        
        except Exception as e:
            raise ConfigError(f"保存配置失败: {filepath}", str(e))
    
    @classmethod
    def load(cls, filepath: Union[str, Path]) -> 'Config':
        """
        从文件加载配置
        
        Args:
            filepath: 文件路径
            
        Returns:
            配置对象
        """
        filepath = Path(filepath)
        
        if not filepath.exists():
            raise ConfigNotFoundError(str(filepath))
        
        try:
            # 根据扩展名确定格式
            ext = filepath.suffix.lower()
            
            if ext in ['.yaml', '.yml']:
                with open(filepath, 'r', encoding='utf-8') as f:
                    data = yaml.safe_load(f)
            
            elif ext == '.json':
                with open(filepath, 'r', encoding='utf-8') as f:
                    data = json.load(f)
            
            elif ext == '.toml':
                with open(filepath, 'r', encoding='utf-8') as f:
                    data = toml.load(f)
            
            else:
                # 尝试自动检测格式
                content = filepath.read_text(encoding='utf-8')
                if content.strip().startswith('{'):
                    data = json.loads(content)
                elif ':' in content.split('\n')[0]:
                    data = yaml.safe_load(content)
                else:
                    data = toml.loads(content)
            
            return cls.from_dict(data)
        
        except Exception as e:
            raise ConfigError(f"加载配置失败: {filepath}", str(e))
    
    @classmethod
    def get_default(cls) -> 'Config':
        """获取默认配置"""
        return cls()
    
    def update(self, updates: Dict[str, Any]):
        """
        更新配置
        
        Args:
            updates: 更新数据，支持嵌套更新
        """
        self._update_nested(self.to_dict(), updates)
    
    def _update_nested(self, target: Dict[str, Any], updates: Dict[str, Any]):
        """递归更新嵌套字典"""
        for key, value in updates.items():
            if key in target and isinstance(target[key], dict) and isinstance(value, dict):
                self._update_nested(target[key], value)
            else:
                target[key] = value
        
        # 重新创建配置对象
        updated_config = self.from_dict(target)
        self.__dict__.update(updated_config.__dict__)
    
    def validate(self) -> bool:
        """
        验证配置有效性
        
        Returns:
            是否有效
        """
        try:
            # 验证游戏配置
            if not self.game.window_title:
                raise ConfigError("window_title", "窗口标题不能为空")
            
            if self.game.window_search_timeout <= 0:
                raise ConfigError("window_search_timeout", "窗口搜索超时必须大于0")
            
            # 验证监控配置
            if self.monitor.window_monitor_interval <= 0:
                raise ConfigError("window_monitor_interval", "窗口监控间隔必须大于0")
            
            # 验证读取配置
            if self.reader.image_match_threshold < 0 or self.reader.image_match_threshold > 1:
                raise ConfigError("image_match_threshold", "图像匹配阈值必须在0-1之间")
            
            # 验证自动化配置
            if self.automation.input_delay_min < 0:
                raise ConfigError("input_delay_min", "输入延迟最小值不能为负")
            
            if self.automation.input_delay_max < self.automation.input_delay_min:
                raise ConfigError("input_delay_max", "输入延迟最大值必须大于等于最小值")
            
            return True
        
        except ConfigError:
            return False


# 全局配置实例
_config_instance: Optional[Config] = None


def get_config(config_path: Optional[Union[str, Path]] = None) -> Config:
    """
    获取配置实例（单例模式）
    
    Args:
        config_path: 配置文件路径，如果为None则使用默认配置
        
    Returns:
        配置实例
    """
    global _config_instance
    
    if _config_instance is None:
        if config_path and Path(config_path).exists():
            _config_instance = Config.load(config_path)
        else:
            _config_instance = Config.get_default()
    
    return _config_instance


def reload_config(config_path: Union[str, Path]) -> Config:
    """
    重新加载配置
    
    Args:
        config_path: 配置文件路径
        
    Returns:
        新的配置实例
    """
    global _config_instance
    _config_instance = Config.load(config_path)
    return _config_instance


def reset_config() -> Config:
    """重置为默认配置"""
    global _config_instance
    _config_instance = Config.get_default()
    return _config_instance