#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
修复ASSA脚本文件编码工具
"""

import os
import chardet
from pathlib import Path

def 检测文件编码(文件路径):
    """检测文件的编码"""
    with open(文件路径, 'rb') as f:
        raw_data = f.read()
        result = chardet.detect(raw_data)
        return result

def 尝试解码文件(文件路径, 输出路径=None):
    """尝试用多种编码解码文件"""
    原始路径 = Path(文件路径)
    
    if 输出路径 is None:
        输出路径 = 原始路径.parent / f"{原始路径.stem}_修复{原始路径.suffix}"
    
    with open(文件路径, 'rb') as f:
        原始数据 = f.read()
    
    # 尝试的编码列表
    编码列表 = [
        'gbk', 'gb2312', 'gb18030',  # 中文编码
        'big5',  # 繁体中文
        'utf-8', 'utf-8-sig',  # UTF编码
        'latin1', 'iso-8859-1',  # 西欧编码
        'cp1252',  # Windows编码
    ]
    
    print(f"正在处理文件: {文件路径}")
    print(f"文件大小: {len(原始数据)} 字节")
    
    for 编码 in 编码列表:
        try:
            解码内容 = 原始数据.decode(编码)
            print(f"\n尝试编码: {编码}")
            
            # 检查是否包含ASSA脚本常见关键词
            assa关键词 = ["dim", "let", "if", "goto", "label", "call", "return", "say", "wait", "set"]
            找到关键词 = []
            
            for 关键词 in assa关键词:
                if 关键词 in 解码内容.lower():
                    找到关键词.append(关键词)
            
            if 找到关键词:
                print(f"  找到ASSA关键词: {', '.join(找到关键词)}")
                
                # 写入文件
                with open(输出路径, 'w', encoding='utf-8') as f:
                    f.write(解码内容)
                
                print(f"  成功保存到: {输出路径}")
                
                # 显示前几行内容
                print("\n=== 文件内容预览（前20行）===")
                行列表 = 解码内容.split('\n')
                for i, 行 in enumerate(行列表[:20]):
                    if 行.strip():  # 只显示非空行
                        print(f"{i+1:3}: {行[:100]}{'...' if len(行) > 100 else ''}")
                
                return True, 编码
                
        except UnicodeDecodeError as e:
            continue
        except Exception as e:
            print(f"  编码 {编码} 错误: {e}")
            continue
    
    print("\n⚠️ 无法找到合适的编码")
    return False, None

def 分析ASSA脚本(文件路径):
    """分析ASSA脚本的结构"""
    try:
        with open(文件路径, 'r', encoding='utf-8') as f:
            内容 = f.read()
        
        print(f"\n{'='*60}")
        print(f"ASSA脚本分析报告: {文件路径}")
        print(f"{'='*60}")
        
        # 基本统计
        总行数 = len(内容.split('\n'))
        非空行数 = len([行 for 行 in 内容.split('\n') if 行.strip()])
        注释行数 = len([行 for 行 in 内容.split('\n') if 行.strip().startswith("'")])
        
        print(f"📊 基本统计:")
        print(f"  总行数: {总行数}")
        print(f"  非空行数: {非空行数}")
        print(f"  注释行数: {注释行数}")
        print(f"  代码行数: {非空行数 - 注释行数}")
        
        # 查找变量定义
        import re
        变量定义 = re.findall(r'dim\s+(@\w+)', 内容, re.IGNORECASE)
        if 变量定义:
            print(f"\n🔧 变量定义 ({len(变量定义)}个):")
            for i, 变量 in enumerate(变量定义[:10]):  # 只显示前10个
                print(f"  {i+1}. {变量}")
            if len(变量定义) > 10:
                print(f"  ... 还有 {len(变量定义)-10} 个变量")
        
        # 查找标签
        标签定义 = re.findall(r'label\s+(\w+)', 内容, re.IGNORECASE)
        if 标签定义:
            print(f"\n🏷️  标签定义 ({len(标签定义)}个):")
            for i, 标签 in enumerate(标签定义[:10]):
                print(f"  {i+1}. {标签}")
            if len(标签定义) > 10:
                print(f"  ... 还有 {len(标签定义)-10} 个标签")
        
        # 查找函数调用
        函数调用 = re.findall(r'call\s+(\w+)', 内容, re.IGNORECASE)
        if 函数调用:
            print(f"\n📞 函数调用 ({len(函数调用)}次):")
            调用统计 = {}
            for 调用 in 函数调用:
                调用统计[调用] = 调用统计.get(调用, 0) + 1
            
            for 函数, 次数 in sorted(调用统计.items(), key=lambda x: x[1], reverse=True)[:10]:
                print(f"  {函数}: {次数}次")
        
        # 查找set命令
        set命令 = re.findall(r'set\s+([^,]+)', 内容, re.IGNORECASE)
        if set命令:
            print(f"\n⚙️  SET命令 ({len(set命令)}个):")
            set统计 = {}
            for 命令 in set命令:
                命令 = 命令.strip()
                if 命令:
                    set统计[命令] = set统计.get(命令, 0) + 1
            
            for 命令, 次数 in sorted(set统计.items(), key=lambda x: x[1], reverse=True)[:10]:
                print(f"  {命令}: {次数}次")
        
        # 查找中文内容
        中文内容 = re.findall(r'[\u4e00-\u9fff]+', 内容)
        if 中文内容:
            print(f"\n🇨🇳 中文关键词 ({len(中文内容)}处):")
            中文统计 = {}
            for 词 in 中文内容:
                if len(词) > 1:  # 只统计长度大于1的词
                    中文统计[词] = 中文统计.get(词, 0) + 1
            
            for 词, 次数 in sorted(中文统计.items(), key=lambda x: x[1], reverse=True)[:15]:
                print(f"  {词}: {次数}次")
        
        print(f"\n{'='*60}")
        return True
        
    except Exception as e:
        print(f"分析脚本时出错: {e}")
        return False

def 主函数():
    """主函数"""
    import sys
    
    if len(sys.argv) < 2:
        print("""
ASSA脚本编码修复和分析工具
用法:
  python 修复编码.py [命令] [文件]
  
命令:
  help       显示帮助信息
  detect <文件>  检测文件编码
  fix <文件>    尝试修复文件编码
  analyze <文件> 分析ASSA脚本结构
  
示例:
  python 修复编码.py detect 脚本.asc
  python 修复编码.py fix 脚本.asc
  python 修复编码.py analyze 脚本.asc
""")
        return
    
    命令 = sys.argv[1]
    
    if 命令 == 'help':
        print("帮助信息已显示")
    
    elif 命令 == 'detect' and len(sys.argv) >= 3:
        文件路径 = sys.argv[2]
        if os.path.exists(文件路径):
            编码信息 = 检测文件编码(文件路径)
            print(f"文件: {文件路径}")
            print(f"检测编码: {编码信息['encoding']}")
            print(f"置信度: {编码信息['confidence']:.2%}")
            print(f"语言: {编码信息.get('language', '未知')}")
        else:
            print(f"文件不存在: {文件路径}")
    
    elif 命令 == 'fix' and len(sys.argv) >= 3:
        文件路径 = sys.argv[2]
        输出文件 = sys.argv[3] if len(sys.argv) >= 4 else None
        成功, 编码 = 尝试解码文件(文件路径, 输出文件)
        if 成功:
            print(f"\n✅ 修复成功! 使用编码: {编码}")
        else:
            print("\n❌ 修复失败")
    
    elif 命令 == 'analyze' and len(sys.argv) >= 3:
        文件路径 = sys.argv[2]
        if os.path.exists(文件路径):
            分析ASSA脚本(文件路径)
        else:
            print(f"文件不存在: {文件路径}")
    
    else:
        print(f"未知命令: {命令}")
        print("使用 'python 修复编码.py help' 查看帮助")

if __name__ == "__main__":
    主函数()