#!/usr/bin/env python3
"""
覆盖率分析器
分析脚本代码的测试覆盖率
"""

import os
import ast
import json
from pathlib import Path
from typing import Dict, List, Set, Tuple, Any
import logging

logger = logging.getLogger(__name__)

class CodeCoverageAnalyzer:
    """代码覆盖率分析器"""
    
    def __init__(self):
        self.coverage_data: Dict[str, Dict[str, Any]] = {}
        self.executed_lines: Dict[str, Set[int]] = {}
        
    def analyze_script(self, script_path: str) -> Dict[str, Any]:
        """分析脚本代码结构"""
        script_path = Path(script_path)
        
        if not script_path.exists():
            logger.error(f"脚本文件不存在: {script_path}")
            return {}
        
        try:
            with open(script_path, 'r', encoding='utf-8') as f:
                source_code = f.read()
            
            # 解析AST
            tree = ast.parse(source_code)
            
            # 收集代码信息
            total_lines = len(source_code.splitlines())
            executable_lines = set()
            functions = []
            classes = []
            
            # 遍历AST收集信息
            for node in ast.walk(tree):
                if hasattr(node, 'lineno'):
                    executable_lines.add(node.lineno)
                
                if isinstance(node, ast.FunctionDef):
                    functions.append({
                        "name": node.name,
                        "line": node.lineno,
                        "end_line": getattr(node, 'end_lineno', node.lineno),
                        "args": [arg.arg for arg in node.args.args]
                    })
                
                if isinstance(node, ast.ClassDef):
                    classes.append({
                        "name": node.name,
                        "line": node.lineno,
                        "end_line": getattr(node, 'end_lineno', node.lineno)
                    })
            
            analysis_result = {
                "script_path": str(script_path),
                "total_lines": total_lines,
                "executable_lines": len(executable_lines),
                "executable_line_numbers": sorted(list(executable_lines)),
                "functions": functions,
                "classes": classes,
                "coverage_percentage": 0.0,
                "covered_lines": [],
                "uncovered_lines": sorted(list(executable_lines))
            }
            
            self.coverage_data[str(script_path)] = analysis_result
            self.executed_lines[str(script_path)] = set()
            
            return analysis_result
            
        except Exception as e:
            logger.error(f"分析脚本时发生错误: {e}")
            return {}
    
    def record_execution(self, script_path: str, line_numbers: List[int]) -> None:
        """记录执行的行号"""
        script_path = str(script_path)
        
        if script_path not in self.executed_lines:
            self.executed_lines[script_path] = set()
        
        self.executed_lines[script_path].update(line_numbers)
        
        # 更新覆盖率数据
        if script_path in self.coverage_data:
            covered = self.executed_lines[script_path]
            all_executable = set(self.coverage_data[script_path]["executable_line_numbers"])
            
            if all_executable:
                coverage_percentage = len(covered) / len(all_executable) * 100
                self.coverage_data[script_path]["coverage_percentage"] = coverage_percentage
                self.coverage_data[script_path]["covered_lines"] = sorted(list(covered))
                self.coverage_data[script_path]["uncovered_lines"] = sorted(list(all_executable - covered))
    
    def get_coverage_report(self, script_path: str = None) -> Dict[str, Any]:
        """获取覆盖率报告"""
        if script_path:
            script_path = str(script_path)
            if script_path in self.coverage_data:
                return self.coverage_data[script_path]
            return {}
        
        # 汇总所有脚本的覆盖率
        total_executable = 0
        total_covered = 0
        script_reports = []
        
        for path, data in self.coverage_data.items():
            executable = data["executable_lines"]
            covered = len(data["covered_lines"])
            
            total_executable += executable
            total_covered += covered
            
            script_reports.append({
                "script_path": path,
                "executable_lines": executable,
                "covered_lines": covered,
                "coverage_percentage": data["coverage_percentage"],
                "functions": len(data["functions"]),
                "classes": len(data["classes"])
            })
        
        overall_coverage = total_covered / total_executable * 100 if total_executable > 0 else 0
        
        return {
            "overall_coverage": overall_coverage,
            "total_scripts": len(self.coverage_data),
            "total_executable_lines": total_executable,
            "total_covered_lines": total_covered,
            "script_reports": script_reports,
            "detailed_reports": self.coverage_data
        }
    
    def generate_html_coverage_report(self, output_path: str) -> str:
        """生成HTML覆盖率报告"""
        report = self.get_coverage_report()
        
        html = """
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <title>代码覆盖率报告</title>
            <style>
                body { font-family: Arial, sans-serif; margin: 20px; }
                .header { background: #f0f0f0; padding: 20px; border-radius: 5px; }
                .summary { margin: 20px 0; padding: 15px; background: #f9f9f9; border-radius: 5px; }
                .coverage-bar { width: 100%; height: 30px; background: #e0e0e0; border-radius: 5px; overflow: hidden; margin: 10px 0; }
                .coverage-fill { height: 100%; background: linear-gradient(90deg, #4CAF50, #8BC34A); }
                .script-report { margin: 15px 0; padding: 15px; border: 1px solid #ddd; border-radius: 5px; }
                .coverage-high { color: #4CAF50; font-weight: bold; }
                .coverage-medium { color: #FF9800; font-weight: bold; }
                .coverage-low { color: #F44336; font-weight: bold; }
                .stats { display: flex; gap: 20px; margin: 20px 0; }
                .stat-box { padding: 15px; background: white; border-radius: 5px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); flex: 1; }
                .details { margin-top: 20px; }
                .function-list { margin: 10px 0; padding-left: 20px; }
                .function-item { margin: 5px 0; }
            </style>
        </head>
        <body>
            <div class="header">
                <h1>代码覆盖率报告</h1>
                <p>生成时间: """ + datetime.now().strftime("%Y-%m-%d %H:%M:%S") + """</p>
            </div>
        """
        
        # 总体覆盖率
        overall_coverage = report["overall_coverage"]
        coverage_class = "coverage-high" if overall_coverage >= 80 else "coverage-medium" if overall_coverage >= 50 else "coverage-low"
        
        html += f"""
            <div class="summary">
                <h2>总体覆盖率</h2>
                <div class="coverage-bar">
                    <div class="coverage-fill" style="width: {overall_coverage}%"></div>
                </div>
                <p class="{coverage_class}">覆盖率: {overall_coverage:.1f}%</p>
                
                <div class="stats">
                    <div class="stat-box">
                        <h3>脚本数量</h3>
                        <p style="font-size: 24px; font-weight: bold;">{report['total_scripts']}</p>
                    </div>
                    <div class="stat-box">
                        <h3>可执行行数</h3>
                        <p style="font-size: 24px; font-weight: bold;">{report['total_executable_lines']}</p>
                    </div>
                    <div class="stat-box">
                        <h3>覆盖行数</h3>
                        <p style="font-size: 24px; font-weight: bold;">{report['total_covered_lines']}</p>
                    </div>
                </div>
            </div>
            
            <h2>脚本详细报告</h2>
        """
        
        # 脚本详细报告
        for script_report in report["script_reports"]:
            coverage = script_report["coverage_percentage"]
            script_class = "coverage-high" if coverage >= 80 else "coverage-medium" if coverage >= 50 else "coverage-low"
            
            html += f"""
            <div class="script-report">
                <h3>{Path(script_report['script_path']).name}</h3>
                <p>路径: {script_report['script_path']}</p>
                <div class="coverage-bar">
                    <div class="coverage-fill" style="width: {coverage}%"></div>
                </div>
                <p class="{script_class}">覆盖率: {coverage:.1f}%</p>
                <p>可执行行数: {script_report['executable_lines']}</p>
                <p>覆盖行数: {script_report['covered_lines']}</p>
                <p>函数数量: {script_report['functions']}</p>
                <p>类数量: {script_report['classes']}</p>
            </div>
            """
        
        html += """
            <div class="details">
                <h2>详细数据</h2>
                <pre id="json-data"></pre>
            </div>
            
            <script>
                document.getElementById('json-data').textContent = JSON.stringify(""" + json.dumps(report, indent=2) + """, null, 2);
            </script>
        </body>
        </html>
        """
        
        # 保存HTML文件
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(html)
        
        logger.info(f"覆盖率报告已生成: {output_path}")
        return html

# 导入datetime
from datetime import datetime