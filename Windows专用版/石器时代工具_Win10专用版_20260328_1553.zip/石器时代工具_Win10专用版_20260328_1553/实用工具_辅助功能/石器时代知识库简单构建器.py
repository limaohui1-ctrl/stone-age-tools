#!/usr/bin/env python3
"""
石器时代知识库简单构建器
快速从脚本文件中提取关键信息
"""

import os
import re
import json
import time

def ensure_directories():
    """确保目录结构存在"""
    knowledge_dir = "/root/.openclaw/workspace/石器时代知识库_简单版"
    directories = [
        knowledge_dir,
        os.path.join(knowledge_dir, "原始脚本"),
        os.path.join(knowledge_dir, "分析结果"),
    ]
    
    for directory in directories:
        os.makedirs(directory, exist_ok=True)
        print(f"✅ 目录已创建: {directory}")
    
    return knowledge_dir

def find_script_files():
    """查找所有石器时代脚本文件"""
    workspace_dir = "/root/.openclaw/workspace"
    script_files = []
    
    # 搜索.asc文件
    for root, dirs, files in os.walk(workspace_dir):
        for file in files:
            if file.endswith('.asc'):
                script_files.append(os.path.join(root, file))
    
    print(f"📁 找到 {len(script_files)} 个脚本文件")
    return script_files[:5]  # 只处理前5个文件

def extract_maps(content):
    """提取地图信息"""
    maps = []
    patterns = [
        r'map\s*[=:]\s*(\d+)',
        r'地图\s*[=:]\s*(\d+)',
    ]
    
    for pattern in patterns:
        matches = re.findall(pattern, content, re.IGNORECASE)
        for match in matches:
            if match not in maps:
                maps.append(match)
    
    return maps

def extract_npcs(content):
    """提取NPC信息"""
    npcs = []
    patterns = [
        r'NPC\s*[=:]\s*([^\s\n,;]{2,20})',
        r'对话\s*[=:]\s*([^\s\n,;]{2,20})',
    ]
    
    for pattern in patterns:
        matches = re.findall(pattern, content, re.IGNORECASE)
        for match in matches:
            if match not in npcs and len(match) > 1:
                npcs.append(match)
    
    return npcs

def extract_pets(content):
    """提取宠物信息"""
    pets = []
    patterns = [
        r'宠物\s*[=:]\s*([^\s\n,;]{2,20})',
        r'宠\s*[=:]\s*([^\s\n,;]{2,20})',
    ]
    
    for pattern in patterns:
        matches = re.findall(pattern, content, re.IGNORECASE)
        for match in matches:
            if match not in pets and len(match) > 1:
                pets.append(match)
    
    return pets

def extract_coordinates(content):
    """提取坐标信息"""
    coordinates = []
    patterns = [
        r'坐标\s*[=:]\s*(\d+)[,\s]+(\d+)',
        r'\((\d+)[,\s]+(\d+)\)',
    ]
    
    for pattern in patterns:
        matches = re.findall(pattern, content)
        for match in matches:
            if len(match) == 2:
                coord = f"{match[0]},{match[1]}"
                if coord not in coordinates:
                    coordinates.append(coord)
    
    return coordinates

def analyze_script_file(filepath, knowledge_dir):
    """分析单个脚本文件"""
    filename = os.path.basename(filepath)
    print(f"🔍 分析文件: {filename}")
    
    try:
        with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read()
        
        # 复制到知识库
        dest_path = os.path.join(knowledge_dir, "原始脚本", filename)
        with open(dest_path, 'w', encoding='utf-8') as f:
            f.write(content)
        
        # 提取信息
        extracted = {
            "file": filename,
            "size": len(content),
            "lines": content.count('\n') + 1,
            "maps": extract_maps(content),
            "npcs": extract_npcs(content),
            "pets": extract_pets(content),
            "coordinates": extract_coordinates(content),
        }
        
        return extracted
        
    except Exception as e:
        print(f"❌ 分析文件失败 {filepath}: {e}")
        return None

def build_knowledge_base():
    """构建知识库"""
    print("="*60)
    print("🧠 开始构建石器时代知识库（简单版）")
    print("="*60)
    
    # 创建目录
    knowledge_dir = ensure_directories()
    
    # 查找脚本文件
    script_files = find_script_files()
    
    # 知识库数据结构
    knowledge_base = {
        "metadata": {
            "name": "石器时代游戏知识库（简单版）",
            "version": "1.0.0",
            "created_at": time.strftime("%Y-%m-%d %H:%M:%S"),
            "description": "从脚本文件中提取的石器时代游戏知识"
        },
        "maps": [],
        "npcs": [],
        "pets": [],
        "coordinates": [],
        "scripts": []
    }
    
    all_analysis = []
    
    # 分析文件
    for filepath in script_files:
        analysis = analyze_script_file(filepath, knowledge_dir)
        if analysis:
            all_analysis.append(analysis)
            
            # 合并到知识库
            knowledge_base["maps"].extend(analysis["maps"])
            knowledge_base["npcs"].extend(analysis["npcs"])
            knowledge_base["pets"].extend(analysis["pets"])
            knowledge_base["coordinates"].extend(analysis["coordinates"])
            
            # 添加脚本信息
            script_info = {
                "name": analysis["file"],
                "size": analysis["size"],
                "lines": analysis["lines"],
            }
            knowledge_base["scripts"].append(script_info)
    
    # 去重
    for key in ["maps", "npcs", "pets", "coordinates"]:
        knowledge_base[key] = list(set(knowledge_base[key]))
    
    # 保存知识库
    save_knowledge_base(knowledge_base, knowledge_dir)
    
    # 生成分析报告
    generate_analysis_report(all_analysis, knowledge_dir)
    
    return knowledge_base, knowledge_dir

def save_knowledge_base(knowledge_base, knowledge_dir):
    """保存知识库到文件"""
    # JSON格式
    json_file = os.path.join(knowledge_dir, "知识库.json")
    with open(json_file, 'w', encoding='utf-8') as f:
        json.dump(knowledge_base, f, ensure_ascii=False, indent=2)
    
    # Markdown格式
    md_file = os.path.join(knowledge_dir, "知识库.md")
    with open(md_file, 'w', encoding='utf-8') as f:
        f.write("# 石器时代游戏知识库（简单版）\n\n")
        f.write(f"**生成时间**: {knowledge_base['metadata']['created_at']}\n\n")
        
        f.write("## 数据统计\n\n")
        f.write(f"- **地图数量**: {len(knowledge_base['maps'])}\n")
        f.write(f"- **NPC数量**: {len(knowledge_base['npcs'])}\n")
        f.write(f"- **宠物数量**: {len(knowledge_base['pets'])}\n")
        f.write(f"- **坐标数量**: {len(knowledge_base['coordinates'])}\n")
        f.write(f"- **脚本数量**: {len(knowledge_base['scripts'])}\n\n")
        
        f.write("## 地图列表\n\n")
        for i, map_id in enumerate(sorted(knowledge_base['maps']), 1):
            f.write(f"{i}. 地图ID: {map_id}\n")
        
        f.write("\n## NPC列表\n\n")
        for i, npc in enumerate(sorted(knowledge_base['npcs']), 1):
            f.write(f"{i}. {npc}\n")
        
        f.write("\n## 宠物列表\n\n")
        for i, pet in enumerate(sorted(knowledge_base['pets']), 1):
            f.write(f"{i}. {pet}\n")
        
        f.write("\n## 坐标列表\n\n")
        for i, coord in enumerate(sorted(knowledge_base['coordinates']), 1):
            f.write(f"{i}. {coord}\n")
        
        f.write("\n## 脚本列表\n\n")
        for i, script in enumerate(knowledge_base['scripts'], 1):
            f.write(f"{i}. **{script['name']}**\n")
            f.write(f"   - 大小: {script['size']} 字节\n")
            f.write(f"   - 行数: {script['lines']} 行\n")
    
    print(f"✅ 知识库已保存:")
    print(f"   📄 JSON格式: {json_file}")
    print(f"   📄 Markdown格式: {md_file}")

def generate_analysis_report(all_analysis, knowledge_dir):
    """生成分析报告"""
    report_file = os.path.join(knowledge_dir, "分析结果", "脚本分析报告.md")
    
    with open(report_file, 'w', encoding='utf-8') as f:
        f.write("# 石器时代脚本分析报告（简单版）\n\n")
        f.write(f"**分析时间**: {time.strftime('%Y-%m-%d %H:%M:%S')}\n")
        f.write(f"**分析文件数**: {len(all_analysis)}\n\n")
        
        f.write("## 文件分析详情\n\n")
        
        total_size = 0
        total_lines = 0
        
        for analysis in all_analysis:
            f.write(f"### {analysis['file']}\n")
            f.write(f"- **大小**: {analysis['size']} 字节\n")
            f.write(f"- **行数**: {analysis['lines']} 行\n")
            
            total_size += analysis['size']
            total_lines += analysis['lines']
            
            f.write(f"- **地图ID**: {len(analysis['maps'])} 个\n")
            if analysis['maps']:
                f.write(f"  - {', '.join(analysis['maps'])}\n")
            
            f.write(f"- **NPC**: {len(analysis['npcs'])} 个\n")
            if analysis['npcs']:
                f.write(f"  - {', '.join(analysis['npcs'])}\n")
            
            f.write(f"- **宠物**: {len(analysis['pets'])} 个\n")
            if analysis['pets']:
                f.write(f"  - {', '.join(analysis['pets'])}\n")
            
            f.write(f"- **坐标**: {len(analysis['coordinates'])} 个\n")
            if analysis['coordinates']:
                f.write(f"  - {', '.join(analysis['coordinates'])}\n")
            
            f.write("\n")
        
        f.write("## 总体统计\n\n")
        f.write(f"- **总文件数**: {len(all_analysis)}\n")
        f.write(f"- **总大小**: {total_size} 字节 ({total_size/1024:.1f} KB)\n")
        f.write(f"- **总行数**: {total_lines} 行\n")
        f.write(f"- **平均文件大小**: {total_size/len(all_analysis):.0f} 字节\n")
        f.write(f"- **平均行数**: {total_lines/len(all_analysis):.0f} 行\n")
    
    print(f"📊 分析报告已生成: {report_file}")

def main():
    """主函数"""
    print("🚀 石器时代知识库构建器（简单版）启动")
    print("="*60)
    
    # 构建知识库
    knowledge_base, knowledge_dir = build_knowledge_base()
    
    print("\n" + "="*60)
    print("🎉 知识库构建完成!")
    print("="*60)
    
    # 显示统计信息
    print("📊 知识库统计:")
    print(f"  📍 地图: {len(knowledge_base['maps'])} 个")
    print(f"  👤 NPC: {len(knowledge_base['npcs'])} 个")
    print(f"  🐾 宠物: {len(knowledge_base['pets'])} 个")
    print(f"  📍 坐标: {len(knowledge_base['coordinates'])} 个")
    print(f"  📜 脚本: {len(knowledge_base['scripts'])} 个")
    
    print("\n📁 生成的文件:")
    print(f"  📄 知识库JSON: {knowledge_dir}/知识库.json")
    print(f"  📄 知识库MD: {knowledge_dir}/知识库.md")
    print(f"  📄 分析报告: {knowledge_dir}/分析结果/脚本分析报告.md")
    
    print("\n💡 下一步建议:")
    print("1. 查看知识库文件，了解游戏结构")
    print("2. 基于提取的数据开发新的游戏脚本")
    print("3. 将知识库用于脚本开发和教学")
    print("4. 可以扩展分析更多脚本文件")

if __name__ == "__main__":
    main()