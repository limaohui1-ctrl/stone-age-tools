#!/usr/bin/env python3
"""
石器时代脚本查询工具
基于1,083个脚本数据库的快速查询系统
"""

import json
import os
import re
from datetime import datetime

DB_FILE = "/root/.openclaw/workspace/石器时代脚本数据库/脚本数据库.json"
OUTPUT_DIR = "/root/.openclaw/workspace/石器时代脚本查询结果"

class ScriptSearcher:
    def __init__(self):
        with open(DB_FILE, 'r', encoding='utf-8') as f:
            self.database = json.load(f)
        print(f"✅ 加载数据库: {len(self.database)} 个脚本")
        
        # 创建输出目录
        os.makedirs(OUTPUT_DIR, exist_ok=True)
    
    def search_by_keyword(self, keyword):
        """按关键词搜索"""
        results = []
        keyword_lower = keyword.lower()
        
        for script in self.database:
            # 在文件名中搜索
            if keyword_lower in script['file_name'].lower():
                results.append(script)
                continue
            
            # 在标题中搜索
            if 'title' in script and keyword_lower in script['title'].lower():
                results.append(script)
                continue
            
            # 在功能中搜索
            if 'functions' in script:
                for func in script['functions']:
                    if keyword_lower in func.lower():
                        results.append(script)
                        break
        
        return results
    
    def search_by_npc(self, npc_name):
        """按NPC搜索"""
        results = []
        npc_lower = npc_name.lower()
        
        for script in self.database:
            if 'npcs' in script:
                for npc in script['npcs']:
                    if npc_lower in npc.lower():
                        results.append(script)
                        break
        
        return results
    
    def search_by_coordinate(self, x=None, y=None, coord_str=None):
        """按坐标搜索"""
        results = []
        
        for script in self.database:
            if 'coordinates' in script:
                for coord in script['coordinates']:
                    if coord_str and coord_str in coord:
                        results.append(script)
                        break
                    elif x and y:
                        try:
                            cx, cy = map(int, coord.split(','))
                            if cx == x and cy == y:
                                results.append(script)
                                break
                        except:
                            pass
        
        return results
    
    def search_by_function(self, function_name):
        """按功能分类搜索"""
        results = []
        func_lower = function_name.lower()
        
        for script in self.database:
            if 'functions' in script:
                for func in script['functions']:
                    if func_lower in func.lower():
                        results.append(script)
                        break
        
        return results
    
    def search_by_item(self, item_name):
        """按物品搜索"""
        results = []
        item_lower = item_name.lower()
        
        for script in self.database:
            if 'items' in script:
                for item in script['items']:
                    if item_lower in item.lower():
                        results.append(script)
                        break
        
        return results
    
    def generate_report(self, results, search_type, query):
        """生成查询报告"""
        if not results:
            report = f"# 🔍 脚本查询报告\n\n"
            report += f"**查询类型**: {search_type}\n"
            report += f"**查询条件**: {query}\n"
            report += f"**查询时间**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n"
            report += "## ❌ 未找到匹配的脚本\n"
            return report
        
        report = f"# 🔍 脚本查询报告\n\n"
        report += f"**查询类型**: {search_type}\n"
        report += f"**查询条件**: {query}\n"
        report += f"**查询时间**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n"
        report += f"**找到脚本**: {len(results)} 个\n\n"
        
        report += "## 📊 结果摘要\n\n"
        report += f"- **脚本数量**: {len(results)} 个\n"
        
        # 按功能统计
        func_stats = {}
        for script in results:
            for func in script.get('functions', []):
                func_stats[func] = func_stats.get(func, 0) + 1
        
        if func_stats:
            report += "- **功能分布**:\n"
            for func, count in sorted(func_stats.items(), key=lambda x: x[1], reverse=True):
                report += f"  - {func}: {count} 个\n"
        
        report += "\n## 📋 脚本列表\n\n"
        
        for i, script in enumerate(results, 1):
            report += f"### {i}. {script.get('title', script['file_name'])}\n"
            report += f"- **文件**: `{script['file_name']}`\n"
            report += f"- **路径**: `{script['file_path']}`\n"
            report += f"- **大小**: {script['file_size']} 字节\n"
            report += f"- **行数**: {script['line_count']} 行\n"
            
            if 'author' in script:
                report += f"- **作者**: {script['author']}\n"
            
            if 'version' in script:
                report += f"- **版本**: {script['version']}\n"
            
            if 'functions' in script:
                report += f"- **功能**: {', '.join(script['functions'])}\n"
            
            if 'npcs' in script and script['npcs']:
                npcs = script['npcs'][:5]
                report += f"- **NPC**: {', '.join(npcs)}"
                if len(script['npcs']) > 5:
                    report += f" 等 {len(script['npcs'])} 个"
                report += "\n"
            
            if 'coordinates' in script and script['coordinates']:
                coords = script['coordinates'][:5]
                report += f"- **坐标**: {', '.join(coords)}"
                if len(script['coordinates']) > 5:
                    report += f" 等 {len(script['coordinates'])} 个"
                report += "\n"
            
            if 'items' in script and script['items']:
                items = script['items'][:5]
                report += f"- **物品**: {', '.join(items)}"
                if len(script['items']) > 5:
                    report += f" 等 {len(script['items'])} 个"
                report += "\n"
            
            report += "\n"
        
        report += "## 🚀 使用建议\n\n"
        report += "1. **直接使用**: 复制脚本文件到ASSA脚本目录即可使用\n"
        report += "2. **学习参考**: 分析脚本逻辑和实现方式\n"
        report += "3. **修改适配**: 根据NG25私服需求调整脚本\n"
        report += "4. **组合使用**: 多个脚本组合完成复杂任务\n\n"
        
        report += "---\n"
        report += "*本报告由石器时代脚本查询工具自动生成*\n"
        
        return report
    
    def save_report(self, report, filename):
        """保存报告到文件"""
        filepath = os.path.join(OUTPUT_DIR, filename)
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(report)
        return filepath
    
    def interactive_search(self):
        """交互式查询界面"""
        print("🦕 石器时代脚本查询工具")
        print("=" * 60)
        print("可用的查询方式:")
        print("1. 关键词搜索 (文件名、标题、功能)")
        print("2. NPC搜索")
        print("3. 坐标搜索")
        print("4. 功能分类搜索")
        print("5. 物品搜索")
        print("=" * 60)
        
        while True:
            print("\n请选择查询方式 (1-5, 输入q退出):")
            choice = input("> ").strip()
            
            if choice.lower() == 'q':
                print("👋 再见！")
                break
            
            if choice == '1':
                keyword = input("请输入关键词: ").strip()
                if keyword:
                    results = self.search_by_keyword(keyword)
                    report = self.generate_report(results, "关键词搜索", keyword)
                    filename = f"关键词搜索_{keyword}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.md"
                    filepath = self.save_report(report, filename)
                    print(f"✅ 找到 {len(results)} 个脚本")
                    print(f"📄 报告已保存: {filepath}")
            
            elif choice == '2':
                npc = input("请输入NPC名称: ").strip()
                if npc:
                    results = self.search_by_npc(npc)
                    report = self.generate_report(results, "NPC搜索", npc)
                    filename = f"NPC搜索_{npc}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.md"
                    filepath = self.save_report(report, filename)
                    print(f"✅ 找到 {len(results)} 个脚本")
                    print(f"📄 报告已保存: {filepath}")
            
            elif choice == '3':
                print("坐标搜索选项:")
                print("a. 输入完整坐标 (如 100,200)")
                print("b. 输入坐标部分 (如 100)")
                coord_choice = input("请选择 (a/b): ").strip().lower()
                
                if coord_choice == 'a':
                    coord = input("请输入完整坐标 (x,y): ").strip()
                    if coord:
                        results = self.search_by_coordinate(coord_str=coord)
                        report = self.generate_report(results, "坐标搜索", coord)
                        filename = f"坐标搜索_{coord}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.md"
                        filepath = self.save_report(report, filename)
                        print(f"✅ 找到 {len(results)} 个脚本")
                        print(f"📄 报告已保存: {filepath}")
                
                elif coord_choice == 'b':
                    coord_part = input("请输入坐标部分: ").strip()
                    if coord_part:
                        results = self.search_by_coordinate(coord_str=coord_part)
                        report = self.generate_report(results, "坐标搜索", f"包含{coord_part}")
                        filename = f"坐标搜索_部分_{coord_part}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.md"
                        filepath = self.save_report(report, filename)
                        print(f"✅ 找到 {len(results)} 个脚本")
                        print(f"📄 报告已保存: {filepath}")
            
            elif choice == '4':
                print("可用功能分类:")
                print("- 自动挂机")
                print("- 宠物相关")
                print("- 任务脚本")
                print("- 料理合成")
                print("- 赚钱脚本")
                print("- 交通脚本")
                print("- 副本活动")
                func = input("请输入功能名称: ").strip()
                if func:
                    results = self.search_by_function(func)
                    report = self.generate_report(results, "功能搜索", func)
                    filename = f"功能搜索_{func}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.md"
                    filepath = self.save_report(report, filename)
                    print(f"✅ 找到 {len(results)} 个脚本")
                    print(f"📄 报告已保存: {filepath}")
            
            elif choice == '5':
                item = input("请输入物品名称: ").strip()
                if item:
                    results = self.search_by_item(item)
                    report = self.generate_report(results, "物品搜索", item)
                    filename = f"物品搜索_{item}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.md"
                    filepath = self.save_report(report, filename)
                    print(f"✅ 找到 {len(results)} 个脚本")
                    print(f"📄 报告已保存: {filepath}")
            
            else:
                print("❌ 无效选择，请重新输入")

def main():
    searcher = ScriptSearcher()
    searcher.interactive_search()

if __name__ == "__main__":
    main()