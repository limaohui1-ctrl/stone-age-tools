#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
验证码识别核心模块
"""

import os
import cv2
import numpy as np
from PIL import Image
import pytesseract
from typing import Optional, Tuple, List
import logging

class CaptchaRecognizer:
    """验证码识别器"""
    
    def __init__(self, config_path: Optional[str] = None):
        """
        初始化验证码识别器
        
        Args:
            config_path: 配置文件路径
        """
        self.logger = logging.getLogger(__name__)
        self.config = self._load_config(config_path)
        
        # OCR配置
        self.tesseract_path = self.config.get('tesseract_path', None)
        if self.tesseract_path and os.path.exists(self.tesseract_path):
            pytesseract.pytesseract.tesseract_cmd = self.tesseract_path
        
        # 图像预处理参数
        self.preprocess_params = {
            'grayscale': True,
            'threshold': True,
            'denoise': True,
            'morphology': True,
            'resize': (200, 80)  # 标准验证码尺寸
        }
        
        self.logger.info("验证码识别器初始化完成")
    
    def _load_config(self, config_path: Optional[str]) -> dict:
        """加载配置"""
        default_config = {
            'tesseract_path': None,
            'language': 'eng',
            'ocr_engine': 'tesseract',  # tesseract, easyocr, paddleocr
            'preprocess_enabled': True,
            'confidence_threshold': 0.7,
            'character_whitelist': 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789',
            'max_retry': 3
        }
        
        # 在实际版本中，这里会从配置文件加载
        return default_config
    
    def preprocess_image(self, image: np.ndarray) -> np.ndarray:
        """
        图像预处理
        
        Args:
            image: 输入图像
            
        Returns:
            预处理后的图像
        """
        if not self.preprocess_params['preprocess_enabled']:
            return image
        
        # 转换为灰度图
        if len(image.shape) == 3:
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        else:
            gray = image
        
        # 二值化
        if self.preprocess_params['threshold']:
            # 使用OTSU自动阈值
            _, binary = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
        else:
            binary = gray
        
        # 去噪
        if self.preprocess_params['denoise']:
            # 中值滤波
            denoised = cv2.medianBlur(binary, 3)
        else:
            denoised = binary
        
        # 形态学操作（去除小点，连接断裂字符）
        if self.preprocess_params['morphology']:
            kernel = np.ones((2, 2), np.uint8)
            morphed = cv2.morphologyEx(denoised, cv2.MORPH_CLOSE, kernel)
        else:
            morphed = denoised
        
        # 调整尺寸
        if self.preprocess_params['resize']:
            target_size = self.preprocess_params['resize']
            resized = cv2.resize(morphed, target_size, interpolation=cv2.INTER_CUBIC)
        else:
            resized = morphed
        
        return resized
    
    def recognize(self, image_path: str) -> str:
        """
        识别验证码
        
        Args:
            image_path: 验证码图片路径
            
        Returns:
            识别结果字符串
        """
        self.logger.info(f"开始识别验证码: {image_path}")
        
        # 检查文件是否存在
        if not os.path.exists(image_path):
            self.logger.error(f"图片文件不存在: {image_path}")
            return ""
        
        try:
            # 读取图片
            image = cv2.imread(image_path)
            if image is None:
                self.logger.error(f"无法读取图片: {image_path}")
                return ""
            
            # 预处理
            processed = self.preprocess_image(image)
            
            # OCR识别
            result = self._ocr_recognize(processed)
            
            # 后处理
            cleaned_result = self._postprocess_result(result)
            
            self.logger.info(f"识别结果: {cleaned_result}")
            return cleaned_result
            
        except Exception as e:
            self.logger.error(f"验证码识别失败: {e}")
            return ""
    
    def _ocr_recognize(self, image: np.ndarray) -> str:
        """
        OCR识别核心
        
        Args:
            image: 预处理后的图像
            
        Returns:
            识别文本
        """
        # 配置Tesseract参数
        config = f'--psm 8 --oem 3 -c tessedit_char_whitelist={self.config["character_whitelist"]}'
        
        # 转换为PIL Image
        pil_image = Image.fromarray(image)
        
        # 使用Tesseract识别
        text = pytesseract.image_to_string(pil_image, 
                                          config=config,
                                          lang=self.config['language'])
        
        return text.strip()
    
    def _postprocess_result(self, text: str) -> str:
        """
        识别结果后处理
        
        Args:
            text: 原始识别文本
            
        Returns:
            清理后的文本
        """
        # 移除空白字符
        cleaned = ''.join(text.split())
        
        # 移除非字母数字字符
        cleaned = ''.join(c for c in cleaned if c.isalnum())
        
        # 转换为大写（验证码通常是大写）
        cleaned = cleaned.upper()
        
        # 限制长度（通常验证码是4-6个字符）
        if len(cleaned) > 6:
            cleaned = cleaned[:6]
        
        return cleaned
    
    def batch_recognize(self, image_dir: str) -> List[Tuple[str, str]]:
        """
        批量识别验证码
        
        Args:
            image_dir: 图片目录
            
        Returns:
            列表，每个元素为(文件名, 识别结果)
        """
        results = []
        
        if not os.path.isdir(image_dir):
            self.logger.error(f"目录不存在: {image_dir}")
            return results
        
        # 获取所有图片文件
        image_files = []
        for ext in ['.png', '.jpg', '.jpeg', '.bmp', '.gif']:
            image_files.extend([f for f in os.listdir(image_dir) 
                              if f.lower().endswith(ext)])
        
        self.logger.info(f"找到 {len(image_files)} 个图片文件")
        
        for image_file in image_files:
            image_path = os.path.join(image_dir, image_file)
            result = self.recognize(image_path)
            results.append((image_file, result))
            
            self.logger.debug(f"{image_file}: {result}")
        
        return results
    
    def test_accuracy(self, test_dir: str, ground_truth: dict) -> dict:
        """
        测试识别准确率
        
        Args:
            test_dir: 测试图片目录
            ground_truth: 真实标签字典 {文件名: 真实文本}
            
        Returns:
            准确率统计
        """
        results = self.batch_recognize(test_dir)
        
        total = len(results)
        correct = 0
        details = []
        
        for filename, predicted in results:
            truth = ground_truth.get(filename, "")
            is_correct = (predicted == truth)
            
            if is_correct:
                correct += 1
            
            details.append({
                'filename': filename,
                'predicted': predicted,
                'truth': truth,
                'correct': is_correct
            })
        
        accuracy = correct / total if total > 0 else 0
        
        return {
            'total': total,
            'correct': correct,
            'accuracy': accuracy,
            'details': details
        }


# 简单测试函数
def test_captcha_recognizer():
    """测试验证码识别器"""
    print("🔍 测试验证码识别器")
    
    # 创建识别器
    recognizer = CaptchaRecognizer()
    
    # 创建测试目录
    test_dir = "/tmp/test_captchas"
    os.makedirs(test_dir, exist_ok=True)
    
    print(f"📁 测试目录: {test_dir}")
    print("💡 请将验证码图片放入该目录进行测试")
    print("📝 支持的格式: PNG, JPG, JPEG, BMP")
    
    # 检查是否有测试图片
    image_files = [f for f in os.listdir(test_dir) 
                  if f.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp'))]
    
    if image_files:
        print(f"\n📸 找到 {len(image_files)} 个测试图片:")
        for image_file in image_files[:5]:  # 显示前5个
            image_path = os.path.join(test_dir, image_file)
            result = recognizer.recognize(image_path)
            print(f"  {image_file}: {result}")
    else:
        print("\n📝 测试目录为空，请添加验证码图片")

if __name__ == "__main__":
    test_captcha_recognizer()