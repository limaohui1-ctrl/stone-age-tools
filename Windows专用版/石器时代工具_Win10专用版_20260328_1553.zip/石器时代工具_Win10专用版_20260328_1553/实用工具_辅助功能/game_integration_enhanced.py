#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
增强版游戏集成模块 - 智能窗口检测和验证码区域定位
"""

import os
import sys
import time
import logging
import json
from typing import Optional, List, Tuple, Dict, Any
from pathlib import Path
import subprocess

# 尝试导入Windows相关库
try:
    import win32gui
    import win32con
    import win32api
    import win32process
    HAS_WIN32 = True
except ImportError:
    HAS_WIN32 = False
    print("⚠️  win32库未安装，部分功能可能受限")

# 尝试导入自动化库
try:
    import pyautogui
    HAS_PYAUTOGUI = True
except ImportError:
    HAS_PYAUTOGUI = False
    print("⚠️  pyautogui未安装，部分功能可能受限")

# 尝试导入图像处理库
try:
    import cv2
    import numpy as np
    from PIL import Image, ImageGrab
    HAS_IMAGE_PROCESSING = True
except ImportError:
    HAS_IMAGE_PROCESSING = False
    print("⚠️  图像处理库未安装，部分功能可能受限")

class GameIntegrationEnhanced:
    """增强版游戏集成类"""
    
    def __init__(self, config_manager=None):
        """
        初始化增强版游戏集成
        
        Args:
            config_manager: 配置管理器实例
        """
        self.logger = logging.getLogger(__name__)
        self.config_manager = config_manager
        
        # 加载配置
        self.config = self._load_config()
        
        # 游戏窗口信息
        self.game_window = None
        self.game_title = self.config.get('game_title', '石器时代')
        self.game_process = None
        self.game_pid = None
        
        # 验证码检测配置
        self.captcha_detection = {
            'enabled': True,
            'detection_method': 'color',  # color, template, ml
            'color_range': {'lower': [200, 200, 200], 'upper': [255, 255, 255]},
            'min_area': 100,
            'confidence_threshold': 0.8
        }
        
        # 智能定位配置
        self.auto_detection = {
            'enabled': True,
            'max_attempts': 3,
            'detection_timeout': 10,
            'learning_enabled': True
        }
        
        # 状态跟踪
        self.stats = {
            'windows_found': 0,
            'captchas_detected': 0,
            'captchas_processed': 0,
            'auto_detections': 0,
            'errors': 0,
            'last_detection_time': None
        }
        
        # 学习数据
        self.learning_data = {
            'captcha_positions': [],
            'window_sizes': [],
            'detection_patterns': []
        }
        
        self.logger.info("增强版游戏集成模块初始化完成")
    
    def _load_config(self) -> dict:
        """加载配置"""
        default_config = {
            'game_title': '石器时代',
            'game_title_patterns': ['石器时代', 'StoneAge', 'SA'],
            'game_exe_path': None,
            'game_class_name': None,
            
            'captcha_area': {'x': 100, 'y': 200, 'width': 200, 'height': 80},
            'input_area': {'x': 150, 'y': 300, 'width': 100, 'height': 30},
            'submit_button': {'x': 250, 'y': 300, 'width': 60, 'height': 30},
            
            'captcha_check_interval': 5,
            'auto_input_enabled': True,
            'screenshot_quality': 90,
            'max_retry': 3,
            
            'smart_detection': {
                'enabled': True,
                'method': 'hybrid',  # hybrid, color, template, ocr
                'confidence_threshold': 0.7,
                'adaptive_learning': True
            },
            
            'performance': {
                'cache_enabled': True,
                'parallel_processing': False,
                'optimization_level': 'balanced'  # minimal, balanced, aggressive
            }
        }
        
        # 如果提供了配置管理器，从配置管理器加载
        if self.config_manager:
            try:
                config_data = self.config_manager.load_config()
                if 'game' in config_data:
                    game_config = config_data['game']
                    default_config.update({
                        'game_title': game_config.get('window_title', default_config['game_title']),
                        'game_exe_path': game_config.get('exe_path', default_config['game_exe_path']),
                        'captcha_area': game_config.get('captcha_area', default_config['captcha_area']),
                        'input_area': game_config.get('input_area', default_config['input_area'])
                    })
            except Exception as e:
                self.logger.warning(f"从配置管理器加载配置失败: {e}")
        
        return default_config
    
    def find_game_windows_advanced(self) -> List[Dict[str, Any]]:
        """
        高级查找游戏窗口（支持多种查找方式）
        
        Returns:
            窗口信息列表
        """
        windows = []
        
        if not HAS_WIN32:
            self.logger.warning("win32库未安装，无法查找游戏窗口")
            return windows
        
        try:
            # 方法1: 按标题查找
            title_windows = self._find_windows_by_title()
            windows.extend(title_windows)
            
            # 方法2: 按类名查找
            class_windows = self._find_windows_by_class()
            windows.extend(class_windows)
            
            # 方法3: 按进程名查找
            process_windows = self._find_windows_by_process()
            windows.extend(process_windows)
            
            # 去重
            unique_windows = []
            seen_handles = set()
            
            for window in windows:
                hwnd = window['handle']
                if hwnd not in seen_handles:
                    seen_handles.add(hwnd)
                    unique_windows.append(window)
            
            self.stats['windows_found'] = len(unique_windows)
            self.logger.info(f"找到 {len(unique_windows)} 个唯一游戏窗口")
            
            return unique_windows
            
        except Exception as e:
            self.logger.error(f"高级查找游戏窗口失败: {e}")
            return []
    
    def _find_windows_by_title(self) -> List[Dict[str, Any]]:
        """按标题查找窗口"""
        windows = []
        
        def callback(hwnd, extra):
            if win32gui.IsWindowVisible(hwnd):
                title = win32gui.GetWindowText(hwnd)
                
                # 检查标题是否匹配
                for pattern in self.config['game_title_patterns']:
                    if pattern and pattern in title:
                        try:
                            rect = win32gui.GetWindowRect(hwnd)
                            pid = win32process.GetWindowThreadProcessId(hwnd)[1]
                            
                            windows.append({
                                'handle': hwnd,
                                'title': title,
                                'rect': rect,
                                'pid': pid,
                                'method': 'title',
                                'pattern': pattern
                            })
                            break
                        except Exception as e:
                            self.logger.debug(f"获取窗口信息失败: {e}")
            return True
        
        win32gui.EnumWindows(callback, None)
        return windows
    
    def _find_windows_by_class(self) -> List[Dict[str, Any]]:
        """按类名查找窗口"""
        windows = []
        
        if not self.config.get('game_class_name'):
            return windows
        
        def callback(hwnd, extra):
            if win32gui.IsWindowVisible(hwnd):
                class_name = win32gui.GetClassName(hwnd)
                
                if class_name == self.config['game_class_name']:
                    try:
                        title = win32gui.GetWindowText(hwnd)
                        rect = win32gui.GetWindowRect(hwnd)
                        pid = win32process.GetWindowThreadProcessId(hwnd)[1]
                        
                        windows.append({
                            'handle': hwnd,
                            'title': title,
                            'class_name': class_name,
                            'rect': rect,
                            'pid': pid,
                            'method': 'class'
                        })
                    except Exception as e:
                        self.logger.debug(f"获取窗口信息失败: {e}")
            return True
        
        win32gui.EnumWindows(callback, None)
        return windows
    
    def _find_windows_by_process(self) -> List[Dict[str, Any]]:
        """按进程名查找窗口"""
        windows = []
        
        if not self.config.get('game_exe_path'):
            return windows
        
        # 提取进程名
        exe_path = self.config['game_exe_path']
        process_name = os.path.basename(exe_path).lower()
        
        def callback(hwnd, extra):
            if win32gui.IsWindowVisible(hwnd):
                try:
                    pid = win32process.GetWindowThreadProcessId(hwnd)[1]
                    
                    # 获取进程信息
                    import psutil
                    try:
                        process = psutil.Process(pid)
                        if process.name().lower() == process_name:
                            title = win32gui.GetWindowText(hwnd)
                            rect = win32gui.GetWindowRect(hwnd)
                            
                            windows.append({
                                'handle': hwnd,
                                'title': title,
                                'process_name': process.name(),
                                'rect': rect,
                                'pid': pid,
                                'method': 'process'
                            })
                    except (psutil.NoSuchProcess, psutil.AccessDenied):
                        pass
                        
                except Exception as e:
                    self.logger.debug(f"检查进程失败: {e}")
            return True
        
        win32gui.EnumWindows(callback, None)
        return windows
    
    def auto_detect_captcha_area(self, hwnd: int) -> Optional[Dict[str, Any]]:
        """
        自动检测验证码区域
        
        Args:
            hwnd: 窗口句柄
            
        Returns:
            检测到的区域信息，如果失败则返回None
        """
        if not HAS_IMAGE_PROCESSING or not HAS_PYAUTOGUI:
            self.logger.warning("必要的库未安装，无法自动检测")
            return None
        
        try:
            # 激活窗口
            win32gui.SetForegroundWindow(hwnd)
            time.sleep(0.5)
            
            # 获取窗口截图
            rect = win32gui.GetWindowRect(hwnd)
            screenshot = self._capture_window_area(hwnd, rect)
            
            if screenshot is None:
                return None
            
            # 多种检测方法
            detection_results = []
            
            # 方法1: 颜色检测
            color_result = self._detect_by_color(screenshot)
            if color_result:
                detection_results.append(('color', color_result))
            
            # 方法2: 模板匹配
            template_result = self._detect_by_template(screenshot)
            if template_result:
                detection_results.append(('template', template_result))
            
            # 方法3: 文本检测
            text_result = self._detect_by_text(screenshot)
            if text_result:
                detection_results.append(('text', text_result))
            
            # 选择最佳结果
            best_result = self._select_best_detection(detection_results)
            
            if best_result:
                self.stats['auto_detections'] += 1
                self.stats['last_detection_time'] = time.time()
                
                # 保存学习数据
                if self.auto_detection['learning_enabled']:
                    self._save_learning_data(hwnd, best_result)
                
                self.logger.info(f"自动检测成功: {best_result}")
                return best_result
            
            return None
            
        except Exception as e:
            self.logger.error(f"自动检测失败: {e}")
            return None
    
    def _capture_window_area(self, hwnd: int, rect: Tuple) -> Optional[np.ndarray]:
        """捕获窗口区域"""
        try:
            left, top, right, bottom = rect
            width = right - left
            height = bottom - top
            
            # 使用pyautogui截图
            screenshot = pyautogui.screenshot(region=(left, top, width, height))
            
            # 转换为OpenCV格式
            screenshot_cv = cv2.cvtColor(np.array(screenshot), cv2.COLOR_RGB2BGR)
            
            return screenshot_cv
            
        except Exception as e:
            self.logger.error(f"捕获窗口区域失败: {e}")
            return None
    
    def _detect_by_color(self, image: np.ndarray) -> Optional[Dict[str, Any]]:
        """通过颜色检测验证码区域"""
        try:
            # 转换为HSV颜色空间
            hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
            
            # 定义验证码常见颜色范围（白色/亮色）
            lower_white = np.array([0, 0, 200])
            upper_white = np.array([180, 30, 255])
            
            # 创建掩码
            mask = cv2.inRange(hsv, lower_white, upper_white)
            
            # 形态学操作
            kernel = np.ones((3, 3), np.uint8)
            mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)
            mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)
            
            # 查找轮廓
            contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            
            # 筛选轮廓
            valid_contours = []
            for contour in contours:
                area = cv2.contourArea(contour)
                if area > self.captcha_detection['min_area']:
                    x, y, w, h = cv2.boundingRect(contour)
                    
                    # 验证码通常有特定的宽高比
                    aspect_ratio = w / h
                    if 1.5 < aspect_ratio < 5.0:  # 验证码通常较宽
                        valid_contours.append((x, y, w, h, area))
            
            if not valid_contours:
                return None
            
            # 选择最大的轮廓
            valid_contours.sort(key=lambda c: c[4], reverse=True)
            x, y, w, h, area = valid_contours[0]
            
            return {
                'method': 'color',
                'x': x,
                'y': y,
                'width': w,
                'height': h,
                'area': area,
                'confidence': min(area / 10000, 1.0)  # 简单置信度计算
            }
            
        except Exception as e:
            self.logger.debug(f"颜色检测失败: {e}")
            return None
    
    def _detect_by_template(self, image: np.ndarray) -> Optional[Dict[str, Any]]:
        """通过模板匹配检测验证码区域"""
        try:
            # 加载模板（在实际版本中，模板应该从文件加载）
            # 这里使用简单的文本区域检测作为示例
            
            # 转换为灰度图
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
            
            # 边缘检测
            edges = cv2.Canny(gray, 50, 150)
            
            # 查找轮廓
            contours, _ = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            
            # 筛选文本区域
            text_regions = []
            for contour in contours:
                x, y, w, h = cv2.boundingRect(contour)
                
                # 文本区域特征
                aspect_ratio = w / h
                area = w * h
                extent = area / (image.shape[0] * image.shape[1])
                
                # 筛选条件
                if (10 < w < 300 and 10 < h < 100 and  # 合理尺寸
                    1.5 < aspect_ratio < 5.0 and        # 文本通常较宽
                    0.001 < extent < 0.1):              # 合理面积比例
                    
                    text_regions.append((x, y, w, h, area))
            
            if not text_regions:
                return None
            
            # 合并重叠区域
            merged_regions = self._merge_regions(text_regions)
            
            # 选择最佳区域
            if merged_regions:
                # 选择面积最大的区域
                merged_regions.sort(key=lambda r: r[4], reverse=True)
                x, y, w, h, area = merged_regions[0]
                
                return {
                    'method': 'template',
                    'x': x,
                    'y': y,
                    'width': w,
                    'height': h,
                    'area': area,
                    'confidence': 0.7  # 模板匹配的固定置信度
                }
            
            return None
            
        except Exception as e:
            self.logger.debug(f"模板检测失败: {e}")
            return None
    
    def _detect_by_text(self, image: np.ndarray) -> Optional[Dict[str, Any]]:
        """通过文本检测验证码区域"""
        try:
            # 在实际版本中，这里会使用OCR检测文本区域
            # 由于依赖问题，这里返回None
            
            return None
            
        except Exception as e:
            self.logger.debug(f"文本检测失败: {e}")
            return None
    
    def _merge_regions(self, regions: List[Tuple]) -> List[Tuple]:
        """合并重叠区域"""
        if not regions:
            return []
        
        # 按x坐标排序
        regions.sort(key=lambda r: r[0])
        
        merged = []
        current = list(regions[0])
        
        for region in regions[1:]:
            x1, y1, w1, h1, a1 = current
            x2, y2, w2, h2, a2 = region
            
            # 检查是否重叠
            if (x2 <= x1 + w1 and  # 水平重叠
                abs(y1 - y2) < max(h1, h2) * 0.5):  # 垂直接近
                
                # 合并区域
                new_x = min(x1, x2)
                new_y = min(y1, y2)
                new_w = max(x1 + w1, x2 + w2) - new_x
                new_h = max(y1 + h1, y2 + h2) - new_y
                new_a = new_w * new_h
                
                current = [new_x, new_y, new_w, new_h, new_a]
            else:
                merged.append(tuple(current))
                current = list(region)
        
        merged.append(tuple(current))
        return merged
    
    def _select_best_detection(self, detections: List[Tuple[str, Dict]]) -> Optional[Dict[str, Any]]:
        """选择最佳检测结果"""
        if not detections:
            return None
        
        # 按置信度排序
        detections.sort(key=lambda d: d[1].get('confidence', 0), reverse=True)
        
        # 返回置信度最高的结果
        method, best_result = detections[0]
        
        # 应用学习数据修正
        if self.auto_detection['learning_enabled'] and self.learning_data['captcha_positions']:
            corrected_result = self._apply_learning_correction(best_result)
            if corrected_result:
                best_result = corrected_result
        
        return best_result
    
    def _apply_learning_correction(self, detection: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """应用学习数据修正"""
        try:
            if not self.learning_data['captcha_positions']:
                return detection
            
            # 计算历史位置的平均值
            positions = self.learning_data['captcha_positions']
            avg_x = sum(p['x'] for p in positions) / len(positions)
            avg_y = sum(p['y'] for p in positions) / len(positions)
            avg_w = sum(p['width'] for p in positions) / len(positions)
            avg_h = sum(p['height'] for p in positions) / len(positions)
            
            # 当前检测结果
            curr_x = detection['x']
            curr_y = detection['y']
            curr_w = detection['width']
            curr_h = detection['height']
            
            # 计算差异
            diff_x = abs(curr_x - avg_x)
            diff_y = abs(curr_y - avg_y)
            diff_w = abs(curr_w - avg_w) / avg_w if avg_w > 0 else 0
            diff_h = abs(curr_h - avg_h) / avg_h if avg_h > 0 else 0
            
            # 如果差异过大，使用历史平均值
            threshold = 0.3  # 30%差异阈值
            
            if (diff_x > avg_w * threshold or diff_y > avg_h * threshold or
                diff_w > threshold or diff_h > threshold):
                
                corrected = detection.copy()
                corrected.update({
                    'x': int(avg_x),
                    'y': int(avg_y),
                    'width': int(avg_w),
                    'height': int(avg_h),
                    'corrected': True,
                    'original_confidence': detection.get('confidence', 0),
                    'confidence': detection.get('confidence', 0) * 0.9  # 修正后降低置信度
                })
                
                self.logger.debug(f"应用学习修正: {detection} -> {corrected}")
                return corrected
            
            return detection
            
        except Exception as e:
            self.logger.debug(f"学习修正失败: {e}")
            return detection
    
    def _save_learning_data(self, hwnd: int, detection: Dict[str, Any]):
        """保存学习数据"""
        try:
            # 获取窗口信息
            rect = win32gui.GetWindowRect(hwnd)
            window_size = {
                'width': rect[2] - rect[0],
                'height': rect[3] - rect[1]
            }
            
            # 保存验证码位置（相对坐标）
            captcha_pos = {
                'x': detection['x'],
                'y': detection['y'],
                'width': detection['width'],
                'height': detection['height'],
                'timestamp': time.time(),
                'method': detection.get('method', 'unknown')
            }
            
            # 添加到学习数据
            self.learning_data['captcha_positions'].append(captcha_pos)
            self.learning_data['window_sizes'].append(window_size)
            
            # 限制数据量
            max_entries = 100
            for key in self.learning_data:
                if len(self.learning_data[key]) > max_entries:
                    self.learning_data[key] = self.learning_data[key][-max_entries:]
            
            # 保存到文件
            self._save_learning_to_file()
            
        except Exception as e:
            self.logger.debug(f"保存学习数据失败: {e}")
    
    def _save_learning_to_file(self):
        """保存学习数据到文件"""
        try:
            data_dir = Path.home() / "StoneCaptcha" / "learning"
            data_dir.mkdir(parents=True, exist_ok=True)
            
            data_file = data_dir / "game_integration_learning.json"
            
            save_data = {
                'stats': self.stats,
                'learning_data': self.learning_data,
                'config': self.config,
                'last_update': time.time()
            }
            
            with open(data_file, 'w', encoding='utf-8') as f:
                json.dump(save_data, f, indent=2, ensure_ascii=False)
            
        except Exception as e:
            self.logger.debug(f"保存学习文件失败: {e}")
    
    def load_learning_from_file(self) -> bool:
        """从文件加载学习数据"""
        try:
            data_file = Path.home() / "StoneCaptcha" / "learning" / "game_integration_learning.json"
            
            if data_file.exists():
                with open(data_file, 'r', encoding='utf-8') as f:
                    loaded_data = json.load(f)
                
                if 'learning_data' in loaded_data:
                    self.learning_data = loaded_data['learning_data']
                    self.logger.info(f"加载学习数据: {len(self.learning_data['captcha_positions'])} 条记录")
                    return True
            
            return False
            
        except Exception as e:
            self.logger.debug(f"加载学习文件失败: {e}")
            return False
    
    def smart_capture_captcha(self, hwnd: Optional[int] = None, 
                             use_auto_detection: bool = True) -> Optional[Dict[str, Any]]:
        """
        智能截取验证码
        
        Args:
            hwnd: 窗口句柄
            use_auto_detection: 是否使用自动检测
            
        Returns:
            包含截图路径和区域信息的字典
        """
        if not HAS_PYAUTOGUI:
            self.logger.warning("pyautogui未安装，无法截图")
            return None
        
        if hwnd is None:
            windows = self.find_game_windows_advanced()
            if not windows:
                self.logger.error("未找到游戏窗口")
                return None
            hwnd = windows[0]['handle']
        
        try:
            # 激活窗口
            win32gui.SetForegroundWindow(hwnd)
            time.sleep(0.5)
            
            # 获取窗口位置
            rect = win32gui.GetWindowRect(hwnd)
            left, top, right, bottom = rect
            
            # 确定验证码区域
            if use_auto_detection and self.auto_detection['enabled']:
                # 自动检测区域
                detection_result = self.auto_detect_captcha_area(hwnd)
                if detection_result:
                    captcha_x = detection_result['x']
                    captcha_y = detection_result['y']
                    captcha_width = detection_result['width']
                    captcha_height = detection_result['height']
                    detection_method = detection_result.get('method', 'auto')
                else:
                    # 自动检测失败，使用配置的区域
                    self.logger.warning("自动检测失败，使用配置区域")
                    captcha_x = self.config['captcha_area']['x']
                    captcha_y = self.config['captcha_area']['y']
                    captcha_width = self.config['captcha_area']['width']
                    captcha_height = self.config['captcha_area']['height']
                    detection_method = 'config'
            else:
                # 使用配置的区域
                captcha_x = self.config['captcha_area']['x']
                captcha_y = self.config['captcha_area']['y']
                captcha_width = self.config['captcha_area']['width']
                captcha_height = self.config['captcha_area']['height']
                detection_method = 'config'
            
            # 计算绝对坐标
            abs_x = left + captcha_x
            abs_y = top + captcha_y
            
            # 截图
            screenshot = pyautogui.screenshot(
                region=(abs_x, abs_y, captcha_width, captcha_height)
            )
            
            # 保存截图
            timestamp = int(time.time())
            save_dir = Path.home() / "StoneCaptcha" / "captchas"
            save_dir.mkdir(parents=True, exist_ok=True)
            
            save_path = save_dir / f"captcha_{timestamp}.png"
            screenshot.save(save_path, quality=self.config['screenshot_quality'])
            
            self.stats['captchas_detected'] += 1
            self.logger.info(f"验证码截图已保存: {save_path} (方法: {detection_method})")
            
            return {
                'screenshot_path': str(save_path),
                'window_handle': hwnd,
                'window_rect': rect,
                'captcha_area': {
                    'x': captcha_x,
                    'y': captcha_y,
                    'width': captcha_width,
                    'height': captcha_height,
                    'absolute_x': abs_x,
                    'absolute_y': abs_y
                },
                'detection_method': detection_method,
                'timestamp': timestamp
            }
            
        except Exception as e:
            self.logger.error(f"智能截图失败: {e}")
            self.stats['errors'] += 1
            return None
    
    def smart_input_captcha(self, text: str, hwnd: Optional[int] = None,
                           captcha_info: Optional[Dict] = None) -> bool:
        """
        智能输入验证码
        
        Args:
            text: 验证码文本
            hwnd: 窗口句柄
            captcha_info: 验证码信息（来自smart_capture_captcha）
            
        Returns:
            是否成功
        """
        if not HAS_WIN32 or not HAS_PYAUTOGUI:
            self.logger.warning("必要的库未安装，无法输入验证码")
            return False
        
        if hwnd is None and captcha_info:
            hwnd = captcha_info.get('window_handle')
        
        if hwnd is None:
            windows = self.find_game_windows_advanced()
            if not windows:
                self.logger.error("未找到游戏窗口")
                return False
            hwnd = windows[0]['handle']
        
        if not text:
            self.logger.warning("验证码文本为空")
            return False
        
        try:
            # 激活窗口
            win32gui.SetForegroundWindow(hwnd)
            time.sleep(0.3)
            
            # 获取窗口位置
            rect = win32gui.GetWindowRect(hwnd)
            left, top, right, bottom = rect
            
            # 确定输入区域
            if captcha_info and 'captcha_area' in captcha_info:
                # 基于验证码位置计算输入框位置
                captcha_area = captcha_info['captcha_area']
                input_x = left + captcha_area['x'] + captcha_area['width'] + 20  # 验证码右侧20像素
                input_y = top + captcha_area['y'] + captcha_area['height'] // 2
            else:
                # 使用配置的输入区域
                input_x = left + self.config['input_area']['x'] + self.config['input_area']['width'] // 2
                input_y = top + self.config['input_area']['y'] + self.config['input_area']['height'] // 2
            
            # 点击输入框
            pyautogui.click(input_x, input_y)
            time.sleep(0.2)
            
            # 清空输入框
            pyautogui.hotkey('ctrl', 'a')
            time.sleep(0.1)
            pyautogui.press('delete')
            time.sleep(0.1)
            
            # 输入验证码
            pyautogui.typewrite(text, interval=0.05)
            time.sleep(0.2)
            
            # 按Enter确认
            pyautogui.press('enter')
            
            self.stats['captchas_processed'] += 1
            self.logger.info(f"验证码输入完成: {text}")
            return True
            
        except Exception as e:
            self.logger.error(f"输入验证码失败: {e}")
            self.stats['errors'] += 1
            return False
    
    def get_performance_stats(self) -> Dict[str, Any]:
        """获取性能统计"""
        return {
            'timestamp': time.time(),
            'stats': self.stats.copy(),
            'learning_data_summary': {
                'captcha_positions': len(self.learning_data['captcha_positions']),
                'window_sizes': len(self.learning_data['window_sizes']),
                'detection_patterns': len(self.learning_data['detection_patterns'])
            },
            'auto_detection_enabled': self.auto_detection['enabled'],
            'learning_enabled': self.auto_detection['learning_enabled']
        }
    
    def optimize_config_based_on_learning(self) -> Dict[str, Any]:
        """
        基于学习数据优化配置
        
        Returns:
            优化建议
        """
        suggestions = []
        
        if not self.learning_data['captcha_positions']:
            return {'suggestions': ['无足够学习数据']}
        
        # 分析验证码位置
        positions = self.learning_data['captcha_positions']
        
        # 计算平均位置
        avg_x = sum(p['x'] for p in positions) / len(positions)
        avg_y = sum(p['y'] for p in positions) / len(positions)
        avg_w = sum(p['width'] for p in positions) / len(positions)
        avg_h = sum(p['height'] for p in positions) / len(positions)
        
        # 计算标准差
        std_x = np.std([p['x'] for p in positions]) if len(positions) > 1 else 0
        std_y = np.std([p['y'] for p in positions]) if len(positions) > 1 else 0
        
        # 生成建议
        current_config = self.config['captcha_area']
        current_x, current_y = current_config['x'], current_config['y']
        current_w, current_h = current_config['width'], current_config['height']
        
        # 检查位置差异
        diff_x = abs(current_x - avg_x)
        diff_y = abs(current_y - avg_y)
        
        if diff_x > avg_w * 0.2 or diff_y > avg_h * 0.2:
            suggestions.append(f"建议调整验证码区域位置: ({current_x}, {current_y}) -> ({int(avg_x)}, {int(avg_y)})")
        
        # 检查尺寸差异
        diff_w = abs(current_w - avg_w) / avg_w if avg_w > 0 else 0
        diff_h = abs(current_h - avg_h) / avg_h if avg_h > 0 else 0
        
        if diff_w > 0.2 or diff_h > 0.2:
            suggestions.append(f"建议调整验证码区域尺寸: {current_w}x{current_h} -> {int(avg_w)}x{int(avg_h)}")
        
        # 检查稳定性
        if std_x > avg_w * 0.3 or std_y > avg_h * 0.3:
            suggestions.append("验证码位置不稳定，建议启用自动检测")
        
        return {
            'suggestions': suggestions,
            'current_config': current_config,
            'learned_average': {
                'x': avg_x,
                'y': avg_y,
                'width': avg_w,
                'height': avg_h
            },
            'stability': {
                'std_x': std_x,
                'std_y': std_y,
                'position_stable': std_x < avg_w * 0.2 and std_y < avg_h * 0.2
            }
        }


# 测试函数
def test_enhanced_game_integration():
    """测试增强版游戏集成模块"""
    print("🎮 测试增强版游戏集成模块")
    print("=" * 50)
    
    # 创建实例
    game = GameIntegrationEnhanced()
    
    # 加载学习数据
    if game.load_learning_from_file():
        print("✅ 学习数据加载成功")
    
    # 查找游戏窗口
    print("\n🔍 查找游戏窗口...")
    windows = game.find_game_windows_advanced()
    
    if windows:
        print(f"✅ 找到 {len(windows)} 个游戏窗口:")
        for i, window in enumerate(windows, 1):
            print(f"  {i}. {window['title']} (方法: {window['method']})")
        
        # 测试智能截图
        print("\n📸 测试智能截图...")
        if HAS_PYAUTOGUI:
            hwnd = windows[0]['handle']
            captcha_info = game.smart_capture_captcha(hwnd, use_auto_detection=True)
            
            if captcha_info:
                print(f"✅ 截图成功: {captcha_info['screenshot_path']}")
                print(f"   检测方法: {captcha_info['detection_method']}")
                print(f"   区域: {captcha_info['captcha_area']['width']}x{captcha_info['captcha_area']['height']}")
            else:
                print("❌ 截图失败")
        else:
            print("⚠️  pyautogui未安装，无法测试截图")
        
        # 测试智能输入
        print("\n⌨️  测试智能输入...")
        if HAS_PYAUTOGUI and HAS_WIN32:
            test_text = "TEST123"
            success = game.smart_input_captcha(test_text, hwnd, captcha_info)
            if success:
                print(f"✅ 输入测试成功: {test_text}")
            else:
                print("❌ 输入测试失败")
        else:
            print("⚠️  必要的库未安装，无法测试输入")
        
        # 显示性能统计
        print("\n📊 性能统计:")
        stats = game.get_performance_stats()
        print(f"   窗口找到: {stats['stats']['windows_found']}")
        print(f"   验证码检测: {stats['stats']['captchas_detected']}")
        print(f"   验证码处理: {stats['stats']['captchas_processed']}")
        print(f"   自动检测: {stats['stats']['auto_detections']}")
        print(f"   错误: {stats['stats']['errors']}")
        
        # 优化建议
        print("\n💡 优化建议:")
        suggestions = game.optimize_config_based_on_learning()
        for suggestion in suggestions['suggestions']:
            print(f"   • {suggestion}")
        
    else:
        print("❌ 未找到游戏窗口")
        print("💡 请确保石器时代游戏已启动")
    
    print("\n" + "=" * 50)
    print("增强版游戏集成模块测试完成")

if __name__ == "__main__":
    # 设置日志
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    test_enhanced_game_integration()
