#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ASSA语法检查器
确保所有脚本语法100%基于ASSA指令和内挂指令
"""

import os
import re
import sys
from pathlib import Path

class ASSA语法检查器:
    """ASSA语法检查器"""
    
    def __init__(self):
        # ASSA标准指令集（从客户端脚本分析得出）
        self.assa_指令集 = self.加载ASSA指令集()
        
        # 内挂支持指令集
        self.内挂_指令集 = self.加载内挂指令集()
        
        # 允许的语法模式
        self.允许的语法模式 = self.加载允许的语法模式()
        
        # 检查结果
        self.检查结果 = {
            '总文件数': 0,
            '通过文件数': 0,
            '失败文件数': 0,
            '总错误数': 0,
            '错误详情': []
        }
    
    def 加载ASSA指令集(self):
        """加载ASSA标准指令集"""
        return {
            # 变量操作指令
            '变量操作': ['dim', 'set', 'let', 'inc', 'dec'],
            
            # 流程控制指令
            '流程控制': ['label', 'goto', 'call', 'return', 'end'],
            
            # 条件判断指令
            '条件判断': ['if', 'check'],
            
            # 游戏交互指令
            '游戏交互': [
                'walkpos', 'waitpos', 'waitmap', 'delay',
                'say', 'waitsay', 'button', 'cls', 'print', 'log',
                'doffitem', 'getitem', 'saveitem', 'checkitem',
                'input', 'msg'
            ],
            
            # 战斗相关指令
            '战斗相关': [
                'set 自动战斗', 'set 自动补血', 'set 自动补魔',
                'check 战斗状态', 'check 人物', 'check 宠物'
            ],
            
            # 数学运算指令
            '数学运算': ['+', '-', '*', '/', '%'],
            
            # 比较运算符
            '比较运算符': ['=', '!=', '>', '<', '>=', '<=', 'like'],
            
            # 跳转目标
            '跳转目标': ['+1', '+2', '+3', '+4', '+5', '+6', '+7', '+8', '+9', '+10',
                       '-1', '-2', '-3', '-4', '-5', '-6', '-7', '-8', '-9', '-10']
        }
    
    def 加载内挂指令集(self):
        """加载内挂支持指令集"""
        return {
            # 内挂特有指令
            '内挂特有': [
                'say SQNG', 'say Assa', 'say www.shiqi.so',
                'waitsay SQNG', 'waitsay Assa'
            ],
            
            # 内挂设置指令
            '内挂设置': [
                'set 自动战斗', 'set 自动补血', 'set 自动补魔',
                'set 自动抓宠', 'set 自动登机'
            ],
            
            # 内挂检查指令
            '内挂检查': [
                'check 人物', 'check 宠物', 'check 物品',
                'check 地图', 'check 战斗状态', 'check 对话框'
            ]
        }
    
    def 加载允许的语法模式(self):
        """加载允许的语法模式"""
        return [
            # 变量声明
            r'^\s*dim\s+@[a-zA-Z0-9_\u4e00-\u9fff]+',
            r'^\s*set\s+[a-zA-Z0-9_\u4e00-\u9fff]+\s*,\s*[^,]+',
            r'^\s*let\s+@[a-zA-Z0-9_\u4e00-\u9fff]+\s*,\s*[^,]+',
            
            # 标签定义
            r'^\s*label\s+[a-zA-Z0-9_\u4e00-\u9fff]+',
            
            # 跳转指令
            r'^\s*goto\s+[a-zA-Z0-9_\u4e00-\u9fff\+\-]+',
            r'^\s*call\s+[a-zA-Z0-9_\u4e00-\u9fff]+',
            r'^\s*return',
            r'^\s*end',
            
            # 条件判断
            r'^\s*if\s+[^,]+\s*,\s*[^,]+\s*,\s*[^,]+\s*,\s*[^,]+',
            r'^\s*check\s+[^,]+\s*,\s*[^,]+\s*,\s*[^,]+\s*,\s*[^,]+\s*,\s*[^,]+',
            
            # 游戏交互
            r'^\s*walkpos\s+\d+\s*,\s*\d+',
            r'^\s*waitpos\s+\d+\s*,\s*\d+',
            r'^\s*waitmap\s+\d+\s*,\s*\d+',
            r'^\s*delay\s+\d+',
            r'^\s*say\s+.+',
            r'^\s*waitsay\s+\d+\s*,\s*.+\s*,\s*\d+',
            
            # 物品操作
            r'^\s*doffitem\s+.+',
            r'^\s*getitem\s+.+',
            r'^\s*saveitem\s+.+',
            r'^\s*checkitem\s+.+',
            
            # 输入输出
            r'^\s*input\s+@[a-zA-Z0-9_\u4e00-\u9fff]+\s*,\s*.+',
            r'^\s*print\s+.+',
            r'^\s*log\s+.+',
            r'^\s*msg\s+.+',
            
            # 注释
            r"^\s*'",
            r'^\s*//',
            
            # 空行
            r'^\s*$'
        ]
    
    def 检查脚本语法(self, 文件路径):
        """检查脚本语法合规性"""
        文件名 = os.path.basename(文件路径)
        错误列表 = []
        
        with open(文件路径, 'r', encoding='gbk', errors='ignore') as f:
            行号 = 0
            for 行 in f:
                行号 += 1
                原始行 = 行.rstrip('\r\n')
                
                # 跳过空行
                if not 原始行.strip():
                    continue
                
                # 检查语法
                语法错误 = self.检查单行语法(原始行, 行号)
                if 语法错误:
                    错误列表.append({
                        '行号': 行号,
                        '内容': 原始行,
                        '错误': 语法错误
                    })
        
        return {
            '文件名': 文件名,
            '总行数': 行号,
            '错误数': len(错误列表),
            '错误列表': 错误列表,
            '通过': len(错误列表) == 0
        }
    
    def 检查单行语法(self, 行内容, 行号):
        """检查单行语法"""
        # 去除行首尾空格
        行内容 = 行内容.strip()
        
        # 跳过注释
        if 行内容.startswith("'") or 行内容.startswith('//'):
            return None
        
        # 检查是否符合允许的语法模式
        for 模式 in self.允许的语法模式:
            if re.match(模式, 行内容, re.IGNORECASE):
                return None
        
        # 检查是否包含不允许的语法
        错误信息 = self.检查不允许的语法(行内容)
        if 错误信息:
            return 错误信息
        
        # 未知语法
        return f"未知语法: {行内容}"
    
    def 检查不允许的语法(self, 行内容):
        """检查不允许的语法"""
        # 检查不存在的指令
        不允许的指令 = [
            'function', 'endif', 'endfunction', 'while', 'endwhile',
            'for', 'endforeach', 'switch', 'case', 'default',
            'try', 'catch', 'finally', 'throw', 'class', 'struct',
            'interface', 'implements', 'extends', 'namespace',
            'using', 'import', 'package', 'module', 'export'
        ]
        
        for 指令 in 不允许的指令:
            if re.search(rf'\b{指令}\b', 行内容, re.IGNORECASE):
                return f"不允许的指令: {指令}"
        
        # 检查不存在的ASSA语法
        if 'endif' in 行内容.lower():
            return "ASSA不支持endif，应使用if 条件,=,值,跳转标签格式"
        
        if 'function' in 行内容.lower():
            return "ASSA不支持function，应使用label定义函数"
        
        if 'return' in 行内容 and 'return' != 行内容.strip():
            return "ASSA的return不能返回值，应单独使用return"
        
        # 检查复杂的表达式（ASSA不支持）
        if re.search(r'\(.*\)', 行内容) and not 行内容.startswith('say'):
            return "ASSA不支持括号表达式"
        
        if re.search(r'\[.*\]', 行内容):
            return "ASSA不支持方括号语法"
        
        if re.search(r'\{.*\}', 行内容):
            return "ASSA不支持花括号语法"
        
        return None
    
    def 批量检查(self, 目录路径):
        """批量检查脚本"""
        print(f"🔍 开始检查目录: {目录路径}")
        print("=" * 60)
        
        # 获取所有ASSA脚本
        脚本文件列表 = []
        for 根目录, 目录列表, 文件列表 in os.walk(目录路径):
            for 文件名 in 文件列表:
                if 文件名.lower().endswith('.asc'):
                    脚本文件列表.append(os.path.join(根目录, 文件名))
        
        # 检查每个脚本
        for 脚本文件 in 脚本文件列表:
            print(f"📄 检查: {os.path.basename(脚本文件)}")
            检查结果 = self.检查脚本语法(脚本文件)
            
            self.检查结果['总文件数'] += 1
            
            if 检查结果['通过']:
                print(f"  ✅ 通过 ({检查结果['总行数']}行)")
                self.检查结果['通过文件数'] += 1
            else:
                print(f"  ❌ 失败 - {检查结果['错误数']}个错误")
                self.检查结果['失败文件数'] += 1
                self.检查结果['总错误数'] += 检查结果['错误数']
                
                # 记录错误详情
                for 错误 in 检查结果['错误列表']:
                    self.检查结果['错误详情'].append({
                        '文件': os.path.basename(脚本文件),
                        '行号': 错误['行号'],
                        '内容': 错误['内容'],
                        '错误': 错误['错误']
                    })
        
        # 生成报告
        self.生成检查报告()
    
    def 生成检查报告(self):
        """生成检查报告"""
        print("\n" + "=" * 60)
        print("📊 语法检查报告")
        print("=" * 60)
        
        print(f"总文件数: {self.检查结果['总文件数']}")
        print(f"通过文件: {self.检查结果['通过文件数']}")
        print(f"失败文件: {self.检查结果['失败文件数']}")
        print(f"总错误数: {self.检查结果['总错误数']}")
        
        if self.检查结果['总错误数'] > 0:
            print("\n🔴 错误详情:")
            for 错误 in self.检查结果['错误详情'][:10]:  # 显示前10个错误
                print(f"  📄 {错误['文件']}:{错误['行号']}")
                print(f"    内容: {错误['内容']}")
                print(f"    错误: {错误['错误']}")
                print()
            
            if len(self.检查结果['错误详情']) > 10:
                print(f"  ... 还有{len(self.检查结果['错误详情']) - 10}个错误未显示")
        
        print("=" * 60)
        
        # 保存详细报告
        self.保存详细报告()
    
    def 保存详细报告(self):
        """保存详细报告"""
        报告路径 = "/root/.openclaw/workspace/ASSA语法检查报告.md"
        
        报告内容 = [
            "# 📋 ASSA语法检查报告",
            "",
            f"## 📅 检查时间: 2026-03-19 21:55",
            "",
            "## 📊 检查统计",
            "",
            f"- **总文件数**: {self.检查结果['总文件数']}",
            f"- **通过文件**: {self.检查结果['通过文件数']}",
            f"- **失败文件**: {self.检查结果['失败文件数']}",
            f"- **总错误数**: {self.检查结果['总错误数']}",
            f"- **通过率**: {self.检查结果['通过文件数']/self.检查结果['总文件数']*100:.1f}%",
            ""
        ]
        
        if self.检查结果['总错误数'] > 0:
            报告内容.append("## 🔴 语法错误详情")
            报告内容.append("")
            
            for 错误 in self.检查结果['错误详情']:
                报告内容.append(f"### 📄 {错误['文件']} (第{错误['行号']}行)")
                报告内容.append("")
                报告内容.append(f"**错误内容**:")
                报告内容.append(f"```asca")
                报告内容.append(f"{错误['内容']}")
                报告内容.append(f"```")
                报告内容.append("")
                报告内容.append(f"**错误原因**: {错误['错误']}")
                报告内容.append("")
                报告内容.append("---")
                报告内容.append("")
        
        报告内容.append("## ✅ 允许的ASSA语法")
        报告内容.append("")
        报告内容.append("### 1. 变量操作指令")
        报告内容.append("- `dim @变量名` - 声明变量")
        报告内容.append("- `set 变量名,值` - 设置变量")
        报告内容.append("- `let @变量名,=,值` - 赋值操作")
        报告内容.append("")
        
        报告内容.append("### 2. 流程控制指令")
        报告内容.append("- `label 标签名` - 定义标签")
        报告内容.append("- `goto 标签名` - 跳转到标签")
        报告内容.append("- `call 函数名` - 调用函数")
        报告内容.append("- `return` - 返回")
        报告内容.append("- `end` - 结束脚本")
        报告内容.append("")
        
        报告内容.append("### 3. 条件判断指令")
        报告内容.append("- `if 条件,=,值,跳转标签` - 条件判断")
        报告内容.append("- `check 对象,属性,操作符,值,跳转标签` - 检查条件")
        报告内容.append("")
        
        报告内容.append("### 4. 游戏交互指令")
        报告内容.append("- `walkpos X,Y` - 移动到坐标")
        报告内容.append("- `waitpos X,Y` - 等待到达坐标")
        报告内容.append("- `delay 毫秒数` - 延迟等待")
        报告内容.append("- `say 文本` - 说话")
        报告内容.append("- `waitsay 行数,文本,超时` - 等待特定说话")
        报告内容.append("")
        
        报告内容.append("### 5. 物品操作指令")
        报告内容.append("- `doffitem 物品名,数量` - 丢弃物品")
        报告内容.append("- `getitem 物品名,数量` - 获取物品")
        报告内容.append("- `checkitem 物品名,数量` - 检查物品")
        报告内容.append("")
        
        报告内容.append("## ❌ 不允许的语法")
        报告内容.append("")
        报告内容.append("### 1. 不存在的指令")
        报告内容.append("- `function` - ASSA没有function关键字")
        报告内容.append("- `endif` - ASSA没有endif")
        报告内容.append("- `return 值` - ASSA函数不能返回值")
        报告内容.append("")
        
        报告内容.append("### 2. 不支持的语法结构")
        报告内容.append("- 括号表达式 `(表达式)`")
        报告内容.append("- 方括号语法 `[索引]`")
        报告内容.append("- 花括号语法 `{代码块}`")
        报告内容.append("- 嵌套if语句（应使用label/goto）")
        报告内容.append("")
        
        报告内容.append("### 3. 其他编程语言特性")
        报告内容.append("- 循环结构 `while/for`")
        报告内容.append("- 异常处理 `try/catch`")
        报告内容.append("- 面向对象语法 `class/struct`")
        报告内容.append("- 模块化语法 `import/export`")
        报告内容.append("")
        
        报告内容.append("---")
        报告内容.append("*报告生成时间: 2026-03-19 21:55*")
        
        # 保存报告
        with open(报告路径, 'w', encoding='utf-8') as f:
            f.write('\n'.join(报告内容))
        
        print(f"📄 详细报告已保存: {报告路径}")
        return 报告路径

def main():
    """主函数"""
    print("🔍 ASSA语法检查器启动")
    print("=" * 60)
    
    # 创建检查器实例
    检查器 = ASSA语法检查器()
    
    # 检查纯ASSA优化版本
    纯ASSA优化目录 = "/root/.openclaw/workspace/石器时代知识库/优化框架/纯ASSA优化版本/三楼"
    
    if os.path.exists(纯ASSA优化目录):
        print(f"📁 检查目录: {纯ASSA优化目录}")
        检查器.批量检查(纯ASSA优化目录)
    else:
        print(f"❌ 目录不存在: {纯ASSA优化目录}")
        
        # 检查原始脚本
        原始脚本目录 = "/root/.openclaw/qqbot/downloads/三楼"
        if os.path.exists(原始脚本目录):
            print(f"📁 检查原始脚本目录: {原始脚本目录}")
            检查器.批量检查(原始脚本目录)
        else:
            print("❌ 没有找到可检查的脚本目录")

if __name__ == "__main__":
    main()