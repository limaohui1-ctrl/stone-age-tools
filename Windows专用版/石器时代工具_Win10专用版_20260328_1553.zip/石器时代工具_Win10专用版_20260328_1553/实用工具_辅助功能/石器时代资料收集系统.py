#!/usr/bin/env python3
"""
石器时代资料收集系统
用于全网搜索石器时代端游的资料，包含：
1. 地图编号
2. NPC名字  
3. 宠物名字
4. 角色走路坐标
5. 网上所有脚本
"""

import os
import json
import time
import requests
from urllib.parse import quote
import subprocess
import re

class StoneAgeDataCollector:
    def __init__(self):
        self.workspace_dir = "/root/.openclaw/workspace"
        self.data_dir = os.path.join(self.workspace_dir, "石器时代资料库")
        self.ensure_directories()
        
        # 已知的石器时代资料网站
        self.known_sites = [
            "bbs.sqng.cc",  # 石器时代论坛
            "www.shiqi.so",  # 石器时代资料站
            "tieba.baidu.com/f?kw=石器时代",  # 百度贴吧
            "www.17173.com/zq/shiqi/",  # 17173石器时代专区
            "games.sina.com.cn/z/cross/",  # 新浪游戏石器时代
        ]
        
        # 搜索关键词
        self.search_keywords = {
            "maps": ["石器时代 地图编号", "石器时代 地图大全", "石器时代 地图ID"],
            "npcs": ["石器时代 NPC", "石器时代 人物名称", "石器时代 NPC列表"],
            "pets": ["石器时代 宠物", "石器时代 宠物图鉴", "石器时代 宠物名称"],
            "coordinates": ["石器时代 坐标", "石器时代 路径", "石器时代 走路坐标"],
            "scripts": ["石器时代 脚本", "石器时代 ASSA", "石器时代 自动化脚本", "石器时代 私服脚本"]
        }
        
    def ensure_directories(self):
        """确保目录结构存在"""
        directories = [
            self.data_dir,
            os.path.join(self.data_dir, "地图资料"),
            os.path.join(self.data_dir, "NPC资料"),
            os.path.join(self.data_dir, "宠物资料"),
            os.path.join(self.data_dir, "坐标路径"),
            os.path.join(self.data_dir, "脚本收集"),
            os.path.join(self.data_dir, "原始数据"),
        ]
        
        for directory in directories:
            os.makedirs(directory, exist_ok=True)
            print(f"✅ 目录已创建: {directory}")
    
    def fetch_webpage(self, url, method="jina"):
        """使用web-content-fetcher获取网页内容"""
        try:
            # 构建fetch命令
            fetch_script = os.path.join(self.workspace_dir, "skills/web-content-fetcher/fetch.sh")
            
            if os.path.exists(fetch_script):
                cmd = [fetch_script, url, method]
                result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
                return result.stdout
            else:
                # 如果没有fetch脚本，直接使用requests
                services = {
                    "jina": "https://r.jina.ai/",
                    "markdown": "https://markdown.new/",
                    "defuddle": "https://defuddle.md/"
                }
                
                if method in services:
                    fetch_url = services[method] + url
                    response = requests.get(fetch_url, timeout=30)
                    return response.text
                else:
                    response = requests.get(url, timeout=30)
                    return response.text
                    
        except Exception as e:
            print(f"❌ 获取网页失败 {url}: {e}")
            return None
    
    def search_with_alternative(self, query):
        """使用替代方法搜索"""
        print(f"🔍 搜索: {query}")
        
        # 尝试直接访问已知网站
        results = []
        
        for site in self.known_sites:
            try:
                # 构建搜索URL
                if "bbs.sqng.cc" in site:
                    search_url = f"http://{site}/search.php?mod=forum&searchid=1&orderby=lastpost&ascdesc=desc&searchsubmit=yes&kw={quote(query)}"
                elif "tieba.baidu.com" in site:
                    search_url = f"https://{site}&q={quote(query)}"
                else:
                    search_url = f"https://{site}/search?q={quote(query)}"
                
                print(f"  尝试访问: {search_url}")
                content = self.fetch_webpage(search_url, "jina")
                
                if content and len(content) > 100:
                    results.append({
                        "site": site,
                        "url": search_url,
                        "content_preview": content[:500] + "..." if len(content) > 500 else content
                    })
                    print(f"  ✅ 成功获取内容 ({len(content)} 字符)")
                    
                    # 保存原始数据
                    filename = f"{site.replace('/', '_')}_{int(time.time())}.txt"
                    filepath = os.path.join(self.data_dir, "原始数据", filename)
                    with open(filepath, "w", encoding="utf-8") as f:
                        f.write(f"搜索关键词: {query}\n")
                        f.write(f"来源URL: {search_url}\n")
                        f.write(f"获取时间: {time.strftime('%Y-%m-%d %H:%M:%S')}\n")
                        f.write("="*50 + "\n")
                        f.write(content)
                        
            except Exception as e:
                print(f"  ❌ 访问失败: {e}")
                continue
        
        return results
    
    def extract_stone_age_data(self, content, data_type):
        """从内容中提取石器时代数据"""
        extracted = []
        
        # 根据数据类型使用不同的正则表达式
        patterns = {
            "maps": [
                r'地图[：:]\s*(\d+)[\s\-]*([^\s\n]+)',  # 地图: 1001-法兰城
                r'(\d+)[\s\-]+([^\s\d][^\n]{2,20})',  # 1001 法兰城
                r'([A-Za-z]+?\d+)[\s\-]+([^\n]{2,30})'  # MAP1001 法兰城
            ],
            "npcs": [
                r'NPC[：:]\s*([^\s\n][^\n]{2,20})',  # NPC: 村长
                r'([^\s\d][^\n]{2,20})[\(（][Nn][Pp][Cc][\)）]',  # 村长(NPC)
                r'人物[：:]\s*([^\s\n][^\n]{2,20})'  # 人物: 村长
            ],
            "pets": [
                r'宠物[：:]\s*([^\s\n][^\n]{2,20})',  # 宠物: 雷龙
                r'([^\s\d][^\n]{2,20})[\(（]宠物[\)）]',  # 雷龙(宠物)
                r'宠[：:]\s*([^\s\n][^\n]{2,20})'  # 宠: 雷龙
            ],
            "coordinates": [
                r'坐标[：:]\s*(\d+)[,\s]+(\d+)',  # 坐标: 100,200
                r'\((\d+)[,\s]+(\d+)\)',  # (100,200)
                r'(\d+)[,\s]+(\d+)[^\d]'  # 100,200的
            ],
            "scripts": [
                r'脚本[：:]\s*([^\n]{5,100})',  # 脚本: 自动练级脚本
                r'\.asc\s+([^\n]{10,200})',  # .asc 文件内容
                r'ASSA[：:]\s*([^\n]{10,200})'  # ASSA: 脚本内容
            ]
        }
        
        if data_type in patterns:
            for pattern in patterns[data_type]:
                matches = re.findall(pattern, content, re.IGNORECASE)
                for match in matches:
                    if isinstance(match, tuple):
                        extracted.append(" ".join(match).strip())
                    else:
                        extracted.append(match.strip())
        
        return list(set(extracted))  # 去重
    
    def collect_all_data(self):
        """收集所有类型的数据"""
        print("="*60)
        print("🎮 开始收集石器时代端游资料")
        print("="*60)
        
        all_results = {}
        
        for data_type, queries in self.search_keywords.items():
            print(f"\n📂 收集 {data_type} 数据...")
            type_results = []
            
            for query in queries:
                print(f"\n  🔎 搜索关键词: {query}")
                search_results = self.search_with_alternative(query)
                
                for result in search_results:
                    content = result.get("content_preview", "")
                    if content:
                        extracted = self.extract_stone_age_data(content, data_type)
                        if extracted:
                            type_results.extend(extracted)
                            print(f"    ✅ 提取到 {len(extracted)} 条数据")
            
            # 去重并保存
            if type_results:
                unique_results = list(set(type_results))
                all_results[data_type] = unique_results
                
                # 保存到文件
                filename = f"{data_type}_收集结果_{time.strftime('%Y%m%d_%H%M%S')}.txt"
                filepath = os.path.join(self.data_dir, self.get_subdir(data_type), filename)
                
                with open(filepath, "w", encoding="utf-8") as f:
                    f.write(f"石器时代 {data_type} 数据收集结果\n")
                    f.write(f"收集时间: {time.strftime('%Y-%m-%d %H:%M:%S')}\n")
                    f.write(f"数据条数: {len(unique_results)}\n")
                    f.write("="*50 + "\n\n")
                    
                    for i, item in enumerate(unique_results, 1):
                        f.write(f"{i}. {item}\n")
                
                print(f"  💾 已保存 {len(unique_results)} 条数据到: {filepath}")
            else:
                print(f"  ⚠️  未找到 {data_type} 数据")
        
        # 生成汇总报告
        self.generate_summary_report(all_results)
        
        return all_results
    
    def get_subdir(self, data_type):
        """获取数据类型的子目录"""
        mapping = {
            "maps": "地图资料",
            "npcs": "NPC资料", 
            "pets": "宠物资料",
            "coordinates": "坐标路径",
            "scripts": "脚本收集"
        }
        return mapping.get(data_type, "其他资料")
    
    def generate_summary_report(self, all_results):
        """生成汇总报告"""
        print("\n" + "="*60)
        print("📊 生成汇总报告")
        print("="*60)
        
        report_file = os.path.join(self.data_dir, f"石器时代资料汇总_{time.strftime('%Y%m%d_%H%M%S')}.md")
        
        with open(report_file, "w", encoding="utf-8") as f:
            f.write("# 石器时代端游资料收集汇总报告\n\n")
            f.write(f"**生成时间**: {time.strftime('%Y-%m-%d %H:%M:%S')}\n\n")
            
            total_items = 0
            for data_type, items in all_results.items():
                total_items += len(items)
            
            f.write(f"**总数据量**: {total_items} 条\n\n")
            f.write("## 数据分类统计\n\n")
            
            for data_type, items in all_results.items():
                chinese_name = {
                    "maps": "地图资料",
                    "npcs": "NPC资料",
                    "pets": "宠物资料", 
                    "coordinates": "坐标路径",
                    "scripts": "脚本收集"
                }.get(data_type, data_type)
                
                f.write(f"### {chinese_name}\n")
                f.write(f"- **数量**: {len(items)} 条\n")
                
                if items:
                    f.write("- **示例**:\n")
                    for i, item in enumerate(items[:10], 1):  # 只显示前10条
                        f.write(f"  {i}. {item}\n")
                    
                    if len(items) > 10:
                        f.write(f"  ... 还有 {len(items)-10} 条数据\n")
                
                f.write("\n")
            
            f.write("## 已知资料网站\n\n")
            for site in self.known_sites:
                f.write(f"- {site}\n")
            
            f.write("\n## 后续建议\n\n")
            f.write("1. **持续监控**: 定期检查已知网站更新\n")
            f.write("2. **社区参与**: 参与石器时代论坛和贴吧讨论\n")
            f.write("3. **脚本分析**: 对收集到的脚本进行深入分析\n")
            f.write("4. **数据验证**: 验证收集到的数据的准确性\n")
            f.write("5. **知识库建设**: 将数据整理成结构化知识库\n")
        
        print(f"📄 汇总报告已生成: {report_file}")
        
        # 显示统计信息
        print("\n📈 数据收集统计:")
        for data_type, items in all_results.items():
            chinese_name = {
                "maps": "地图资料",
                "npcs": "NPC资料",
                "pets": "宠物资料",
                "coordinates": "坐标路径", 
                "scripts": "脚本收集"
            }.get(data_type, data_type)
            print(f"  {chinese_name}: {len(items)} 条")
        
        print(f"\n✅ 所有数据已保存到: {self.data_dir}")
    
    def create_structured_database(self):
        """创建结构化数据库"""
        print("\n" + "="*60)
        print("🗃️ 创建结构化数据库")
        print("="*60)
        
        # 创建JSON数据库
        database = {
            "metadata": {
                "name": "石器时代端游资料数据库",
                "version": "1.0.0",
                "created_at": time.strftime("%Y-%m-%d %H:%M:%S"),
                "description": "全网收集的石器时代游戏资料"
            },
            "data_sources": self.known_sites,
            "categories": {}
        }
        
        # 读取所有收集的数据
        for data_type in self.search_keywords.keys():
            subdir = self.get_subdir(data_type)
            data_dir = os.path.join(self.data_dir, subdir)
            
            if os.path.exists(data_dir):
                data_files = [f for f in os.listdir(data_dir) if f.endswith('.txt')]
                latest_file = None
                latest_time = 0
                
                for file in data_files:
                    filepath = os.path.join(data_dir, file)
                    mtime = os.path.getmtime(filepath)
                    if mtime > latest_time:
                        latest_time = mtime
                        latest_file = filepath
                
                if latest_file:
                    with open(latest_file, "r", encoding="utf-8") as f:
                        content = f.read()
                        # 提取数据行
                        lines = content.split('\n')
                        data_items = []
                        for line in lines:
                            if re.match(r'^\d+\.\s+.+', line):
                                item = line.split('. ', 1)[1] if '. ' in line else line
                                data_items.append(item.strip())
                        
                        if data_items:
                            chinese_name = {
                                "maps": "地图资料",
                                "npcs": "NPC资料",
                                "pets": "宠物资料",
                                "coordinates": "坐标路径",
                                "scripts": "脚本收集"
                            }.get(data_type, data_type)
                            
                            database["categories"][chinese_name] = {
                                "count": len(data_items),
                                "items": data_items,
                                "source_file": os.path.basename(latest_file)
                            }
        
        # 保存JSON数据库
        db_file = os.path.join(self.data_dir, "石器时代资料数据库.json")
        with open(db_file, "w", encoding="utf-8") as f:
            json.dump(database, f, ensure_ascii=False, indent=2)
        
        print(f"✅ 结构化数据库已创建: {db_file}")
        print(f"📊 包含 {len(database['categories'])} 个分类的数据")
        
        return database

def main():
    """主函数"""
    print("🚀 石器时代资料收集系统启动")
    print("="*60)
    
    collector = StoneAgeDataCollector()
    
    # 收集所有数据
    all_data = collector.collect_all_data()
    
    # 创建结构化数据库
    database = collector.create_structured_database()
    
    print("\n" + "="*60)
    print("🎉 资料收集完成!")
    print("="*60)
    print(f"📁 所有资料保存在: {collector.data_dir}")
    print(f"📊 数据库文件: {collector.data_dir}/石器时代资料数据库.json")
    print("\n下一步建议:")
    print("1. 查看收集到的资料文件")
    print("2. 验证数据的准确性")
    print("3. 将数据用于脚本开发")
    print("4. 定期更新资料库")

if __name__ == "__main__":
    main()