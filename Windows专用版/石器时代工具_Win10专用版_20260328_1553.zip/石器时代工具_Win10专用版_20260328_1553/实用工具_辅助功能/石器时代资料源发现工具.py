#!/usr/bin/env python3
"""
石器时代资料源发现工具
寻找当前可访问的石器时代资料网站，测试不同抓取服务
"""

import os
import sys
import json
import time
from datetime import datetime
import subprocess
import requests
from urllib.parse import urlparse

class StoneAgeDataSourceFinder:
    def __init__(self):
        self.workspace_root = "/root/.openclaw/workspace"
        self.results_dir = os.path.join(self.workspace_root, "石器时代资料源发现结果")
        os.makedirs(self.results_dir, exist_ok=True)
        
        # 潜在的资料源列表（基于常见游戏社区和论坛）
        self.potential_sources = [
            # 百度贴吧（石器时代相关）
            {"name": "百度贴吧-石器时代吧", "url": "https://tieba.baidu.com/f?kw=石器时代", "type": "forum"},
            {"name": "百度贴吧-石器时代私服吧", "url": "https://tieba.baidu.com/f?kw=石器时代私服", "type": "forum"},
            {"name": "百度贴吧-NG25吧", "url": "https://tieba.baidu.com/f?kw=NG25", "type": "forum"},
            
            # 游戏攻略网站
            {"name": "游民星空-石器时代", "url": "https://www.gamersky.com/z/stoneage/", "type": "guide"},
            {"name": "3DM-石器时代", "url": "https://www.3dmgame.com/games/stoneage/", "type": "guide"},
            {"name": "游侠网-石器时代", "url": "https://www.ali213.net/zt/stoneage/", "type": "guide"},
            
            # 脚本分享平台
            {"name": "GitHub-石器时代脚本", "url": "https://github.com/search?q=石器时代+脚本", "type": "code"},
            {"name": "GitHub-ASSA脚本", "url": "https://github.com/search?q=ASSA+脚本", "type": "code"},
            {"name": "GitHub-NG25脚本", "url": "https://github.com/search?q=NG25+脚本", "type": "code"},
            
            # 私服资讯网站
            {"name": "石器时代私服发布站", "url": "https://www.shiqisf.com/", "type": "private_server"},
            {"name": "石器时代私服大全", "url": "https://www.shiqi.so/", "type": "private_server"},
            {"name": "石器时代私服论坛", "url": "https://bbs.shiqi.so/", "type": "forum"},
            
            # 游戏资料网站
            {"name": "石器时代资料站", "url": "https://www.shiqi123.com/", "type": "database"},
            {"name": "石器时代地图大全", "url": "https://www.shiqimap.com/", "type": "database"},
            {"name": "石器时代宠物图鉴", "url": "https://www.shiqipet.com/", "type": "database"},
            
            # 社区和论坛
            {"name": "石器时代玩家社区", "url": "https://bbs.17173.com/forum-100-1.html", "type": "forum"},
            {"name": "多玩石器时代论坛", "url": "https://bbs.duowan.com/forum-827-1.html", "type": "forum"},
            {"name": "贴吧石器时代综合", "url": "https://tieba.baidu.com/f?ie=utf-8&kw=石器时代&fr=search", "type": "forum"},
        ]
        
        # 抓取服务列表
        self.crawler_services = [
            {"name": "r.jina.ai", "url": "https://r.jina.ai/", "method": "direct"},
            {"name": "markdown.new", "url": "https://markdown.new/", "method": "api"},
            {"name": "defuddle.md", "url": "https://defuddle.md/", "method": "api"},
        ]
    
    def test_url_accessibility(self, url, timeout=10):
        """测试URL可访问性"""
        try:
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            }
            response = requests.get(url, headers=headers, timeout=timeout, allow_redirects=True)
            
            return {
                "accessible": True,
                "status_code": response.status_code,
                "content_type": response.headers.get('Content-Type', ''),
                "content_length": len(response.content),
                "final_url": response.url,
                "redirected": response.history != [],
                "title": self._extract_title(response.text) if response.text else ""
            }
        except requests.exceptions.Timeout:
            return {"accessible": False, "error": "请求超时"}
        except requests.exceptions.ConnectionError:
            return {"accessible": False, "error": "连接错误"}
        except requests.exceptions.RequestException as e:
            return {"accessible": False, "error": str(e)}
        except Exception as e:
            return {"accessible": False, "error": f"未知错误: {e}"}
    
    def _extract_title(self, html):
        """从HTML中提取标题"""
        import re
        title_match = re.search(r'<title[^>]*>(.*?)</title>', html, re.IGNORECASE | re.DOTALL)
        if title_match:
            title = title_match.group(1).strip()
            # 清理标题
            title = re.sub(r'\s+', ' ', title)
            return title[:100]  # 限制长度
        return ""
    
    def test_crawler_service(self, service, test_url):
        """测试抓取服务"""
        try:
            if service["method"] == "direct":
                # 直接访问服务
                crawler_url = f"{service['url']}{test_url}"
                response = requests.get(crawler_url, timeout=15)
                
                return {
                    "service": service["name"],
                    "success": response.status_code == 200,
                    "status_code": response.status_code,
                    "content_type": response.headers.get('Content-Type', ''),
                    "content_length": len(response.content),
                    "has_markdown": "text/markdown" in response.headers.get('Content-Type', '') or 
                                   "# " in response.text[:500] or "## " in response.text[:500]
                }
            else:
                # API方式（简化测试）
                return {
                    "service": service["name"],
                    "success": False,
                    "error": "API方式需要具体实现",
                    "note": "需要查看具体API文档"
                }
        except Exception as e:
            return {
                "service": service["name"],
                "success": False,
                "error": str(e)
            }
    
    def find_working_sources(self):
        """寻找可工作的资料源"""
        print("=" * 70)
        print("🔍 石器时代资料源发现工具")
        print("=" * 70)
        
        results = {
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "total_sources": len(self.potential_sources),
            "working_sources": [],
            "failed_sources": [],
            "by_type": {},
            "crawler_tests": {}
        }
        
        print(f"\n📊 开始测试 {len(self.potential_sources)} 个潜在资料源...")
        
        for i, source in enumerate(self.potential_sources, 1):
            print(f"\n[{i}/{len(self.potential_sources)}] 测试: {source['name']}")
            print(f"   URL: {source['url']}")
            
            # 测试可访问性
            access_result = self.test_url_accessibility(source['url'])
            
            if access_result["accessible"]:
                print(f"   ✅ 可访问 (状态码: {access_result['status_code']})")
                if access_result.get('title'):
                    print(f"   标题: {access_result['title']}")
                
                # 添加到工作源列表
                working_source = source.copy()
                working_source.update({
                    "access_test": access_result,
                    "tested_at": datetime.now().strftime("%H:%M:%S")
                })
                results["working_sources"].append(working_source)
                
                # 按类型分类
                source_type = source["type"]
                if source_type not in results["by_type"]:
                    results["by_type"][source_type] = []
                results["by_type"][source_type].append(working_source)
                
            else:
                print(f"   ❌ 不可访问: {access_result.get('error', '未知错误')}")
                
                failed_source = source.copy()
                failed_source.update({
                    "access_test": access_result,
                    "tested_at": datetime.now().strftime("%H:%M:%S")
                })
                results["failed_sources"].append(failed_source)
            
            # 短暂暂停，避免请求过快
            time.sleep(1)
        
        # 统计结果
        results["working_count"] = len(results["working_sources"])
        results["failed_count"] = len(results["failed_sources"])
        
        print(f"\n{'='*70}")
        print("📊 测试结果统计")
        print(f"{'='*70}")
        print(f"✅ 可访问的资料源: {results['working_count']}/{results['total_sources']}")
        print(f"❌ 不可访问的资料源: {results['failed_count']}/{results['total_sources']}")
        
        # 显示按类型分类的结果
        if results["by_type"]:
            print(f"\n📁 按类型分类:")
            for source_type, sources in results["by_type"].items():
                print(f"   {source_type}: {len(sources)} 个")
        
        return results
    
    def test_crawler_services_on_best_source(self, best_source_url):
        """在最佳资料源上测试抓取服务"""
        print(f"\n{'='*70}")
        print("🛠️ 测试抓取服务")
        print(f"{'='*70}")
        
        crawler_results = []
        
        print(f"测试目标: {best_source_url}")
        print(f"抓取服务数量: {len(self.crawler_services)}")
        
        for service in self.crawler_services:
            print(f"\n测试服务: {service['name']} ({service['method']})")
            
            test_result = self.test_crawler_service(service, best_source_url)
            crawler_results.append(test_result)
            
            if test_result.get("success"):
                print(f"   ✅ 成功")
                if test_result.get("has_markdown"):
                    print(f"   包含Markdown内容")
                print(f"   内容长度: {test_result.get('content_length', 0)} 字节")
            else:
                print(f"   ❌ 失败: {test_result.get('error', '未知错误')}")
        
        return crawler_results
    
    def generate_recommendations(self, results):
        """生成推荐和建议"""
        recommendations = {
            "best_sources": [],
            "crawler_strategy": {},
            "next_steps": []
        }
        
        # 推荐最佳资料源（基于类型和可访问性）
        source_priority = ["database", "guide", "forum", "private_server", "code"]
        
        for source_type in source_priority:
            if source_type in results["by_type"]:
                for source in results["by_type"][source_type][:2]:  # 每个类型取前2个
                    recommendations["best_sources"].append({
                        "name": source["name"],
                        "url": source["url"],
                        "type": source["type"],
                        "status_code": source["access_test"]["status_code"],
                        "title": source["access_test"].get("title", "")
                    })
        
        # 抓取策略建议
        recommendations["crawler_strategy"] = {
            "primary": "r.jina.ai (最稳定)",
            "secondary": "markdown.new (Cloudflare专用)",
            "fallback": "defuddle.md (备用方案)",
            "note": "根据网站反爬策略选择合适服务"
        }
        
        # 下一步建议
        recommendations["next_steps"] = [
            "使用web-content-fetcher技能测试推荐资料源",
            "开始收集地图、NPC、宠物等游戏资料",
            "建立石器时代知识库数据结构",
            "开发资料查询和搜索工具"
        ]
        
        return recommendations
    
    def save_results(self, results, recommendations):
        """保存结果到文件"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M")
        
        # 保存详细结果
        detailed_file = os.path.join(self.results_dir, f"资料源发现结果_{timestamp}.json")
        with open(detailed_file, 'w', encoding='utf-8') as f:
            json.dump({
                "results": results,
                "recommendations": recommendations
            }, f, ensure_ascii=False, indent=2)
        
        # 保存摘要报告
        summary_file = os.path.join(self.results_dir, f"资料源发现摘要_{timestamp}.md")
        summary = self._generate_summary_report(results, recommendations)
        with open(summary_file, 'w', encoding='utf-8') as f:
            f.write(summary)
        
        print(f"\n💾 结果已保存:")
        print(f"   详细结果: {detailed_file}")
        print(f"   摘要报告: {summary_file}")
        
        return detailed_file, summary_file
    
    def _generate_summary_report(self, results, recommendations):
        """生成摘要报告"""
        report = f"""# 石器时代资料源发现报告

**生成时间**: {results['timestamp']}  
**测试数量**: {results['total_sources']} 个潜在资料源  
**可访问数量**: {results['working_count']} 个 ({results['working_count']/results['total_sources']*100:.1f}%)

## 📊 测试结果概览

### 可访问资料源 ({results['working_count']}个)
"""
        
        for source_type, sources in results["by_type"].items():
            report += f"\n#### {source_type.upper()} 类型 ({len(sources)}个)\n"
            for source in sources[:3]:  # 每个类型显示前3个
                title = source["access_test"].get("title", "无标题")
                report += f"- **{source['name']}**\n"
                report += f"  - URL: {source['url']}\n"
                report += f"  - 状态码: {source['access_test']['status_code']}\n"
                report += f"  - 标题: {title[:50]}{'...' if len(title) > 50 else ''}\n"
        
        report += f"\n### 不可访问资料源 ({results['failed_count']}个)\n"
        if results['failed_count'] > 0:
            for source in results["failed_sources"][:5]:  # 显示前5个失败源
                report += f"- {source['name']}: {source['access_test'].get('error', '未知错误')}\n"
        
        report += "\n## 🎯 推荐资料源\n\n"
        for i, source in enumerate(recommendations["best_sources"], 1):
            report += f"{i}. **{source['name']}** ({source['type']})\n"
            report += f"   - URL: {source['url']}\n"
            report += f"   - 状态: ✅ 可访问 (状态码: {source['status_code']})\n"
            if source['title']:
                report += f"   - 标题: {source['title'][:80]}{'...' if len(source['title']) > 80 else ''}\n"
        
        report += "\n## 🛠️ 抓取策略建议\n\n"
        for key, value in recommendations["crawler_strategy"].items():
            report += f"- **{key}**: {value}\n"
        
        report += "\n## 🚀 下一步建议\n\n"
        for i, step in enumerate(recommendations["next_steps"], 1):
            report += f"{i}. {step}\n"
        
        report += "\n## 💡 使用指南\n\n"
        report += "1. **测试抓取服务**: 使用web-content-fetcher技能测试推荐资料源\n"
        report += "2. **开始资料收集**: 优先收集地图、NPC、宠物等核心游戏资料\n"
        report += "3. **建立知识库**: 将收集的资料整理到知识库系统中\n"
        report += "4. **开发查询工具**: 创建资料查询和搜索工具方便使用\n"
        
        report += f"\n---\n*报告生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}*\n"
        
        return report
    
    def run(self):
        """运行资料源发现工具"""
        try:
            # 1. 寻找可工作的资料源
            results = self.find_working_sources()
            
            if results["working_count"] == 0:
                print("\n⚠️ 警告: 未找到可访问的资料源")
                print("建议: 尝试其他资料源或调整测试策略")
                return results
            
            # 2. 如果有可访问的资料源，测试抓取服务
            if results["working_sources"]:
                # 选择第一个可访问的资料源进行抓取服务测试
                best_source = results["working_sources"][0]
                crawler_results = self.test_crawler_services_on_best_source(best_source["url"])
                results["crawler_tests"] = {
                    "tested_source": best_source["name"],
                    "tested_url": best_source["url"],
                    "results": crawler_results
                }
            
            # 3. 生成推荐和建议
            recommendations = self.generate_recommendations(results)
            
            # 4. 保存结果
            self.save_results(results, recommendations)
            
            # 5. 显示最终建议
            print(f"\n{'='*70}")
            print("🎯 最终建议")
            print(f"{'='*70}")
            
            print(f"\n推荐优先测试的资料源:")
            for i, source in enumerate(recommendations["best_sources"][:3], 1):
                print(f"{i}. {source['name']} ({source['type']})")
                print(f"   URL: {source['url']}")
            
            print(f"\n抓取策略:")
            for key, value in recommendations["crawler_strategy"].items():
                print(f"   {key}: {value}")
            
            print(f"\n下一步:")
            for i, step in enumerate(recommendations["next_steps"][:3], 1):
                print(f"{i}. {step}")
            
            print(f"\n{'='*70}")
            print("✅ 资料源发现完成！")
            print(f"{'='*70}")
            
            return results
            
        except Exception as e:
            print(f"\n❌ 工具执行失败: {e}")
            import traceback
            traceback.print_exc()
            return None

def main():
    """主函数"""
    try:
        finder = StoneAgeDataSourceFinder()
        results = finder.run()
        
        if results:
            print(f"\n📊 发现 {results['working_count']} 个可访问资料源")
            print(f"📁 结果保存在: {finder.results_dir}/")
            
            # 更新今日记忆文件
            today_file = f"/root/.openclaw/workspace/memory/{datetime.now().strftime('%Y-%m-%d')}.md"
            if os.path.exists(today_file):
                with open(today_file, 'a', encoding='utf-8') as f:
                    f.write(f"\n## 🔍 资料源发现结果 (04:39)\n")
                    f.write(f"- 测试资料源数量: {results['total_sources']} 个\n")
                    f.write(f"- 可访问资料源: {results['working_count']} 个\n")
                    f.write(f"- 推荐资料源: {min(3, len(results.get('working_sources', [])))} 个\n")
                    f.write(f"- 下一步: 使用web-content-fetcher测试推荐资料源\n")
        
        return 0
        
    except Exception as e:
        print(f"❌ 主函数执行失败: {e}")
        return 1

if __name__ == "__main__":
    sys.exit(main())