#!/usr/bin/env python3
"""
进程监控测试脚本

在Windows环境中测试游戏进程监控功能。
需要实际的石器时代游戏客户端运行。
"""

import sys
import os
import time

# 添加src目录到Python路径
current_dir = os.path.dirname(os.path.abspath(__file__))
src_dir = os.path.join(current_dir, '..', 'src')
sys.path.insert(0, src_dir)

def print_header(title):
    """打印标题"""
    print("\n" + "=" * 60)
    print(f"🖥️  {title}")
    print("=" * 60)

def test_process_finding():
    """测试进程查找功能"""
    print_header("进程查找测试")
    
    try:
        from monitor.process_monitor import ProcessMonitor
        
        print("初始化进程监控器...")
        pm = ProcessMonitor()
        print("✅ 进程监控器初始化成功")
        
        print(f"\n查找游戏进程 (名称包含: '{pm.game_config.process_name}')...")
        print("请确保石器时代游戏客户端已启动...")
        
        try:
            # 查找游戏进程
            process_info = pm.find_game_process(timeout=10)
            
            if process_info:
                print("✅ 找到游戏进程！")
                print(f"\n进程详细信息:")
                print(f"  名称: {process_info.name}")
                print(f"  PID: {process_info.pid}")
                print(f"  状态: {process_info.status.value}")
                print(f"  可执行文件: {process_info.exe_path}")
                print(f"  命令行: {' '.join(process_info.cmdline[:3])}...")
                print(f"  创建时间: {time.ctime(process_info.create_time)}")
                print(f"  运行时间: {process_info.uptime_formatted}")
                print(f"  CPU使用率: {process_info.cpu_percent:.1f}%")
                print(f"  内存使用: {process_info.memory_rss_mb:.1f}MB ({process_info.memory_percent:.1f}%)")
                print(f"  虚拟内存: {process_info.memory_vms_mb:.1f}MB")
                print(f"  线程数: {process_info.num_threads}")
                print(f"  句柄数: {process_info.num_handles}")
                print(f"  用户名: {process_info.username}")
                print(f"  优先级: {process_info.nice}")
                
                return process_info
            else:
                print("❌ 未找到游戏进程")
                print("可能原因:")
                print("1. 游戏未启动")
                print("2. 进程名称不匹配")
                print("3. 游戏以不同名称运行")
                print("4. 权限不足")
                
                # 显示所有进程
                print("\n尝试查找所有进程...")
                all_processes = pm.get_all_processes()
                print(f"系统中共有 {len(all_processes)} 个进程")
                
                # 显示前10个进程
                print("\n前10个进程:")
                for i, proc in enumerate(all_processes[:10]):
                    print(f"{i+1}. {proc.name} (PID: {proc.pid}, 内存: {proc.memory_rss_mb:.1f}MB)")
                
                return None
                
        except Exception as e:
            print(f"❌ 查找进程时出错: {e}")
            return None
            
    except Exception as e:
        print(f"❌ 初始化进程监控器失败: {e}")
        import traceback
        traceback.print_exc()
        return None

def test_process_monitoring(process_info):
    """测试进程监控功能"""
    if not process_info:
        print("⚠️  没有进程信息，跳过进程监控测试")
        return False
    
    print_header("进程监控测试")
    
    try:
        from monitor.process_monitor import ProcessMonitor
        
        pm = ProcessMonitor()
        pid = process_info.pid
        
        print(f"测试进程监控 (PID: {pid})")
        
        # 测试1: 监控进程状态
        print("\n1. 测试进程状态监控...")
        print("   监控进程状态变化 (10秒)...")
        
        states = []
        cpu_values = []
        memory_values = []
        
        for i in range(10):
            try:
                info = pm.monitor_process(pid, interval=1)
                states.append(info.status.value)
                cpu_values.append(info.cpu_percent)
                memory_values.append(info.memory_rss_mb)
                
                print(f"   第{i+1}秒: 状态={info.status.value}, CPU={info.cpu_percent:.1f}%, 内存={info.memory_rss_mb:.1f}MB")
                
                # 在游戏中执行一些操作以改变资源使用
                if i == 3:
                    print("   (建议: 在游戏中执行一些操作以观察资源变化)")
                
            except Exception as e:
                print(f"   监控失败: {e}")
                break
        
        if states:
            print(f"\n   状态变化: {', '.join(states)}")
            if cpu_values:
                print(f"   CPU平均值: {sum(cpu_values)/len(cpu_values):.1f}%")
                print(f"   CPU最大值: {max(cpu_values):.1f}%")
            if memory_values:
                print(f"   内存平均值: {sum(memory_values)/len(memory_values):.1f}MB")
                print(f"   内存最大值: {max(memory_values):.1f}MB")
        
        # 测试2: 获取资源统计
        print("\n2. 测试资源统计...")
        stats = pm.get_resource_stats(pid)
        if stats:
            print("✅ 资源统计获取成功")
            print(f"   进程名称: {stats['name']}")
            print(f"   当前CPU: {stats['current_cpu']:.1f}%")
            print(f"   平均CPU: {stats['avg_cpu']:.1f}%")
            print(f"   最大CPU: {stats['max_cpu']:.1f}%")
            print(f"   当前内存: {stats['current_memory_mb']:.1f}MB")
            print(f"   平均内存: {stats['avg_memory_mb']:.1f}MB")
            print(f"   最大内存: {stats['max_memory_mb']:.1f}MB")
            print(f"   运行时间: {stats['uptime_formatted']}")
            print(f"   状态: {stats['status']}")
            print(f"   线程数: {stats['num_threads']}")
            print(f"   用户名: {stats['username']}")
        else:
            print("❌ 资源统计获取失败")
        
        # 测试3: 获取资源历史
        print("\n3. 测试资源历史记录...")
        history = pm.get_resource_history(pid, limit=5)
        
        if history['cpu']:
            print("   CPU历史 (最近5次):")
            for ts, cpu in history['cpu'][-5:]:
                time_str = time.strftime("%H:%M:%S", time.localtime(ts))
                print(f"     {time_str}: {cpu:.1f}%")
        
        if history['memory']:
            print("   内存历史 (最近5次):")
            for ts, mem in history['memory'][-5:]:
                time_str = time.strftime("%H:%M:%S", time.localtime(ts))
                print(f"     {time_str}: {mem:.1f}MB")
        
        # 测试4: 获取状态历史
        print("\n4. 测试状态历史记录...")
        status_history = pm.get_status_history(pid, limit=5)
        
        if status_history:
            print("   状态变化历史:")
            for ts, old_status, new_status in status_history:
                time_str = time.strftime("%H:%M:%S", time.localtime(ts))
                print(f"     {time_str}: {old_status} -> {new_status}")
        else:
            print("   无状态变化历史")
        
        print("\n🎉 进程监控测试完成！")
        return True
        
    except Exception as e:
        print(f"❌ 进程监控测试失败: {e}")
        import traceback
        traceback.print_exc()
        return False

def test_process_management(process_info):
    """测试进程管理功能"""
    if not process_info:
        print("⚠️  没有进程信息，跳过进程管理测试")
        return False
    
    print_header("进程管理测试")
    
    try:
        from monitor.process_monitor import ProcessMonitor
        
        pm = ProcessMonitor()
        pid = process_info.pid
        
        print(f"测试进程管理功能 (PID: {pid})")
        print("警告: 这些测试可能会影响游戏运行，请谨慎操作！")
        
        # 确认用户是否继续
        response = input("\n是否继续进程管理测试？(y/N): ").strip().lower()
        if response != 'y':
            print("跳过进程管理测试")
            return True
        
        # 测试1: 设置进程优先级
        print("\n1. 测试设置进程优先级...")
        print("   当前优先级: normal")
        
        # 尝试设置为高优先级
        if pm.set_process_priority(pid, priority="high"):
            print("   ✅ 进程优先级设置成功 (high)")
            time.sleep(2)
            
            # 恢复为普通优先级
            pm.set_process_priority(pid, priority="normal")
            print("   ✅ 进程优先级恢复成功 (normal)")
        else:
            print("   ⚠️  进程优先级设置失败 (可能需要管理员权限)")
        
        # 测试2: 挂起/恢复进程 (危险操作，谨慎测试)
        print("\n2. 测试挂起/恢复进程...")
        print("   警告: 这会暂停游戏运行！")
        
        response = input("   是否测试挂起/恢复？(y/N): ").strip().lower()
        if response == 'y':
            # 挂起进程
            print("   正在挂起进程...")
            if pm.suspend_process(pid):
                print("   ✅ 进程挂起成功")
                print("   游戏应该已经暂停，等待3秒...")
                time.sleep(3)
                
                # 恢复进程
                print("   正在恢复进程...")
                if pm.resume_process(pid):
                    print("   ✅ 进程恢复成功")
                    print("   游戏应该已经恢复运行")
                else:
                    print("   ❌ 进程恢复失败")
            else:
                print("   ⚠️  进程挂起失败 (可能需要管理员权限或平台不支持)")
        else:
            print("   跳过挂起/恢复测试")
        
        # 测试3: 终止进程 (危险操作，仅演示)
        print("\n3. 演示终止进程功能...")
        print("   警告: 这会关闭游戏！")
        print("   此测试仅演示功能，不会实际执行")
        
        print("   终止进程代码演示:")
        print("   success = pm.terminate_process(pid)  # 正常终止")
        print("   success = pm.terminate_process(pid, force=True)  # 强制终止")
        print("   实际使用时请谨慎！")
        
        print("\n🎉 进程管理测试完成！")
        return True
        
    except Exception as e:
        print(f"❌ 进程管理测试失败: {e}")
        import traceback
        traceback.print_exc()
        return False

def test_multiple_processes():
    """测试多进程管理"""
    print_header("多进程管理测试")
    
    try:
        from monitor.process_monitor import ProcessMonitor
        
        pm = ProcessMonitor()
        
        print("查找所有进程...")
        all_processes = pm.get_all_processes()
        
        if all_processes:
            print(f"✅ 找到 {len(all_processes)} 个进程")
            
            # 按内存使用排序
            sorted_processes = sorted(all_processes, key=lambda p: p.memory_rss_mb, reverse=True)
            
            print("\n内存使用最高的10个进程:")
            for i, proc in enumerate(sorted_processes[:10]):
                print(f"{i+1:2d}. {proc.name:30s} (PID: {proc.pid:6d}, 内存: {proc.memory_rss_mb:7.1f}MB, CPU: {proc.cpu_percent:5.1f}%)")
            
            # 查找石器时代相关进程
            print("\n查找石器时代相关进程...")
            stoneage_processes = pm.find_processes_by_name("stone")
            stoneage_processes.extend(pm.find_processes_by_name("石器"))
            stoneage_processes.extend(pm.find_processes_by_name("ng25"))
            
            if stoneage_processes:
                print(f"找到 {len(stoneage_processes)} 个石器时代相关进程:")
                for proc in stoneage_processes:
                    print(f"  - {proc.name} (PID: {proc.pid}, 内存: {proc.memory_rss_mb:.1f}MB)")
            else:
                print("未找到石器时代相关进程")
        else:
            print("❌ 无法获取进程列表")
        
        print("\n🎉 多进程管理测试完成！")
        return True
        
    except Exception as e:
        print(f"❌ 多进程管理测试失败: {e}")
        import traceback
        traceback.print_exc()
        return False

def test_error_handling():
    """测试错误处理"""
    print_header("错误处理测试")
    
    try:
        from monitor.process_monitor import ProcessMonitor
        from core.exceptions import ProcessNotFoundError
        
        pm = ProcessMonitor()
        
        print("测试错误情况处理...")
        
        # 测试1: 查找不存在的进程
        print("\n1. 测试查找不存在的进程...")
        try:
            pm.find_game_process(process_name="这个进程肯定不存在", timeout=3)
            print("❌ 应该抛出异常但未抛出")
        except ProcessNotFoundError as e:
            print(f"✅ 正确抛出异常: {e}")
        except Exception as e:
            print(f"⚠️  抛出异常但类型不对: {type(e).__name__}: {e}")
        
        # 测试2: 监控不存在的进程
        print("\n2. 测试监控不存在的进程...")
        try:
            pm.monitor_process(999999)  # 无效PID
            print("❌ 应该抛出异常但未抛出")
        except ProcessNotFoundError as e:
            print(f"✅ 正确抛出异常: {e}")
        except Exception as e:
            print(f"⚠️  抛出异常但类型不对: {type(e).__name__}: {e}")
        
        # 测试3: 获取不存在进程的信息
        print("\n3. 测试获取不存在进程的信息...")
        info = pm.get_process_info(999999)
        if info is None:
            print("✅ 正确处理无效进程，返回None")
        else:
            print("❌ 应该返回None但返回了信息")
        
        print("\n🎉 错误处理测试完成！")
        return True
        
    except Exception as e:
        print(f"❌ 错误处理测试失败: {e}")
        import traceback
        traceback.print_exc()
        return False

def test_resource_thresholds(process_info):
    """测试资源阈值警报"""
    if not process_info:
        print("⚠️  没有进程信息，跳过阈值测试")
        return False
    
    print_header("资源阈值警报测试")
    
    try:
        from monitor.process_monitor import ProcessMonitor
        
        pm = ProcessMonitor()
        pid = process_info.pid
        
        print("测试资源使用阈值警报...")
        
        # 修改配置以降低阈值，便于测试
        original_cpu_threshold = pm.monitor_config.cpu_threshold
        original_memory_threshold = pm.monitor_config.memory_threshold
        
        pm.monitor_config.cpu_threshold = 5.0  # 降低CPU阈值
        pm.monitor_config.memory_threshold = 50.0  # 降低内存阈值
        
        print(f"设置测试阈值: CPU > {pm.monitor_config.cpu_threshold}%, 内存 > {pm.monitor_config.memory_threshold}MB")
        print("请在游戏中执行一些操作以提高资源使用...")
        
        # 监控并检查阈值
        warnings = []
        for i in range(5):
            try:
                info = pm.monitor_process(pid, interval=2)
                
                print(f"监控 {i+1}: CPU={info.cpu_percent:.1f}%, 内存={info.memory_rss_mb:.1f}MB")
                
                # 检查阈值
                if info.cpu_percent > pm.monitor_config.cpu_threshold:
                    warnings.append(f"CPU使用率过高: {info.cpu_percent:.1f}%")
                
                if info.memory_rss_mb > pm.monitor_config.memory_threshold:
                    warnings.append(f"内存使用过高: {info.memory_rss_mb:.1f}MB")
                
                if warnings:
                    print(f"   ⚠️  警告: {warnings[-1]}")
                
            except Exception as e:
                print(f"监控失败: {e}")
                break
        
        # 恢复原始配置
        pm.monitor_config.cpu_threshold = original_cpu_threshold
        pm.monitor_config.memory_threshold = original_memory_threshold
        
        if warnings:
            print(f"\n✅ 阈值警报测试成功！检测到 {len(warnings)} 次警告")
            print("警告列表:")
            for warning in warnings:
                print(f"  - {warning}")
        else:
            print(f"\n⚠️  未触发阈值警报")
            print("可能原因:")
            print("1. 游戏资源使用较低")
            print("2. 阈值设置过高")
            print("3. 监控时间太短")
        
        print("\n🎉 资源阈值测试完成！")
        return True
        
    except Exception as e:
        print(f"❌ 资源阈值测试失败: {e}")
        import traceback
        traceback.print_exc()
        return False

def main():
    """主测试函数"""
    print("🦖 石器时代游戏客户端集成工具 - 进程监控测试")
    print("=" * 60)
    print("测试环境: Windows 10/11 + 石器时代客户端")
    print("=" * 60)
    print("重要提示:")
    print("1. 请先启动石器时代游戏客户端")
    print("2. 建议以管理员身份运行此测试脚本")
    print("3. 进程管理测试可能会影响游戏运行，请谨慎操作")
    print("=" * 60)
    
    test_results = {}
    
    try:
        # 运行各个测试
        process_info = test_process_finding()
        test_results["进程查找"] = "通过" if process_info else "失败"
        
        if process_info:
            monitor_result = test_process_monitoring(process_info)
            test_results["进程监控"] = "通过" if monitor_result else "失败"
            
            management_result = test_process_management(process_info)
            test_results["进程管理"] = "通过" if management_result else "失败"
            
            threshold_result = test_resource_thresholds(process_info)
            test_results["阈值警报"] = "通过" if threshold_result else "失败"
        else:
            test_results["进程监控"] = "跳过"
            test_results["进程管理"] = "跳过"
            test_results["阈值警报"] = "跳过"
        
        multi_result = test_multiple_processes()
        test_results["多进程管理"] = "通过" if multi_result else "失败"
        
        error_result = test_error_handling()
        test_results["错误处理"] = "通过" if error_result else "失败"
        
        # 生成测试报告
        print_header("测试报告")
        
        passed = sum(1 for result in test_results.values() if result == "通过")
        total = len([r for r in test_results.values() if r != "跳过"])
        
        print("测试结果汇总:")
        for test_name, result in test_results.items():
            if result == "跳过":
                status = "⚠️"
            elif result == "通过":
                status = "✅"
            else:
                status = "❌"
            print(f"  {status} {test_name}: {result}")
        
        print(f"\n🏁 总体结果: {passed}/{total} 项测试通过")
        
        if passed == total:
            print("\n🎉 恭喜！所有进程监控测试通过！")
        else:
            print("\n⚠️  部分测试失败，请检查错误信息。")
        
        print("\n" + "=" * 60)
        print("📝 测试完成")
        print("=" * 60)
        print("进程监控功能测试完成。")
        print("如果测试中发现问题，请记录错误信息并反馈。")
        
        return 0 if passed == total else 1
        
    except KeyboardInterrupt:
        print("\n\n⏹️  测试被用户中断")
        return 1
    except Exception as e:
        print(f"\n❌ 测试过程发生未预期错误: {e}")
        import traceback
        traceback.print_exc()
        return 1

if __name__ == "__main__":
    sys.exit(main())