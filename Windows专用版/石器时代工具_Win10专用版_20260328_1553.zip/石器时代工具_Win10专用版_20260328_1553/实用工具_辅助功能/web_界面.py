#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
石器时代脚本性能监控系统 - Web界面
基于Flask的轻量级Web界面，提供可视化监控和控制功能
"""

from flask import Flask, render_template, jsonify, request, send_file
import json
import os
import threading
import time
from datetime import datetime
from typing import Dict, Any, Optional
import logging


class PerformanceMonitorWebUI:
    """性能监控系统Web界面"""
    
    def __init__(self, controller, host='127.0.0.1', port=8080, debug=False):
        """
        初始化Web界面
        
        Args:
            controller: 主控制器实例
            host: 监听主机
            port: 监听端口
            debug: 调试模式
        """
        self.controller = controller
        self.host = host
        self.port = port
        self.debug = debug
        
        # 创建Flask应用
        self.app = Flask(__name__, 
                        template_folder=self._get_template_dir(),
                        static_folder=self._get_static_dir())
        
        # 设置路由
        self._setup_routes()
        
        # 设置日志
        self._setup_logging()
        
        # Flask服务器线程
        self.server_thread = None
        self.running = False
        
    def _get_template_dir(self):
        """获取模板目录"""
        template_dir = "/root/.openclaw/workspace/石器时代脚本性能监控系统/templates"
        os.makedirs(template_dir, exist_ok=True)
        return template_dir
    
    def _get_static_dir(self):
        """获取静态文件目录"""
        static_dir = "/root/.openclaw/workspace/石器时代脚本性能监控系统/static"
        os.makedirs(static_dir, exist_ok=True)
        return static_dir
    
    def _setup_logging(self):
        """设置日志"""
        log_dir = "/root/.openclaw/workspace/石器时代脚本性能监控系统/logs"
        os.makedirs(log_dir, exist_ok=True)
        
        # 禁用Flask默认日志
        logging.getLogger('werkzeug').setLevel(logging.WARNING)
        
        # 设置应用日志
        self.logger = logging.getLogger("PerformanceMonitorWebUI")
        self.logger.setLevel(logging.INFO)
        
        if not self.logger.handlers:
            log_file = os.path.join(log_dir, f"webui_{datetime.now().strftime('%Y%m%d')}.log")
            file_handler = logging.FileHandler(log_file, encoding='utf-8')
            file_handler.setLevel(logging.INFO)
            
            console_handler = logging.StreamHandler()
            console_handler.setLevel(logging.INFO)
            
            formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
            file_handler.setFormatter(formatter)
            console_handler.setFormatter(formatter)
            
            self.logger.addHandler(file_handler)
            self.logger.addHandler(console_handler)
    
    def _setup_routes(self):
        """设置路由"""
        
        # 主页
        @self.app.route('/')
        def index():
            return render_template('index.html')
        
        # 系统状态API
        @self.app.route('/api/status')
        def api_status():
            status = self.controller.get_system_status()
            return jsonify(status)
        
        # 模块控制API
        @self.app.route('/api/module/<module_name>/start', methods=['POST'])
        def api_module_start(module_name):
            success = self.controller.start_module(module_name)
            return jsonify({"success": success, "module": module_name})
        
        @self.app.route('/api/module/<module_name>/stop', methods=['POST'])
        def api_module_stop(module_name):
            success = self.controller.stop_module(module_name)
            return jsonify({"success": success, "module": module_name})
        
        # 任务API
        @self.app.route('/api/tasks', methods=['GET'])
        def api_tasks():
            # 返回任务列表
            tasks = {
                "pending": self.controller.task_queue,
                "completed": list(self.controller.task_results.values()),
            }
            return jsonify(tasks)
        
        @self.app.route('/api/task', methods=['POST'])
        def api_task_create():
            data = request.json
            task_type = data.get('type')
            if not task_type:
                return jsonify({"error": "任务类型必填"}), 400
            
            task_id = self.controller.add_task(task_type, **data.get('params', {}))
            return jsonify({"success": True, "task_id": task_id})
        
        # 性能数据API
        @self.app.route('/api/metrics')
        def api_metrics():
            metrics = self.controller.system_metrics_history
            # 返回最近100个数据点
            recent_metrics = metrics[-100:] if metrics else []
            return jsonify([m.__dict__ for m in recent_metrics])
        
        # 报告API
        @self.app.route('/api/report')
        def api_report():
            report = self.controller.generate_system_report()
            return jsonify({"report": report})
        
        # 配置API
        @self.app.route('/api/config')
        def api_config():
            return jsonify(self.controller.config)
        
        @self.app.route('/api/config/save', methods=['POST'])
        def api_config_save():
            data = request.json
            if data:
                # 在实际环境中，这里应该更新配置并保存
                pass
            return jsonify({"success": True})
        
        # 系统控制API
        @self.app.route('/api/system/start', methods=['POST'])
        def api_system_start():
            success = self.controller.start()
            return jsonify({"success": success})
        
        @self.app.route('/api/system/stop', methods=['POST'])
        def api_system_stop():
            success = self.controller.stop()
            return jsonify({"success": success})
        
        # 静态文件服务
        @self.app.route('/static/<path:filename>')
        def serve_static(filename):
            return send_file(os.path.join(self._get_static_dir(), filename))
    
    def _create_default_templates(self):
        """创建默认模板"""
        template_dir = self._get_template_dir()
        
        # 创建index.html
        index_html = """<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>石器时代脚本性能监控系统</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body {
            background-color: #f8f9fa;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .navbar-brand {
            font-weight: bold;
            color: #0d6efd !important;
        }
        .card {
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
            border: none;
        }
        .card-header {
            background-color: #fff;
            border-bottom: 2px solid #0d6efd;
            font-weight: 600;
        }
        .status-badge {
            font-size: 0.8rem;
            padding: 4px 8px;
            border-radius: 12px;
        }
        .status-running {
            background-color: #d1e7dd;
            color: #0f5132;
        }
        .status-stopped {
            background-color: #f8d7da;
            color: #842029;
        }
        .status-starting {
            background-color: #fff3cd;
            color: #664d03;
        }
        .metric-card {
            text-align: center;
            padding: 15px;
        }
        .metric-value {
            font-size: 2rem;
            font-weight: bold;
            color: #0d6efd;
        }
        .metric-label {
            font-size: 0.9rem;
            color: #6c757d;
            margin-top: 5px;
        }
        .chart-container {
            position: relative;
            height: 300px;
            width: 100%;
        }
        .module-card {
            transition: transform 0.2s;
        }
        .module-card:hover {
            transform: translateY(-5px);
        }
        .btn-module {
            width: 100%;
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <!-- 导航栏 -->
    <nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">
                <i class="bi bi-speedometer2 me-2"></i>
                石器时代脚本性能监控系统
            </a>
            <div class="d-flex align-items-center">
                <span class="me-3 text-muted" id="current-time">--:--:--</span>
                <div class="form-check form-switch">
                    <input class="form-check-input" type="checkbox" id="auto-refresh" checked>
                    <label class="form-check-label" for="auto-refresh">自动刷新</label>
                </div>
            </div>
        </div>
    </nav>

    <div class="container-fluid mt-4">
        <div class="row">
            <!-- 左侧：系统状态和模块控制 -->
            <div class="col-lg-4">
                <!-- 系统状态卡片 -->
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <span>系统状态</span>
                        <div>
                            <button class="btn btn-sm btn-outline-success me-2" id="btn-start-system">
                                <i class="bi bi-play-fill"></i> 启动
                            </button>
                            <button class="btn btn-sm btn-outline-danger" id="btn-stop-system">
                                <i class="bi bi-stop-fill"></i> 停止
                            </button>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="row mb-3">
                            <div class="col-6">
                                <div class="metric-card">
                                    <div class="metric-value" id="system-status">--</div>
                                    <div class="metric-label">系统状态</div>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="metric-card">
                                    <div class="metric-value" id="system-uptime">--</div>
                                    <div class="metric-label">运行时间</div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-6">
                                <div class="metric-card">
                                    <div class="metric-value" id="total-tasks">0</div>
                                    <div class="metric-label">总任务数</div>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="metric-card">
                                    <div class="metric-value" id="pending-tasks">0</div>
                                    <div class="metric-label">待处理任务</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- 模块控制卡片 -->
                <div class="card">
                    <div class="card-header">
                        模块控制
                    </div>
                    <div class="card-body">
                        <div id="modules-container">
                            <!-- 模块将通过JavaScript动态加载 -->
                            <div class="text-center text-muted">
                                <i class="bi bi-arrow-repeat spinner"></i> 加载模块信息...
                            </div>
                        </div>
                    </div>
                </div>

                <!-- 快速任务卡片 -->
                <div class="card">
                    <div class="card-header">
                        快速任务
                    </div>
                    <div class="card-body">
                        <div class="d-grid gap-2">
                            <button class="btn btn-outline-primary" id="btn-monitor-script">
                                <i class="bi bi-graph-up"></i> 监控脚本性能
                            </button>
                            <button class="btn btn-outline-success" id="btn-analyze-data">
                                <i class="bi bi-bar-chart"></i> 分析性能数据
                            </button>
                            <button class="btn btn-outline-warning" id="btn-optimize-script">
                                <i class="bi bi-gear"></i> 优化脚本配置
                            </button>
                            <button class="btn btn-outline-info" id="btn-generate-report">
                                <i class="bi bi-file-earmark-text"></i> 生成报告
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            <!-- 右侧：性能图表和详细信息 -->
            <div class="col-lg-8">
                <!-- 性能图表卡片 -->
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <span>性能监控图表</span>
                        <div class="btn-group btn-group-sm">
                            <button class="btn btn-outline-secondary active" data-chart="cpu">CPU</button>
                            <button class="btn btn-outline-secondary" data-chart="memory">内存</button>
                            <button class="btn btn-outline-secondary" data-chart="network">网络</button>
                            <button class="btn btn-outline-secondary" data-chart="tasks">任务</button>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="chart-container">
                            <canvas id="performance-chart"></canvas>
                        </div>
                    </div>
                </div>

                <!-- 实时指标卡片 -->
                <div class="card">
                    <div class="card-header">
                        实时系统指标
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-3 col-6">
                                <div class="metric-card">
                                    <div class="metric-value" id="cpu-usage">--%</div>
                                    <div class="metric-label">CPU使用率</div>
                                </div>
                            </div>
                            <div class="col-md-3 col-6">
                                <div class="metric-card">
                                    <div class="metric-value" id="memory-usage">--%</div>
                                    <div class="metric-label">内存使用率</div>
                                </div>
                            </div>
                            <div class="col-md-3 col-6">
                                <div class="metric-card">
                                    <div class="metric-value" id="disk-usage">--%</div>
                                    <div class="metric-label">磁盘使用率</div>
                                </div>
                            </div>
                            <div class="col-md-3 col-6">
                                <div class="metric-card">
                                    <div class="metric-value" id="error-count">0</div>
                                    <div class="metric-label">错误计数</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- 最近任务卡片 -->
                <div class="card">
                    <div class="card-header">
                        最近任务
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>任务ID</th>
                                        <th>类型</th>
                                        <th>状态</th>
                                        <th>创建时间</th>
                                        <th>操作</th>
                                    </tr>
                                </thead>
                                <tbody id="recent-tasks">
                                    <tr>
                                        <td colspan="5" class="text-center text-muted">
                                            暂无任务数据
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- 模态框：任务详情 -->
    <div class="modal fade" id="taskDetailModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">任务详情</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <pre id="task-detail-content" class="bg-light p-3 rounded" style="max-height: 400px; overflow: auto;"></pre>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- 自定义JavaScript -->
    <script>
        // 全局变量
        let refreshInterval = null;
        let currentChart = null;
        let chartData = {
            cpu: { labels: [], datasets: [] },
            memory: { labels: [], datasets: [] },
            network: { labels: [], datasets: [] },
            tasks: { labels: [], datasets: [] }
        };

        // 初始化函数
        document.addEventListener('DOMContentLoaded', function() {
            // 初始化时间显示
            updateCurrentTime();
            setInterval(updateCurrentTime, 1000);

            // 初始化自动刷新
            initAutoRefresh();

            // 初始化按钮事件
            initButtonEvents();

            // 初始化图表
            initCharts();

            // 首次加载数据
            loadSystemData();
        });

        // 更新当前时间
        function updateCurrentTime() {
            const now = new Date();
            const timeStr = now.toLocaleTimeString('zh-CN');
            document.getElementById('current-time').textContent = timeStr;
        }

        // 初始化自动刷新