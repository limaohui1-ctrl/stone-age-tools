#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
游戏集成模块 - 负责与石器时代游戏交互
"""

import os
import sys
import time
import logging
from typing import Optional, List, Tuple, Dict
import subprocess

# 尝试导入Windows相关库
try:
    import win32gui
    import win32con
    import win32api
    HAS_WIN32 = True
except ImportError:
    HAS_WIN32 = False
    print("⚠️  win32库未安装，部分功能可能受限")

# 尝试导入自动化库
try:
    import pyautogui
    HAS_PYAUTOGUI = True
except ImportError:
    HAS_PYAUTOGUI = False
    print("⚠️  pyautogui未安装，部分功能可能受限")

class GameIntegration:
    """游戏集成类"""
    
    def __init__(self, config_path: Optional[str] = None):
        """
        初始化游戏集成
        
        Args:
            config_path: 配置文件路径
        """
        self.logger = logging.getLogger(__name__)
        self.config = self._load_config(config_path)
        
        # 游戏窗口信息
        self.game_window = None
        self.game_title = self.config.get('game_title', '石器时代')
        self.game_process = None
        
        # 验证码区域配置
        self.captcha_area = self.config.get('captcha_area', {
            'x': 100,
            'y': 200,
            'width': 200,
            'height': 80
        })
        
        # 输入区域配置
        self.input_area = self.config.get('input_area', {
            'x': 150,
            'y': 300,
            'width': 100,
            'height': 30
        })
        
        self.logger.info("游戏集成模块初始化完成")
    
    def _load_config(self, config_path: Optional[str]) -> dict:
        """加载配置"""
        default_config = {
            'game_title': '石器时代',
            'game_exe_path': None,
            'captcha_area': {'x': 100, 'y': 200, 'width': 200, 'height': 80},
            'input_area': {'x': 150, 'y': 300, 'width': 100, 'height': 30},
            'captcha_check_interval': 5,  # 检查验证码的间隔（秒）
            'auto_input_enabled': True,
            'screenshot_quality': 90,
            'max_retry': 3
        }
        
        # 在实际版本中，这里会从配置文件加载
        return default_config
    
    def find_game_windows(self) -> List[Tuple[int, str]]:
        """
        查找石器时代游戏窗口
        
        Returns:
            列表，每个元素为(窗口句柄, 窗口标题)
        """
        windows = []
        
        if not HAS_WIN32:
            self.logger.warning("win32库未安装，无法查找游戏窗口")
            return windows
        
        def callback(hwnd, extra):
            """窗口枚举回调函数"""
            if win32gui.IsWindowVisible(hwnd):
                title = win32gui.GetWindowText(hwnd)
                if self.game_title in title:
                    windows.append((hwnd, title))
            return True
        
        try:
            win32gui.EnumWindows(callback, None)
            self.logger.info(f"找到 {len(windows)} 个游戏窗口")
        except Exception as e:
            self.logger.error(f"查找游戏窗口失败: {e}")
        
        return windows
    
    def get_active_game_window(self) -> Optional[int]:
        """
        获取当前活动的游戏窗口
        
        Returns:
            窗口句柄，如果没有则返回None
        """
        windows = self.find_game_windows()
        
        if not windows:
            self.logger.warning("未找到游戏窗口")
            return None
        
        # 如果有多个窗口，返回第一个
        hwnd, title = windows[0]
        self.game_window = hwnd
        
        # 获取窗口位置和大小
        try:
            rect = win32gui.GetWindowRect(hwnd)
            self.logger.info(f"游戏窗口: {title}, 位置: {rect}")
        except Exception as e:
            self.logger.error(f"获取窗口信息失败: {e}")
        
        return hwnd
    
    def capture_captcha_area(self, hwnd: Optional[int] = None) -> Optional[str]:
        """
        截取验证码区域
        
        Args:
            hwnd: 窗口句柄，如果为None则使用当前游戏窗口
            
        Returns:
            截图保存路径，如果失败则返回None
        """
        if not HAS_PYAUTOGUI:
            self.logger.warning("pyautogui未安装，无法截图")
            return None
        
        if hwnd is None:
            hwnd = self.game_window or self.get_active_game_window()
        
        if hwnd is None:
            self.logger.error("未找到游戏窗口")
            return None
        
        try:
            # 激活窗口
            win32gui.SetForegroundWindow(hwnd)
            time.sleep(0.5)  # 等待窗口激活
            
            # 获取窗口位置
            rect = win32gui.GetWindowRect(hwnd)
            left, top, right, bottom = rect
            
            # 计算验证码区域
            captcha_x = left + self.captcha_area['x']
            captcha_y = top + self.captcha_area['y']
            captcha_width = self.captcha_area['width']
            captcha_height = self.captcha_area['height']
            
            # 截图
            screenshot = pyautogui.screenshot(
                region=(captcha_x, captcha_y, captcha_width, captcha_height)
            )
            
            # 保存截图
            timestamp = int(time.time())
            save_dir = os.path.join(os.path.expanduser("~"), "StoneCaptcha", "captchas")
            os.makedirs(save_dir, exist_ok=True)
            
            save_path = os.path.join(save_dir, f"captcha_{timestamp}.png")
            screenshot.save(save_path, quality=self.config['screenshot_quality'])
            
            self.logger.info(f"验证码截图已保存: {save_path}")
            return save_path
            
        except Exception as e:
            self.logger.error(f"截取验证码失败: {e}")
            return None
    
    def input_captcha_result(self, text: str, hwnd: Optional[int] = None) -> bool:
        """
        输入验证码结果
        
        Args:
            text: 要输入的文本
            hwnd: 窗口句柄
            
        Returns:
            是否成功
        """
        if not HAS_WIN32 or not HAS_PYAUTOGUI:
            self.logger.warning("必要的库未安装，无法输入验证码")
            return False
        
        if hwnd is None:
            hwnd = self.game_window or self.get_active_game_window()
        
        if hwnd is None:
            self.logger.error("未找到游戏窗口")
            return False
        
        if not text:
            self.logger.warning("验证码文本为空")
            return False
        
        try:
            # 激活窗口
            win32gui.SetForegroundWindow(hwnd)
            time.sleep(0.3)
            
            # 获取窗口位置
            rect = win32gui.GetWindowRect(hwnd)
            left, top, right, bottom = rect
            
            # 计算输入框位置
            input_x = left + self.input_area['x'] + self.input_area['width'] // 2
            input_y = top + self.input_area['y'] + self.input_area['height'] // 2
            
            # 点击输入框
            pyautogui.click(input_x, input_y)
            time.sleep(0.2)
            
            # 清空输入框（Ctrl+A, Delete）
            pyautogui.hotkey('ctrl', 'a')
            time.sleep(0.1)
            pyautogui.press('delete')
            time.sleep(0.1)
            
            # 输入验证码
            pyautogui.typewrite(text, interval=0.05)
            time.sleep(0.2)
            
            # 按Enter确认
            pyautogui.press('enter')
            
            self.logger.info(f"验证码输入完成: {text}")
            return True
            
        except Exception as e:
            self.logger.error(f"输入验证码失败: {e}")
            return False
    
    def auto_captcha_process(self, recognizer) -> Dict:
        """
        自动验证码处理流程
        
        Args:
            recognizer: 验证码识别器实例
            
        Returns:
            处理结果字典
        """
        result = {
            'success': False,
            'captcha_text': '',
            'screenshot_path': '',
            'error': ''
        }
        
        try:
            # 1. 查找游戏窗口
            hwnd = self.get_active_game_window()
            if hwnd is None:
                result['error'] = '未找到游戏窗口'
                return result
            
            # 2. 截取验证码
            screenshot_path = self.capture_captcha_area(hwnd)
            if not screenshot_path:
                result['error'] = '截取验证码失败'
                return result
            
            result['screenshot_path'] = screenshot_path
            
            # 3. 识别验证码
            captcha_text = recognizer.recognize(screenshot_path)
            if not captcha_text:
                result['error'] = '识别验证码失败'
                return result
            
            result['captcha_text'] = captcha_text
            
            # 4. 输入验证码
            if self.config['auto_input_enabled']:
                input_success = self.input_captcha_result(captcha_text, hwnd)
                if not input_success:
                    result['error'] = '输入验证码失败'
                    return result
            
            result['success'] = True
            return result
            
        except Exception as e:
            result['error'] = str(e)
            return result
    
    def start_game(self, game_path: Optional[str] = None) -> bool:
        """
        启动游戏
        
        Args:
            game_path: 游戏可执行文件路径
            
        Returns:
            是否成功
        """
        if game_path is None:
            game_path = self.config.get('game_exe_path')
        
        if not game_path or not os.path.exists(game_path):
            self.logger.error(f"游戏路径不存在: {game_path}")
            return False
        
        try:
            self.logger.info(f"启动游戏: {game_path}")
            
            # 启动游戏进程
            self.game_process = subprocess.Popen(
                [game_path],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE
            )
            
            # 等待游戏启动
            time.sleep(5)
            
            self.logger.info("游戏启动成功")
            return True
            
        except Exception as e:
            self.logger.error(f"启动游戏失败: {e}")
            return False
    
    def monitor_captcha(self, recognizer, interval: Optional[int] = None) -> None:
        """
        监控验证码出现
        
        Args:
            recognizer: 验证码识别器
            interval: 检查间隔（秒）
        """
        if interval is None:
            interval = self.config['captcha_check_interval']
        
        self.logger.info(f"开始监控验证码，检查间隔: {interval}秒")
        
        try:
            while True:
                # 检查游戏窗口
                hwnd = self.get_active_game_window()
                if hwnd:
                    # 这里可以添加验证码出现的检测逻辑
                    # 例如：检测特定颜色、特定区域变化等
                    
                    # 暂时简单实现：定期截图检查
                    result = self.auto_captcha_process(recognizer)
                    
                    if result['success']:
                        self.logger.info(f"验证码处理成功: {result['captcha_text']}")
                    elif result['error']:
                        self.logger.debug(f"验证码检查: {result['error']}")
                
                time.sleep(interval)
                
        except KeyboardInterrupt:
            self.logger.info("监控已停止")
        except Exception as e:
            self.logger.error(f"监控过程中出错: {e}")


# 简单测试函数
def test_game_integration():
    """测试游戏集成模块"""
    print("🎮 测试游戏集成模块")
    print("-" * 40)
    
    # 创建游戏集成实例
    game = GameIntegration()
    
    # 查找游戏窗口
    print("🔍 查找游戏窗口...")
    windows = game.find_game_windows()
    
    if windows:
        print(f"✅ 找到 {len(windows)} 个游戏窗口:")
        for i, (hwnd, title) in enumerate(windows, 1):
            print(f"  {i}. {title} (句柄: {hwnd})")
        
        # 测试截图
        print("\n📸 测试验证码截图...")
        if HAS_PYAUTOGUI:
            screenshot_path = game.capture_captcha_area(windows[0][0])
            if screenshot_path:
                print(f"✅ 截图已保存: {screenshot_path}")
            else:
                print("❌ 截图失败")
        else:
            print("⚠️  pyautogui未安装，无法测试截图")
        
        # 测试输入
        print("\n⌨️  测试验证码输入...")
        if HAS_PYAUTOGUI and HAS_WIN32:
            test_text = "TEST123"
            success = game.input_captcha_result(test_text, windows[0][0])
            if success:
                print(f"✅ 输入测试成功: {test_text}")
            else:
                print("❌ 输入测试失败")
        else:
            print("⚠️  必要的库未安装，无法测试输入")
    else:
        print("❌ 未找到游戏窗口")
        print("💡 请确保石器时代游戏已启动")

if __name__ == "__main__":
    test_game_integration()