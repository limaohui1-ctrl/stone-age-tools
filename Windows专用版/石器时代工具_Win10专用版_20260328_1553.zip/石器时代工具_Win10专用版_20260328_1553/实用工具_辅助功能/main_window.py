#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
主窗口 - PyQt6用户界面
石器时代验证码识别工具的主界面
"""

import sys
import os
import logging
from pathlib import Path
from typing import Optional, Dict, Any

# 尝试导入PyQt6
try:
    from PyQt6.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, 
                                 QHBoxLayout, QLabel, QPushButton, QTextEdit,
                                 QTabWidget, QGroupBox, QGridLayout, QStatusBar,
                                 QMessageBox, QSystemTrayIcon, QMenu, QSplitter)
    from PyQt6.QtCore import Qt, QTimer, pyqtSignal, QThread, pyqtSlot
    from PyQt6.QtGui import QIcon, QFont, QPalette, QColor, QAction
    PYQT6_AVAILABLE = True
except ImportError as e:
    print(f"⚠️  PyQt6未安装: {e}")
    print("💡 请安装: pip install PyQt6")
    PYQT6_AVAILABLE = False

class MainWindow(QMainWindow):
    """主窗口类 - v2.0 集成新功能"""
    
    # 信号定义
    recognition_started = pyqtSignal()
    recognition_stopped = pyqtSignal()
    config_changed = pyqtSignal(dict)
    error_occurred = pyqtSignal(str, str)  # (错误类型, 错误消息)
    status_updated = pyqtSignal(str)       # 状态消息
    
    def __init__(self, config_manager=None, logger=None):
        super().__init__()
        
        # 设置日志
        self.logger = logger or logging.getLogger(__name__)
        self.config_manager = config_manager
        
        # 状态变量
        self.is_recognizing = False
        self.recognition_stats = {
            'total': 0,
            'success': 0,
            'failed': 0,
            'start_time': None
        }
        
        # 新功能组件
        self.ocr_engine = None
        self.game_integration = None
        self.error_handler = None
        
        # 初始化新功能
        self.init_new_features()
        
        # 初始化UI
        self.init_ui()
        
        # 初始化定时器
        self.init_timers()
        
        # 初始化系统托盘
        self.init_system_tray()
        
        # 连接信号
        self.connect_signals()
        
        self.logger.info("主窗口 v2.0 初始化完成")
    
    def connect_signals(self):
        """连接信号"""
        # 连接错误信号
        if hasattr(self, 'error_occurred'):
            self.error_occurred.connect(self.on_error_occurred)
        
        # 连接状态信号
        if hasattr(self, 'status_updated'):
            self.status_updated.connect(self.on_status_updated)
    
    def init_new_features(self):
        """初始化新功能组件"""
        try:
            # 初始化OCR多引擎
            from src.core.ocr_multi_engine import OCRMultiEngine
            self.ocr_engine = OCRMultiEngine()
            self.logger.info(f"OCR多引擎初始化完成，可用引擎: {self.ocr_engine.available_engines}")
        except Exception as e:
            self.logger.error(f"OCR多引擎初始化失败: {e}")
            self.ocr_engine = None
        
        try:
            # 初始化游戏集成
            from src.core.game_integration_enhanced import GameIntegrationEnhanced
            self.game_integration = GameIntegrationEnhanced()
            self.logger.info("游戏集成增强版初始化完成")
        except Exception as e:
            self.logger.error(f"游戏集成初始化失败: {e}")
            self.game_integration = None
        
        try:
            # 初始化错误处理器
            from src.utils.error_handler import get_global_error_handler
            self.error_handler = get_global_error_handler()
            self.logger.info("错误处理系统初始化完成")
        except Exception as e:
            self.logger.error(f"错误处理系统初始化失败: {e}")
            self.error_handler = None
    
    def init_ui(self):
        """初始化用户界面"""
        # 设置窗口属性
        self.setWindowTitle("石器时代验证码识别工具 v1.0")
        self.setGeometry(100, 100, 1000, 700)
        
        # 设置窗口图标
        self.setWindowIcon(self._create_icon())
        
        # 创建中心部件
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        # 创建主布局
        main_layout = QVBoxLayout(central_widget)
        
        # 创建分割器（左侧面板 + 右侧主区域）
        splitter = QSplitter(Qt.Orientation.Horizontal)
        
        # 左侧面板
        left_panel = self._create_left_panel()
        splitter.addWidget(left_panel)
        
        # 右侧主区域
        right_panel = self._create_right_panel()
        splitter.addWidget(right_panel)
        
        # 设置分割器比例
        splitter.setSizes([250, 750])
        
        # 添加到主布局
        main_layout.addWidget(splitter)
        
        # 创建状态栏
        self._create_status_bar()
        
        # 应用样式
        self._apply_styles()
    
    def _create_left_panel(self) -> QWidget:
        """创建左侧面板"""
        panel = QWidget()
        layout = QVBoxLayout(panel)
        
        # 游戏状态组
        game_group = QGroupBox("🎮 游戏状态")
        game_layout = QVBoxLayout()
        
        # 游戏状态标签
        self.game_status_label = QLabel("状态: 未检测到游戏")
        self.game_status_label.setStyleSheet("color: #ff6b6b; font-weight: bold;")
        game_layout.addWidget(self.game_status_label)
        
        # 游戏窗口信息
        self.game_window_label = QLabel("窗口: 无")
        game_layout.addWidget(self.game_window_label)
        
        # 验证码状态
        self.captcha_status_label = QLabel("验证码: 未检测")
        game_layout.addWidget(self.captcha_status_label)
        
        game_group.setLayout(game_layout)
        layout.addWidget(game_group)
        
        # 用户管理组
        user_group = QGroupBox("👤 用户管理")
        user_layout = QVBoxLayout()
        
        # 当前用户
        self.current_user_label = QLabel("当前用户: 未选择")
        user_layout.addWidget(self.current_user_label)
        
        # 用户列表
        self.user_list_widget = QTextEdit()
        self.user_list_widget.setMaximumHeight(100)
        self.user_list_widget.setReadOnly(True)
        self.user_list_widget.setPlainText("用户1 (启用)\n用户2 (禁用)")
        user_layout.addWidget(self.user_list_widget)
        
        # 用户管理按钮
        user_btn_layout = QHBoxLayout()
        add_user_btn = QPushButton("添加用户")
        edit_user_btn = QPushButton("编辑用户")
        user_btn_layout.addWidget(add_user_btn)
        user_btn_layout.addWidget(edit_user_btn)
        user_layout.addLayout(user_btn_layout)
        
        user_group.setLayout(user_layout)
        layout.addWidget(user_group)
        
        # 统计信息组
        stats_group = QGroupBox("📊 统计信息")
        stats_layout = QVBoxLayout()
        
        # OCR引擎统计
        self.ocr_stats_label = QLabel("OCR引擎: 加载中...")
        stats_layout.addWidget(self.ocr_stats_label)
        
        # 识别统计
        self.recognition_stats_label = QLabel("识别: 0/0 (0%)")
        stats_layout.addWidget(self.recognition_stats_label)
        
        # 时间统计
        self.time_stats_label = QLabel("运行: 0小时0分钟")
        stats_layout.addWidget(self.time_stats_label)
        
        # 性能统计
        self.performance_stats_label = QLabel("响应: 0.0秒")
        stats_layout.addWidget(self.performance_stats_label)
        
        # 错误统计
        self.error_stats_label = QLabel("错误: 0 (恢复: 0%)")
        stats_layout.addWidget(self.error_stats_label)
        
        stats_group.setLayout(stats_layout)
        layout.addWidget(stats_group)
        
        # 控制按钮组
        control_group = QGroupBox("🔧 控制")
        control_layout = QVBoxLayout()
        
        # 开始/停止按钮
        self.start_stop_btn = QPushButton("▶ 开始识别")
        self.start_stop_btn.setStyleSheet("""
            QPushButton {
                background-color: #4CAF50;
                color: white;
                font-weight: bold;
                padding: 10px;
                border-radius: 5px;
            }
            QPushButton:hover {
                background-color: #45a049;
            }
        """)
        self.start_stop_btn.clicked.connect(self.toggle_recognition)
        control_layout.addWidget(self.start_stop_btn)
        
        # 手动识别按钮
        manual_btn = QPushButton("🔍 手动识别")
        manual_btn.clicked.connect(self.manual_recognition)
        control_layout.addWidget(manual_btn)
        
        # 设置按钮
        settings_btn = QPushButton("⚙️ 设置")
        settings_btn.clicked.connect(self.open_settings)
        control_layout.addWidget(settings_btn)
        
        control_group.setLayout(control_layout)
        layout.addWidget(control_group)
        
        # 添加弹性空间
        layout.addStretch()
        
        return panel
    
    def _create_right_panel(self) -> QWidget:
        """创建右侧主区域"""
        panel = QWidget()
        layout = QVBoxLayout(panel)
        
        # 创建标签页
        self.tab_widget = QTabWidget()
        
        # 标签页1：实时预览
        preview_tab = self._create_preview_tab()
        self.tab_widget.addTab(preview_tab, "👁️ 实时预览")
        
        # 标签页2：识别结果
        results_tab = self._create_results_tab()
        self.tab_widget.addTab(results_tab, "📋 识别结果")
        
        # 标签页3：日志查看
        logs_tab = self._create_logs_tab()
        self.tab_widget.addTab(logs_tab, "📝 日志")
        
        # 标签页4：OCR引擎管理
        ocr_tab = self._create_ocr_tab()
        self.tab_widget.addTab(ocr_tab, "🔤 OCR引擎")
        
        # 标签页5：错误监控
        error_tab = self._create_error_tab()
        self.tab_widget.addTab(error_tab, "🛡️ 错误监控")
        
        # 标签页6：配置管理
        config_tab = self._create_config_tab()
        self.tab_widget.addTab(config_tab, "⚙️ 配置")
        
        layout.addWidget(self.tab_widget)
        
        return panel
    
    def _create_preview_tab(self) -> QWidget:
        """创建实时预览标签页"""
        tab = QWidget()
        layout = QVBoxLayout(tab)
        
        # 预览标题
        preview_title = QLabel("🖼️ 验证码实时预览")
        preview_title.setStyleSheet("font-size: 16px; font-weight: bold;")
        preview_title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(preview_title)
        
        # 预览图像区域
        self.preview_label = QLabel("等待验证码...")
        self.preview_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.preview_label.setStyleSheet("""
            QLabel {
                background-color: #2c3e50;
                color: #ecf0f1;
                border: 2px dashed #7f8c8d;
                border-radius: 10px;
                padding: 20px;
                font-size: 14px;
            }
        """)
        self.preview_label.setMinimumHeight(300)
        layout.addWidget(self.preview_label)
        
        # 识别信息
        info_group = QGroupBox("识别信息")
        info_layout = QGridLayout()
        
        # 原始图像
        info_layout.addWidget(QLabel("原始图像:"), 0, 0)
        self.original_image_label = QLabel("未捕获")
        info_layout.addWidget(self.original_image_label, 0, 1)
        
        # 处理后的图像
        info_layout.addWidget(QLabel("处理后:"), 1, 0)
        self.processed_image_label = QLabel("未处理")
        info_layout.addWidget(self.processed_image_label, 1, 1)
        
        # 识别结果
        info_layout.addWidget(QLabel("识别结果:"), 2, 0)
        self.recognition_result_label = QLabel("等待识别...")
        self.recognition_result_label.setStyleSheet("font-weight: bold; color: #3498db;")
        info_layout.addWidget(self.recognition_result_label, 2, 1)
        
        # 置信度
        info_layout.addWidget(QLabel("置信度:"), 3, 0)
        self.confidence_label = QLabel("0%")
        info_layout.addWidget(self.confidence_label, 3, 1)
        
        # 处理时间
        info_layout.addWidget(QLabel("处理时间:"), 4, 0)
        self.processing_time_label = QLabel("0.0秒")
        info_layout.addWidget(self.processing_time_label, 4, 1)
        
        info_group.setLayout(info_layout)
        layout.addWidget(info_group)
        
        # 控制按钮
        btn_layout = QHBoxLayout()
        
        # 刷新预览按钮
        refresh_btn = QPushButton("🔄 刷新预览")
        refresh_btn.clicked.connect(self.refresh_preview)
        btn_layout.addWidget(refresh_btn)
        
        # 保存图像按钮
        save_btn = QPushButton("💾 保存图像")
        save_btn.clicked.connect(self.save_captcha_image)
        btn_layout.addWidget(save_btn)
        
        # 测试识别按钮
        test_btn = QPushButton("🧪 测试识别")
        test_btn.clicked.connect(self.test_recognition)
        btn_layout.addWidget(test_btn)
        
        layout.addLayout(btn_layout)
        
        return tab
    
    def _create_results_tab(self) -> QWidget:
        """创建识别结果标签页"""
        tab = QWidget()
        layout = QVBoxLayout(tab)
        
        # 结果标题
        results_title = QLabel("📊 识别结果历史")
        results_title.setStyleSheet("font-size: 16px; font-weight: bold;")
        results_title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(results_title)
        
        # 结果表格（用文本编辑框模拟）
        self.results_text = QTextEdit()
        self.results_text.setReadOnly(True)
        self.results_text.setPlainText("""时间戳               用户    结果   置信度   状态
-----------------------------------------------
2026-03-19 23:30:01  user1   ABCD   95%     ✅ 成功
2026-03-19 23:25:47  user2   EFGH   87%     ✅ 成功
2026-03-19 23:20:12  user1   IJKL   92%     ✅ 成功
2026-03-19 23:15:33  user2   MNOP   45%     ❌ 失败
2026-03-19 23:10:58  user1   QRST   96%     ✅ 成功""")
        
        # 设置等宽字体
        font = QFont("Courier New", 10)
        self.results_text.setFont(font)
        
        layout.addWidget(self.results_text)
        
        # 结果操作按钮
        btn_layout = QHBoxLayout()
        
        # 清空结果按钮
        clear_btn = QPushButton("🗑️ 清空结果")
        clear_btn.clicked.connect(self.clear_results)
        btn_layout.addWidget(clear_btn)
        
        # 导出结果按钮
        export_btn = QPushButton("📤 导出结果")
        export_btn.clicked.connect(self.export_results)
        btn_layout.addWidget(export_btn)
        
        # 统计按钮
        stats_btn = QPushButton("📈 查看统计")
        stats_btn.clicked.connect(self.show_statistics)
        btn_layout.addWidget(stats_btn)
        
        layout.addLayout(btn_layout)
        
        return tab
    
    def _create_logs_tab(self) -> QWidget:
        """创建日志查看标签页"""
        tab = QWidget()
        layout = QVBoxLayout(tab)
        
        # 日志标题
        logs_title = QLabel("📝 系统日志")
        logs_title.setStyleSheet("font-size: 16px; font-weight: bold;")
        logs_title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(logs_title)
        
        # 日志级别选择
        level_layout = QHBoxLayout()
        level_layout.addWidget(QLabel("日志级别:"))
        
        self.log_level_combo = QComboBox()
        self.log_level_combo.addItems(["DEBUG", "INFO", "WARNING", "ERROR"])
        self.log_level_combo.setCurrentText("INFO")
        self.log_level_combo.currentTextChanged.connect(self.change_log_level)
        level_layout.addWidget(self.log_level_combo)
        
        level_layout.addStretch()
        layout.addLayout(level_layout)
        
        # 日志显示区域
        self.log_text = QTextEdit()
        self.log_text.setReadOnly(True)
        
        # 设置等宽字体
        font = QFont("Courier New", 9)
        self.log_text.setFont(font)
        
        # 添加示例日志
        self.log_text.setPlainText("""[2026-03-19 23:30:01] INFO: 应用程序启动
[2026-03-19 23:30:02] INFO: 加载配置文件成功
[2026-03-19 23:30:03] INFO: 初始化OCR引擎完成
[2026-03-19 23:30:04] INFO: 检测到游戏窗口: 石器时代
[2026-03-19 23:30:05] INFO: 开始监控验证码
[2026-03-19 23:31:15] INFO: 检测到验证码
[2026-03-19 23:31:16] INFO: 识别结果: ABCD (置信度: 95%)
[2026-03-19 23:31:17] INFO: 输入验证码成功""")
        
        layout.addWidget(self.log_text)
        
        # 日志操作按钮
        log_btn_layout = QHBoxLayout()
        
        # 清空日志按钮
        clear_log_btn = QPushButton("🗑️ 清空日志")
        clear_log_btn.clicked.connect(self.clear_logs)
        log_btn_layout.addWidget(clear_log_btn)
        
        # 保存日志按钮
        save_log_btn = QPushButton("💾 保存日志")
        save_log_btn.clicked.connect(self.save_logs)
        log_btn_layout.addWidget(save_log_btn)
        
        # 刷新日志按钮
        refresh_log_btn = QPushButton("🔄 刷新日志")
        refresh_log_btn.clicked.connect(self.refresh_logs)
        log_btn_layout.addWidget(refresh_log_btn)
        
        layout.addLayout(log_btn_layout)
        
        return tab
    
    def _create_ocr_tab(self) -> QWidget:
        """创建OCR引擎管理标签页"""
        tab = QWidget()
        layout = QVBoxLayout(tab)
        
        # OCR标题
        ocr_title = QLabel("🔤 OCR引擎管理 v2.0")
        ocr_title.setStyleSheet("font-size: 16px; font-weight: bold;")
        ocr_title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(ocr_title)
        
        # 引擎状态组
        engine_group = QGroupBox("引擎状态")
        engine_layout = QVBoxLayout()
        
        # 可用引擎列表
        self.available_engines_label = QLabel("可用引擎: 加载中...")
        engine_layout.addWidget(self.available_engines_label)
        
        # 当前配置
        self.current_config_label = QLabel("当前配置: 加载中...")
        engine_layout.addWidget(self.current_config_label)
        
        # 性能统计
        self.performance_stats_label = QLabel("性能统计: 加载中...")
        engine_layout.addWidget(self.performance_stats_label)
        
        engine_group.setLayout(engine_layout)
        layout.addWidget(engine_group)
        
        # 引擎控制组
        control_group = QGroupBox("引擎控制")
        control_layout = QGridLayout()
        
        # 主引擎选择
        control_layout.addWidget(QLabel("主引擎:"), 0, 0)
        self.primary_engine_combo = QComboBox()
        self.primary_engine_combo.addItems(["tesseract", "easyocr", "paddleocr"])
        control_layout.addWidget(self.primary_engine_combo, 0, 1)
        
        # 集成方法选择
        control_layout.addWidget(QLabel("集成方法:"), 1, 0)
        self.ensemble_method_combo = QComboBox()
        self.ensemble_method_combo.addItems(["confidence", "voting", "weighted"])
        control_layout.addWidget(self.ensemble_method_combo, 1, 1)
        
        # 缓存启用
        self.cache_enabled_check = QCheckBox("启用结果缓存")
        self.cache_enabled_check.setChecked(True)
        control_layout.addWidget(self.cache_enabled_check, 2, 0, 1, 2)
        
        # 预处理启用
        self.preprocessing_check = QCheckBox("启用图像预处理")
        self.preprocessing_check.setChecked(True)
        control_layout.addWidget(self.preprocessing_check, 3, 0, 1, 2)
        
        control_group.setLayout(control_layout)
        layout.addWidget(control_group)
        
        # 测试组
        test_group = QGroupBox("引擎测试")
        test_layout = QVBoxLayout()
        
        # 测试图像选择
        test_image_layout = QHBoxLayout()
        test_image_layout.addWidget(QLabel("测试图像:"))
        self.test_image_path_edit = QLineEdit()
        self.test_image_path_edit.setPlaceholderText("选择测试图像...")
        test_image_layout.addWidget(self.test_image_path_edit)
        
        browse_btn = QPushButton("浏览...")
        browse_btn.clicked.connect(self.browse_test_image)
        test_image_layout.addWidget(browse_btn)
        
        test_layout.addLayout(test_image_layout)
        
        # 测试按钮
        test_btn_layout = QHBoxLayout()
        
        single_test_btn = QPushButton("🔧 单引擎测试")
        single_test_btn.clicked.connect(self.run_single_engine_test)
        test_btn_layout.addWidget(single_test_btn)
        
        ensemble_test_btn = QPushButton("🎯 集成测试")
        ensemble_test_btn.clicked.connect(self.run_ensemble_test)
        test_btn_layout.addWidget(ensemble_test_btn)
        
        benchmark_btn = QPushButton("📊 基准测试")
        benchmark_btn.clicked.connect(self.run_benchmark_test)
        test_btn_layout.addWidget(benchmark_btn)
        
        test_layout.addLayout(test_btn_layout)
        
        # 测试结果
        self.test_result_text = QTextEdit()
        self.test_result_text.setMaximumHeight(150)
        self.test_result_text.setReadOnly(True)
        test_layout.addWidget(self.test_result_text)
        
        test_group.setLayout(test_layout)
        layout.addWidget(test_group)
        
        # 优化建议组
        suggestion_group = QGroupBox("💡 优化建议")
        suggestion_layout = QVBoxLayout()
        
        self.suggestion_text = QTextEdit()
        self.suggestion_text.setMaximumHeight(100)
        self.suggestion_text.setReadOnly(True)
        self.suggestion_text.setPlainText("加载优化建议...")
        suggestion_layout.addWidget(self.suggestion_text)
        
        optimize_btn = QPushButton("🔄 运行优化分析")
        optimize_btn.clicked.connect(self.run_optimization_analysis)
        suggestion_layout.addWidget(optimize_btn)
        
        suggestion_group.setLayout(suggestion_layout)
        layout.addWidget(suggestion_group)
        
        # 操作按钮
        ocr_btn_layout = QHBoxLayout()
        
        save_config_btn = QPushButton("💾 保存OCR配置")
        save_config_btn.clicked.connect(self.save_ocr_config)
        ocr_btn_layout.addWidget(save_config_btn)
        
        reload_btn = QPushButton("🔄 重新加载引擎")
        reload_btn.clicked.connect(self.reload_ocr_engines)
        ocr_btn_layout.addWidget(reload_btn)
        
        layout.addLayout(ocr_btn_layout)
        
        # 初始化OCR信息
        QTimer.singleShot(100, self.update_ocr_info)
        
        return tab
    
    def _create_error_tab(self) -> QWidget:
        """创建错误监控标签页"""
        tab = QWidget()
        layout = QVBoxLayout(tab)
        
        # 错误监控标题
        error_title = QLabel("🛡️ 错误监控系统")
        error_title.setStyleSheet("font-size: 16px; font-weight: bold;")
        error_title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(error_title)
        
        # 错误统计组
        stats_group = QGroupBox("错误统计")
        stats_layout = QGridLayout()
        
        # 总错误数
        stats_layout.addWidget(QLabel("总错误数:"), 0, 0)
        self.total_errors_label = QLabel("0")
        stats_layout.addWidget(self.total_errors_label, 0, 1)
        
        # 最近24小时
        stats_layout.addWidget(QLabel("最近24小时:"), 1, 0)
        self.recent_errors_label = QLabel("0")
        stats_layout.addWidget(self.recent_errors_label, 1, 1)
        
        # 恢复成功率
        stats_layout.addWidget(QLabel("恢复成功率:"), 2, 0)
        self.recovery_rate_label = QLabel("0%")
        stats_layout.addWidget(self.recovery_rate_label, 2, 1)
        
        # 最后错误时间
        stats_layout.addWidget(QLabel("最后错误:"), 3, 0)
        self.last_error_time_label = QLabel("从未")
        stats_layout.addWidget(self.last_error_time_label, 3, 1)
        
        stats_group.setLayout(stats_layout)
        layout.addWidget(stats_group)
        
        # 错误类型分布
        type_group = QGroupBox("错误类型分布")
        type_layout = QVBoxLayout()
        
        self.error_type_text = QTextEdit()
        self.error_type_text.setMaximumHeight(100)
        self.error_type_text.setReadOnly(True)
        self.error_type_text.setPlainText("加载错误类型分布...")
        type_layout.addWidget(self.error_type_text)
        
        type_group.setLayout(type_layout)
        layout.addWidget(type_group)
        
        # 最近错误列表
        recent_group = QGroupBox("最近错误")
        recent_layout = QVBoxLayout()
        
        self.recent_errors_text = QTextEdit()
        self.recent_errors_text.setReadOnly(True)
        self.recent_errors_text.setPlainText("加载最近错误...")
        
        # 设置等宽字体
        font = QFont("Courier New", 9)
        self.recent_errors_text.setFont(font)
        
        recent_layout.addWidget(self.recent_errors_text)
        
        recent_group.setLayout(recent_layout)
        layout.addWidget(recent_group)
        
        # 错误操作按钮
        error_btn_layout = QHBoxLayout()
        
        refresh_btn = QPushButton("🔄 刷新错误统计")
        refresh_btn.clicked.connect(self.refresh_error_stats)
        error_btn_layout.addWidget(refresh_btn)
        
        clear_btn = QPushButton("🗑️ 清空错误历史")
        clear_btn.clicked.connect(self.clear_error_history)
        error_btn_layout.addWidget(clear_btn)
        
        report_btn = QPushButton("📄 生成错误报告")
        report_btn.clicked.connect(self.generate_error_report)
        error_btn_layout.addWidget(report_btn)
        
        test_btn = QPushButton("🧪 测试错误处理")
        test_btn.clicked.connect(self.test_error_handling)
        error_btn_layout.addWidget(test_btn)
        
        layout.addLayout(error_btn_layout)
        
        # 监控控制组
        monitor_group = QGroupBox("监控控制")
        monitor_layout = QHBoxLayout()
        
        self.monitor_enabled_check = QCheckBox("启用错误监控")
        self.monitor_enabled_check.setChecked(True)
        monitor_layout.addWidget(self.monitor_enabled_check)
        
        self.notify_critical_check = QCheckBox("严重错误通知")
        self.notify_critical_check.setChecked(False)
        monitor_layout.addWidget(self.notify_critical_check)
        
        self.auto_recovery_check = QCheckBox("自动恢复")
        self.auto_recovery_check.setChecked(True)
        monitor_layout.addWidget(self.auto_recovery_check)
        
        monitor_group.setLayout(monitor_layout)
        layout.addWidget(monitor_group)
        
        # 初始化错误信息
        QTimer.singleShot(100, self.update_error_info)
        
        return tab
    
    def _create_config_tab(self) -> QWidget:
        """创建配置管理标签页"""
        tab = QWidget()
        layout = QVBoxLayout(tab)
        
        # 配置标题
        config_title = QLabel("⚙️ 系统配置")
        config_title.setStyleSheet("font-size: 16px; font-weight: bold;")
        config_title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(config_title)
        
        # 配置编辑区域
        self.config_text = QTextEdit()
        self.config_text.setPlainText("""{
  "game": {
    "window_title": "石器时代",
    "check_interval": 5
  },
  "ocr": {
    "engine": "tesseract",
    "language": "eng"
  },
  "system": {
    "log_level": "INFO",
    "auto_start": false
  }
}""")
        
        # 设置等宽字体
        font = QFont("Courier New", 10)
        self.config_text.setFont(font)
        
        layout.addWidget(self.config_text)
        
        # 配置操作按钮
        config_btn_layout = QHBoxLayout()
        
        # 加载配置按钮
        load_btn = QPushButton("📂 加载配置")
        load_btn.clicked.connect(self.load_config)
        config_btn_layout.addWidget(load_btn)
        
        # 保存配置按钮
        save_btn = QPushButton("💾 保存配置")
        save_btn.clicked.connect(self.save_config)
        config_btn_layout.addWidget(save_btn)
        
        # 重置配置按钮
        reset_btn = QPushButton("🔄 重置配置")
        reset_btn.clicked.connect(self.reset_config)
        config_btn_layout.addWidget(reset_btn)
        
        layout.addLayout(config_btn_layout)
        
        return tab
    
    def _create_status_bar(self):
        """创建状态栏"""
        self.status_bar = QStatusBar()
        self.setStatusBar(self.status_bar)
        
        # 状态标签
        self.status_label = QLabel("就绪")
        self.status_bar.addWidget(self.status_label)
        
        # 添加永久部件
        self.memory_label = QLabel("内存: --")
        self.status_bar.addPermanentWidget(self.memory_label)
        
        self.cpu_label = QLabel("CPU: --")
        self.status_bar.addPermanentWidget(self.cpu_label)
        
        self.time_label = QLabel("时间: --")
        self.status_bar.addPermanentWidget(self.time_label)
    
    def _apply_styles(self):
        """应用样式表"""
        style_sheet = """
        QMainWindow {
            background-color: #2c3e50;
        }
        
        QGroupBox {
            font-weight: bold;
            border: 2px solid #34495e;
            border-radius: 5px;
            margin-top: 10px;
            padding-top: 10px;
        }
        
        QGroupBox::title {
            subcontrol-origin: margin;
            left: 10px;
            padding: 0 5px 0 5px;
        }
        
        QPushButton {
            background-color: #3498db;
            color: white;
            border: none;
            padding: 8px;
            border-radius: 4px;
        }
        
        QPushButton:hover {
            background-color: #2980b9;
        }
        
        QPushButton:pressed {
            background-color: #1c6ea4;
        }
        
        QTabWidget::pane {
            border: 1px solid #34495e;
            background-color: #34495e;
        }
        
        QTabBar::tab {
            background-color: #2c3e50;
            color: #ecf0f1;
            padding: 8px 16px;
            margin-right: 2px;
        }
        
        QTabBar::tab:selected {
            background-color: #3498db;
        }
        
        QTextEdit {
            background-color: #1c2833;
            color: #ecf0f1;
            border: 1px solid #34495e;
            border-radius: 4px;
        }
        
        QLabel {
            color: #ecf0f1;
        }
        """
        
        self.setStyleSheet(style_sheet)
    
    def _create_icon(self) -> QIcon:
        """创建应用程序图标"""
        # 在实际实现中，这里会加载图标文件
        # 暂时返回空图标
        return QIcon()
    
    def init_timers(self):
        """初始化定时器"""
        # 状态更新定时器
        self.status_timer = QTimer()
        self.status_timer.timeout.connect(self.update_status)
        self.status_timer.start(1000)  # 每秒更新一次
        
        # 内存监控定时器
        self.memory_timer = QTimer()
        self.memory_timer.timeout.connect(self.update_system_info)
        self.memory_timer.start(5000)  # 每5秒更新一次
    
    def init_system_tray(self):
        """初始化系统托盘"""
        if QSystemTrayIcon.isSystemTrayAvailable():
            self.tray_icon = QSystemTrayIcon(self)
            self.tray_icon.setIcon(self._create_icon())
            
            # 创建托盘菜单
            tray_menu = QMenu()
            
            show_action = QAction("显示窗口", self)
            show_action.triggered.connect(self.show)
            tray_menu.addAction(show_action)
            
            hide_action = QAction("隐藏窗口", self)
            hide_action.triggered.connect(self.hide)
            tray_menu.addAction(hide_action)
            
            tray_menu.addSeparator()
            
            quit_action = QAction("退出", self)
            quit_action.triggered.connect(self.close)
            tray_menu.addAction(quit_action)
            
            self.tray_icon.setContextMenu(tray_menu)
            self.tray_icon.show()
    
    # ========== 槽函数 ==========
    
    @pyqtSlot()
    def toggle_recognition(self):
        """切换识别状态"""
        if self.start_stop_btn.text().startswith("▶"):
            # 开始识别
            self.start_stop_btn.setText("⏸ 停止识别")
            self.start_stop_btn.setStyleSheet("""
                QPushButton {
                    background-color: #e74c3c;
                    color: white;
                    font-weight: bold;
                    padding: 10px;
                    border-radius: 5px;
                }
                QPushButton:hover {
                    background-color: #c0392b;
                }
            """)
            self.status_label.setText("识别进行中...")
            self.recognition_started.emit()
        else:
            # 停止识别
            self.start_stop_btn.setText("▶ 开始识别")
            self.start_stop_btn.setStyleSheet("""
                QPushButton {
                    background-color: #4CAF50;
                    color: white;
                    font-weight: bold;
                    padding: 10px;
                    border-radius: 5px;
                }
                QPushButton:hover {
                    background-color: #45a049;
                }
            """)
            self.status_label.setText("识别已停止")
            self.recognition_stopped.emit()
    
    @pyqtSlot()
    def manual_recognition(self):
        """手动识别"""
        QMessageBox.information(self, "手动识别", "手动识别功能开发中...")
    
    @pyqtSlot()
    def open_settings(self):
        """打开设置对话框"""
        QMessageBox.information(self, "设置", "设置对话框开发中...")
    
    @pyqtSlot()
    def refresh_preview(self):
        """刷新预览"""
        self.preview_label.setText("刷新中...")
        QTimer.singleShot(1000, lambda: self.preview_label.setText("预览已刷新"))
    
    @pyqtSlot()
    def save_captcha_image(self):
        """保存验证码图像"""
        QMessageBox.information(self, "保存图像", "图像保存功能开发中...")
    
    @pyqtSlot()
    def test_recognition(self):
        """测试识别"""
        self.recognition_result_label.setText("测试结果: TEST")
        self.confidence_label.setText("99%")
        self.processing_time_label.setText("0.1秒")
    
    @pyqtSlot()
    def clear_results(self):
        """清空结果"""
        self.results_text.clear()
    
    @pyqtSlot()
    def export_results(self):
        """导出结果"""
        QMessageBox.information(self, "导出结果", "结果导出功能开发中...")
    
    @pyqtSlot()
    def show_statistics(self):
        """显示统计"""
        QMessageBox.information(self, "统计", "统计功能开发中...")
    
    @pyqtSlot()
    def change_log_level(self, level: str):
        """更改日志级别"""
        self.log_text.append(f"[系统] 日志级别更改为: {level}")
    
    @pyqtSlot()
    def clear_logs(self):
        """清空日志"""
        self.log_text.clear()
        self.log_text.append("[系统] 日志已清空")
    
    @pyqtSlot()
    def save_logs(self):
        """保存日志"""
        QMessageBox.information(self, "保存日志", "日志保存功能开发中...")
    
    @pyqtSlot()
    def refresh_logs(self):
        """刷新日志"""
        self.log_text.append("[系统] 日志已刷新")
    
    @pyqtSlot()
    def load_config(self):
        """加载配置"""
        QMessageBox.information(self, "加载配置", "配置加载功能开发中...")
    
    @pyqtSlot()
    def save_config(self):
        """保存配置"""
        config_text = self.config_text.toPlainText()
        self.config_text.append("\n// 配置已保存")
        self.config_changed.emit({"config": config_text})
    
    @pyqtSlot()
    def reset_config(self):
        """重置配置"""
        reply = QMessageBox.question(self, "重置配置", 
                                    "确定要重置为默认配置吗？",
                                    QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        if reply == QMessageBox.StandardButton.Yes:
            self.config_text.setPlainText("""{
  "game": {
    "window_title": "石器时代",
    "check_interval": 5
  },
  "ocr": {
    "engine": "tesseract",
    "language": "eng"
  },
  "system": {
    "log_level": "INFO",
    "auto_start": false
  }
}""")
    
    @pyqtSlot()
    def update_status(self):
        """更新状态"""
        current_time = QTime.currentTime().toString("hh:mm:ss")
        self.time_label.setText(f"时间: {current_time}")
    
    @pyqtSlot()
    def update_system_info(self):
        """更新系统信息"""
        # 在实际实现中，这里会获取真实的系统信息
        self.memory_label.setText("内存: 128MB/2GB")
        self.cpu_label.setText("CPU: 15%")
        
        # 更新OCR统计
        self.update_ocr_stats()
        
        # 更新错误统计
        self.update_error_stats()
    
    # ========== 新功能槽函数 ==========
    
    @pyqtSlot(str, str)
    def on_error_occurred(self, error_type: str, error_message: str):
        """处理错误信号"""
        self.status_label.setText(f"错误: {error_type}")
        self.log_text.append(f"[错误] {error_type}: {error_message}")
    
    @pyqtSlot(str)
    def on_status_updated(self, status_message: str):
        """处理状态更新信号"""
        self.status_label.setText(status_message)
    
    @pyqtSlot()
    def update_ocr_info(self):
        """更新OCR信息"""
        if not self.ocr_engine:
            self.available_engines_label.setText("可用引擎: OCR引擎未初始化")
            return
        
        # 更新可用引擎
        engines = self.ocr_engine.available_engines
        self.available_engines_label.setText(f"可用引擎: {', '.join(engines) if engines else '无'}")
        
        # 更新性能统计
        try:
            stats = self.ocr_engine.get_performance_stats()
            self.performance_stats_label.setText(
                f"性能: {stats['success_rate']:.1%} 成功率, {stats['average_confidence']:.1%} 置信度"
            )
        except Exception as e:
            self.logger.error(f"获取OCR性能统计失败: {e}")
    
    @pyqtSlot()
    def update_ocr_stats(self):
        """更新OCR统计到左侧面板"""
        if not self.ocr_engine:
            self.ocr_stats_label.setText("OCR引擎: 未初始化")
            return
        
        try:
            stats = self.ocr_engine.get_performance_stats()
            engine_count = len(self.ocr_engine.available_engines)
            self.ocr_stats_label.setText(f"OCR引擎: {engine_count}个, {stats['success_rate']:.1%} 成功率")
        except Exception as e:
            self.ocr_stats_label.setText("OCR引擎: 统计失败")
    
    @pyqtSlot()
    def update_error_info(self):
        """更新错误信息"""
        if not self.error_handler:
            self.total_errors_label.setText("错误系统未初始化")
            return
        
        try:
            summary = self.error_handler.get_error_summary()
            
            # 更新统计标签
            self.total_errors_label.setText(str(summary['total_errors']))
            self.recent_errors_label.setText(str(summary['recent_24h']))
            self.recovery_rate_label.setText(f"{summary['recovery_stats']['success_rate']:.1%}")
            
            if summary['last_error_time']:
                from datetime import datetime
                last_time = datetime.fromtimestamp(summary['last_error_time']).strftime("%H:%M:%S")
                self.last_error_time_label.setText(last_time)
            
            # 更新错误类型分布
            type_text = ""
            for etype, count in summary['by_type'].items():
                type_text += f"{etype}: {count}\n"
            self.error_type_text.setPlainText(type_text.strip())
            
            # 更新最近错误
            recent_text = ""
            for error in self.error_handler.error_history[-10:]:  # 最近10个错误
                time_str = datetime.fromtimestamp(error.timestamp).strftime("%H:%M:%S")
                recent_text += f"[{time_str}] {error.error_type.value}: {error.message[:50]}...\n"
            self.recent_errors_text.setPlainText(recent_text.strip())
            
        except Exception as e:
            self.logger.error(f"更新错误信息失败: {e}")
    
    @pyqtSlot()
    def update_error_stats(self):
        """更新错误统计到左侧面板"""
        if not self.error_handler:
            self.error_stats_label.setText("错误系统: 未初始化")
            return
        
        try:
            summary = self.error_handler.get_error_summary()
            self.error_stats_label.setText(
                f"错误: {summary['total_errors']} (恢复: {summary['recovery_stats']['success_rate']:.1%})"
            )
        except Exception as e:
            self.error_stats_label.setText("错误系统: 统计失败")
    
    @pyqtSlot()
    def browse_test_image(self):
        """浏览测试图像"""
        from PyQt6.QtWidgets import QFileDialog
        
        file_path, _ = QFileDialog.getOpenFileName(
            self, "选择测试图像", 
            str(Path.home() / "StoneCaptcha" / "test_captchas"),
            "图像文件 (*.png *.jpg *.jpeg *.bmp)"
        )
        
        if file_path:
            self.test_image_path_edit.setText(file_path)
    
    @pyqtSlot()
    def run_single_engine_test(self):
        """运行单引擎测试"""
        image_path = self.test_image_path_edit.text().strip()
        if not image_path or not os.path.exists(image_path):
            QMessageBox.warning(self, "警告", "请选择有效的测试图像")
            return
        
        if not self.ocr_engine:
            QMessageBox.warning(self, "警告", "OCR引擎未初始化")
            return
        
        engine_name = self.primary_engine_combo.currentText()
        
        self.test_result_text.append(f"🔧 测试 {engine_name} 引擎...")
        
        try:
            start_time = time.time()
            result = self.ocr_engine.recognize(image_path, engine=engine_name)
            processing_time = time.time() - start_time
            
            if result:
                self.test_result_text.append(f"  结果: {result.text}")
                self.test_result_text.append(f"  置信度: {result.confidence:.1%}")
                self.test_result_text.append(f"  时间: {processing_time:.2f}秒")
                self.test_result_text.append("")
            else:
                self.test_result_text.append("  识别失败")
                self.test_result_text.append("")
                
        except Exception as e:
            self.test_result_text.append(f"  测试失败: {e}")
            self.test_result_text.append("")
    
    @pyqtSlot()
    def run_ensemble_test(self):
        """运行集成测试"""
        image_path = self.test_image_path_edit.text().strip()
        if not image_path or not os.path.exists(image_path):
            QMessageBox.warning(self, "警告", "请选择有效的测试图像")
            return
        
        if not self.ocr_engine:
            QMessageBox.warning(self, "警告", "OCR引擎未初始化")
            return
        
        if len(self.ocr_engine.available_engines) < 2:
            QMessageBox.warning(self, "警告", "需要至少2个引擎进行集成测试")
            return
        
        self.test_result_text.append("🎯 测试集成识别...")
        
        try:
            start_time = time.time()
            result = self.ocr_engine.recognize(image_path, engine='all')
            processing_time = time.time() - start_time
            
            if result:
                self.test_result_text.append(f"  结果: {result.text}")
                self.test_result_text.append(f"  置信度: {result.confidence:.1%}")
                self.test_result_text.append(f"  时间: {processing_time:.2f}秒")
                self.test_result_text.append(f"  方法: {result.engine}")
                self.test_result_text.append("")
            else:
                self.test_result_text.append("  集成识别失败")
                self.test_result_text.append("")
                
        except Exception as e:
            self.test_result_text.append(f"  集成测试失败: {e}")
            self.test_result_text.append("")
    
    @pyqtSlot()
    def run_benchmark_test(self):
        """运行基准测试"""
        QMessageBox.information(self, "基准测试", "基准测试功能开发中...")
    
    @pyqtSlot()
    def run_optimization_analysis(self):
        """运行优化分析"""
        if not self.ocr_engine:
            QMessageBox.warning(self, "警告", "OCR引擎未初始化")
            return
        
        self.suggestion_text.setPlainText("正在分析优化建议...")
        
        try:
            suggestions = self.ocr_engine.optimize_engine_selection()
            
            suggestion_text = "💡 优化建议:\n"
            for suggestion in suggestions['suggestions']:
                suggestion_text += f"• {suggestion}\n"
            
            if suggestions['recommendations']:
                suggestion_text += "\n🎯 推荐配置:\n"
                for rec in suggestions['recommendations']:
                    suggestion_text += f"• {rec['reason']}\n"
            
            self.suggestion_text.setPlainText(suggestion_text.strip())
            
        except Exception as e:
            self.suggestion_text.setPlainText(f"优化分析失败: {e}")
    
    @pyqtSlot()
    def save_ocr_config(self):
        """保存OCR配置"""
        QMessageBox.information(self, "保存配置", "OCR配置保存功能开发中...")
    
    @pyqtSlot()
    def reload_ocr_engines(self):
        """重新加载OCR引擎"""
        try:
            from src.core.ocr_multi_engine import OCRMultiEngine
            self.ocr_engine = OCRMultiEngine()
            self.update_ocr_info()
            QMessageBox.information(self, "重新加载", "OCR引擎重新加载成功")
        except Exception as e:
            QMessageBox.warning(self, "重新加载失败", f"重新加载OCR引擎失败: {e}")
    
    @pyqtSlot()
    def refresh_error_stats(self):
        """刷新错误统计"""
        self.update_error_info()
        QMessageBox.information(self, "刷新", "错误统计已刷新")
    
    @pyqtSlot()
    def clear_error_history(self):
        """清空错误历史"""
        if not self.error_handler:
            QMessageBox.warning(self, "警告", "错误处理器未初始化")
            return
        
        reply = QMessageBox.question(self, "清空错误历史", 
                                    "确定要清空所有错误历史吗？",
                                    QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        if reply == QMessageBox.StandardButton.Yes:
            self.error_handler.clear_history()
            self.update_error_info()
            QMessageBox.information(self, "清空", "错误历史已清空")
    
    @pyqtSlot()
    def generate_error_report(self):
        """生成错误报告"""
        if not self.error_handler:
            QMessageBox.warning(self, "警告", "错误处理器未初始化")
            return
        
        try:
            from pathlib import Path
            report_dir = Path.home() / "StoneCaptcha" / "reports"
            report_dir.mkdir(parents=True, exist_ok=True)
            
            import time
            report_file = report_dir / f"error_report_{int(time.time())}.json"
            
            if self.error_handler.save_error_report(str(report_file)):
                QMessageBox.information(self, "生成报告", f"错误报告已保存:\n{report_file}")
            else:
                QMessageBox.warning(self, "生成报告失败", "保存错误报告失败")
                
        except Exception as e:
            QMessageBox.warning(self, "生成报告失败", f"生成错误报告失败: {e}")
    
    @pyqtSlot()
    def test_error_handling(self):
        """测试错误处理"""
        try:
            # 故意引发一个错误来测试错误处理系统
            raise ValueError("测试错误: 这是故意的错误处理测试")
        except Exception as e:
            if self.error_handler:
                self.error_handler.record_error(e)
                QMessageBox.information(self, "错误处理测试", "错误已记录到错误处理系统")
            else:
                QMessageBox.warning(self, "错误处理测试", "错误处理器未初始化")
    
    @pyqtSlot()
    def update_system_info(self):
    
    def closeEvent(self, event):
        """关闭事件处理"""
        if hasattr(self, 'tray_icon') and self.tray_icon.isVisible():
            reply = QMessageBox.question(self, "退出",
                                        "确定要退出程序吗？",
                                        QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
            if reply == QMessageBox.StandardButton.Yes:
                event.accept()
            else:
                event.ignore()
        else:
            event.accept()

# 导入缺失的类
try:
    from PyQt6.QtWidgets import QComboBox, QCheckBox, QLineEdit, QFileDialog
    from PyQt6.QtCore import QTime
    import time
    from datetime import datetime
    from pathlib import Path
    import os
except ImportError:
    pass

# 测试函数
def test_main_window():
    """测试主窗口 v2.0"""
    print("🔍 测试主窗口 v2.0")
    print("=" * 50)
    
    if not PYQT6_AVAILABLE:
        print("❌ PyQt6未安装，无法测试GUI")
        print("💡 请安装: pip install PyQt6")
        return
    
    # 设置日志
    import logging
    logging.basicConfig(level=logging.INFO)
    logger = logging.getLogger(__name__)
    
    # 创建配置管理器（模拟）
    class MockConfigManager:
        def __init__(self):
            self.config_dir = "~/StoneCaptcha/configs"
        
        def load_config(self):
            return {
                'version': '2.0.0',
                'description': '测试配置'
            }
    
    app = QApplication(sys.argv)
    
    # 设置应用程序信息
    app.setApplicationName("石器时代验证码识别工具")
    app.setApplicationVersion("2.0.0")
    app.setOrganizationName("StoneCaptcha")
    
    # 创建主窗口
    config_manager = MockConfigManager()
    window = MainWindow(config_manager, logger)
    window.show()
    
    print("✅ 主窗口 v2.0 创建成功")
    print("💡 新功能:")
    print("  • 🔤 OCR引擎管理标签页")
    print("  • 🛡️  错误监控标签页")
    print("  • 📊 实时统计更新")
    print("  • 🎯 集成测试功能")
    print("\n⚠️  按窗口关闭按钮退出测试")
    
    sys.exit(app.exec())

if __name__ == "__main__":
    test_main_window()