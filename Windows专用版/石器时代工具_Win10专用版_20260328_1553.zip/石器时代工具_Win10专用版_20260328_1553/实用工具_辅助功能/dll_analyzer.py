#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
DLL分析器 - 分析原软件OCR库的算法和接口
"""

import os
import sys
import struct
import logging
from pathlib import Path
from typing import Dict, List, Optional, Tuple
import pefile

class DLLAnalyzer:
    """DLL文件分析器"""
    
    def __init__(self, dll_path: str):
        """
        初始化DLL分析器
        
        Args:
            dll_path: DLL文件路径
        """
        self.logger = logging.getLogger(__name__)
        self.dll_path = Path(dll_path)
        
        if not self.dll_path.exists():
            raise FileNotFoundError(f"DLL文件不存在: {dll_path}")
        
        self.pe = None
        self.analysis_result = {
            'file_info': {},
            'imports': [],
            'exports': [],
            'sections': [],
            'resources': [],
            'analysis': {}
        }
        
        self.logger.info(f"DLL分析器初始化完成: {self.dll_path}")
    
    def analyze_basic_info(self) -> Dict[str, any]:
        """分析基本文件信息"""
        try:
            self.pe = pefile.PE(str(self.dll_path))
            
            file_info = {
                'filename': self.dll_path.name,
                'size': self.dll_path.stat().st_size,
                'md5': self._calculate_md5(),
                'machine_type': self._get_machine_type(),
                'timestamp': self._get_timestamp(),
                'entry_point': hex(self.pe.OPTIONAL_HEADER.AddressOfEntryPoint),
                'image_base': hex(self.pe.OPTIONAL_HEADER.ImageBase),
                'subsystem': self._get_subsystem(),
                'characteristics': self._get_characteristics()
            }
            
            self.analysis_result['file_info'] = file_info
            self.logger.info(f"基本文件信息分析完成")
            return file_info
            
        except Exception as e:
            self.logger.error(f"分析基本文件信息失败: {e}")
            return {}
    
    def analyze_imports(self) -> List[Dict]:
        """分析导入函数"""
        imports = []
        
        try:
            if hasattr(self.pe, 'DIRECTORY_ENTRY_IMPORT'):
                for entry in self.pe.DIRECTORY_ENTRY_IMPORT:
                    dll_name = entry.dll.decode('utf-8', errors='ignore')
                    
                    for imp in entry.imports:
                        if imp.name:
                            func_name = imp.name.decode('utf-8', errors='ignore')
                            imports.append({
                                'dll': dll_name,
                                'function': func_name,
                                'address': hex(imp.address) if imp.address else 'N/A'
                            })
            
            self.analysis_result['imports'] = imports
            self.logger.info(f"导入函数分析完成: {len(imports)}个函数")
            return imports
            
        except Exception as e:
            self.logger.error(f"分析导入函数失败: {e}")
            return []
    
    def analyze_exports(self) -> List[Dict]:
        """分析导出函数"""
        exports = []
        
        try:
            if hasattr(self.pe, 'DIRECTORY_ENTRY_EXPORT'):
                export_dir = self.pe.DIRECTORY_ENTRY_EXPORT
                
                for exp in export_dir.symbols:
                    if exp.name:
                        func_name = exp.name.decode('utf-8', errors='ignore')
                        exports.append({
                            'name': func_name,
                            'ordinal': exp.ordinal,
                            'address': hex(exp.address + self.pe.OPTIONAL_HEADER.ImageBase),
                            'hint': exp.hint
                        })
            
            self.analysis_result['exports'] = exports
            self.logger.info(f"导出函数分析完成: {len(exports)}个函数")
            return exports
            
        except Exception as e:
            self.logger.error(f"分析导出函数失败: {e}")
            return []
    
    def analyze_sections(self) -> List[Dict]:
        """分析节区信息"""
        sections = []
        
        try:
            for section in self.pe.sections:
                section_info = {
                    'name': section.Name.decode('utf-8', errors='ignore').strip('\x00'),
                    'virtual_address': hex(section.VirtualAddress),
                    'virtual_size': section.Misc_VirtualSize,
                    'raw_size': section.SizeOfRawData,
                    'characteristics': hex(section.Characteristics),
                    'entropy': section.get_entropy()
                }
                sections.append(section_info)
            
            self.analysis_result['sections'] = sections
            self.logger.info(f"节区信息分析完成: {len(sections)}个节区")
            return sections
            
        except Exception as e:
            self.logger.error(f"分析节区信息失败: {e}")
            return []
    
    def analyze_resources(self) -> List[Dict]:
        """分析资源信息"""
        resources = []
        
        try:
            if hasattr(self.pe, 'DIRECTORY_ENTRY_RESOURCE'):
                for resource_type in self.pe.DIRECTORY_ENTRY_RESOURCE.entries:
                    if resource_type.name is not None:
                        type_name = str(resource_type.name)
                    else:
                        type_name = pefile.RESOURCE_TYPE.get(resource_type.struct.Id, 'UNKNOWN')
                    
                    if hasattr(resource_type, 'directory'):
                        for resource_id in resource_type.directory.entries:
                            if hasattr(resource_id, 'directory'):
                                for resource_lang in resource_id.directory.entries:
                                    resource_info = {
                                        'type': type_name,
                                        'id': resource_id.struct.Id,
                                        'language': resource_lang.data.struct.Lang,
                                        'size': resource_lang.data.struct.Size,
                                        'offset': hex(resource_lang.data.struct.OffsetToData)
                                    }
                                    resources.append(resource_info)
            
            self.analysis_result['resources'] = resources
            self.logger.info(f"资源信息分析完成: {len(resources)}个资源")
            return resources
            
        except Exception as e:
            self.logger.error(f"分析资源信息失败: {e}")
            return []
    
    def analyze_ocr_specific(self) -> Dict[str, any]:
        """分析OCR特定信息"""
        ocr_analysis = {
            'likely_ocr_functions': [],
            'image_processing_hints': [],
            'character_recognition_patterns': [],
            'recommendations': []
        }
        
        try:
            # 分析导出函数名中的OCR相关模式
            exports = self.analysis_result.get('exports', [])
            
            ocr_keywords = ['ocr', 'recognize', 'image', 'captcha', 'text', 'char', 'digit', 'letter']
            image_keywords = ['process', 'filter', 'threshold', 'binary', 'gray', 'noise']
            
            for export in exports:
                func_name = export['name'].lower()
                
                # 检查OCR相关函数
                for keyword in ocr_keywords:
                    if keyword in func_name:
                        ocr_analysis['likely_ocr_functions'].append({
                            'function': export['name'],
                            'address': export['address'],
                            'keyword': keyword
                        })
                        break
                
                # 检查图像处理函数
                for keyword in image_keywords:
                    if keyword in func_name:
                        ocr_analysis['image_processing_hints'].append({
                            'function': export['name'],
                            'address': export['address'],
                            'keyword': keyword
                        })
                        break
            
            # 分析导入的库
            imports = self.analysis_result.get('imports', [])
            for imp in imports:
                dll_name = imp['dll'].lower()
                func_name = imp['function'].lower()
                
                # 检查图像处理相关导入
                if any(keyword in dll_name for keyword in ['gdi', 'gdiplus', 'opengl', 'directx']):
                    ocr_analysis['image_processing_hints'].append({
                        'import': f"{imp['dll']}.{imp['function']}",
                        'type': 'graphics_library'
                    })
                
                # 检查数学计算相关导入
                if any(keyword in func_name for keyword in ['sqrt', 'sin', 'cos', 'atan', 'log']):
                    ocr_analysis['character_recognition_patterns'].append('mathematical_calculations')
            
            # 生成建议
            if ocr_analysis['likely_ocr_functions']:
                ocr_analysis['recommendations'].append('实现类似的OCR函数接口')
            
            if ocr_analysis['image_processing_hints']:
                ocr_analysis['recommendations'].append('集成图像预处理功能')
            
            # 检查是否有机器学习相关模式
            ml_patterns = ['train', 'model', 'neural', 'network', 'svm', 'knn']
            for export in exports:
                if any(pattern in export['name'].lower() for pattern in ml_patterns):
                    ocr_analysis['character_recognition_patterns'].append('machine_learning')
                    ocr_analysis['recommendations'].append('考虑使用机器学习模型')
                    break
            
            self.analysis_result['analysis'] = ocr_analysis
            self.logger.info(f"OCR特定分析完成")
            return ocr_analysis
            
        except Exception as e:
            self.logger.error(f"分析OCR特定信息失败: {e}")
            return ocr_analysis
    
    def generate_analysis_report(self) -> str:
        """生成分析报告"""
        try:
            report_dir = self.dll_path.parent / "analysis_reports"
            report_dir.mkdir(exist_ok=True)
            
            report_path = report_dir / f"{self.dll_path.stem}_analysis_report.md"
            
            # 执行所有分析
            self.analyze_basic_info()
            self.analyze_imports()
            self.analyze_exports()
            self.analyze_sections()
            self.analyze_resources()
            self.analyze_ocr_specific()
            
            # 生成报告内容
            report_content = [
                f"# 🔍 {self.dll_path.name} 分析报告",
                "",
                f"## 📅 分析时间: {time.strftime('%Y-%m-%d %H:%M:%S')}",
                "",
                "## 📊 基本文件信息",
                ""
            ]
            
            # 文件信息
            file_info = self.analysis_result['file_info']
            for key, value in file_info.items():
                report_content.append(f"- **{key}**: {value}")
            
            # 节区信息
            report_content.extend([
                "",
                "## 📁 节区信息",
                ""
            ])
            
            sections = self.analysis_result['sections']
            for section in sections[:10]:  # 显示前10个节区
                report_content.append(f"### {section['name']}")
                report_content.append(f"- 虚拟地址: {section['virtual_address']}")
                report_content.append(f"- 虚拟大小: {section['virtual_size']} 字节")
                report_content.append(f"- 原始大小: {section['raw_size']} 字节")
                report_content.append(f"- 熵值: {section['entropy']:.2f}")
                report_content.append("")
            
            # 导出函数（OCR相关）
            report_content.extend([
                "",
                "## 🔧 导出函数（OCR相关）",
                ""
            ])
            
            ocr_analysis = self.analysis_result['analysis']
            if ocr_analysis['likely_ocr_functions']:
                report_content.append("### 可能的OCR函数:")
                for func in ocr_analysis['likely_ocr_functions'][:20]:  # 显示前20个
                    report_content.append(f"- `{func['function']}` (地址: {func['address']})")
                report_content.append("")
            
            # 导入库
            report_content.extend([
                "",
                "## 📚 导入库",
                ""
            ])
            
            imports = self.analysis_result['imports']
            dll_counts = {}
            for imp in imports:
                dll = imp['dll']
                dll_counts[dll] = dll_counts.get(dll, 0) + 1
            
            for dll, count in sorted(dll_counts.items(), key=lambda x: x[1], reverse=True)[:10]:
                report_content.append(f"- `{dll}`: {count}个函数")
            
            # OCR分析结果
            report_content.extend([
                "",
                "## 🎯 OCR算法分析",
                ""
            ])
            
            if ocr_analysis['image_processing_hints']:
                report_content.append("### 图像处理提示:")
                for hint in ocr_analysis['image_processing_hints'][:10]:
                    if 'function' in hint:
                        report_content.append(f"- 函数: `{hint['function']}`")
                    elif 'import' in hint:
                        report_content.append(f"- 导入: `{hint['import']}`")
                report_content.append("")
            
            if ocr_analysis['character_recognition_patterns']:
                report_content.append("### 字符识别模式:")
                for pattern in ocr_analysis['character_recognition_patterns']:
                    report_content.append(f"- {pattern}")
                report_content.append("")
            
            # 开发建议
            report_content.extend([
                "",
                "## 🚀 开发建议",
                ""
            ])
            
            if ocr_analysis['recommendations']:
                for recommendation in ocr_analysis['recommendations']:
                    report_content.append(f"- ✅ {recommendation}")
            else:
                report_content.append("- 📝 需要进一步分析")
            
            report_content.extend([
                "",
                "## 📋 下一步行动",
                "",
                "1. **实现OCR函数接口** - 基于分析结果设计兼容接口",
                "2. **开发图像预处理模块** - 实现类似的图像处理功能",
                "3. **集成开源OCR库** - 使用Tesseract/EasyOCR作为后端",
                "4. **测试兼容性** - 确保功能与原DLL相当",
                "",
                "---",
                "",
                "*分析报告生成完成*"
            ])
            
            # 写入报告
            with open(report_path, 'w', encoding='utf-8') as f:
                f.write('\n'.join(report_content))
            
            self.logger.info(f"分析报告已生成: {report_path}")
            return str(report_path)
            
        except Exception as e:
            self.logger.error(f"生成分析报告失败: {e}")
            return ""
    
    def _calculate_md5(self) -> str:
        """计算MD5哈希值"""
        import hashlib
        with open(self.dll_path, 'rb') as f:
            return hashlib.md5(f.read()).hexdigest()
    
    def _get_machine_type(self) -> str:
        """获取机器类型"""
        machine_types = {
            0x014c: 'IMAGE_FILE_MACHINE_I386',
            0x8664: 'IMAGE_FILE_MACHINE_AMD64',
            0x0200: 'IMAGE_FILE_MACHINE_IA64',
        }
        return machine_types.get(self.pe.FILE_HEADER.Machine, 'UNKNOWN')
    
    def _get_timestamp(self) -> str:
        """获取时间戳"""
        import datetime
        timestamp = self.pe.FILE_HEADER.TimeDateStamp
        return datetime.datetime.fromtimestamp(timestamp).strftime('%Y-%m-%d %H:%M:%S')
    
    def _get_subsystem(self) -> str:
        """获取子系统类型"""
        subsystems = {
            1: 'IMAGE_SUBSYSTEM_NATIVE',
            2: 'IMAGE_SUBSYSTEM_WINDOWS_GUI',
            3: 'IMAGE_SUBSYSTEM_WINDOWS_CUI',
        }
        return subsystems.get(self.pe.OPTIONAL_HEADER.Subsystem, 'UNKNOWN')
    
    def _get_characteristics(self) -> List[str]:
        """获取文件特性"""
        characteristics = []
        chars = self.pe.FILE_HEADER.Characteristics
        
        char_map = {
            0x0001: 'RELOCS_STRIPPED',
            0x0002: 'EXECUTABLE_IMAGE',
            0x0004: 'LINE_NUMS_STRIPPED',
            0x0008: 'LOCAL_SYMS_STRIPPED',
            0x0010: 'AGGRESSIVE_WS_TRIM',
            0x0020: 'LARGE_ADDRESS_AWARE',
            0x0080: 'BYTES_REVERSED_LO',
            0x0100: '32BIT_MACHINE',
            0x0200: 'DEBUG_STRIPPED',
            0x0400: 'REMOVABLE_RUN_FROM_SWAP',
            0x0800: 'NET_RUN_FROM_SWAP',
            0x1000: 'SYSTEM',
            0x2000: 'DLL',
            0x4000: 'UP_SYSTEM_ONLY',
            0x8000: 'BYTES_REVERSED_HI',
        }
        
        for value, name in char_map.items():
            if chars & value:
                characteristics.append(name)
        
        return characteristics

# 导入time模块
import time

# 简单测试函数
def test_dll_analyzer():
    """测试DLL分析器"""
    print("🔍 测试DLL分析器")
    print("-" * 40)
    
    # OCR DLL路径
    ocr_dll_path = "/root/.openclaw/workspace/石器时代验证码识别工具/extracted_resources/ocr_resources/Ocr.dll"
    
    if not os.path.exists(ocr_dll_path):
        print(f"❌ OCR DLL文件不存在: {ocr_dll_path}")
        print("💡 请先运行资源提取器")
        return
    
    try:
        # 创建分析器
        analyzer = DLLAnalyzer(ocr_dll_path)
        
        # 分析基本信息
        print("📊 分析基本文件信息...")
        file_info = analyzer.analyze_basic_info()
        print(f"✅ 文件大小: {file_info.get('size', 0) / 1024 / 1024:.2f} MB")
        print(f"✅ 机器类型: {file_info.get('machine_type', '未知')}")
        
        # 分析导出函数
        print("\n🔧 分析导出函数...")
        exports = analyzer.analyze_exports()
        print(f"✅ 导出函数数: {len(exports)}")
        
        # 分析导入函数
        print("\n📚 分析导入函数...")
        imports = analyzer.analyze_imports()
        print(f"✅ 导入函数数: {len(imports)}")
        
        # 分析OCR特定信息
        print("\n🎯 分析OCR特定信息...")
        ocr_analysis = analyzer.analyze_ocr_specific()
        print(f"✅ 可能的OCR函数: {len(ocr_analysis.get('likely_ocr_functions', []))}")
        
        # 生成报告
        print("\n📊 生成分析报告...")
        report_path = analyzer.generate_analysis_report()
        if report_path:
            print(f"✅ 报告已生成: {report_path}")
        
        print("\n🎉 DLL分析完成")
        
    except Exception as e:
        print(f"❌ DLL分析失败: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    test_dll_analyzer()