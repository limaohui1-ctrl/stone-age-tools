#!/usr/bin/env python3
"""
石器时代脚本测试框架 - 图形用户界面
基于PyQt6的现代化GUI界面
"""

import os
import sys
import json
import time
import logging
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Any, Optional

# PyQt6导入
try:
    from PyQt6.QtWidgets import (
        QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
        QPushButton, QLabel, QTextEdit, QListWidget, QListWidgetItem,
        QTabWidget, QGroupBox, QLineEdit, QFileDialog, QMessageBox,
        QProgressBar, QTreeWidget, QTreeWidgetItem, QSplitter,
        QTableWidget, QTableWidgetItem, QHeaderView, QComboBox,
        QCheckBox, QSpinBox, QDoubleSpinBox, QToolBar, QStatusBar,
        QMenuBar, QMenu, QAction, QDialog, QDialogButtonBox,
        QFormLayout, QGridLayout, QScrollArea
    )
    from PyQt6.QtCore import Qt, QTimer, QThread, pyqtSignal, QSize
    from PyQt6.QtGui import QIcon, QFont, QPalette, QColor, QPixmap
    PYQT6_AVAILABLE = True
except ImportError:
    print("警告: PyQt6未安装，GUI功能不可用")
    print("安装命令: pip install PyQt6")
    PYQT6_AVAILABLE = False

# 导入测试框架
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
try:
    from 石器时代测试运行器 import StoneAgeTestRunner, TestStatus
    from 石器时代专用测试模块 import StoneAgeScriptParser
except ImportError:
    print("警告: 无法导入测试框架模块")

logger = logging.getLogger(__name__)

class TestWorker(QThread):
    """测试工作线程"""
    test_started = pyqtSignal(str)
    test_finished = pyqtSignal(dict)
    test_progress = pyqtSignal(int)
    test_log = pyqtSignal(str)
    
    def __init__(self, config_path: str):
        super().__init__()
        self.config_path = config_path
        self.runner = None
        self.results = None
    
    def run(self):
        """运行测试"""
        try:
            self.test_log.emit("🚀 开始运行测试...")
            
            # 创建测试运行器
            self.runner = StoneAgeTestRunner()
            
            # 运行测试套件
            self.test_log.emit(f"📁 加载配置: {self.config_path}")
            self.results = self.runner.run_test_suite(self.config_path)
            
            # 保存结果
            output_dir = "gui_test_results"
            output_path = self.runner.save_results(output_dir)
            
            self.test_log.emit(f"💾 结果已保存到: {output_path}")
            self.test_log.emit("✅ 测试完成!")
            
            # 发射完成信号
            self.test_finished.emit({
                "success": True,
                "results": self.results,
                "output_path": output_path
            })
            
        except Exception as e:
            self.test_log.emit(f"❌ 测试失败: {e}")
            self.test_finished.emit({
                "success": False,
                "error": str(e)
            })

class ScriptParserWorker(QThread):
    """脚本解析工作线程"""
    parsing_started = pyqtSignal(str)
    parsing_finished = pyqtSignal(dict)
    parsing_progress = pyqtSignal(int)
    
    def __init__(self, script_path: str):
        super().__init__()
        self.script_path = script_path
    
    def run(self):
        """解析脚本"""
        try:
            self.parsing_started.emit(f"📄 开始解析脚本: {self.script_path}")
            
            # 解析脚本
            parser = StoneAgeScriptParser()
            script = parser.parse_script(self.script_path)
            
            # 准备结果
            result = {
                "success": True,
                "script_info": {
                    "name": script.script_name,
                    "path": str(script.file_path),
                    "total_lines": script.total_lines,
                    "command_count": len(script.commands),
                    "function_count": len(script.functions),
                    "variable_count": len(script.variables),
                    "errors": script.errors,
                    "warnings": script.warnings
                },
                "commands": [
                    {
                        "line": cmd.line_number,
                        "command": cmd.command,
                        "type": cmd.command_type.value,
                        "parameters": cmd.parameters,
                        "comment": cmd.comment
                    }
                    for cmd in script.commands[:100]  # 只取前100个命令
                ],
                "functions": list(script.functions.keys()),
                "variables": [
                    {"name": k, "value": v}
                    for k, v in script.variables.items()
                ]
            }
            
            self.parsing_finished.emit(result)
            
        except Exception as e:
            self.parsing_finished.emit({
                "success": False,
                "error": str(e)
            })

class MainWindow(QMainWindow):
    """主窗口"""
    
    def __init__(self):
        super().__init__()
        self.test_worker = None
        self.parser_worker = None
        self.current_script = None
        self.current_config = None
        self.init_ui()
    
    def init_ui(self):
        """初始化用户界面"""
        self.setWindowTitle("石器时代脚本测试框架")
        self.setGeometry(100, 100, 1200, 800)
        
        # 设置图标
        self.setWindowIcon(self.create_icon())
        
        # 创建中心部件
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        # 主布局
        main_layout = QVBoxLayout(central_widget)
        
        # 创建标签页
        self.tab_widget = QTabWidget()
        main_layout.addWidget(self.tab_widget)
        
        # 添加标签页
        self.create_dashboard_tab()
        self.create_script_editor_tab()
        self.create_test_config_tab()
        self.create_test_runner_tab()
        self.create_results_viewer_tab()
        self.create_settings_tab()
        
        # 创建状态栏
        self.status_bar = QStatusBar()
        self.setStatusBar(self.status_bar)
        self.status_bar.showMessage("就绪")
        
        # 创建工具栏
        self.create_toolbar()
        
        # 创建菜单栏
        self.create_menubar()
    
    def create_icon(self):
        """创建应用程序图标"""
        # 创建一个简单的图标
        pixmap = QPixmap(64, 64)
        pixmap.fill(QColor(70, 130, 180))  # 钢蓝色
        return QIcon(pixmap)
    
    def create_toolbar(self):
        """创建工具栏"""
        toolbar = QToolBar("主工具栏")
        self.addToolBar(toolbar)
        
        # 打开脚本按钮
        open_script_action = QAction("📄 打开脚本", self)
        open_script_action.triggered.connect(self.open_script)
        toolbar.addAction(open_script_action)
        
        # 运行测试按钮
        run_test_action = QAction("🚀 运行测试", self)
        run_test_action.triggered.connect(self.run_tests)
        toolbar.addAction(run_test_action)
        
        toolbar.addSeparator()
        
        # 查看报告按钮
        view_report_action = QAction("📊 查看报告", self)
        view_report_action.triggered.connect(self.view_report)
        toolbar.addAction(view_report_action)
        
        # 帮助按钮
        help_action = QAction("❓ 帮助", self)
        help_action.triggered.connect(self.show_help)
        toolbar.addAction(help_action)
    
    def create_menubar(self):
        """创建菜单栏"""
        menubar = self.menuBar()
        
        # 文件菜单
        file_menu = menubar.addMenu("文件")
        
        open_script_action = QAction("打开脚本", self)
        open_script_action.triggered.connect(self.open_script)
        file_menu.addAction(open_script_action)
        
        open_config_action = QAction("打开配置", self)
        open_config_action.triggered.connect(self.open_config)
        file_menu.addAction(open_config_action)
        
        file_menu.addSeparator()
        
        exit_action = QAction("退出", self)
        exit_action.triggered.connect(self.close)
        file_menu.addAction(exit_action)
        
        # 测试菜单
        test_menu = menubar.addMenu("测试")
        
        run_test_action = QAction("运行测试", self)
        run_test_action.triggered.connect(self.run_tests)
        test_menu.addAction(run_test_action)
        
        stop_test_action = QAction("停止测试", self)
        stop_test_action.triggered.connect(self.stop_tests)
        test_menu.addAction(stop_test_action)
        
        # 视图菜单
        view_menu = menubar.addMenu("视图")
        
        refresh_action = QAction("刷新", self)
        refresh_action.triggered.connect(self.refresh_view)
        view_menu.addAction(refresh_action)
        
        # 帮助菜单
        help_menu = menubar.addMenu("帮助")
        
        about_action = QAction("关于", self)
        about_action.triggered.connect(self.show_about)
        help_menu.addAction(about_action)
    
    def create_dashboard_tab(self):
        """创建仪表板标签页"""
        dashboard_widget = QWidget()
        layout = QVBoxLayout(dashboard_widget)
        
        # 欢迎标题
        title_label = QLabel("🎮 石器时代脚本测试框架")
        title_font = QFont()
        title_font.setPointSize(24)
        title_font.setBold(True)
        title_label.setFont(title_font)
        title_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(title_label)
        
        # 副标题
        subtitle_label = QLabel("自动化测试您的石器时代脚本，确保质量和稳定性")
        subtitle_font = QFont()
        subtitle_font.setPointSize(14)
        subtitle_label.setFont(subtitle_font)
        subtitle_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(subtitle_label)
        
        layout.addSpacing(30)
        
        # 快速操作区域
        quick_actions_group = QGroupBox("🚀 快速操作")
        quick_actions_layout = QGridLayout()
        
        # 打开脚本按钮
        self.open_script_btn = QPushButton("📄 打开脚本文件")
        self.open_script_btn.clicked.connect(self.open_script)
        self.open_script_btn.setMinimumHeight(50)
        quick_actions_layout.addWidget(self.open_script_btn, 0, 0)
        
        # 运行测试按钮
        self.run_test_btn = QPushButton("🧪 运行测试")
        self.run_test_btn.clicked.connect(self.run_tests)
        self.run_test_btn.setMinimumHeight(50)
        quick_actions_layout.addWidget(self.run_test_btn, 0, 1)
        
        # 查看报告按钮
        self.view_report_btn = QPushButton("📊 查看测试报告")
        self.view_report_btn.clicked.connect(self.view_report)
        self.view_report_btn.setMinimumHeight(50)
        quick_actions_layout.addWidget(self.view_report_btn, 1, 0)
        
        # 配置管理按钮
        self.config_btn = QPushButton("⚙️ 管理测试配置")
        self.config_btn.clicked.connect(self.manage_config)
        self.config_btn.setMinimumHeight(50)
        quick_actions_layout.addWidget(self.config_btn, 1, 1)
        
        quick_actions_group.setLayout(quick_actions_layout)
        layout.addWidget(quick_actions_group)
        
        layout.addSpacing(30)
        
        # 最近文件区域
        recent_group = QGroupBox("📁 最近文件")
        recent_layout = QVBoxLayout()
        
        self.recent_list = QListWidget()
        self.recent_list.itemDoubleClicked.connect(self.open_recent_file)
        recent_layout.addWidget(self.recent_list)
        
        recent_group.setLayout(recent_layout)
        layout.addWidget(recent_group)
        
        layout.addStretch()
        
        # 状态信息
        status_group = QGroupBox("📊 系统状态")
        status_layout = QFormLayout()
        
        self.status_time_label = QLabel("就绪")
        status_layout.addRow("状态:", self.status_time_label)
        
        self.status_script_label = QLabel("未加载脚本")
        status_layout.addRow("当前脚本:", self.status_script_label)
        
        self.status_config_label = QLabel("未加载配置")
        status_layout.addRow("当前配置:", self.status_config_label)
        
        status_group.setLayout(status_layout)
        layout.addWidget(status_group)
        
        self.tab_widget.addTab(dashboard_widget, "🏠 仪表板")
    
    def create_script_editor_tab(self):
        """创建脚本编辑器标签页"""
        editor_widget = QWidget()
        layout = QVBoxLayout(editor_widget)
        
        # 工具栏
        editor_toolbar = QHBoxLayout()
        
        self.open_script_editor_btn = QPushButton("打开脚本")
        self.open_script_editor_btn.clicked.connect(self.open_script)
        editor_toolbar.addWidget(self.open_script_editor_btn)
        
        self.save_script_btn = QPushButton("保存脚本")
        self.save_script_btn.clicked.connect(self.save_script)
        editor_toolbar.addWidget(self.save_script_btn)
        
        self.parse_script_btn = QPushButton("解析脚本")
        self.parse_script_btn.clicked.connect(self.parse_current_script)
        editor_toolbar.addWidget(self.parse_script_btn)
        
        editor_toolbar.addStretch()
        
        layout.addLayout(editor_toolbar)
        
        # 分割器：左侧编辑器，右侧信息
        splitter = QSplitter(Qt.Orientation.Horizontal)
        
        # 左侧：脚本编辑器
        editor_container = QWidget()
        editor_layout = QVBoxLayout(editor_container)
        
        self.script_editor = QTextEdit()
        self.script_editor.setFont(QFont("Courier", 10))
        editor_layout.addWidget(QLabel("脚本内容:"))
        editor_layout.addWidget(self.script_editor)
        
        splitter.addWidget(editor_container)
        
        # 右侧：脚本信息
        info_container = QWidget()
        info_layout = QVBoxLayout(info_container)
        
        # 脚本信息
        info_group = QGroupBox("📋 脚本信息")
        info_form = QFormLayout()
        
        self.script_name_label = QLabel("未加载")
        info_form.addRow("脚本名称:", self.script_name_label)
        
        self.script_lines_label = QLabel("0")
        info_form.addRow("总行数:", self.script_lines_label)
        
        self.script_commands_label = QLabel("0")
        info_form.addRow("命令数量:", self.script_commands_label)
        
        self.script_functions_label = QLabel("0")
        info_form.addRow("函数数量:", self.script_functions_label)
        
        self.script_variables_label = QLabel("0")
        info_form.addRow("变量数量:", self.script_variables_label)
        
        info_group.setLayout(info_form)
        info_layout.addWidget(info_group)
        
        # 函数列表
        functions_group = QGroupBox("🔧 函数列表")
        functions_layout = QVBoxLayout()
        
        self.functions_list = QListWidget()
        functions_layout.addWidget(self.functions_list)
        
        functions_group.setLayout(functions_layout)
        info_layout.addWidget(functions_group)
        
        # 变量列表
        variables_group = QGroupBox("📊 变量列表")
        variables_layout = QVBoxLayout()
        
        self.variables_table = QTableWidget()
        self.variables_table.setColumnCount(2)
        self.variables_table.setHorizontalHeaderLabels(["变量名", "值"])
        self.variables_table.horizontalHeader().setStretchLastSection(True)
        variables_layout.addWidget(self.variables_table)
        
        variables_group.setLayout(variables_layout)
        info_layout.addWidget(variables_group)
        
        info_layout.addStretch()
        
        splitter.addWidget(info_container)
        
        # 设置分割器比例
        splitter.setSizes([800, 400])
        
        layout.addWidget(splitter)
        
        self.tab_widget.addTab(editor_widget, "📝 脚本编辑器")
    
    def create_test_config_tab(self):
        """创建测试配置标签页"""
        config_widget = QWidget()
        layout = QVBoxLayout(config_widget)
        
        # 工具栏
        config_toolbar = QHBoxLayout()
        
        self.open_config_btn = QPushButton("打开配置")
        self.open_config_btn.clicked.connect(self.open_config)
        config_toolbar.addWidget(self.open_config_btn)
        
        self.save_config_btn = QPushButton("保存配置")
        self.save_config_btn.clicked.connect(self.save_config)
        config_toolbar.addWidget(self.save_config_btn)
        
        self.new_config_btn = QPushButton("新建配置")
        self.new_config_btn.clicked.connect(self.new_config)
        config_toolbar.addWidget(self.new_config_btn)
        
        config_toolbar.addStretch()
        
        layout.addLayout(config_toolbar)
        
        # 配置编辑器
        config_editor_group = QGroupBox("📋 测试配置")
        config_editor_layout = QVBoxLayout()
        
        self.config_editor = QTextEdit()
        self.config_editor.setFont(QFont("Courier", 10))
        config_editor_layout.addWidget(self.config_editor)
        
        config_editor_group.setLayout(config_editor_layout)
        layout.addWidget(config_editor_group)
        
        # 配置预览
        config_preview_group = QGroupBox("👁️ 配置预览")
        config_preview_layout = QVBoxLayout()
        
        self.config_preview = QTextEdit()
        self.config_preview.setReadOnly(True)
        self.config_preview.setFont(QFont("Courier", 9))
        config_preview_layout.addWidget(self.config_preview)
        
        config_preview_group.setLayout(config_preview_layout)
        layout.addWidget(config_preview_group)
        
        self.tab_widget.addTab(config_widget, "⚙️ 测试配置")
    
    def create_test_runner_tab(self):
        """创建测试运行器标签页"""
        runner_widget = QWidget()
        layout = QVBoxLayout(runner_widget)
        
        # 控制区域
        control_group = QGroupBox("🎮 测试控制")
        control_layout = QVBoxLayout()
        
        # 配置选择
        config_select_layout = QHBoxLayout()
        config_select_layout.addWidget(QLabel("测试配置:"))
        
        self.config_combo = QComboBox()
        self.config_combo.addItem("选择配置文件...")
        self.config_combo.addItem("石器时代脚本测试配置.json")
        self.config_combo.addItem("custom_test_config.json")
        config_select_layout.addWidget(self.config_combo)
        
        self.browse_config_btn = QPushButton("浏览...")
        self.browse_config_btn.clicked.connect(self.browse_config)
        config_select_layout.addWidget(self.browse_config_btn)
        
        config_select_layout.addStretch()
        control_layout.addLayout(config_select_layout)
        
        # 测试选项
        options_layout = QGridLayout()
        
        self.parallel_check = QCheckBox("并行执行")
        options_layout.addWidget(self.parallel_check, 0, 0)
        
        self.stop_on_fail_check = QCheckBox("失败时停止")
        options_layout.addWidget(self.stop_on_fail_check, 0, 1)
        
        self.coverage_check = QCheckBox("启用覆盖率分析")
        self.coverage_check.setChecked(True)
        options_layout.addWidget(self.coverage_check, 1, 0)
        
        self.verbose_check = QCheckBox("详细输出")
        options_layout.addWidget(self.verbose_check, 1, 1)
        
        control_layout.addLayout(options_layout)
        
        # 运行按钮
        button_layout = QHBoxLayout()
        
        self.run_tests_btn = QPushButton("🚀 开始测试")
        self.run_tests_btn.clicked.connect(self.run_tests)
        self.run_tests_btn.setMinimumHeight(40)
        button_layout.addWidget(self.run_tests_btn)
        
        self.stop_tests_btn = QPushButton("⏹️ 停止测试")
        self.stop_tests_btn.clicked.connect(self.stop_tests)
        self.stop_tests_btn.setEnabled(False)
        self.stop_tests_btn.setMinimumHeight(40)
        button_layout.addWidget(self.stop_tests_btn)
        
        button_layout.addStretch()
        control_layout.addLayout(button_layout)
        
        control_group.setLayout(control_layout)
        layout.addWidget(control_group)
        
        # 进度区域
        progress_group = QGroupBox("📊 测试进度")
        progress_layout = QVBoxLayout()
        
        self.progress_bar = QProgressBar()
        progress_layout.addWidget(self.progress_bar)
        
        self.progress_label = QLabel("等待开始测试...")
        progress_layout.addWidget(self.progress_label)
        
        progress_group.setLayout(progress_layout)
        layout.addWidget(progress_group)
        
        # 日志区域
        log_group = QGroupBox("📝 测试日志")
        log_layout = QVBoxLayout()
        
        self.test_log = QTextEdit()
        self.test_log.setReadOnly(True)
        self.test_log.setFont(QFont("Courier", 9))
        log_layout.addWidget(self.test_log)
        
        log_group.setLayout(log_layout)
        layout.addWidget(log_group)
        
        self.tab_widget.addTab(runner_widget, "🧪 测试运行器")
    
    def create_results_viewer_tab(self):
        """创建结果查看器标签页"""
        results_widget = QWidget()
        layout = QVBoxLayout(results_widget)
        
        # 工具栏
        results_toolbar = QHBoxLayout()
        
        self.load_results_btn = QPushButton("加载结果")
        self.load_results_btn.clicked.connect(self.load_results)
        results_toolbar.addWidget(self.load_results_btn)
        
        self.export_results_btn = QPushButton("导出报告")
        self.export_results_btn.clicked.connect(self.export_results)
        results_toolbar.addWidget(self.export_results_btn)
        
        self.clear_results_btn = QPushButton("清除结果")
        self.clear_results_btn.clicked.connect(self.clear_results)
        results_toolbar.addWidget(self.clear_results_btn)
        
        results_toolbar.addStretch()
        layout.addLayout(results_toolbar)
        
        # 结果摘要
        summary_group = QGroupBox("📈 测试摘要")
        summary_layout = QGridLayout()
        
        summary_layout.addWidget(QLabel("总测试数:"), 0, 0)
        self.total_tests_label = QLabel("0")
        summary_layout.addWidget(self.total_tests_label, 0, 1)
        
        summary_layout.addWidget(QLabel("通过:"), 0, 2)
        self.passed_tests_label = QLabel("0")
        summary_layout.addWidget(self.passed_tests_label, 0, 3)
        
        summary_layout.addWidget(QLabel("失败:"), 1, 0)
        self.failed_tests_label = QLabel("0")
        summary_layout.addWidget(self.failed_tests_label, 1, 1)
        
        summary_layout.addWidget(QLabel("错误:"), 1, 2)
        self.error_tests_label = QLabel("0")
        summary_layout.addWidget(self.error_tests_label, 1, 3)
        
        summary_layout.addWidget(QLabel("通过率:"), 2, 0)
        self.pass_rate_label = QLabel("0%")
        summary_layout.addWidget(self.pass_rate_label, 2, 1)
        
        summary_layout.addWidget(QLabel("总耗时:"), 2, 2)
        self.duration_label = QLabel("0秒")
        summary_layout.addWidget(self.duration_label, 2, 3)
        
        summary_group.setLayout(summary_layout)
        layout.addWidget(summary_group)
        
        # 详细结果
        details_group = QGroupBox("📋 详细结果")
        details_layout = QVBoxLayout()
        
        self.results_table = QTableWidget()
        self.results_table.setColumnCount(6)
        self.results_table.setHorizontalHeaderLabels([
            "测试名称", "状态", "耗时", "断言通过", "断言总数", "详细信息"
        ])
        self.results_table.horizontalHeader().setStretchLastSection(True)
        details_layout.addWidget(self.results_table)
        
        details_group.setLayout(details_layout)
        layout.addWidget(details_group)
        
        # 报告预览
        report_group = QGroupBox("📄 报告预览")
        report_layout = QVBoxLayout()
        
        self.report_viewer = QTextEdit()
        self.report_viewer.setReadOnly(True)
        self.report_viewer.setFont(QFont("Courier", 9))
        report_layout.addWidget(self.report_viewer)
        
        report_group.setLayout(report_layout)
        layout.addWidget(report_group)
        
        self.tab_widget.addTab(results_widget, "📊 结果查看")
    
    def create_settings_tab(self):
        """创建设置标签页"""
        settings_widget = QWidget()
        layout = QVBoxLayout(settings_widget)
        
        # 常规设置
        general_group = QGroupBox("⚙️ 常规设置")
        general_layout = QFormLayout()
        
        self.theme_combo = QComboBox()
        self.theme_combo.addItems(["浅色主题", "深色主题", "系统主题"])
        general_layout.addRow("界面主题:", self.theme_combo)
        
        self.language_combo = QComboBox()
        self.language_combo.addItems(["简体中文", "English"])
        general_layout.addRow("语言:", self.language_combo)
        
        self.auto_save_check = QCheckBox("自动保存")
        self.auto_save_check.setChecked(True)
        general_layout.addRow("", self.auto_save_check)
        
        self.auto_update_check = QCheckBox("自动检查更新")
        general_layout.addRow("", self.auto_update_check)
        
        general_group.setLayout(general_layout)
        layout.addWidget(general_group)
        
        # 测试设置
        test_group = QGroupBox("🧪 测试设置")
        test_layout = QFormLayout()
        
        self.default_timeout_spin = QSpinBox()
        self.default_timeout_spin.setRange(10, 3600)
        self.default_timeout_spin.setValue(300)
        self.default_timeout_spin.setSuffix("秒")
        test_layout.addRow("默认超时时间:", self.default_timeout_spin)
        
        self.max_retries_spin = QSpinBox()
        self.max_retries_spin.setRange(0, 10)
        self.max_retries_spin.setValue(3)
        test_layout.addRow("最大重试次数:", self.max_retries_spin)
        
        self.log_level_combo = QComboBox()
        self.log_level_combo.addItems(["DEBUG", "INFO", "WARNING", "ERROR"])
        self.log_level_combo.setCurrentText("INFO")
        test_layout.addRow("日志级别:", self.log_level_combo)
        
        test_group.setLayout(test_layout)
        layout.addWidget(test_group)
        
        # 路径设置
        path_group = QGroupBox("📁 路径设置")
        path_layout = QFormLayout()
        
        path_layout.addRow(QLabel("脚本目录:"))
        script_path_layout = QHBoxLayout()
        self.script_dir_edit = QLineEdit()
        script_path_layout.addWidget(self.script_dir_edit)
        self.browse_script_dir_btn = QPushButton("浏览...")
        self.browse_script_dir_btn.clicked.connect(self.browse_script_dir)
        script_path_layout.addWidget(self.browse_script_dir_btn)
        path_layout.addRow(script_path_layout)
        
        path_layout.addRow(QLabel("结果目录:"))
        result_path_layout = QHBoxLayout()
        self.result_dir_edit = QLineEdit()
        self.result_dir_edit.setText("test_results")
        result_path_layout.addWidget(self.result_dir_edit)
        self.browse_result_dir_btn = QPushButton("浏览...")
        self.browse_result_dir_btn.clicked.connect(self.browse_result_dir)
        result_path_layout.addWidget(self.browse_result_dir_btn)
        path_layout.addRow(result_path_layout)
        
        path_group.setLayout(path_layout)
        layout.addWidget(path_group)
        
        # 按钮
        button_layout = QHBoxLayout()
        
        self.save_settings_btn = QPushButton("保存设置")
        self.save_settings_btn.clicked.connect(self.save_settings)
        button_layout.addWidget(self.save_settings_btn)
        
        self.reset_settings_btn = QPushButton("恢复默认")
        self.reset_settings_btn.clicked.connect(self.reset_settings)
        button_layout.addWidget(self.reset_settings_btn)
        
        button_layout.addStretch()
        layout.addLayout(button_layout)
        
        layout.addStretch()
        
        self.tab_widget.addTab(settings_widget, "⚙️ 设置")
    
    # ==================== 事件处理函数 ====================
    
    def open_script(self):
        """打开脚本文件"""
        file_path, _ = QFileDialog.getOpenFileName(
            self, "打开脚本文件", "", 
            "石器时代脚本 (*.asc *.txt);;所有文件 (*.*)"
        )
        
        if file_path:
            self.load_script(file_path)
    
    def load_script(self, file_path: str):
        """加载脚本文件"""
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
            
            self.current_script = file_path
            self.script_editor.setText(content)
            
            # 更新状态
            self.status_script_label.setText(Path(file_path).name)
            self.status_bar.showMessage(f"已加载脚本: {file_path}")
            
            # 添加到最近文件列表
            self.add_to_recent(file_path)
            
            # 自动解析脚本
            self.parse_current_script()
            
        except Exception as e:
            QMessageBox.critical(self, "错误", f"加载脚本失败: {e}")
    
    def parse_current_script(self):
        """解析当前脚本"""
        if not self.current_script:
            QMessageBox.warning(self, "警告", "请先打开一个脚本文件")
            return
        
        # 创建解析工作线程
        self.parser_worker = ScriptParserWorker(self.current_script)
        self.parser_worker.parsing_started.connect(self.on_parsing_started)
        self.parser_worker.parsing_finished.connect(self.on_parsing_finished)
        self.parser_worker.start()
    
    def on_parsing_started(self, message: str):
        """解析开始"""
        self.status_bar.showMessage(message)
    
    def on_parsing_finished(self, result: dict):
        """解析完成"""
        if result.get("success"):
            script_info = result["script_info"]
            
            # 更新脚本信息
            self.script_name_label.setText(script_info["name"])
            self.script_lines_label.setText(str(script_info["total_lines"]))
            self.script_commands_label.setText(str(script_info["command_count"]))
            self.script_functions_label.setText(str(script_info["function_count"]))
            self.script_variables_label.setText(str(script_info["variable_count"]))
            
            # 更新函数列表
            self.functions_list.clear()
            for func in result["functions"]:
                self.functions_list.addItem(func)
            
            # 更新变量表格
            variables = result["variables"]
            self.variables_table.setRowCount(len(variables))
            for i, var in enumerate(variables):
                self.variables_table.setItem(i, 0, QTableWidgetItem(var["name"]))
                self.variables_table.setItem(i, 1, QTableWidgetItem(str(var["value"])))
            
            self.status_bar.showMessage(f"脚本解析完成: {script_info['name']}")
            
        else:
            QMessageBox.warning(self, "警告", f"解析失败: {result.get('error', '未知错误')}")
    
    def save_script(self):
        """保存脚本"""
        if not self.current_script:
            QMessageBox.warning(self, "警告", "没有打开的脚本文件")
            return
        
        try:
            content = self.script_editor.toPlainText()
            with open(self.current_script, 'w', encoding='utf-8') as f:
                f.write(content)
            
            self.status_bar.showMessage(f"脚本已保存: {self.current_script}")
            
        except Exception as e:
            QMessageBox.critical(self, "错误", f"保存脚本失败: {e}")
    
    def open_config(self):
        """打开配置文件"""
        file_path, _ = QFileDialog.getOpenFileName(
            self, "打开配置文件", "", 
            "JSON文件 (*.json);;所有文件 (*.*)"
        )
        
        if file_path:
            self.load_config(file_path)
    
    def load_config(self, file_path: str):
        """加载配置文件"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            self.current_config = file_path
            self.config_editor.setText(content)
            
            # 格式化预览
            try:
                config_data = json.loads(content)
                formatted = json.dumps(config_data, ensure_ascii=False, indent=2)
                self.config_preview.setText(formatted)
            except:
                self.config_preview.setText("无法格式化JSON")
            
            # 更新状态
            self.status_config_label.setText(Path(file_path).name)
            self.status_bar.showMessage(f"已加载配置: {file_path}")
            
            # 更新配置下拉框
            config_name = Path(file_path).name
            if self.config_combo.findText(config_name) == -1:
                self.config_combo.addItem(config_name)
            self.config_combo.setCurrentText(config_name)
            
        except Exception as e:
            QMessageBox.critical(self, "错误", f"加载配置失败: {e}")
    
    def save_config(self):
        """保存配置"""
        if not self.current_config:
            QMessageBox.warning(self, "警告", "没有打开的配置文件")
            return
        
        try:
            content = self.config_editor.toPlainText()
            
            # 验证JSON格式
            json.loads(content)
            
            with open(self.current_config, 'w', encoding='utf-8') as f:
                f.write(content)
            
            self.status_bar.showMessage(f"配置已保存: {self.current_config}")
            
        except json.JSONDecodeError as e:
            QMessageBox.critical(self, "错误", f"JSON格式错误: {e}")
        except Exception as e:
            QMessageBox.critical(self, "错误", f"保存配置失败: {e}")
    
    def new_config(self):
        """新建配置"""
        file_path, _ = QFileDialog.getSaveFileName(
            self, "新建配置文件", "", 
            "JSON文件 (*.json);;所有文件 (*.*)"
        )
        
        if file_path:
            # 创建默认配置
            default_config = {
                "test_suite": {
                    "name": "新建测试套件",
                    "description": "新建的测试套件配置",
                    "version