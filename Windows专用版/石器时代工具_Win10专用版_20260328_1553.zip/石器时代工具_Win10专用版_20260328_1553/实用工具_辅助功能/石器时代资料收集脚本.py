#!/usr/bin/env python3
"""
石器时代资料收集脚本
使用web-content-fetcher技能收集石器时代相关资料
"""

import subprocess
import json
import os
import time
from datetime import datetime
from pathlib import Path

class StoneAgeDataCollector:
    def __init__(self):
        self.workspace_dir = Path("/root/.openclaw/workspace")
        self.results_dir = self.workspace_dir / "石器时代资料收集结果"
        self.results_dir.mkdir(exist_ok=True)
        
        # 石器时代相关网站列表
        self.stone_age_sites = [
            # GitHub搜索
            {
                "name": "GitHub-石器时代脚本搜索",
                "url": "https://github.com/search?q=%E7%9F%B3%E5%99%A8%E6%97%B6%E4%BB%A3+%E8%84%9A%E6%9C%AC",
                "type": "code_search",
                "priority": 1
            },
            {
                "name": "GitHub-ASSA脚本搜索",
                "url": "https://github.com/search?q=ASSA+%E8%84%9A%E6%9C%AC",
                "type": "code_search",
                "priority": 1
            },
            {
                "name": "GitHub-NG25搜索",
                "url": "https://github.com/search?q=NG25",
                "type": "code_search",
                "priority": 2
            },
            
            # 石器时代论坛和社区
            {
                "name": "17173石器时代论坛",
                "url": "https://bbs.17173.com/forum-100-1.html",
                "type": "forum",
                "priority": 2
            },
            
            # 游戏攻略网站
            {
                "name": "3DM石器时代攻略",
                "url": "https://www.3dmgame.com/games/stoneage/",
                "type": "guide",
                "priority": 3
            },
            
            # 其他可能的相关网站
            {
                "name": "百度贴吧-石器时代",
                "url": "https://tieba.baidu.com/f?kw=%E7%9F%B3%E5%99%A8%E6%97%B6%E4%BB%A3",
                "type": "forum",
                "priority": 3
            },
        ]
        
        # 抓取服务列表
        self.fetch_services = [
            "https://r.jina.ai/",
            "https://markdown.new/",
            "https://defuddle.md/"
        ]
        
        self.collection_results = []
        self.start_time = datetime.now()
    
    def fetch_with_service(self, url, service_url):
        """使用指定的抓取服务获取网页内容"""
        fetch_url = f"{service_url}{url}"
        
        print(f"  使用服务: {service_url}")
        print(f"  抓取URL: {fetch_url}")
        
        try:
            # 使用curl获取内容
            result = subprocess.run(
                ["curl", "-s", "-L", "-m", "30", fetch_url],
                capture_output=True,
                text=True,
                timeout=35
            )
            
            if result.returncode == 0:
                content = result.stdout
                
                # 检查内容是否有效
                if len(content) > 100:  # 有实际内容
                    return {
                        "success": True,
                        "content": content[:5000],  # 限制内容长度
                        "service": service_url,
                        "content_length": len(content)
                    }
                else:
                    return {
                        "success": False,
                        "error": "内容过短或无内容",
                        "service": service_url,
                        "content_length": len(content)
                    }
            else:
                return {
                    "success": False,
                    "error": f"curl错误: {result.stderr[:100]}",
                    "service": service_url
                }
                
        except subprocess.TimeoutExpired:
            return {
                "success": False,
                "error": "请求超时(30秒)",
                "service": service_url
            }
        except Exception as e:
            return {
                "success": False,
                "error": f"异常: {str(e)}",
                "service": service_url
            }
    
    def collect_site_data(self, site_info):
        """收集单个网站的数据"""
        print(f"\n{'='*60}")
        print(f"收集: {site_info['name']}")
        print(f"URL: {site_info['url']}")
        print(f"类型: {site_info['type']}")
        print(f"优先级: {site_info['priority']}")
        print(f"{'='*60}")
        
        site_result = {
            "site_info": site_info,
            "fetch_attempts": [],
            "successful_fetches": [],
            "best_result": None,
            "collected_at": datetime.now().isoformat()
        }
        
        # 尝试所有抓取服务
        for service_url in self.fetch_services:
            print(f"\n尝试服务: {service_url}")
            
            fetch_result = self.fetch_with_service(site_info['url'], service_url)
            site_result["fetch_attempts"].append(fetch_result)
            
            if fetch_result["success"]:
                print(f"  ✅ 成功获取内容 ({fetch_result['content_length']} 字符)")
                site_result["successful_fetches"].append(fetch_result)
                
                # 保存内容到文件
                safe_name = site_info['name'].replace(" ", "_").replace("-", "_")
                service_name = service_url.replace("https://", "").replace("/", "_")
                filename = f"{safe_name}_{service_name}.md"
                filepath = self.results_dir / filename
                
                with open(filepath, 'w', encoding='utf-8') as f:
                    f.write(f"# {site_info['name']}\n")
                    f.write(f"**URL**: {site_info['url']}\n")
                    f.write(f"**抓取服务**: {service_url}\n")
                    f.write(f"**抓取时间**: {datetime.now().isoformat()}\n")
                    f.write(f"**内容长度**: {fetch_result['content_length']} 字符\n")
                    f.write(f"\n{'='*60}\n\n")
                    f.write(fetch_result['content'])
                
                print(f"  内容保存: {filepath}")
                
                # 选择最佳结果（内容最长的）
                if (site_result["best_result"] is None or 
                    fetch_result["content_length"] > site_result["best_result"]["content_length"]):
                    site_result["best_result"] = fetch_result
            else:
                print(f"  ❌ 失败: {fetch_result.get('error', '未知错误')}")
            
            # 避免请求过快
            time.sleep(2)
        
        # 更新总体结果
        site_result["success"] = len(site_result["successful_fetches"]) > 0
        self.collection_results.append(site_result)
        
        # 打印总结
        print(f"\n{'='*60}")
        print(f"收集完成: {site_info['name']}")
        print(f"成功抓取: {len(site_result['successful_fetches'])}/{len(self.fetch_services)} 个服务")
        
        if site_result["success"]:
            print(f"✅ 成功获取内容")
            if site_result["best_result"]:
                print(f"最佳结果: {site_result['best_result']['service']}")
                print(f"内容长度: {site_result['best_result']['content_length']} 字符")
        else:
            print(f"❌ 所有抓取服务都失败")
        
        return site_result
    
    def analyze_content(self, content, site_info):
        """分析抓取的内容"""
        analysis = {
            "has_stone_age_keywords": False,
            "has_script_keywords": False,
            "has_ng25_keywords": False,
            "content_type": "unknown",
            "estimated_quality": "low"
        }
        
        content_lower = content.lower()
        
        # 检查关键词
        stone_age_keywords = ["石器时代", "stone age", "stoneage", "石器"]
        script_keywords = ["脚本", "script", "ass", "asc", "自动化"]
        ng25_keywords = ["ng25", "ng 25", "私服"]
        
        analysis["has_stone_age_keywords"] = any(keyword in content_lower for keyword in stone_age_keywords)
        analysis["has_script_keywords"] = any(keyword in content_lower for keyword in script_keywords)
        analysis["has_ng25_keywords"] = any(keyword in content_lower for keyword in ng25_keywords)
        
        # 判断内容类型
        if "github.com" in site_info["url"]:
            analysis["content_type"] = "code_repository"
            if analysis["has_stone_age_keywords"] and analysis["has_script_keywords"]:
                analysis["estimated_quality"] = "high"
        elif "forum" in site_info["url"] or "bbs" in site_info["url"]:
            analysis["content_type"] = "forum_discussion"
            analysis["estimated_quality"] = "medium"
        elif "guide" in site_info["type"]:
            analysis["content_type"] = "game_guide"
            analysis["estimated_quality"] = "medium"
        
        return analysis
    
    def generate_summary_report(self):
        """生成收集结果摘要报告"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        report_file = self.results_dir / f"资料收集摘要_{timestamp}.md"
        
        # 计算统计信息
        total_sites = len(self.collection_results)
        successful_sites = sum(1 for r in self.collection_results if r["success"])
        total_fetches = sum(len(r["fetch_attempts"]) for r in self.collection_results)
        successful_fetches = sum(len(r["successful_fetches"]) for r in self.collection_results)
        
        # 生成报告内容
        report_content = f"""# 石器时代资料收集报告

## 收集信息
- **开始时间**: {self.start_time.strftime('%Y-%m-%d %H:%M:%S')}
- **结束时间**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
- **收集时长**: {(datetime.now() - self.start_time).total_seconds():.1f} 秒
- **目标网站**: {total_sites} 个
- **成功收集**: {successful_sites} 个 ({successful_sites/total_sites*100:.1f}%)
- **总抓取尝试**: {total_fetches} 次
- **成功抓取**: {successful_fetches} 次 ({successful_fetches/total_fetches*100:.1f}%)

## 抓取服务使用情况
"""
        
        # 服务统计
        service_stats = {}
        for result in self.collection_results:
            for attempt in result["fetch_attempts"]:
                service = attempt["service"]
                if service not in service_stats:
                    service_stats[service] = {"total": 0, "success": 0}
                service_stats[service]["total"] += 1
                if attempt["success"]:
                    service_stats[service]["success"] += 1
        
        for service, stats in service_stats.items():
            success_rate = stats["success"] / stats["total"] * 100 if stats["total"] > 0 else 0
            report_content += f"- **{service}**: {stats['success']}/{stats['total']} 成功 ({success_rate:.1f}%)\n"
        
        report_content += f"""

## 网站收集详情

"""
        
        # 每个网站的详情
        for i, result in enumerate(self.collection_results, 1):
            site_info = result["site_info"]
            
            report_content += f"\n### {i}. {site_info['name']}\n"
            report_content += f"- **URL**: {site_info['url']}\n"
            report_content += f"- **类型**: {site_info['type']}\n"
            report_content += f"- **优先级**: {site_info['priority']}\n"
            report_content += f"- **收集状态**: {'✅ 成功' if result['success'] else '❌ 失败'}\n"
            report_content += f"- **成功抓取**: {len(result['successful_fetches'])}/{len(result['fetch_attempts'])}\n"
            
            if result["best_result"]:
                best = result["best_result"]
                report_content += f"- **最佳结果**: {best['service']}\n"
                report_content += f"- **内容长度**: {best['content_length']} 字符\n"
                
                # 内容分析
                analysis = self.analyze_content(best.get('content', ''), site_info)
                report_content += f"- **内容分析**:\n"
                report_content += f"  - 包含石器时代关键词: {'✅ 是' if analysis['has_stone_age_keywords'] else '❌ 否'}\n"
                report_content += f"  - 包含脚本关键词: {'✅ 是' if analysis['has_script_keywords'] else '❌ 否'}\n"
                report_content += f"  - 包含NG25关键词: {'✅ 是' if analysis['has_ng25_keywords'] else '❌ 否'}\n"
                report_content += f"  - 内容类型: {analysis['content_type']}\n"
                report_content += f"  - 预估质量: {analysis['estimated_quality']}\n"
            
            report_content += f"- **抓取尝试**:\n"
            for attempt in result["fetch_attempts"]:
                status = "✅ 成功" if attempt["success"] else f"❌ 失败 ({attempt.get('error', '未知错误')})"
                report_content += f"  - {attempt['service']}: {status}\n"
        
        report_content += f"""

## 收集的文件

所有收集的内容已保存到以下文件:

```
{self.results_dir}/
"""
        
        # 列出所有生成的文件
        for filepath in self.results_dir.glob("*.md"):
            if filepath.name.startswith("资料收集摘要_"):
                continue
            file_size = filepath.stat().st_size
            report_content += f"- {filepath.name} ({file_size} 字节)\n"
        
        report_content += f"```\n"

        report_content += f"""
## 关键发现

### 1. 网站可访问性
"""
        
        # 分析可访问性
        accessible_by_type = {}
        for result in self.collection_results:
            site_type = result["site_info"]["type"]
            if site_type not in accessible_by_type:
                accessible_by_type[site_type] = {"total": 0, "success": 0}
            accessible_by_type[site_type]["total"] += 1
            if result["success"]:
                accessible_by_type[site_type]["success"] += 1
        
        for site_type, stats in accessible_by_type.items():
            success_rate = stats["success"] / stats["total"] * 100 if stats["total"] > 0 else 0
            report_content += f"- **{site_type}**: {stats['success']}/{stats['total']} 可访问 ({success_rate:.1f}%)\n"
        
        report_content += f"""
### 2. 内容质量分析
"""
        
        # 分析内容质量
        high_quality_sites = []
        medium_quality_sites = []
        low_quality_sites = []
        
        for result in self.collection_results:
            if result["best_result"]:
                analysis = self.analyze_content(result["best_result"].get('content', ''), result["site_info"])
                if analysis["estimated_quality"] == "high":
                    high_quality_sites.append(result["site_info"]["name"])
                elif analysis["estimated_quality"] == "medium":
                    medium_quality_sites.append(result["site_info"]["name"])
                else:
                    low_quality_sites.append(result["site_info"]["name"])
        
        report_content += f"- **高质量网站** ({len(high_quality_sites)}个): {', '.join(high_quality_sites) if high_quality_sites else '无'}\n"
        report_content += f"- **中等质量网站** ({len(medium_quality_sites)}个): {', '.join(medium_quality_sites) if medium_quality_sites else '无'}\n"
        report_content += f"- **低质量网站** ({len(low_quality_sites)}个): {', '.join(low_quality_sites) if low_quality_sites else '无'}\n"
        
        report_content += f"""
### 3. 抓取服务效果
"""
        
        # 推荐最佳服务
        best_service = None
        best_success_rate = 0
        
        for service, stats in service_stats.items():
            success_rate = stats["success"] / stats["total"] * 100 if stats["total"] > 0 else 0
            if success_rate > best_success_rate:
                best_success_rate = success_rate
                best_service = service
        
        report_content += f"- **最佳抓取服务**: {best_service} ({best_success_rate:.1f}% 成功率)\n"
        report_content += f"- **推荐使用**: 对于石器时代资料收集，建议优先使用 {best_service}\n"
        
        report_content += f"""

## 下一步建议

### 立即行动
1. **分析高质量内容**: 仔细分析 {', '.join(high_quality_sites[:3]) if high_quality_sites else '收集到的内容'} 中的有用信息
2. **建立知识库**: 将有用信息整理到石器时代知识库中
3. **扩展搜索范围**: 基于现有结果，搜索更多相关网站

### 短期计划
1. **深度分析GitHub代码**: 分析GitHub上的石器时代相关代码仓库
2. **建立脚本库**: 收集和整理ASSA脚本文件
3. **开发分析工具**: 开发专门的石器时代资料分析工具

### 长期规划
1. **智能推荐系统**: 基于收集的资料建立智能推荐系统
2. **社区建设**: 建立石器时代玩家社区工具
3. **持续改进**: 建立持续的资料收集和更新机制

## 总结

本次资料收集工作完成了对多个石器时代相关网站的测试和内容抓取，获得了宝贵的第一手资料。基于收集结果，可以开始实质性知识库建设工作。

---

**报告生成时间**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
**报告文件**: {report_file}
"""

        # 保存报告
        with open(report_file, 'w', encoding='utf-8') as f:
            f.write(report_content)
        
        print(f"\n{'='*60}")
        print(f"✅ 资料收集完成!")
        print(f"✅ 摘要报告保存: {report_file}")
        
        return report_file