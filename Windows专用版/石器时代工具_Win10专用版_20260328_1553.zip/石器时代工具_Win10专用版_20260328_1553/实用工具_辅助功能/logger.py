"""
日志系统模块

提供统一的日志记录功能，基于loguru库。
"""

import sys
from pathlib import Path
from typing import Optional, Dict, Any
from loguru import logger

from .config import get_config


class Logger:
    """日志管理器"""
    
    def __init__(self, name: str = "stoneage_client", config_path: Optional[str] = None):
        """
        初始化日志管理器
        
        Args:
            name: 日志器名称
            config_path: 配置文件路径
        """
        self.name = name
        self.config = get_config(config_path)
        self._setup_logger()
    
    def _setup_logger(self):
        """设置日志器"""
        # 移除默认的处理器
        logger.remove()
        
        # 控制台处理器
        console_format = self.config.logging.console_format
        logger.add(
            sys.stderr,
            format=console_format,
            level=self.config.logging.console_level,
            colorize=True,
            backtrace=True,
            diagnose=self.config.debug_mode
        )
        
        # 文件处理器
        log_file = Path(self.config.logging.log_file)
        log_file.parent.mkdir(parents=True, exist_ok=True)
        
        file_format = self.config.logging.log_format
        logger.add(
            str(log_file),
            format=file_format,
            level=self.config.logging.file_level,
            rotation=f"{self.config.logging.max_file_size} MB",
            retention=f"{self.config.logging.backup_count} days",
            compression="zip",
            backtrace=True,
            diagnose=self.config.debug_mode
        )
        
        # 设置全局日志级别
        logger.level(self.config.logging.log_level)
    
    def get_logger(self):
        """获取日志器实例"""
        return logger.bind(name=self.name)
    
    # ==================== 日志方法 ====================
    
    def debug(self, message: str, **kwargs):
        """调试日志"""
        self.get_logger().debug(message, **kwargs)
    
    def info(self, message: str, **kwargs):
        """信息日志"""
        self.get_logger().info(message, **kwargs)
    
    def warning(self, message: str, **kwargs):
        """警告日志"""
        self.get_logger().warning(message, **kwargs)
    
    def error(self, message: str, **kwargs):
        """错误日志"""
        self.get_logger().error(message, **kwargs)
    
    def critical(self, message: str, **kwargs):
        """严重错误日志"""
        self.get_logger().critical(message, **kwargs)
    
    def exception(self, message: str, exc: Exception, **kwargs):
        """异常日志"""
        self.get_logger().exception(f"{message}: {exc}", **kwargs)
    
    # ==================== 特定场景日志 ====================
    
    def window_event(self, event: str, window_info: Dict[str, Any], **kwargs):
        """窗口事件日志"""
        title = window_info.get('title', '未知')
        hwnd = window_info.get('hwnd', '未知')
        self.info(f"窗口事件 [{event}]: {title} (HWND: {hwnd})", **kwargs)
    
    def process_event(self, event: str, process_info: Dict[str, Any], **kwargs):
        """进程事件日志"""
        name = process_info.get('name', '未知')
        pid = process_info.get('pid', '未知')
        self.info(f"进程事件 [{event}]: {name} (PID: {pid})", **kwargs)
    
    def memory_event(self, event: str, address: str, value: Any, **kwargs):
        """内存事件日志"""
        self.debug(f"内存事件 [{event}]: 地址 {address} = {value}", **kwargs)
    
    def automation_event(self, event: str, action: str, details: str = "", **kwargs):
        """自动化事件日志"""
        if details:
            self.info(f"自动化事件 [{event}]: {action} - {details}", **kwargs)
        else:
            self.info(f"自动化事件 [{event}]: {action}", **kwargs)
    
    def integration_event(self, event: str, component: str, details: str = "", **kwargs):
        """集成事件日志"""
        if details:
            self.info(f"集成事件 [{event}]: {component} - {details}", **kwargs)
        else:
            self.info(f"集成事件 [{event}]: {component}", **kwargs)
    
    # ==================== 性能日志 ====================
    
    def performance_start(self, operation: str, **kwargs):
        """开始性能计时"""
        import time
        start_time = time.time()
        self.debug(f"性能开始: {operation}", **kwargs)
        return start_time
    
    def performance_end(self, operation: str, start_time: float, threshold: float = 1.0, **kwargs):
        """结束性能计时并记录"""
        import time
        elapsed = time.time() - start_time
        if elapsed > threshold:
            self.warning(f"性能警告: {operation} 耗时 {elapsed:.3f}秒 (阈值: {threshold}秒)", **kwargs)
        else:
            self.debug(f"性能结束: {operation} 耗时 {elapsed:.3f}秒", **kwargs)
        return elapsed
    
    # ==================== 工具方法 ====================
    
    def with_context(self, context: str):
        """
        创建带上下文的日志器
        
        Args:
            context: 上下文名称
            
        Returns:
            带上下文的日志器
        """
        return self.get_logger().bind(context=context)
    
    def create_sublogger(self, subname: str):
        """
        创建子日志器
        
        Args:
            subname: 子日志器名称
            
        Returns:
            子日志器实例
        """
        return Logger(f"{self.name}.{subname}")
    
    # ==================== 静态方法 ====================
    
    @staticmethod
    def get_default():
        """获取默认日志器"""
        return Logger()
    
    @staticmethod
    def setup_global_logging(config_path: Optional[str] = None):
        """设置全局日志配置"""
        logger_instance = Logger(config_path=config_path)
        return logger_instance.get_logger()


# 全局日志器实例
_global_logger: Optional[Logger] = None


def get_logger(name: str = "stoneage_client", config_path: Optional[str] = None) -> Logger:
    """
    获取日志器实例（单例模式）
    
    Args:
        name: 日志器名称
        config_path: 配置文件路径
        
    Returns:
        日志器实例
    """
    global _global_logger
    
    if _global_logger is None:
        _global_logger = Logger(name, config_path)
    
    return _global_logger


def setup_logging(config_path: Optional[str] = None):
    """设置全局日志"""
    global _global_logger
    _global_logger = Logger(config_path=config_path)
    return _global_logger


# 简化导入
log = get_logger()


# 装饰器
def log_function_call(level: str = "DEBUG"):
    """
    记录函数调用的装饰器
    
    Args:
        level: 日志级别
    """
    def decorator(func):
        def wrapper(*args, **kwargs):
            func_name = func.__name__
            module_name = func.__module__
            
            # 记录开始
            log_msg = f"调用函数: {module_name}.{func_name}"
            if args:
                log_msg += f" 参数: {args}"
            if kwargs:
                log_msg += f" 关键字参数: {kwargs}"
            
            getattr(log, level.lower())(log_msg)
            
            try:
                # 执行函数
                result = func(*args, **kwargs)
                
                # 记录结果
                log_msg = f"函数返回: {module_name}.{func_name}"
                if result is not None:
                    # 避免记录过大的结果
                    result_str = str(result)
                    if len(result_str) > 100:
                        result_str = result_str[:100] + "..."
                    log_msg += f" 结果: {result_str}"
                
                getattr(log, level.lower())(log_msg)
                return result
            
            except Exception as e:
                # 记录异常
                log.exception(f"函数异常: {module_name}.{func_name}", e)
                raise
        
        return wrapper
    return decorator


def log_performance(threshold: float = 1.0):
    """
    记录性能的装饰器
    
    Args:
        threshold: 警告阈值（秒）
    """
    def decorator(func):
        def wrapper(*args, **kwargs):
            func_name = func.__name__
            start_time = log.performance_start(func_name)
            
            try:
                result = func(*args, **kwargs)
                log.performance_end(func_name, start_time, threshold)
                return result
            
            except Exception as e:
                log.performance_end(func_name, start_time, threshold)
                raise
        
        return wrapper
    return decorator