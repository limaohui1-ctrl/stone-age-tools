#!/usr/bin/env python3
"""
石器时代脚本开发交互式学习助手
提供交互式学习体验和练习
"""

import os
import sys
import json
from pathlib import Path

class InteractiveLearningAssistant:
    def __init__(self):
        self.base_dir = Path("/root/.openclaw/workspace/石器时代知识库")
        self.learning_dir = self.base_dir / "学习资料"
        self.examples_dir = self.base_dir / "开发工具链" / "示例"
        
        # 学习进度文件
        self.progress_file = self.learning_dir / "学习进度.json"
        self.progress = self.load_progress()
        
        # 学习模块
        self.modules = {
            "1": {"name": "ASSA脚本基础", "file": "ASSA脚本基础教程.md"},
            "2": {"name": "实践练习", "file": "脚本开发实践练习.md"},
            "3": {"name": "学习路径", "file": "学习路径指南.md"},
            "4": {"name": "网络优化", "file": "../优化框架/工具/简单副本优化器.py"},
            "5": {"name": "NG25适配", "file": "../优化框架/工具/快速NG25验证.py"}
        }
        
        # 练习题目
        self.exercises = self.load_exercises()
    
    def load_progress(self):
        """加载学习进度"""
        if self.progress_file.exists():
            with open(self.progress_file, 'r', encoding='utf-8') as f:
                return json.load(f)
        
        # 默认进度
        default_progress = {
            "current_module": "1",
            "completed_modules": [],
            "completed_exercises": [],
            "scores": {},
            "start_date": "",
            "last_study_date": "",
            "total_study_time": 0
        }
        
        # 保存默认进度
        with open(self.progress_file, 'w', encoding='utf-8') as f:
            json.dump(default_progress, f, ensure_ascii=False, indent=2)
        
        return default_progress
    
    def save_progress(self):
        """保存学习进度"""
        with open(self.progress_file, 'w', encoding='utf-8') as f:
            json.dump(self.progress, f, ensure_ascii=False, indent=2)
    
    def load_exercises(self):
        """加载练习题目"""
        exercises = {
            "基础练习": [
                {
                    "id": "ex1-1",
                    "title": "第一个脚本",
                    "description": "编写一个输出'Hello World'的脚本",
                    "difficulty": "简单",
                    "hint": "使用log指令输出文本",
                    "solution": "label start\n    log Hello World\n    stop"
                },
                {
                    "id": "ex1-2",
                    "title": "简单移动",
                    "description": "编写一个从(50,50)移动到(100,100)的脚本",
                    "difficulty": "简单",
                    "hint": "使用walkpos和waitpos指令",
                    "solution": "label start\n    walkpos 50, 50\n    waitpos 50, 50, 5000\n    walkpos 100, 100\n    waitpos 100, 100, 5000\n    stop"
                },
                {
                    "id": "ex1-3",
                    "title": "变量使用",
                    "description": "编写一个使用变量计数的脚本",
                    "difficulty": "简单",
                    "hint": "使用set定义变量，inc增加变量",
                    "solution": "label start\n    set 计数 0\n    inc 计数\n    log 当前计数: {计数}\n    stop"
                }
            ],
            "进阶练习": [
                {
                    "id": "ex2-1",
                    "title": "NPC对话",
                    "description": "编写一个与NPC对话并选择选项的脚本",
                    "difficulty": "中等",
                    "hint": "使用dlg、waitdlg和button指令",
                    "solution": "label start\n    dlg 商人\n    waitdlg 商人, 5000\n    button 1\n    stop"
                },
                {
                    "id": "ex2-2",
                    "title": "简单战斗",
                    "description": "编写一个自动攻击怪物的脚本",
                    "difficulty": "中等",
                    "hint": "使用attack指令和战斗状态判断",
                    "solution": "label start\n    attack 怪物\n    wait 2000\n    stop"
                },
                {
                    "id": "ex2-3",
                    "title": "物品检查",
                    "description": "编写一个检查物品数量的脚本",
                    "difficulty": "中等",
                    "hint": "使用ifitem指令",
                    "solution": "label start\n    ifitem 石头, >, 10, 有足够石头\n    log 石头不足\n    goto 结束\nlabel 有足够石头\n    log 石头充足\nlabel 结束\n    stop"
                }
            ],
            "高级练习": [
                {
                    "id": "ex3-1",
                    "title": "完整任务",
                    "description": "编写一个完整的送货任务脚本",
                    "difficulty": "困难",
                    "hint": "使用函数封装各个步骤",
                    "solution": "function 接任务\n    // 接任务逻辑\n    ret\n\nfunction 取货物\n    // 取货物逻辑\n    ret\n\nlabel start\n    call 接任务\n    call 取货物\n    stop"
                },
                {
                    "id": "ex3-2",
                    "title": "网络优化",
                    "description": "为现有脚本添加网络优化",
                    "difficulty": "困难",
                    "hint": "添加超时和重试机制",
                    "solution": "function waitdlg_safe(npc)\n    waitdlg npc, 10000\n    ret"
                },
                {
                    "id": "ex3-3",
                    "title": "错误处理",
                    "description": "为脚本添加完整的错误处理",
                    "difficulty": "困难",
                    "hint": "添加错误标签和恢复逻辑",
                    "solution": "label 错误处理\n    log 发生错误\n    wait 2000\n    goto 开始"
                }
            ]
        }
        
        return exercises
    
    def show_welcome(self):
        """显示欢迎界面"""
        print("=" * 60)
        print("🎮 石器时代脚本开发交互式学习助手")
        print("=" * 60)
        print(f"👤 当前学习进度: {len(self.progress['completed_modules'])}/{len(self.modules)} 个模块")
        print(f"📊 完成练习: {len(self.progress['completed_exercises'])} 个")
        print("=" * 60)
    
    def show_main_menu(self):
        """显示主菜单"""
        print("\n📚 主菜单")
        print("1. 📖 学习教程")
        print("2. 🏋️ 练习题目")
        print("3. 📊 学习进度")
        print("4. 🛠️ 开发工具")
        print("5. 🎯 学习建议")
        print("6. 🚪 退出")
        
        choice = input("\n请选择 (1-6): ").strip()
        return choice
    
    def show_tutorials_menu(self):
        """显示教程菜单"""
        print("\n📖 学习教程")
        for key, module in self.modules.items():
            status = "✅" if key in self.progress["completed_modules"] else "📝"
            print(f"{key}. {status} {module['name']}")
        
        print("0. 返回主菜单")
        
        choice = input("\n请选择教程编号: ").strip()
        if choice == "0":
            return
        
        if choice in self.modules:
            self.study_module(choice)
        else:
            print("❌ 无效的选择")
    
    def study_module(self, module_id):
        """学习指定模块"""
        module = self.modules[module_id]
        print(f"\n📚 开始学习: {module['name']}")
        print("-" * 40)
        
        # 读取教程内容
        module_path = self.learning_dir / module["file"]
        if not module_path.exists():
            # 尝试其他路径
            module_path = self.base_dir / module["file"]
        
        if module_path.exists():
            with open(module_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # 显示前200个字符作为预览
            preview = content[:200] + "..." if len(content) > 200 else content
            print(f"📄 内容预览:\n{preview}\n")
            
            # 询问是否查看完整内容
            view_full = input("是否查看完整内容? (y/n): ").strip().lower()
            if view_full == 'y':
                print("\n" + "=" * 60)
                print(content)
                print("=" * 60)
            
            # 标记为完成
            if module_id not in self.progress["completed_modules"]:
                self.progress["completed_modules"].append(module_id)
                self.progress["current_module"] = str(int(module_id) + 1) if int(module_id) < len(self.modules) else module_id
                self.save_progress()
                print(f"✅ 已完成学习: {module['name']}")
        else:
            print(f"❌ 教程文件不存在: {module_path}")
        
        input("\n按Enter键继续...")
    
    def show_exercises_menu(self):
        """显示练习菜单"""
        print("\n🏋️ 练习题目")
        print("1. 基础练习 (3题)")
        print("2. 进阶练习 (3题)")
        print("3. 高级练习 (3题)")
        print("4. 随机练习")
        print("0. 返回主菜单")
        
        choice = input("\n请选择练习类型: ").strip()
        
        if choice == "0":
            return
        elif choice in ["1", "2", "3"]:
            category = ["基础练习", "进阶练习", "高级练习"][int(choice) - 1]
            self.show_category_exercises(category)
        elif choice == "4":
            self.show_random_exercise()
        else:
            print("❌ 无效的选择")
    
    def show_category_exercises(self, category):
        """显示指定分类的练习"""
        exercises = self.exercises[category]
        print(f"\n{category}")
        print("-" * 40)
        
        for i, exercise in enumerate(exercises, 1):
            status = "✅" if exercise["id"] in self.progress["completed_exercises"] else "📝"
            print(f"{i}. {status} {exercise['title']} ({exercise['difficulty']})")
        
        print("0. 返回练习菜单")
        
        choice = input("\n请选择题目编号: ").strip()
        if choice == "0":
            return
        
        try:
            exercise_index = int(choice) - 1
            if 0 <= exercise_index < len(exercises):
                self.do_exercise(exercises[exercise_index])
            else:
                print("❌ 无效的题目编号")
        except ValueError:
            print("❌ 请输入数字")
    
    def show_random_exercise(self):
        """显示随机练习"""
        import random
        
        # 随机选择一个分类
        category = random.choice(list(self.exercises.keys()))
        exercises = self.exercises[category]
        
        # 随机选择一个题目
        exercise = random.choice(exercises)
        
        print(f"\n🎲 随机练习: {category}")
        print("-" * 40)
        self.do_exercise(exercise)
    
    def do_exercise(self, exercise):
        """做练习题目"""
        print(f"\n📝 题目: {exercise['title']}")
        print(f"📋 描述: {exercise['description']}")
        print(f"⭐ 难度: {exercise['difficulty']}")
        print("-" * 40)
        
        # 显示提示
        show_hint = input("是否需要提示? (y/n): ").strip().lower()
        if show_hint == 'y':
            print(f"💡 提示: {exercise['hint']}")
        
        print("\n请编写你的解决方案:")
        print("(输入 'solution' 查看参考答案，'skip' 跳过)")
        
        user_solution = ""
        while True:
            line = input("> ")
            if line.lower() == 'solution':
                print(f"\n📚 参考答案:\n{exercise['solution']}")
                break
            elif line.lower() == 'skip':
                print("⏭️ 跳过此题")
                break
            elif line.lower() == 'done':
                # 检查解决方案
                self.check_solution(exercise, user_solution)
                break
            else:
                user_solution += line + "\n"
        
        # 标记为完成
        if exercise["id"] not in self.progress["completed_exercises"]:
            self.progress["completed_exercises"].append(exercise["id"])
            self.save_progress()
        
        input("\n按Enter键继续...")
    
    def check_solution(self, exercise, user_solution):
        """检查解决方案"""
        print("\n🔍 检查你的解决方案...")
        
        # 简单的检查逻辑
        required_keywords = {
            "第一个脚本": ["log"],
            "简单移动": ["walkpos", "waitpos"],
            "变量使用": ["set", "inc"],
            "NPC对话": ["dlg", "waitdlg", "button"],
            "简单战斗": ["attack"],
            "物品检查": ["ifitem"],
            "完整任务": ["function", "call"],
            "网络优化": ["waitdlg", "10000"],
            "错误处理": ["label", "错误"]
        }
        
        title = exercise["title"]
        if title in required_keywords:
            keywords = required_keywords[title]
            missing = []
            for keyword in keywords:
                if keyword not in user_solution:
                    missing.append(keyword)
            
            if missing:
                print(f"⚠️ 缺少关键指令: {', '.join(missing)}")
            else:
                print("✅ 解决方案基本正确！")
        else:
            print("ℹ️ 无法自动检查，请参考参考答案")
    
    def show_progress(self):
        """显示学习进度"""
        print("\n📊 学习进度")
        print("=" * 40)
        
        # 模块进度
        completed = len(self.progress["completed_modules"])
        total = len(self.modules)
        percentage = (completed / total * 100) if total > 0 else 0
        
        print(f"📚 教程进度: {completed}/{total} ({percentage:.1f}%)")
        for key, module in self.modules.items():
            status = "✅ 已完成" if key in self.progress["completed_modules"] else "📝 未完成"
            print(f"  {key}. {module['name']} - {status}")
        
        # 练习进度
        completed_ex = len(self.progress["completed_exercises"])
        total_ex = sum(len(ex_list) for ex_list in self.exercises.values())
        percentage_ex = (completed_ex / total_ex * 100) if total_ex > 0 else 0
        
        print(f"\n🏋️ 练习进度: {completed_ex}/{total_ex} ({percentage_ex:.1f}%)")
        
        # 学习时间
        if self.progress["total_study_time"] > 0:
            hours = self.progress["total_study_time"] / 60
            print(f"⏰ 总学习时间: {hours:.1f} 小时")
        
        input("\n按Enter键继续...")
    
    def show_tools_menu(self):
        """显示开发工具菜单"""
        print("\n🛠️ 开发工具")
        print("1. 脚本开发助手")
        print("2. 脚本测试框架")
        print("3. 知识库管理器")
        print("4. 优化工具")
        print("0. 返回主菜单")
        
        choice = input("\n请选择工具: ").strip()
        
        if choice == "0":
            return
        elif choice == "1":
            self.run_tool("脚本开发助手")
        elif choice == "2":
            self.run_tool("脚本测试框架")
        elif choice == "3":
            self.run_tool("知识库管理器")
        elif choice == "4":
            self.show_optimization_tools()
        else:
            print("❌ 无效的选择")
    
    def run_tool(self, tool_name):
        """运行开发工具"""
        print(f"\n🚀 运行 {tool_name}...")
        
        tool_paths = {
            "脚本开发助手": self.base_dir / "开发工具链" / "脚本开发助手.py",
            "脚本测试框架": self.base_dir / "开发工具链" / "脚本测试框架.py",
            "知识库管理器": self.base_dir / "知识库管理器.py"
        }
        
        if tool_name in tool_paths:
            tool_path = tool_paths[tool_name]
            if tool_path.exists():
                print(f"📁 工具位置: {tool_path}")
                print("💡 提示: 请在新终端中运行此工具")
                print(f"命令: python3 {tool_path}")
            else:
                print(f"❌ 工具文件不存在: {tool_path}")
        else:
            print(f"❌ 未知工具: {tool_name}")
        
        input("\n按Enter键继续...")
    
    def show_optimization_tools(self):
        """显示优化工具"""
        print("\n⚡ 优化工具")
        print("1. 简单副本优化器")
        print("2. NG25名称验证工具")
        print("3. 快速NG25验证")
        print("0. 返回工具菜单")
        
        choice = input("\n请选择优化工具: ").strip()
        
        if choice == "0":
            return
        
        tool_names = {
            "1": "简单副本优化器.py",
            "2": "NG25名称验证工具.py",
            "3": "快速NG25验证.py"
        }
        
        if choice in tool_names:
            tool_file = tool_names[choice]
            tool_path = self.base_dir / "优化框架" / "工具" / tool_file
            
            if tool_path.exists():
                print(f"📁 工具位置: {tool_path}")
                print("💡 提示: 请在新终端中运行此工具")
                print(f"命令: python3 {tool_path}")
            else:
                print(f"❌ 工具文件不存在: {tool_path}")
        else:
            print("❌ 无效的选择")
        
        input("\n按Enter键继续...")
    
    def show_learning_advice(self):
        """显示学习建议"""
        print("\n🎯 学习建议")
        print("=" * 40)
        
        # 根据进度给出建议
        completed_modules = len(self.progress["completed_modules"])
        completed_exercises = len(self.progress["completed_exercises"])
        
        if completed_modules == 0:
            print("📚 建议从基础教程开始学习:")
            print("  1. 学习'ASSA脚本基础'教程")
            print("  2. 完成基础练习题目")
            print("  3. 编写第一个简单脚本")
        elif completed_modules < 3:
            print("🚀 你已经掌握基础，建议继续学习:")
            print("  1. 学习'实践练习'教程")
            print("  2. 尝试进阶练习题目")
            print("  3. 开发实际可用的脚本")
        elif completed_modules < 5:
            print("💪 你已经有一定基础，建议深入学习:")
            print("  1. 学习网络优化技巧")
            print("  2. 掌握NG25适配方法")
            print("  3. 使用开发工具提高效率")
        else:
            print("🏆 你已经掌握核心技能，建议:")
            print("  1. 参与实际项目开发")
            print("  2. 分享你的学习经验")
            print("  3. 帮助其他学习者")
        
        # 具体建议
        print("\n📅 每日学习计划建议:")
        print("  上午: 学习新知识 (1-2小时)")
        print("  下午: 实践练习 (2-3小时)")
        print("  晚上: 总结和复习 (1小时)")
        
        print("\n💡 学习技巧:")
        print("  1. 理论与实践结合")
        print("  2. 遇到问题先自己解决")
        print("  3. 多写代码多练习")
        print("  4. 参与社区交流")
        
        input("\n按Enter键继续...")
    
    def run(self):
        """运行学习助手"""
        self.show_welcome()
        
        while True:
            choice = self.show_main_menu()
            
            if choice == "1":
                self.show_tutorials_menu()
            elif choice == "2":
                self.show_exercises_menu()
            elif choice == "3":
                self.show_progress()
            elif choice == "4":
                self.show_tools_menu()
            elif choice == "5":
                self.show_learning_advice()
            elif choice == "6":
                print("\n👋 感谢使用，再见！")
                break
            else:
                print("❌ 无效的选择，请重新输入")

def main():
    """主函数"""
    assistant = InteractiveLearningAssistant()
    assistant.run()

if __name__ == "__main__":
    main()